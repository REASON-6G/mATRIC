# -*- coding: utf-8 - *-

from typing import Dict
from abc import (
    ABC,
    abstractmethod
)


class AbstractThreadPool(ABC):
    """
    Abstract Thread Pool
    ====================
    """

    def __init__(self, config: Dict = None):
        pass

    @abstractmethod
    def config(self, config: Dict) -> bool:
        """Configures the threadpool"""
        pass

    @abstractmethod
    def get_config(self) -> dict:
        """Getter for the threadpool config"""
        pass

    def get_pool_size(self) -> int:
        """Returns the maximum number of threads in the threadpool."""
        pass

    @abstractmethod
    def start(self, tasks: list) -> None:
        """Starts the threadpool."""
        pass

    @abstractmethod
    def shutdown(self) -> None:
        """Closes the thread pool."""
        pass
