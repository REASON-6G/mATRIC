# -*- coding: utf-8 -*-

from abc import (
    ABC,
    abstractmethod
)

from typing import (
    Any,
    Dict
)


class AbstractProcessor(ABC):
    """
    Abstract Processor
    ==================
    """

    def __init__(self, config: Dict = None):
        """Abstract processor class constructor."""
        pass

    @abstractmethod
    def init(self) -> bool:
        pass

    @abstractmethod
    def process(self) -> None:
        pass

    @abstractmethod
    def _process(self, message: Any) -> Any:
        pass

    @abstractmethod
    def finish(self) -> bool:
        pass
