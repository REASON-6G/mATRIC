# -*- coding: utf-8 -*-

from abc import (
    ABC,
    abstractmethod
)

from typing import Dict


class AbstractScheduler(ABC):
    """
    Abstract Scheduler
    ==================
    """

    def __init__(self, config: Dict = None):
        """Abstract processor class constructor."""
        pass

    @abstractmethod
    def config(self, config: Dict) -> bool:
        pass

    @abstractmethod
    def get_config(self) -> Dict:
        pass

    @abstractmethod
    def register(self) -> bool:
        pass

    @abstractmethod
    def unregister(self) -> bool:
        pass

    @abstractmethod
    def schedule_one(self) -> Dict:
        pass

    @abstractmethod
    def schedule(self) -> Dict:
        pass
