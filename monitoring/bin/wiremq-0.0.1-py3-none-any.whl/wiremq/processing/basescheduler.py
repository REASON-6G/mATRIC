# -*- coding: utf-8 -*-

import uuid
from typing import Dict
import logging
from wiremq.processing import abstractscheduler


class BaseScheduler(abstractscheduler.AbstractScheduler):
    """
    Base Scheduler
    ==============

    The base Scheduler class defines the basic structure for all schedulers
    implemented in wiremq. The scheduler is configured and its components are
    registered to the Scheduler object.

    Attributes
    ----------
    _id: str
        Unique identifier of the scheduler.
    _config: dict
        Configuration of the scheduler.
    _worker_map: dict
        Worker map dictionary.
        worker: object
            Worker object.
        config: dict
            Worker configuration dictionary.
    _log: object
        Python logging instance.

    Methods
    -------
    _generate_id(): str
        Generates a unique id.
    get_id(): str
        Returns the id of the scheduler.
    config(): bool
        Configures the scheduler.
    get_config(): dict
        Returns the configuration of the scheduler.
    register(): bool
        Registers components of scheduler.
    unregister(): bool
        Unregisters components and configuration from the scheduler.
    schedule_one(): bool
        Schedules one task for execution.
    schedule(): bool
        Schedules all tasks for execution.
    format_receipt(): bool
        Helper method formatting receipts.
    """

    def __init__(self, config: Dict = None):
        """Base processor class constructor.

        config: dict
            name: str
                Name of the scheduler.
            type: str
                Type of scheduler.
            id: str
                Identification string of scheduler.

        Example
        -------
        >>> config = {
        ... "type": "basescheduler",
        ... "name": "consumer task scheduler"
        ... }
        >>> scheduler = basescheduler.BaseScheduler(config)
        """
        self._id = self._generate_id()
        self._config = None
        self._worker_map = None
        self._log = None
        if config:
            self.config(config)

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def __repr__(self):
        return f"<Object: {self.__class__.__name__}>"

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def get_id(self) -> str:
        """Returns the id of the scheduler.

        Returns
        -------
        rtn: str
            The unique ID of the scheduler, cast from UUID4 to string.
        """
        self._log.args("%s: ()" % self)
        rtn = str(self._id)
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def config(self, config: Dict) -> bool:
        """Configures the scheduler.

        Parameters
        ----------
        config: dict
            name: str
                Name of the scheduler.
            type: str
                Type of scheduler.
            id: str
                Identification string of scheduler.
            logger: str, optional
                Name of the logger instance.

        Returns
        -------
        configured: bool
            Returns True if the scheduler is configured successfully,
            False otherwise.
        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: ()" % self)
        self._config = config
        self._worker_map = config["worker_map"]
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def get_config(self) -> Dict:
        """Returns scheduler's configuration.

        Returns
        --------
        config: dict
            name: str
                Name of the scheduler.
            type: str
                Type of scheduler.
            id: str
                Identification string of scheduler.
        """
        self._log.args("%s: ()" % self)
        config = self._config
        self._log.rtn("%s: success | data: %s" % (self, config))
        return config

    def register(self) -> bool:
        """Registers components to the BaseScheduler, to be overridden by child
        classes"""
        self._log.args("%s: ()" % self)
        return True

    def unregister(self) -> bool:
        """Unregisters components and configuration from the scheduler."""
        self._log.args("%s: ()" % self)
        self._config = None
        self._worker_map = None
        self._id = None
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def schedule_one(self) -> bool:
        """Schedules one task for execution., to be overriden by child classes.
        """
        self._log.args("%s: ()" % self)
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def schedule(self) -> bool:
        """Base schedule class implemented in child classes"""
        self._log.args("%s: ()" % self)
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def format_receipt(self, tasks: list) -> bool:
        """Helper method formatting result of tasks."""
        self._log.args("%s: (tasks: %s)" % (self, tasks))
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
