# -*- coding: utf-8 -*-

import json
import uuid
from typing import (
    Dict,
    Any
)
import logging
from wiremq.extlib.err.translatorexceptions import ClaimCheckException
from wiremq.extlib.err.sysmanagementexceptions import MessageStoreException
from wiremq.extlib.err.queueexception import (
    QueueEmptyException,
    QueueFullException,
    DurableQueueInsertException,
    DurableQueueSelectException
)
from wiremq.extlib.err.processingexception import (
    ProcessManagerException,
    ProcessingFailureException
)


class BaseProcessManager:
    """
    Base Process Manager
    ====================

    The base process manager is the skeleton of wiremq's process manager. It
    provides the functionality required for managing one or more message
    processors for the duration of their lifetimes. Processor managers are
    composed of a listening channel, filters, processors, a message store, and
    a message buffer.

    Attributes
    ----------
    _id: string
        Unique identifier of process manager.
    _config: Dict
        Configuration for process manager.
    _message_store: object
        A message store object handles storing a message in a database.
    _processor_chain: list
        The ordered list of processor keys.
    _processor_map: Dict
        A mapping of processor key/ID to a tuple of the processor class and
        config to pass to it.
    _processor_state: Dict
        A mapping of processor key/ID to the result of its processing, during
        the current processing run.
    _processing: bool
        True if the process manager is processing a message, False otherwise.
    _current_processor: object
        Current processor, responsible for message processing.
    _current_config: dict
        The current configuration of the processor.
    _current_index: int
        The current index of processing chain
    _queue_timeout: float
        Time in seconds before raising a full exception for putting items into
        a full queue.
    _log: object
        Python logging instance.

    Methods
    -------
    _generate_id(): str
        Generates and returns a unique id for the process manager.
    _determine_processor(): Any
        Determines the next processor in the process chain.
    _process(): Any
        Processes the message using the current processor.
    _store_message_history(): None
        Stores the result of the processor chain into the message store.
    get_id(): str
        Returns the process manager's unique id.
    config(): bool
        Configures the process manager object.
    get_config: dict
        Returns the configuration of the process manager.
    get_message(): Dict
        Retrieve a message from the message store by ID.
    store_message(): bool
        Store a message in the message store.
    remove_message(): bool
        Remove a message from the message store by ID.
    process(): None
        Process message.
    finish(): None
        Unregisters any sub-components and attributes from the process manager.

    Raises
    ------
    ProcessingFailureException:
        Exception raised for errors related to processor failures.
    ProcessManagerException:
        Exception raised for errors related to a process manager.
    """

    def __init__(self, config: Dict = None):
        """Base process manager class constructor.

        config: dict
            name: str
                Name of process manager.
            type: str
                Type of process manager.
            processor_map: dict
                Dictionary holding all implemented processors.
                code: str
                    Processor code.
                processor: object
                    The processor object.
                config: dict
                    Processor configuration.
            processor_queue: object
                Processor queue holding the processing steps.
            processor_chain: list
                A list of the processors to use with this manager.
                Processing chain holds all the processors the message has to go through.
            message_store: object
                Message store, updating the message history
            queue_timeout: float (optional)
                Time in seconds before raising a full exception for putting
                items into a full queue.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> store = messagestore.MessageStore(mconfig)
        >>> pqueue = fifoqueue.FifoQueue(config)
        >>> config = {
        ...    "type": "baseprocessmanager",
        ...    "name": "Base Process Manager",
        ...    "processors": [
        ...        processor1,
        ...        processor2,
        ...        processor3,
        ...        processor4
        ...    ],
        ...    "processor_queue": pqueue,
        ...    "processor_chain": [1, 2, 3],
        ...    "message_stores": store,
        ...    "queue_timeout": None
        ... }
        >>> bpm = baseprocessmanager.BaseProcessManager(config)
        """
        self._id = self._generate_id()
        self._config = config
        self._processor_queue = None
        self._message_buffer = None
        self._message_store = None
        self._processor_chain = []
        self._processor_map = {}
        self._processor_state = {}
        self._processing = False
        self._current_processor = None
        self._current_config = None
        self._current_index = None
        self._queue_timeout = None
        self._log = None
        if config:
            self.config(config)

    def _generate_id(self) -> str:
        """Generates and returns a unique id for the process manager.

        Returns
        -------
        rtn: str
            The unique ID of the process manager, cast from UUID4 to string.
        """
        _id = str(uuid.uuid4())
        return _id

    def _determine_processor(self, status: bool) -> None:
        """Determines the next processor in the process chain.

        Select and return the next processor in the process chain depending on
        the result of the current processor.

        Parameters
        ----------
        status: bool
            The return status of current processor result.
        """
        self._log.args("%s: (status: %s)" % (self, status))
        if status == "success" and self._current_index < (
            len(self._processor_chain) - 1
        ):
            self._current_index += 1
            current_key_value = self._processor_map[
                self._processor_chain[self._current_index]
            ]
            self._current_processor = current_key_value["processor"]
            self._current_config = current_key_value["config"]
        elif status == "ongoing" and self._current_index < (
            len(self._processor_chain) - 1
        ):
            self._processing = False
            # To be developed
        else:
            self._processing = False
        self._log.info("%s: _processor_chain: %s"
                       % (self, self._processor_chain))
        self._log.info("%s: _current_processor: %s"
                       % (self, self._current_processor))
        self._log.info("%s: _current_config: %s"
                       % (self, self._current_config))
        self._log.info("%s: _processing: %s" % (self, self._processing))
        self._log.rtn("%s: success" % self)

    def _process(self) -> None:
        """Processes the message using the current processor."""
        self._log.args("%s: ()" % self)
        self._current_config.update({"processor_queue": self._processor_queue})
        self._current_processor(self._current_config)
        self._log.rtn("%s: success" % self)

    def _store_message_history(self, message: Any) -> None:
        """Stores the result of the processor chain into the message store.

        This method checks to see if the message is of type bytes. If it is,
        it can be stored directly. Otherwise, it will need to be json dumped
        first. A message may be in bytes if a bytes-encoder is a part of the
        processor chain.

        Parameters
        ----------
        message: bytes or Dict
            The message resulting from the processor chain.
        """
        self._log.args("%s: ()" % self)
        if isinstance(message, bytes):
            _message_to_store = message
        else:
            _message_to_store = json.dumps(message)
        self.store_message(
            {"process_id": str(uuid.uuid4()), "message": _message_to_store}
        )
        self._log.rtn("%s: success" % self)

    def get_id(self) -> str:
        """Returns the process manager's unique id.

        Returns
        -------
        rtn: str
            The unique ID of the process manager, cast from UUID4 to string.
        """
        return str(self._id)

    def config(self, config: Dict) -> bool:
        """Configures process manager.

        Parameters
        ----------
        config: dict
            transport_type: str
                Transport type of process manager.
            name: str
                Name of process manager.
            type: str
                Type of process manager.
            processor_map: dict
                Dictionary holding all implemented processors.
                code: str
                    Processor code.
                processor: object
                    The processor object.
                config: dict
                    Processor configuration.
            processor_queue: object
                Processor queue holding the processing steps.
            processor_chain: list
                Processing chain holds all the processors the message has to go
                through.
            message_store: object
                Message store, updating the message history
            queue_timeout: float (optional)
                Time in seconds before raising a full exception for putting
                items into a full queue.
            logger: str, optional
                Name of the logger instance.

        Returns
        -------
        rtn: bool
            Returns True if the process manager is configured successfully,
            False otherwise.
        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: ()" % self)
        self._config = config
        self._processor_map = self._config["processor_map"]
        self._processor_chain = self._config["processor_chain"]
        self._processor_queue = self._config["processor_queue"]
        self._message_store = self._config.get("message_store")
        self._queue_timeout = self._config.get("queue_timeout")
        rtn = True
        self._log.rtn("success | data: {rtn}")
        return rtn

    def get_config(self) -> Dict:
        """Returns the configuration of the process manager.

        Returns
        -------
        config: dict
            transport_type: str
                Transport type of process manager.
            name: str
                Name of process manager.
            type: str
                Type of process manager.
            processor_map: dict
                Dictionary holding all implemented processors.
                code: str
                    Processor code.
                processor: object
                    The processor object.
                config: dict
                    Processor configuration.
            processor_queue: object
                Processor queue holding the processing steps.
            processor_chain: list
                Processing chain holds all the processors the message has to go
                through.
            message_store: object
                Message store, updating the message history
            queue_timeout: float (optional)
                Time in seconds before raising a full exception for putting
                items into a full queue.
            logger: str, optional
                Name of the logger instance.
        """
        self._log.args("%s: ()" % self)
        config = self._config
        self._log.rtn("success | data: {config}")
        return config

    def get_message(self, where: Dict) -> Dict:
        """Retrieves a message from the message store by a structured where
        clause.

        Parameters
        ----------
        where : Dict
            A dictionary where the keys correspond to column names and the
            values to those values used when selecting from the message
            store's db.

        Returns
        -------
        message : Dict
            The message to be stored.

        Raises
        ------
        ProcessManagerException:
            Raised when DB select query raises an exception.
        """
        self._log.args("%s: ()" % self)
        try:
            rtn = self._message_store.get(where)
        except MessageStoreException as e:
            self._log.error(e)
            raise ProcessManagerException(e)
        self._log.rtn(f"success | data: {rtn}")
        return rtn

    def store_message(self, message: Dict) -> bool:
        """Stores a message in the message store.

        Parameters
        ----------
        message : Dict
            The message to be stored.

        Returns
        -------
        bool
            Indicator of the success of storage

        Raises
        ------
        ProcessManagerException:
            Raised if message was unable to be retrieved.
        """
        self._log.args("%s: ()" % self)
        try:
            rtn = self._message_store.store(message)
        except MessageStoreException as e:
            self._log.error(e)
            raise ProcessManagerException(e)
        self._log.rtn(f"success | data: {rtn}")
        return rtn

    def remove_message(self, where: Dict) -> bool:
        """Removes a message from the message store by ID by a structured where
        clause.

        Parameters
        ----------
        where : Dict
            A dictionary where the keys correspond to column names and the
            values to those values used when removing from the message
            store's db.

        Returns
        -------
        rtn: bool
            Indicator of the success of the removal.

        Raises
        ------
        ProcessManagerException:
            Raised when there is an error with removing a message from the
            database.
        """
        self._log.args("%s: (message_id: %s)" % (self, where))
        try:
            rtn = self._message_store.remove(where)
            self._log.warning("RTN")
            self._log.warning(rtn)
        except MessageStoreException as e:
            self._log.error(e)
            raise ProcessManagerException(e)
        self._log.rtn(f"success | data: {rtn}")
        return rtn

    def process(self, message: Dict = None) -> None:
        """Processes message through Processor chain.

        Starts processing the message with the first processor in the
        "_processor_chain". The result is logged and the next processor is
        determined. The final message is placed in the shared queue.
        The process manager raises a ProcessingFailureException if one of the
        processors in the chain raises an exception. Also, a
        ProcessManagerException is raised here if entering an item into a queue
        that is full, if a queue.get() times out, or if there is an issue
        interacting with a message store for a durable queue.

        Parameters
        ----------
        message: Dict
            Message to be processed

        Raises
        ------
        ProcessManagerException:
            Raised when there is an issue interacting with the processor queue.
        ProcessingFailureException:
            Raised when a processor in the processor chain raises an exception.
        """
        self._log.args("%s: ()" % self)
        if message:
            try:
                self._processor_queue.put(message, self._queue_timeout)
            except QueueFullException as e:
                self._log.error(e)
                raise ProcessManagerException(e)
        self._processing = True
        current_key_value = self._processor_map[self._processor_chain[0]]
        self._current_processor = current_key_value["processor"]
        self._current_config = current_key_value["config"]
        self._current_index = 0

        while self._processing:
            try:
                self._process()
            except (MessageStoreException, ClaimCheckException) as e:
                self._log.error(e)
                raise ProcessingFailureException(e)
            except ProcessManagerException as e:
                self._log.error(e)
                raise ProcessingFailureException(e)

            try:
                result = self._processor_queue.get()
            except (QueueEmptyException, DurableQueueSelectException) as e:
                self._log.error(e)
                raise ProcessManagerException(e)

            self._processor_state.update({self._current_index: result})
            self._processor_queue.item_processed()

            try:
                self._processor_queue.put(result["data"], self._queue_timeout)
            except (QueueFullException, DurableQueueInsertException) as e:
                self._log.error(e)
                raise ProcessManagerException(e)

            self._determine_processor(result["status"])

        if self._message_store:
            self._store_message_history(result["data"])
        self._log.info(self._processor_state)
        self._processor_state = {}
        self._log.rtn("%s: success" % self)

    def finish(self) -> bool:
        """Unregisters process manager components.

        Returns
        -------
        bool
            Returns 'True' once the method has been completed.
        """
        self._log.args("%s: ()" % self)
        self._processor_queue = None
        self._message_store = None
        self._processor_chain = None
        self._processor_map = None
        self._processor_state = None
        self._processing = None
        self._current_processor = None
        self._current_config = None
        self._current_index = None
        self._queue_timeout = None
        self._config = None
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
