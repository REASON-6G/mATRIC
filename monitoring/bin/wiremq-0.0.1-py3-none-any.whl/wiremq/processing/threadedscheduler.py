# -*- coding: utf-8 -*-

from typing import (
    Dict,
    Any,
)
from wiremq.processing import basescheduler
from wiremq.extlib.queue import fifoqueue
from wiremq.extlib.err.processingexception import (
    ThreadPoolException,
    ThreadedSchedulerException
)


class ThreadedScheduler(basescheduler.BaseScheduler):
    """
    Threaded Scheduler
    ==================

    The threaded scheduler is responsible for scheduling tasks. Tasks are
    dispatched to the scheduler. The sorted tasks are then assigned to a worker
    and dispatched to the threadpool, to be executed. Once all the tasks are
    completed the scheduler returns the results.

    Attributes
    ----------
    task_queue: FifoQueue
        Task queue.
    threadpool: object
        Threadpool object executing tasks.

    Methods
    -------
    register(): bool
        Registers components of scheduler.
    unregister(): bool
        Unregisters components and configuration from the scheduler.
    schedule(): list
        Schedules all queued tasks for execution.
    create_workers(): None
        Creates a worker and assigns the worker to a task.
    format_receipt(): list
        Helper method formatting results of tasks.

    Raises
    ------
    ProcessingFailureException:
        Exception raised for errors related to processor failures.
    """

    def __init__(
        self,
        config: Dict = None,
        threadpool: Any = None,
        task_queue: Any = None
    ):
        """Threaded scheduler class constructor.

        config: dict
            name: str
                Name of the scheduler.
            type: str
                Type of scheduler.
            id: str
                Identification string of scheduler.
        threadpool: object
            Threadpool object executing multiple tasks in parallel.

        Example
        -------
        >>> config = {
        ...     "type": "threadedcheduler",
        ...     "uid": "616251e047993b9da10745c4d06126c" +
        ...            "79ad730dcd36844aeba1072386e652f187",
        ...     "name": "consumer task scheduler"
        ... }
        >>> threadpool = threadpool.Threadpool(config, queue, workers)
        >>> scheduler = threadedscheduler.ΤhreadedScheduler(config, threadpool)
        """
        super().__init__(config)
        self._task_queue = None
        self._threadpool = None
        self.register(threadpool, task_queue)

    def register(
        self,
        threadpool: Any = None,
        task_queue: Any = None
    ) -> bool:
        """Registers components to the BaseScheduler

        Parameters
        ----------
        threadpool: object
            A threadpool object processing tasks.
        task_queue: object
            Task queue.

        Returns
        --------
        registered: bool
            Returns True if all components are registered, False otherwise.
        """
        if self._log:
            self._log.args("%s}: (threadpool: %s, task_queue: %s)"
                           % (self, threadpool, task_queue))
        self._threadpool = threadpool
        self._task_queue = task_queue
        rtn = True
        if self._log:
            self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def unregister(self) -> bool:
        """Unregisters components and configuration from the scheduler.

        Returns
        -------
        rtn: bool
            Returns true if components are unregistered, false otherwise.
        """
        self._log.args("%s: ()" % self)
        super().unregister()
        self._threadpool = None
        self._task_queue = None
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def schedule(self) -> list:
        """Schedules all queued tasks for execution.

        The schedule method retrieves tasks from a shared task queue.

        Returns
        -------
        receipt: list
            Result of the task execution.
        """
        self._log.args("%s: ()" % self)
        tasks_list = []
        while not self._task_queue.empty():
            tasks_list.append(self._task_queue.get())
            self._task_queue.item_processed()

        # Create and assign worker to a task
        self.create_workers(tasks_list)

        # Execute task(s)
        try:
            self._threadpool.start(tasks_list)
        except ThreadPoolException as e:
            self._log.error(e)
            raise ThreadedSchedulerException(e)
        self._threadpool.shutdown()

        receipt = self.format_receipt(tasks_list)
        self._log.rtn("%s: success | data: %s" % (self, receipt))
        return receipt

    def create_workers(self, tasks: list) -> None:
        """Creates workers for tasks.

        Parameters
        ----------
        tasks: list
            List containing tasks.
        """
        self._log.args("%s: (tasks: %s)" % (self, tasks))
        for task in tasks:
            _worker_info = self._worker_map[task.get_name()]
            worker = _worker_info["worker"]()
            self._log.info("%s: worker: %s" % (self, worker))
            task.set_worker(worker)
            task.set_method(_worker_info["method"])

            if _worker_info["config"]:
                queue = fifoqueue.FifoQueue(_worker_info["queue_config"])
                _worker_info["config"]["processor_queue"] = queue
                worker.config(_worker_info["config"])
        self._log.rtn("%s: success" % self)

    def format_receipt(self, tasks: list) -> Dict:
        """Helper method formatting result of tasks.

        If specified exceptions are found from one of the concurrent futures,
        this is raised as a ProcessingFailureException.

        Parameters
        ----------
        tasks: list
            List of finished tasks. Tasks can be "success" or "failure".

        Returns
        -------
        receipt: list
            List of dictionaries, holding task execution resultsWWWWWW.
            status: str
                Status of the task. Values are "success" or "failure".
            task_id: str
                Task identifier.
            result: object
                Result of task execution. If it is successful returns tx_id,
                otherwise, the exception is returned.

        Raises
        ------
        ProcessingFailureException:
            Raised when a processor in the processor chain raises an exception.
        """
        self._log.args("%s: (tasks: %s)" % (self, tasks))
        receipt = []

        for task in tasks:
            future = task.get_future()
            error = future.get_exception()
            if error:
                status = "failure"
                result = error
                self._log.error(error)
            else:
                result = future.get_result()
                status = "success"

            receipt.append(
                {
                    "status": status,
                    "task_id": str(task.get_id()),
                    "result": result,
                }
            )
        self._log.rtn("%s: success | data: %s" % (self, receipt))
        return receipt
