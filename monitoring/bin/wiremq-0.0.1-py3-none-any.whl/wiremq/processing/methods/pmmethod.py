# -*- coding: utf-8 -*-

from typing import (
    Dict,
    Any
)


def execute(worker: Any, data: Dict) -> str:
    """Executes a task.

    Parameters
    ---------
    worker: object
        Worker object.
    data: dict
        Message to be processed.

    Returns
    -------
    worker_id: str
        Transaction id of processing.
    """
    worker.process(data)
    worker.finish()
    return worker.get_id()
