# -*- coding: utf-8 -*-

import json
from typing import (
    Any,
    Dict
)

from wiremq.processing import baseprocessor


class IdempotentFilter(baseprocessor.BaseProcessor):
    """
    Idempotent Filter
    =================

    The Idempotent filter is used to discard duplicate messages, returning only
    those that have not been processed before.

    It achieves this by checking every incoming message against the message
    store, discarding it if there is a match. Otherwise, in the case of no
    matches, the message is stored for comparison against any future
    duplicates, and returned so that it can be processed further.

    Attributes
    ----------
    config: Dict
        alias: str
            Alias for the idempotent filter.
        name: str
            Name for the idempotent filter.
        type: str
            Type of processor (idempotentfilter).
        uid: hex
            Unique identifier for the idempotent filter.
        processor_queue:
            Queue object.
        message_store: Object
            Message store object, used for storing and comparing messages.
        logger: str, optional
            Name of the logger instance.

    Methods
    -------
    _process(): Dict
        Overrides _process method of Base Processor with idempotent filter
        logic.
    """

    def __init__(self, config: Dict = None):
        """Idempotent filter class constructor.

        Parameters
        ----------
        config: Dict
            alias: str
                Alias for the idempotent filter.
            name: str
                Name for the idempotent filter.
            type: str
                Type of processor (idempotentfilter).
            uid: hex
                Unique identifier for the idempotent filter.
            processor_queue:
                Queue object.
            message_store: Object
                Message store object, used for storing and comparing messages.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> idempotentfilter_config = {
        ...     "alias": "Idempotent Filter",
        ...     "name": "Idempotent filter",
        ...     "type": "idempotentfilter",
        ...     "uid": "a8f43e278bd249cc239d32ab280e35f2",
        ...     "processor_queue": None,
        ...     "message_store": None
        }
        >>> queue = fifoqueue.FifoQueue(queue_config)
        >>> idempotentfilter_config["processor_queue"] = queue
        >>> queue.put(msg)
        >>> idempotentfilter.IdempotentFilter(idempotentfilter_config)
        >>> res = queue.get()
        >>> queue.item_processed()
        """
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._log.rtn("%s: success" % self)

    def _process(self, message: Any) -> Dict:
        """Overrides _process method of Base Processor with idempotent filter
         logic.

        Parameters
        ----------
        message: Any
            Message to check for duplication; it will either be stored and
            returned if it has never been encountered before, or discarded if
            the message is a duplicate.

        Returns
        -------
        rtn: Dict
            Dictionary containing the results of the duplicate check. If the
            message is a duplicate, and already exists within the message
            store, the data returned will be None. Or else, in the case of a
            non-duplicate message, the message will be saved in the message
            store, and returned in the data field of the return dictionary.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        query = self._config["message_store"].get(
            {"message_id": message["message_id"]}
        )
        if len(query) == 0:
            self._config["message_store"].store({
                "message_id": message["message_id"],
                "message": json.dumps(message)
            })
            status = "success"
        else:
            message = "Message already processed"
            status = "failure"
        rtn = {"status": status, "data": message}
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
