# -*- coding: utf-8 -*-

import bson
from typing import Dict
from wiremq.processing import baseprocessor
from wiremq.wmqsockets import (
    broadcastsocket,
    outboundsocket
)
from wiremq.extlib.err.filterexceptions import SocketDispatcherException
from wiremq.extlib.err.socketexception import (
    SocketConnectionRefusedException,
    SocketBrokenPipeException,
    SocketGAIException,
    SocketNotFoundException,
)


class SockDispatcher(baseprocessor.BaseProcessor):
    """
    Socket Dispatcher
    =================

    The sock dispatcher takes a message, and sends it to its intended
    recipient.

    Attributes
    ----------
    _config : dict
        Configuration of the sock dispatcher.

    Methods
    -------
    _create_socket(): OutboundSocket/BroadcastSocket
         Helper method to create either an outboundsocket or broadcastsocket.
    _process(): Dict
        Overrides method of base processor, holds the processor logic.
    -------
    """

    def __init__(self, config: Dict = None):
        """Sock dispatcher class constructor.

        Parameters
        ----------
        config: Dict
            type: str
                The processor type.
            alias: str
                Alias of the sock dispatcher.
            name: str
                Name of the sock dispatcher.
            uid: hash
                Identification number.
            processor_queue: object
                Queue object for receiving & sending messages for processing.
            terminator: bytes, optional
                The termination character for UDP sockets.
            dest_ip: str, optional
                The destination IP address to send messages, if UDP.
            dest_port: int, optional
                The destination port number to send messages, if UDP & INET.
            from_msg: bool, optional
                Whether to select message destination from message headers
            outbound_socket_config: object
                Outbound socket config for dispatching messages.
                name: str
                    Socket name.
                alias: str
                    Socket alias.
                type: str
                    Out socket type (outboundsocket or broadcastsocket).
                family: str
                    Socket family (inet or unix).
                protocol: str
                    Transfer protocol (tcp or udp).
                blocking: bool
                    Flag to denote if the socket is blocking.
                buffer_size: int
                    Maximum buffer size to send (in bytes).
                host: str
                    (Unix family only) hostname.
                logger: str, optional
                    Name of the logger instance.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> config = {
        ...    "alias": "Socket dispatcher",
        ...    "name": "SockDispatcher",
        ...    "type": "sockdispatcher",
        ...    "processor_queue": basequeue.BaseQueue(),
        ...    "outbound": outboundsocket.OutboundSocket(),
        ...    "dest_ip": "localhost",
        ...    "dest_port": 11001,
        ...    "from_msg": False,
        ...    "outbound_socket_config": {
        ...       "name": "Outbound Socket",
        ...       "alias": "outboundsocket1",
        ...       "type": "outboundsocket",
        ...       "family": "unix",
        ...       "protocol": "udp",
        ...       "blocking": "True",
        ...       "buffer_size": 1024,
        ...       "host": "/home/user/.wiremq/domain_sockets/abc123",
        ...    }
        ... }
        >>> sdispatcher = sockdispatcher.SockDispatcher(config)
        """
        super().__init__(config)

    def _create_socket(self):
        """Helper method to create either an outboundsocket or broadcastsocket.

        Returns
        -------
        _socket: OutboundSocket/BroadcastSocket
        """
        if self._config["outbound_socket_config"]["type"] == "outboundsocket":
            _socket = outboundsocket.OutboundSocket(
                self._config["outbound_socket_config"]
            )
        elif self._config["outbound_socket_config"]["type"] == \
                "broadcastsocket":
            _socket = broadcastsocket.BroadcastSocket(
                self._config["outbound_socket_config"]
            )
        return _socket

    def _process(self, message: bytes) -> Dict:
        """Overrides _process method of base processor.

        Takes a message, and sends it via an outbound socket. The outbound
        socket is created, dispatched on, then closed.

        Optionally, the sockdispatcher may be configured to take its routing
        instructions from a message header using the from_msg config.

        Parameters
        ----------
        message: Dict
            The message to send.

        Returns
        -------
        rtn: Dict
            The selected route and status information.

        Raises
        ------
        SocketDispatcherException
            Throws an exception when failing to establishing a connection
            or sending a message
        """
        self._log.args("%s: (message: %s)" % (self, message))
        _host = None
        if self._config.get("from_msg"):
            msg = bson.BSON.decode(message)
            _host = msg.get("dest_ip")
            _port = msg.get("dest_port")
        if not _host:
            _host = self._config.get("dest_ip")
            _port = self._config.get("dest_port")
        if "terminator" in self._config and \
                self._config["terminator"] is not None:
            message = message + self._config["terminator"]
        _socket = self._create_socket()
        try:
            _socket.connect(_host, _port)
            _socket.send(message, _host, _port)
        except (SocketBrokenPipeException, SocketGAIException) as e:
            raise SocketDispatcherException(e)
        except (SocketNotFoundException,
                SocketConnectionRefusedException) as e:
            raise SocketDispatcherException(e)
        except TypeError as e:
            raise SocketDispatcherException(f"{str(e)} (port number must be of"
                                            f" 'int' type, suppled: {_port})")

        _socket.shutdown()
        _socket.close()

        rtn = {"status": "success", "data": message}
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
