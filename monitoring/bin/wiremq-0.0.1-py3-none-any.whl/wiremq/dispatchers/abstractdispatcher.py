# -*- coding: utf-8 - *-

from typing import Dict

from abc import (
    ABC,
    abstractmethod
)


class AbstractDispatcher(ABC):
    """
    Abstract Dispatcher
    ===================

    Abstract class which defines the required methods for any dispatcher.
    """

    def __init__(self, config: Dict = None) -> None:
        """Dispatcher class constructor"""
        pass

    def _generate_id(self) -> str:
        """Generates a unique id."""
        pass

    @abstractmethod
    def config(self, config: Dict) -> None:
        """Configures the dispatcher."""
        pass

    @abstractmethod
    def get_config(self) -> Dict:
        """Getter for dispatcher configuration."""
        pass

    def register(self) -> None:
        """Registers transport objects."""
        pass

    def unregister(self) -> None:
        """Unregisters transport objects."""
        pass

    @abstractmethod
    def dispatch(self, _fd: int, data: bytes) -> Dict:
        """Generic method to dispatch data."""
        pass
