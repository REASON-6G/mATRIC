# -*- coding: utf-8 - *-

import bson
from typing import (
    Dict,
    Any
)
from wiremq.dispatchers import basedispatcher


class TransportDispatcher(basedispatcher.BaseDispatcher):
    """
    Transport Dispatcher
    ====================

    Attributes
    ----------
    _config: dict
        Dispatcher configuration dictionary.
    _dmap: dict
        Dispatcher map, holding all the objects that the dispatcher handles.
    _log: object
        Python logging instance.


    Methods
    -------
    _handle_readable(): Dict
        A helper method for the dispatch method, used to receive data.
    _handle_writeable(): Dict
        A helper method for the dispatch method, used for sending data.
    config: bool
        Configures the dispatcher.
    add: None
        Adds a transport object to dispatcher map.
    remove: None
        Removes a transport object from dispatcher map.
    dispatch(): Any
        Dispatch data outbound or inbound.

    Example
    -------
    >>> config = {
    ...     "type": "transportdispatcher_socket",
    ...     "transport_type": "socket"
    ... }
    >>> dispatcher = transportdispatcher.TransportDispatcher(config)
    """

    def __init__(self, config: Dict = None) -> None:
        """Transport dispatcher class constructor.

        Parameters
        ----------
        config: dict
            Dispatcher configuration dictionary.
            type: str
                Type of dispatcher.
            terminator: bytes, optional
                A terminator string to append to messages before dispatching.
            logger: str, optional
                Name of the logger instance.
        """
        self._terminator = None
        super().__init__(config)

    def _handle_readable(self, _tobj: Any) -> Dict:
        """A helper method for the dispatch method, used to receive data.

        Parameters
        ----------
        _tobj: object
            Transport object (queue or socket), sockets call accept and recv.

        Returns
        -------
        ret: Dict
            data: Any
                Either:
                  - Returned message from the socket's recv method, if the
                  dispatcher's dispatch call was inbound and "accepted" True
                  - conn object from the socket's accept method, if the
                  dispatcher's dispatch call was inbound and "accepted" False
                  - Returned message from the queue's get method
            session_info: Dict
                Information about the message and its receiver.
        """
        self._log.args("%s: (_tobj: %s)" % (self, _tobj))
        ret = {}
        if self._config["transport_type"] == "socket":
            if _tobj._config["protocol"] == "udp" or _tobj._config["accepted"]:
                ret["data"] = _tobj.recv()
                ret["session_info"] = {
                    "socket_id": _tobj.get_id(),
                    "socket_bytes": len(ret["data"]),
                    "receiving": True
                }
            else:
                ret["data"] = _tobj.accept()
                ret["session_info"] = False
        elif self._config["transport_type"] == "queue":
            ret = {
                "data": _tobj.get(),
                "session_info": {
                    "queue_id": _tobj.get_config()['id']
                }
            }
        self._log.rtn("%s: success | data: %s" % (self, ret))
        return ret

    def _handle_writeable(self, _tobj: Any, data: Dict) -> Dict:
        """A helper method for the dispatch method, used for sending data.

        Parameters
        ----------
        _tobj: object
            Transport object (queue or socket).
        data: bytes
            Message to be sent though the transport object.

        Returns
        -------
        ret: Dict
            data: Any
                Either:
                    - int denoting the number of bytes sent, from the socket's
                     send method.
                    - None for queue transport type
            session_info: Dict
                Information about the message and its sender.
        """
        self._log.args("%s: (_tobj: %s, data: %s)" % (self, _tobj, data))
        ret = {}
        if self._config["transport_type"] == "socket":
            if _tobj._config["protocol"] == "tcp":
                socket_bytes = _tobj.send(data["message"])
            elif _tobj._config["protocol"] == "udp":
                _host = data["dest_ip"]
                _port = data.get("dest_port")
                _message = bson.BSON.encode(data["message"])
                if self._terminator:
                    _message = _message + self._terminator

                socket_bytes = _tobj.send(_message,
                                          _host,
                                          _port)
            ret["data"] = _message
            ret["session_info"] = {
                "socket_id": _tobj.get_id(),
                "socket_bytes": socket_bytes,
                "receiving": False
            }
        elif self._config["transport_type"] == "queue":
            _tobj.put(data["message"])
            ret["data"] = data["message"]
            ret["session_info"] = {
                "queue_id": _tobj.get_config()['id']
            }
        self._log.rtn("%s: success | data: %s" % (self, ret))
        return ret

    def config(self, config: Dict) -> bool:
        """Configures the dispatcher.

        Parameters
        ----------
        config: dict
            Dispatcher configuration dictionary.
            type: str
                Type of dispatcher.
            terminator: bytes, optional
                A terminator string to append to messages before dispatching.
            logger: str, optional
                Name of the logger instance.

        Returns
        -------
        bool
            True if configuration successful, False otherwise
        """
        super().config(config)
        self._log.args("%s: (config: %s)" % (self, config))
        self._terminator = self._config.get("terminator")
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def add(self, _tobj: Any) -> bool:
        """Adds transport component to the transport map of the Dispatcher.

        Parameters
        ----------
        _tobj: object
            Transport object (queue or socket).

        Returns
        -------
        rtn: bool
            True if successful, False otherwise
        """
        self._log.args("%s: (_tobj: %s)" % (self, _tobj))
        if self._config["transport_type"] == "socket":
            _file_descriptor = _tobj.get_fd()
        elif self._config["transport_type"] == "queue":
            _file_descriptor = _tobj.get_config()["id"]
        self._dmap[_file_descriptor] = _tobj
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def remove(self, _tobj: Any) -> bool:
        """Removes a transport component from the transport map of the Dispatcher.

        Parameters
        ----------
        _tobj: object
            Transport object (queue or socket).

        Returns
        -------
        rtn: bool
            True if successful, False otherwise
        """
        self._log.args("%s: (_tobj: %s)" % (self, _tobj))
        if self._config["transport_type"] == "socket":
            _file_descriptor = _tobj.get_fd()
        elif self._config["transport_type"] == "queue":
            _file_descriptor = _tobj.get_config()["id"]
        del self._dmap[_file_descriptor]
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def dispatch(self, _fd: int, data: Dict = None) -> Dict:
        """Dispatch data outbound or inbound.

        Parameters
        ----------
        _fd: int
            Socket socket's file descriptor, used as dmap key.
        data: bytes, optional
            Message to be sent though the socket, if outbound dispatch.

        Returns
        -------
        rtn: Dict
            data: Any
                Either:
                  - Returned bytes from the socket's recv method, if the
                  dispatcher's dispatch call was inbound and "accepted" True
                  - conn, addr tuple from the socket's accept method, if the
                  dispatcher's dispatch call was inbound and "accepted" False
                  - Blank, from the socket's send method, if the dispatcher's
                  dispatch call was outbound
            session_info: Dict
                socket_id: str
                socket_bytes: int
                receiving: bool
        """
        self._log.args("%s: (_fd: %s, data: %s)" % (self, _fd, data))
        _tobj = self._dmap[_fd]
        if data:
            rtn = self._handle_writeable(_tobj, data)
        else:
            rtn = self._handle_readable(_tobj)
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def close(self) -> bool:
        """Closes sockets used by the transport dispatcher

        Returns
        -------
        rtn: bool
            True if successful, False otherwise.
        """
        if self._config["transport_type"] == "socket":
            for _socket in self._dmap.values():
                _socket.close()

        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
