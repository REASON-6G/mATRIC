# -*- coding: utf-8 -*-

import uuid
from typing import Any, Dict
from http.server import BaseHTTPRequestHandler
from io import BytesIO, TextIOWrapper


class HTTPRequest(BaseHTTPRequestHandler):
    """
    HTTP Request
    ============

    The HTTPRequest class is a subclass of Python's BaseHTTPRequestHandler, and
    acts as a wrapper for the received HTTP request, parsing it into different
    callable attributes.

    Attributes
    ----------
    rfile: BytesIO
        This is a bytes-stream that contains the optional body data of a
        request
    error_code: str
        This is the error code to be returned for the request, unless
        the request is well formed and ran OK (in which it contains the status
        code, 200).
    error_message: str
        This is the error message to be returned for the request, unless
        the request is well formed and ran OK (in which it contains the status
        message OK).
    outheaders: dict
        A dictionary of key value pairs, where the key is the header field,
        and the value is the header's value.
    message: Any
        The message to be attached to the payload/message body of an http
        response.
    payload: Any
        Payload/message body extracted from a received http request message.

    Methods
    -------
    _extract_payload(): None
        Extracts, converts, and stores http request's payload
    send_error(): None
        Sets argument values as error code and message
    send_headers(): None
        Sets header information for http response message
    send_message(): None
        Sets payload/message body for http response message
    response(): str
        Forms a dict with HTTP response data
    """

    def __init__(self, request_text: bytes):
        """HTTP request class constructor

        Parameters
        ----------
        request_text: bytes
            The received HTTP request, in bytes-format.

        Example
        -------
        received_http_request = received message of the format:
            POST / HTTP/1.1\r\n
            Content-type: application/json\r\n'
            Accept: text/json, application/json\r\n'
            \r\n'
            {
                'service_type': 'unknownservicerequest',
                'service_name': 'unknownservice',
                'service_config': {
                    'test': 'testvalue'
                }
            }
        httpreq = httprequest(received_http_request)
        """
        self._id = self._generate_id()
        self.rfile = BytesIO(request_text)
        self.raw_requestline = self.rfile.readline()
        self.error_code = self.error_message = None
        self.outheaders = {}
        self.message = None
        self._id = None
        self.parse_request()
        self._extract_payload()

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def _extract_payload(self) -> None:
        """Extracts, converts, and stores http request's payload"""
        payload = TextIOWrapper(self.rfile)
        self.payload = payload.readline()

    def get_id(self) -> str:
        """Return the id of the http request.

        Returns
        -------
        rtn: str
            The unique ID of the http request, cast from UUID4 to string.
        """
        _id = str(self._id)
        return _id

    def send_error(self, code, message) -> None:
        """Sets error code and message values

        Parameters
        ----------
        code: int
            The error code
        message: str
            The error message

        Example
        -------
        httpreq = httprequest(received_http_request)
        httpreq.send_error(200, "OK")
        """
        self.error_code = code
        self.error_message = message

    def send_headers(self, headers: Dict) -> None:
        """Sets header information for http response message

        Parameters
        ----------
        headers : Dict
            A dictionary of key value pairs, where the key is the header field,
            and the value is the header's value.

        Example
        -------
        hdr = {
            'Content-Type': 'text/json'
        }
        httpreq.send_headers(hdr)
        """
        self.outheaders = headers

    def send_message(self, message: Any) -> None:
        """Sets payload/message body for http response message

        Parameters
        ----------
        message : Any
            The message to be attached to the payload/message body of an http
            response.

        Example
        -------
        msg = {
            'data': 'response'
        }
        httpreq.send_message(msg)
        """
        self.message = message

    def response(self) -> Dict:
        """Gets a formed http response

        Example
        -------
        httpreq = httprequest(received_http_request)
        httpreq.send_error(200, "OK")
        httpreq.send_headers({"Content-Type": "text/json", "Server": "Ubuntu"})
        httpreq.send_message({"data": "requested JSON data"})
        _res = httpreq.response()

        Returns
        -------
        resp : Dict
            A dictionary containing response information to be formatted into
            an HTTP response message
        """
        resp = {
            "request_version": self.request_version,
            "error_code": self.error_code,
            "error_message": self.error_message,
            "headers": self.outheaders,
        }
        if self.message:
            resp["message"] = self.message
        return resp
