# -*- coding: utf-8 -*-

from abc import (
    ABC,
    abstractmethod
)
from typing import (
    Any,
    Dict
)


class AbstractHandler(ABC):
    """
    Abstract Handler
    ================

    """
    def __init__(self, config: Dict = None):
        """Abstract handler class constructor.
        """
        pass

    @abstractmethod
    def _handle(self, message: bytes) -> Any:
        """Helper method for handle(). To be overridden by sub-classes.
        """
        pass

    @abstractmethod
    def config(self, config) -> bool:
        """Initial setup of the handler.
        """
        pass

    @abstractmethod
    def handle(self, message: bytes) -> None:
        """Handles a message, calls the _handle method implemented by child
        classes.
        """
        pass

    @abstractmethod
    def finish(self) -> bool:
        """Performs teardown/cleanup of the handler.
        """
        pass

    @abstractmethod
    def close(self) -> bool:
        """Closes the dispatcher used by the handler.
        """
        pass
