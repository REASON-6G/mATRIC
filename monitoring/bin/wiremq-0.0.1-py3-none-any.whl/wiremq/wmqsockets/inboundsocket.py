# -*- coding: utf-8 -*-
"""Inbound Socket Class"""

from typing import Dict
from wiremq.wmqsockets import basesocket
from wiremq.extlib.err.socketexception import SocketException


class InboundSocket(basesocket.BaseSocket):
    """Inbound socket class

    Inbound socket inherits from the base socket class. Basic functionality of
    base socket is implemented and extended. Bind, listen, accept and receive
    methods are implemented in the Inbound Socket class.

    Attributes
    ----------
    _config : dict
        Socket configuration dictionary.
        accepted : bool
            As well as the regular fields present in the basesocket's config,
            the inboundsocket config has an 'accepted' flag.
    _log: object
        Python logging instance.

    Methods
    -------
    bind(): None
        Binds the socket to address. The socket must not already be bound.
    listen(): None
        Enables a server to accept connections.
    accept(): tuple
        Accepts a connection.
    recv(): bytes
        Receives data from the socket.

    Raises
    ------
    SocketException:
        Exception raised when an OS error occurs on a socket.
    """

    def __init__(self, config: Dict = None):
        """Inbound Socket Class Constructor.

        Initialize an inbound socket. Inbound socket options are
        required to initialize the socket. They are typically the
        same as those used with a base socket.

        Parameters
        ----------
        config: dict
            Inbound socket configuration dictionary.
            id : hash
                A unique id using secrets lib with sha256 hashing.
            type : str
                Socket type.
            name : str
                Socket name.
            protocol : str
                Socket protocol. Values are tcp, udp, raw, rdm, seq.
            family : str
                Socket family, Values are unix, inet.
            blocking : bool
                True if socket is in blocking mode, False if in non-blocking.
            accepted : bool
                True if socket has accepted an incoming connection, else False
            buffer_size : int
                Socket buffer size for the number of bytes to send and receive
            context : Dict, optional
                type : str
                    Type of sockets to be wrapped - server or client.
                version : float
                    The TLS version to be applied to the wrapped socket.
                    1.1, 1.2, or 1.3, depending on the lowest version
                    required. For example, "1.2" would allow only
                    connections using TLSv1.2 or higher, excluding any
                    TLSv1 and v1.1 connections.
                peer_cert : bool
                    Flag to specify whether a certicifate is required or not.
                cert: str
                    Path to certificate file.
                key: str
                    Path to key file.
                hostname: str
                    Host name for a wrapped socket.
            logger: str, optional
                Name of the logger instance.

        Example:
        -------
        >>> config = {}
        >>> config["type"] = "inboundsocket"
        >>> config["id"] = "6b724f14c9da00cae8ea1da9d4c8c0e5" +
        ...                "858bee1907e8eddfd1e0aeeef249c40f"
        >>> config["protocol"] = "tcp"
        >>> config["family"] = "inet"
        >>> config["blocking"] = True
        >>> socket = inboundsocket.InboundSocket(config)
        """
        super().__init__(config)
        if self._log:
            self._log.args("%s: (config: %s)" % (self, config))
        self._config["accepted"] = config.get("accepted", False)
        if self._log:
            self._log.rtn("%s: success" % self)

    def bind(self, host: str, port: int = None) -> None:
        """Binds the socket to address.

        The socket must not already be bound.
        Raises a SocketException when the binding address is invalid (wrong
        hostname, domain etc).

        Parameters
        ----------
        host : str
            Host address of the socket, either a UNIX domain, IP or URL.
        port : int
            Port number of socket (TCP sockets only).

        Raises
        ------
        SocketException:
            Raised when the address cannot be bound,
        """
        self._log.args("%s: (host: %s, port: %s)" % (self, host, port))
        try:
            if self._config["family"] == "unix":
                self._socket.bind(host)
            else:
                self._socket.bind((host, port))
        except OSError as e:
            raise SocketException("%s | %s : %s" % (e, host, port))
        self._log.rtn("%s: success" % self)

    def listen(self, backlog: int = None) -> None:
        """Enables socket to accept incoming connections.

        Parameters
        ----------
        backlog: int
            backlog is the queue size passed to listen socket method. when 0 a
            default reasonable value is chosen. reuse_port dictates
            whether to set the SO_REUSEPORT socket option.
        """
        self._log.args("%s: (backlog: %s)" % (self, backlog))
        if self._config["protocol"] != "udp":
            self._socket.listen(backlog)
        self._log.rtn("%s: success" % self)

    def accept(self) -> tuple:
        """Accepts an incoming connection.

        The socket must be bound to an address and listening for connections.

        Used by TCP sockets only.

        Returns
        -------
        accept_res: tuple
            The return value is a pair(conn, address) where conn is a new
            socket object usable to send and receive data on the connection
            conn: object
                Connection object to receive and send data
                from sockets.
            address: tuple
                Ip address and port of connected socket created from
                the second return of the socket accept method.

        """
        self._log.args("%s: ()" % self)
        self._config["accepted"] = True
        if self._config["protocol"] == "tcp":
            _conn, addr = self._socket.accept()
            if self._sslctx:
                _conn = self._sslctx.wrap_socket(_conn, server_side=True)
            self._log.rtn("%s: success | data: %s" % (self, (_conn, addr)))
            return _conn, addr

    def recv(self) -> bytes:
        """Receives data from the socket.

        Parameters
        ----------
        buffer_size : int
             The maximum amount of data to be received at once.

        Returns
        -------
        data : bytes
            Data received from a socket.
        """
        self._log.args("%s: ()" % self)
        if self._config["protocol"] == "udp":
            rtn = self._socket.recvfrom(self._config["buffer_size"])
        elif self._config["protocol"] == "tcp":
            rtn = (self._socket.recv(self._config["buffer_size"]), None)
        self._log.info("%s: %s bytes received" % (self, len(rtn[0])))
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
