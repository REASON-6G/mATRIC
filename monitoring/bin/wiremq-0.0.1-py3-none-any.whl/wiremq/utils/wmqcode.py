# -*- coding: utf-8 -*-
"""
WireMQ Command Codes
====================

Commands used by WireMQ Command Messages.

Commands are transported as integers and are mapped here.

0 - 200 are reserved for internal WireMQ messages.

The currently supported codes are shown below.

===========================================  ==================================
Reference                                    Description
===========================================  ==================================
wiremq.utils.wmqcode.ONLINE_NOTIFICATION     Notifies another endpoint that it
                                             is online. Used in durable
                                             endpoints. When an online
                                             notification is received, the
                                             endpoint checks its durable store
                                             for pending messages for the
                                             remote endpoint, triggering a
                                             re-sending of all elligible
                                             messages
wiremq.utils.wmqcode.ADD_SUBSCRIBER          Adds a subscriber to a Publisher-
                                             Subscriber Channel
wiremq.utils.wmqcode.UPDATE_SUBSCRIBER       Updates a subscriber's
                                             subscription criteria or address
wiremq.utils.wmqcode.ADD_BUS_CONNECTION      Adds a Message Bus endpoint to
                                             an existing bus connection pool
wiremq.utils.wmqcode.REMOVE_BUS_CONNECTION   Removes a Message Bus endpoint
                                             from the connection pool
===========================================  ==================================
"""
# =============================MESSAGE TYPES===================================
EVENT = 1
COMMAND = 2

# ===============================COMMANDS======================================
# General
ACKNOWLEDGEMENT = 1
ONLINE_NOTIFICATION = 2

# Subscriptions
ADD_SUBSCRIBER = 21
UPDATE_SUBSCRIBER = 22
REMOVE_SUBSCRIBER = 23

# Bus channel connections
ADD_BUS_CONNECTION = 31
REMOVE_BUS_CONNECTION = 32
