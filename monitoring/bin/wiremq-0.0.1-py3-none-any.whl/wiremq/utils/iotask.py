
# -*- coding: utf-8 -*-

from wiremq.utils import basetask
from typing import Any


class IOTask(basetask.BaseTask):
    """
    IO task
    =======

    Attributes
    ----------
    _buffer: bytes
        Message in byte format.

    Methods
    -------
    set_buffer(): None
        Set the IO bytes buffer to the task.
    get_buffer(): bytes
        Return the bytes buffer within the task.
    """
    def __init__(self, name: Any = None, buff: Any = b""):
        """IO Task class constructor.

        Parameters
        ----------
        name: string
            Name of task.
        buff: bytes
            Message in byte format.

        Example
        -------
        >>> name = "io-task"
        >>> task = iotask.IOTask(name, msg)
        """
        super().__init__(name=name)
        self._buffer = buff

    def get_buffer(self) -> bytes:
        """Return the bytes buffer within the task.

        Returns
        -------
        _buffer : bytes
            Returns the buffer in the task object.
        """
        _buffer = self._buffer
        return _buffer

    def set_buffer(self, buff: Any = b"") -> None:
        """Set the IO bytes buffer to the task.

        Parameters
        ----------
        buff : bytes buffer
            The byte string within the task.
        """
        self._buffer = buff
