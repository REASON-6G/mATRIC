# -*- coding: utf-8 - *-
"""HTTP Formatter class"""

import json
from typing import Dict
from wiremq.processing import baseprocessor


class HTTPFormatter(baseprocessor.BaseProcessor):
    """
    HTTP Formatter
    ==============

    This class inherits the methods from :ref:`Base Processor`, while
    overriding the _process function and introducing a new _decode_data
    function.

    Attributes
    ----------
    _config  : dict
        Configuration of the content filter.
    _log: object
        Python logging instance.

    Methods
    -------
    _process : Dict
        Translates an HTTP request in bytes form into a Dict, using the
        HTTPRequest object.
    """

    def __init__(self, config: Dict = None):
        """HTTP Formatter constructor

        Parameters
        -----------
        config : dict
            type: str
                The type of the translator
            alias: str
                Translator's alias
            name: str
                Translator's name
            translator_id : hex
                Unique id using secrets lib with sha256 hashing.
            processor_queue: object
                Queue object for receiving and sending messages for processing.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        processor_queue = basequeue.BaseQueue(queue_fifo_config)
        config = {
            "alias": "HTTP Request Decoder",
            "name": "HTTP-DCDR Processor",
            "type": "HTTPRequestDecoder",
            "processor_queue": processor_queue
        }
        translator = httprequestdecoder.HTTPRequestDecoder(translator_config)
        """
        self._headers = config.get("headers", {})
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._log.rtn("%s: success" % self)

    def _process(self, data: Dict) -> Dict:
        """Translates an HTTP request in bytes form into a Dict. Overrides
        baseprocessor._process.

        Parameters
        ----------
        data : bytes, required
            This object will be sent to the decoding function.

        Returns
        -------
        _res: Dict
            An HTTP-formatted response string derived from the Dict parameter.
        """
        self._log.args("%s: (data: %s)" % (self, data))
        rtn = data["request_version"] + ' ' + str(data["error_code"])
        rtn = rtn + ' ' + data["error_message"] + '\r\n'
        for k, v in self._headers.items():
            rtn = rtn + k + ': ' + v + '\r\n'
        rtn = rtn + '\r\n'
        if "payload" in data:
            if self._headers["Content-Type"] == "application/json":
                payload = json.dumps(data["payload"])
            elif data.headers["Content-Type"] == "text/plain":
                payload = str(data["payload"])
            rtn = rtn + payload
        rtn = bytes(rtn, 'UTF-8')
        _res = {"status": "success", "data": rtn}
        self._log.rtn("%s: success | data: %s" % (self, _res))
        return _res
