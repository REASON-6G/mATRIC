# -*- coding: utf-8 - *-
"""BSON ContentDecoder"""

import bson
from typing import Dict
from wiremq.processing import baseprocessor
from wiremq.extlib.err.translatorexceptions import BSONDecoderException


class BSONContentDecoder(baseprocessor.BaseProcessor):
    """
    BSON Content Decoder
    ===================

    This class implements inherits the methods from :ref:`Base Processor`,
    while overriding the process function and introducing a new _decode_data
    function. Currently, channel registration, and use of the process() method
    is not included here.

    Methods
    -------
    _process : Dict
        Translates bytes data into Dict, using BSON decoder.
    """

    def __init__(self, config: Dict = None):
        """BSON ContentDecoder constructor

        Parameters
        -----------
        config : dict
            type: str
                The type of the translator
            alias: str
                Translator's alias
            name: str
                Translator's name
            translator_id : hex
                Unique id using secrets lib with sha256 hashing.
            processor_queue: object
                Queue object for receiving and sending messages for processing.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        processor_queue = basequeue.BaseQueue(queue_fifo_config)
        config = {
            "alias": "BSON Content Decoder",
            "name": "CDCODR Processor",
            "type": "BSONContentDecoder",
            "processor_queue": processor_queue
        }
        translator = bsoncontentdecoder.BSONContentDecoder(config)
        """
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._log.rtn("%s: success" % self)

    def _process(self, data: bytes) -> Dict:
        """Translates bytes data into Dict, using BSON decoder. Overrides
        baseprocessor._process

        Parameters
        ----------
        data : bytes, required
            This object will be sent to the decoding function.

        Returns
        -------
        _res: Dict
            The Dict data decoded from the bytes parameter, returned by the
            decoding function.
        """
        self._log.args("%s: (data: %s)" % (self, data))
        try:
            _res = {"status": "success", "data": bson.BSON.decode(data)}
        except bson.errors.InvalidBSON as e:
            self._log.error("Could not decode data, %s: %s" % (e, data))
            raise BSONDecoderException(e)

        self._log.rtn("%s: success | data: %s" % (self, _res))
        return _res
