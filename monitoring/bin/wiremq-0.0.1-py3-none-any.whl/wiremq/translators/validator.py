# -*- coding: utf-8 -*-
"""Validator Class."""

import time
import re
from typing import (
    Dict,
    Any
)
from wiremq.processing import baseprocessor


class Validator(baseprocessor.BaseProcessor):
    """
    Validator
    =========

    The base validator class, which also has the capability to validate
    dict representations of messages.

    Attributes
    ----------
    _config  : dict
        Configuration of the content filter.
    _log: object
        Python logging instance.


    Methods
    -------
    _process() : Dict
        Overrides method of base process.
    _validate_header() : Dict
        Validates the message header.
    _validate_payload() : Dict
        Validates the message payload.
    _validate_version() : bool
        Validates the verison of the message.
    _validate_format() : bool
        Validates the format of the message.
    _validate_command() : bool
        Validates the message command.
    _validate_timestamp() : bool
        Validates the message timestmap.
    _validate_ip_format() : bool
        Validates ip format.
    _validate_signature() : bool
        Validates message signature.

    Example
    -------
    >>> processor_queue = basequeue.BaseQueue(queue_fifo_config)
    >>> config = {
    >>>     "type" : "validator"
    >>>     "alias": "Validator translator",
    >>>     "name": "VNF validator",
    >>>     "hash_method": {
    >>>         "length": 32,
    >>>         "function": "sha256"
    >>>     },
    >>>     "processor_queue": processor_queue,
    >>>     "recv_window": 100000,
    >>>     "known_commands": [1, 2, 3, 4],
    >>>     "version_list": ["0.0.1"],
    >>>     "header_format": {
    >>>         "protocol_version": str,
    >>>         'timestamp': float,
    >>>         'echo': float,
    >>>         'sender_ip': str,
    >>>         'sender_port': int,
    >>>         'sender_alias': str,
    >>>         'sender_signature': str,
    >>>         'return_ip': str,
    >>>         'return_port': int,
    >>>         'dest_ip': str,
    >>>         'dest_port': int,
    >>>         'fdest_ip': str,
    >>>         'fdest_port': int,
    >>>         'tx_id': int,
    >>>         'message_id': int,
    >>>         'correlation_id': int,
    >>>         'tx_correlation_id': int,
    >>>         'nonce': str,
    >>>         'position_id': int,
    >>>         'size': int,
    >>>     }
    >>> }
    >>> processor_queue.put(message)
    >>> validator.Validator(validator_config)
    >>> msg = processor_queue.get()
    >>> processor_queue.item_processed()
    """

    def __init__(self, config: Dict = None):
        """Validator class constructor.

        Parameters
        ----------
        config: Dict
            Configuration of the validator
            type: str
                The type of the translator
            alias: str
                Translator's alias
            name: str
                Translator's name
            hash_method: dict
                length: str
                    Length of the signature
                method: str
                    Hash method.
            recv_window: int
                How many seconds until the message is discarded
                Based on its original timestamp.
            known_commands: list
                List of known message commands
            version_list: list
                List of available versions
            header_format: dict
                Contains all the type of the message to be validated
            processor_queue: object
                Queue object for receiving and sending messages for processing.
            logger: str, optional
                Name of the logger instance.
        """
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._log.rtn("%s: success" % self)

    def _process(self, message: Any) -> Dict:
        """Validates a message according to the validation schema. Overrides
         baseprocessor._process"""
        self._log.info('_process')
        _header_val = self._validate_header(message)
        rtn = {"status": "success", "data": message}
        if _header_val is not True:
            rtn = {"status": "failure", "data": _header_val}
        _payload_val = self._validate_payload(message["payload"])
        if _payload_val is not True:
            rtn = {"status": "failure", "data": _payload_val}
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _validate_header(self, message: Dict) -> Any:
        """Validates message header.

        Returns
        -------
        ret: Any
            if no validation issues found, returns true, otherwise returns a
            message string.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        rtn = True
        if not self._validate_timestamp(message["timestamp"]):
            rtn = "Timestamp expired."
        elif not self._validate_version(message["version"]):
            rtn = "Protocol version not supported"
        elif not self._validate_format(message):
            rtn = "Header format is malformed."
        elif not self._validate_ip_format(message["sender_ip"]):
            rtn = "Sender ip doesnt match an IP format."
        elif not self._validate_ip_format(message["return_ip"]):
            rtn = "Return ip doesnt match an IP format."
        elif not self._validate_ip_format(message["dest_ip"]):
            rtn = "Destination ip doesnt match an IP format."
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _validate_payload(self, payload: Dict) -> Any:
        """Validate message payload.

        Returns
        -------
        ret: Any
            if no validation issues found, returns true, otherwise returns a
            message string.
        """
        self._log.args("%s: (payload: %s)" % (self, payload))
        rtn = True
        if not self._validate_command(payload["command"]):
            rtn = "Payload command is invalid."
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _validate_version(self, version: str) -> bool:
        """Validates the version of message."""
        self._log.args("%s: (version: %s)" % (self, version))
        rtn = True
        if version not in self._config["version_list"]:
            rtn = False
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _validate_format(self, message: Dict) -> bool:
        """Validates message format.

        Each message component is validated based on
        its configuration.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        _hdr = {**message}
        del _hdr["payload"]
        rtn = True
        if len(self._config["header_format"]) != len(_hdr):
            rtn = False
        for element, _type in self._config["header_format"].items():
            if element not in _hdr.keys():
                rtn = False
            if not isinstance(_hdr[element], _type):
                rtn = False
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _validate_command(self, command: int) -> bool:
        """Validates the message command."""
        self._log.args("%s: (command: %d)" % (self, command))
        rtn = True
        if command not in self._config["known_commands"]:
            rtn = False
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _validate_timestamp(self, ts: float) -> bool:
        """Validates nonce number."""
        self._log.args("%s: (ts: %d)" % (self, ts))
        _ts = time.time()
        _recv_window = _ts + self._config["recv_window"]
        rtn = True
        if _recv_window < ts and ts >= _ts:
            rtn = False
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _validate_ip_format(self, ip: str) -> bool:
        """Validates the ip format"""
        self._log.args("%s: (ip: %s)" % (self, ip))
        _ip_format = r"^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.)" \
                     r"{3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$"
        rtn = True
        if not bool(re.match(_ip_format, ip)):
            rtn = False
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
