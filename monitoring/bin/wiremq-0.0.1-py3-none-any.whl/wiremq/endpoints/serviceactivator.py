# -*- coding: utf-8 -*-

import json
import datetime
import threading
from typing import Dict
from wiremq.endpoints import baseendpoint
from wiremq.extlib.err.consumerexceptions import BaseConsumerException
from wiremq.extlib.err.processingexception import ThreadedSchedulerException
from wiremq.extlib.err.producerexceptions import BaseProducerException
from wiremq.extlib.err.queueexception import QueueFullException
from wiremq.extlib.err.endpointexceptions import EndpointException


class ServiceActivator(baseendpoint.BaseEndpoint):
    """
    Service Activator
    =================

    Service activator is a child class of :ref:`Base Endpoint`. It receives
    HTTP requests, converts them to wiremq format, activates services, and then
    returns an HTTP response.

    After instantiating a service activator, two consumers need to be
    registered with the following aliases: "consumer" and "httpconsumer";
    and two producers need to be registered with the following
    aliases: "producer" and "httpproducer".

    Notes
    -----

    This is the advanced API for the Service Activator, for the
    simplified gateway, please see :ref:`Service Activator Gateway`.

    Attributes
    ----------
    _services: Dict
        A mapping of requested service string to handler.
    _requests: Dict
        A mapping of incoming request's generate ID to the request.
    _response_handler: Handler
        The endpoint's response handler that dispatches to the http producer.
    _request_handler: Handler
        The endpoint's response handler that dispatches to the wmq producer.
    _server: object
        The Threaded HTTP Server, using HTTPRequestHandler as its handler.
    _thread: Thread
        The thread that targets the server's serve_forever method.
    _task_queue: Queue
        A queue to hold tasks populated by the service activator's eventloop.
    _message_queue: Queue
        A queue to hold messages to be received.
    _transaction_store: MessageStore
        A message store holding completed transactions.
    For other attributes, see :ref:`Base Endpoint`.

    Methods
    -------
    _process_message_inbound(): None
        Handles all incoming messages.
    _process_message_outbound(): None
        Handles outbound messages.
    _process_http_request(): None
        Processes http requests.
    _construct_message(): Dict
        Constructs wiremq message from http request dict.
    _process_wmq_response(): None
        Processes wmq responses.
    _process_event_message(): None
        Processes event messages.
    _validate_service(): Dict
        Validates service to make sure both it and the command are valid.
    _convert_headers(): Dict
        Converts items from a list of header fields/values into a dict.
    _add_services(): None
        Adds services to the services config.
    _remove_services(): None
        Removes services from the services config.
    start_server(): None
        Starts HTTP Request server.
    config(): bool
        Configures the endpoint.
    register(): bool
        Register components from config.
    run(): None
        Overrides base class method to start server before running the loop.
    start(): None
        Overrides threading.Thread's start method to also start the HTTP
        server.
    start_server(): None
        Starts HTTP Request server, call required when running the service
        activator in non-threaded mode.
    receive() list
        Extracts messages from the message queue that has been populated by
        a queue dispatcher.
    send(): None
        Adds a message to the outbound sending queue, to be sent in the
        endpoint's main loop.
    process(): None
        Consumes, processes, and produces messages. To be called on a loop
        to operate the endpoint.
    stop(): bool
        Stops the endpoint thread by invoking the set event.
    close():
        Closes the components of the service activator.

    Notes
    -----
    Handling of HTTP headers is case-insensitive (as per RFC 2616).
    """

    def __init__(self, config: Dict = None):
        """Base endpoint class constructor.
        Parameters
        ----------
        config: Dict (fields required unless otherwise stated)
            http_consumer: Consumer
                The endpoint's http consumer.
            http_producer: Producer
                The endpoint's http producer.
            request_handler: Handler
                The endpoint's request handler that dispatches to the wmq
                producer.
            response_handler: Handler
                The endpoint's response handler that dispatches to the http
                producer.
            services: Dict
                A mapping of requested service string to handler.
            requests: Dict
                A mapping of incoming request's generate ID to the request.
            eventloop: ioeventloop
                The loop that polls for events from the http and wmq
                in-sockets.

        Example
        -------
        >>> sa_config = {}
        >>> sa_config["durable_store"] = durable_ms
        >>> sa_config["persistent_store"] = persistent_ms
        >>> sa_config["idempotent_store"] = idempotent_ms
        >>> sa_config["eventloop"] = eventloop
        >>> sa_config["scheduler"] = scheduler
        >>> sa_config["task_queue"] = task_queue
        >>> sa_config["durable"] = True
        >>> sa_config["persistent"] = True
        >>> sa_config["idempotent"] = False
        >>> sa_config["wmq_insocket"] = wmq_insocket
        >>> sa_config["send_queue"] = send_queue
        >>> sa_config["response_handler"] = response_handler
        >>> sa_config["max_subscribers"] = 100
        >>> sa = serviceactivator.ServiceActivator(sa_config)
        >>> sa.register_consumer(httpconsumer)
        >>> sa.register_consumer(consumer)
        >>> sa.register_producer(httpproducer)
        >>> sa.register_producer(producer)
        """
        self._services = {}
        self._requests = {}
        self._response_handler = None
        self._request_handler = None
        self._server = None
        self._thread = None
        self._message_queue = None
        self._transaction_store = None
        self._http_host = None
        self._http_port = None
        super().__init__(config)

    def _process_message_inbound(self, data: Dict) -> None:
        """Handles all incoming messages.

        Called by baseendpoint's _handle_inbound method, this method takes a
        message, and processes it as either a

        Parameters
        ----------
        data: Dict
            A dictionary containing values extracted from an HTTP request.
        """
        self._log.args("%s: (data: %s)" % (self, data))
        self._received_queue.put(data)
        if data["type"] == "event":
            self._process_event_message(data)
        elif data["correlation_id"] == "":
            self._process_http_request(data)
        else:
            self._process_wmq_response(data)
        self._log.rtn("%s: success" % self)

    def _process_message_outbound(self, data: tuple) -> None:
        """Handles outbound messages.

        Parameters
        ----------
        data: tuple
            Contains the request/response handler and the request/response
            data.
        """
        self._log.args("%s: ()" % self)
        handler, data = data
        handler.handle(data)
        self._log.rtn("%s: success" % self)

    def _process_http_request(self, data: Dict) -> None:
        """Processes http requests.

        First, the request is validated. If it fails validation, an error
        response is sent back to the http server via the response handler.
        If validation succeeds, the request is stored in the durable store,
        if one is set. After this, the message is stored in a requests
        mapping, and a message is constructed and placed in the send queue,
        along with the request handler.

        Parameters
        ----------
        data: Dict
            A dictionary containing values extracted from an HTTP request.

        Raises
        ------
        EndpointException
            Throws an endpoint exception whenever the send queue is full.
        """
        self._log.args("%s: (data: %s)" % (self, data))
        validation = self._validate_service(data)
        if not validation["valid"]:
            message = validation["error_response"]
            self._response_handler.update_destination({
                "dest_host": data["sender_ip"],
                "dest_port": data["sender_port"]
            })
            handler = self._response_handler
        else:
            if "http_method" in data["payload"]:
                # If it's a new request:
                message_id = self._generate_id()
                tx_id = self._generate_id()
                message = self._construct_message(data, message_id, tx_id)
                self._requests[message_id] = data
                if data["payload"]["http_method"] == "POST":
                    message["payload"]["data"] = data.get("data", "")
                if self._history_store:
                    self._update_message_history(message)
            else:
                # If this is a repeat message after previously not being acked:
                message = self._get_message(
                    {
                        "store": self._history_store,
                        "where": {"message_id": data["message_id"]}
                    }
                )
                message = message[0][1]
            if self._durable_store:
                self._store_durable(
                    message,
                    (message["dest_ip"], message["dest_port"])
                )
            handler = self._request_handler
        try:
            self._send_queue.put((handler, message))
        except QueueFullException as e:
            self._log.error(e)
            raise EndpointException(e)
        self._log.rtn("%s: success" % self)

    def _construct_message(self,
                           data: Dict,
                           message_id: str,
                           tx_id: str) -> Dict:
        """Constructs wiremq message from http request dict.

        Parameters
        ----------
        data: Dict
            A dictionary containing values extracted from an HTTP request.
        message_id: str
            The message id to use for the wiremq message's message_id field.
        tx_id: str
            The transaction id to use for the wiremq message's tx_id field.

        Returns
        -------
        message: Dict
            A WireMq message with the header fields partially supplied.

        Raises
        ------
        EndpointException
            Throws an endpoint exception whenever the send queue is full.
        """
        self._log.args(
            "%s: (data: %s, message_id: %s, tx_id: %s)" % (
                self, data, message_id, tx_id
            )
        )
        message = {
            "message_id": message_id,
            "correlation_id": "",
            "tx_id": tx_id,
            "tx_correlation_id": "",
            "dest_ip": data["dest_ip"],
            "dest_port": data["dest_port"],
            "type": data["type"],
            "method": data["method"],
            "payload": {
                "http_headers": self._convert_headers(
                    data["payload"].get("headers", [])
                ),
                "service": data["payload"]["service"],
                "command": data["payload"]["command"],
                "params": data["payload"]["params"]
            },
            "datetime": datetime.datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S.%f"
            )
        }

        self._log.rtn("%s: success | data: %s" % (self, message))
        return message

    def _process_wmq_response(self, data: Dict) -> None:
        """Processes wmq response.

        First, the response message's tx_correlation_id is used to retrieve
        the original request from the requests mapping. If a transaction store
        is set, the request is stored in the store. The response handler's
        destination values are updated with the request's sender ip/port, and
        the message is then placed in the send queue along with the response
        handler.

        Parameters
        ----------
        data: Dict
            A dictionary containing the response to an HTTP request.

        Raises
        ------
        EndpointException
            Throws an endpoint exception whenever the send queue is full.
        """
        self._log.args("%s: (data: %s)" % (self, data))
        req = self._requests.get(data["correlation_id"])
        if self._transaction_store and req:
            self._store_message({
                "store": self._transaction_store,
                "data": {
                    "transaction_id": req["payload"]["request_id"],
                    "transaction_data": json.dumps(req),
                    "transaction_time": datetime.datetime.now().strftime(
                        "%Y-%m-%d %H:%M:%S.%f"
                    )
                }
            })
        if req:
            self._response_handler.update_destination({
                "dest_host": req["sender_ip"],
                "dest_port": req["sender_port"]
            })
            data["payload"].update({"request_id": req["payload"]["request_id"]})
            try:
                self._send_queue.put((self._response_handler, data))
            except QueueFullException as e:
                self._log.error(e)
                raise EndpointException(e)
            del self._requests[data["correlation_id"]]
        self._log.rtn("%s: (data: %s)" % (self, data))

    def _process_event_message(self, data: Dict) -> None:
        """Processes event messages.

        Handles event messages, stores items in the history store. Handles
        removal of messages from the durable store if an acknowledgement is
        received. Handles

        Parameters
        ----------
        data: Dict
            A dictionary containing header/payload for an event message.

        Raises
        ------
        EndpointException
            Throws an endpoint exception whenever the send queue is full.
        """
        self._log.args("%s: (data: %s)" % (self, data))
        self._received_queue.put(data)
        self._log.rtn("%s: success" % self)

    def _validate_service(self, data: Dict) -> Dict:
        """Validates service to make sure both it and the command are valid.

        The method first makes sure that the requested service exists in the
        service activator's services mapping. If it does, a validation check
        is then performed on the requested command to ensure that also exists
        within the mapping. If either check fails, an error response is
        constructed, to be sent back to the http request server.

        Parameters
        ----------
        data: Dict
            A dictionary containing values extracted from an HTTP request.

        Returns
        -------
        rtn: bool
            True if the service and command are both valid. False, otherwise.

        Raises
        ------
        EndpointException
            Throws an endpoint exception whenever the send queue is full.
        """
        self._log.args("%s: (data: %s)" % (self, data))
        result = {
            "valid": True
        }
        if "service" not in data["payload"]:
            # One or more items were missing in the path (if one is missing
            # service, command, api, and api_version are omitted from the
            # handler)
            result["valid"] = False
            result["error_message"] = "Badly formed URL path. Request path " \
                                      "must follow format api/api_version/" \
                                      "service/command or api/api_version/" \
                                      "service?commands"
        elif data["payload"]["service"] not in self._services.keys():
            result["valid"] = False
            result["error_message"] = "Service not found"
        elif (
            not data["payload"]["command"]
            in self._services[data["payload"]["service"]]
        ):
            result["valid"] = False
            result["error_message"] = "Command not found"

        rtn = {
            "valid": result["valid"]
        }
        if not result["valid"]:
            rtn["error_response"] = {
                "error_code": 400,
                "error_message": result["error_message"],
                "payload": {
                    "request_id": data["payload"]["request_id"],
                    "error_message": result["error_message"]
                }
            }
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _convert_headers(self, headers: list) -> Dict:
        """Converts items from a list of header fields/values into a dict.

        If headers are not found, returns empty dict.

        Parameters
        ----------
        headers: List
            A list of 2-element lists containing HTTP header fields and values.

        Returns
        -------
        rtn: Dict
            A dictionary that contains header fields as keys, along with
            associated values. If no headers exist, return an empty
            dictionary.
        """
        self._log.args("%s: (scope: %s)" % (self, headers))
        http_headers = {}
        for item in headers:
            http_headers[item[0]] = item[1]
        self._log.rtn("%s: success | data: %s" % (self, http_headers))
        return http_headers

    def _add_services(self, services: Dict) -> None:
        """Adds services to the services config.

        Parameters
        ----------
        services: Dict
            A mapping of paths to handlers

        Example
        -------
        battery_info_handler = batteryhandler.BatterHandler()
        wifi_info_handler = wifiinfohandler.WifiInfoHandler()
        services = {
            'battery': ["get_voltage", "get_life"],
            'node': ["get_info"]
        }
        service_activator._add_services(services)
        """
        self._log.args("%s: (services: %s)" % (self, services))
        self._services.update(services)
        self._log.rtn("%s: success" % self)

    def _remove_services(self, services: list) -> None:
        """Removes services from the services config.

        Parameters
        ----------
        services: Dict
            A mapping of paths to handlers

        Example
        -------
        services = ["battery", "wifi"]
        service_activator._remove_services(services)
        """
        self._log.args("%s: (services: %s)" % (self, services))
        for service in services:
            del self._services[service]
        self._log.rtn("%s: success" % self)

    def config(self, config: Dict) -> bool:
        """Configures the endpoint.

        Parameters
        ----------
        config: Dict
            services: Dict
                A mapping of httprequest paths (services) to request handlers.
            requests: Dict, optional
                A mapping of httprequest ID to existing httprequest.
            http_host: str
                Hostname for the HTTP server (e.g. "0.0.0.0").
            http_port: int
                Port number for the HTTP server.
            https_enabled: bool (optional, default = False)
                Flag to denote use of HTTPS (True: HTTPS, False, HTTP).
            ssl_keyfile: str (only required if use_http==True)
                Full path to SSL Key File.
            ssl_certfile: str( only required if use_http==True)
                Full path to SSL Certificate File.

        Returns
        -------
        rtn: bool
            True if successful
        """
        super().config(config)
        self._log.args("%s: (config: %s)" % (self, config))
        self._services = config["services"]
        self._requests = config.get("requests", {})
        self._http_host = config["http_host"]
        self._http_port = config["http_port"]
        self._log.rtn("%s: success" % self)
        return True

    def register(self, config: Dict) -> bool:
        """Register components from config.

        Parameters
        ----------
        config: Dict (fields required unless otherwise stated)
            See BaseEndpoint for other fields required
            request_handler: Handler
                The endpoint's request handler.
            response_handler: Handler
                The endpoint's response handler.
            httpserver:
                The endpoint's HTTP server, from
                http.server.ThreadingHTTPServer
            transaction_store: MessageStore
                A message store holding completed transactions.
        Returns
        -------
        rtn: bool
            True if successful
        """
        self._log.args("%s: (config: %s)" % (self, config))
        self._request_handler = config["request_handler"]
        self._response_handler = config["response_handler"]
        self._server = config["httpserver"]
        self._message_queue = config.get("message_queue")
        self._transaction_store = config.get("transaction_store")
        super().register(config)
        self._log.rtn("%s: success" % self)
        return True

    def run(self) -> None:
        """Overrides base class method to start server before running the loop.
        """
        self._log.args("%s: ()" % self)
        super().run()

    def start(self) -> None:
        """Overrides threading.Thread's start method to also start the HTTP
        server."""
        super().start()
        self.start_server()

    def start_server(self) -> None:
        """Starts HTTP Request server, call required when running the service
        activator in non-threaded mode.
        """
        self._log.args("%s: ()" % self)
        self._thread = threading.Thread(target=self._server.run)
        self._thread.start()
        self._log.rtn("%s: success" % self)

    def receive(self) -> list:
        """Extracts messages from the message queue that has been populated by
        a queue dispatcher.

        Messages extracted from this queue have been received by the consumer.
        Once messages have been received they are marked as processed.

        Returns
        -------
        rtn: list
            List of messages from the message queue.
        """
        self._log.args("%s: ()" % self)
        super().receive()
        rtn = []
        while not self._message_queue.empty():
            _item = self._message_queue.get()
            rtn.append(_item)
            self._message_queue.item_processed()
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def send(self, msg: Dict) -> None:
        """Adds a message to the outbound sending queue, to be sent in the
        endpoint's main loop.

        Parameters
        ----------
        msg: Dict
            Message to be sent.
        """
        self._log.args("%s: (msg: %s)" % (self, msg))
        super().send(msg)
        self._process_wmq_response(msg)
        self._log.rtn("%s: success" % self)

    def process(self) -> None:
        """Consumes, processes, and produces messages. To be called on a loop
        to operate the endpoint."""
        self._log.args("%s: ()" % self)
        try:
            self.consume("consumer")
            self._eventloop.run_once()
            self._handle_inbound()
            self._handle_outbound()
            self.produce("producer")
        except (BaseProducerException, BaseConsumerException) as e:
            self._log.error(e)
            raise EndpointException(e)
        except ThreadedSchedulerException as e:
            self._log.error(e)
            raise EndpointException(e)
        self._log.rtn("%s: success" % self)

    def stop(self) -> bool:
        """Stops the endpoint by joining the thread and invoking the set event.

        Returns
        -------
        rtn: bool
            True if successful
        """
        self._log.args("%s: ()" % self)
        self._thread.join()
        super().stop()
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def close(self) -> bool:
        """Closes the components of the service activator.

        Returns
        -------
        rtn: bool
            True if successful, False otherwise.
        """
        self._log.args("%s: ()" % self)
        self._request_handler.close()
        self._response_handler.close()
        self._request_handler = None
        self._response_handler = None
        self._requests.clear()
        self._services.clear()
        self._server.should_exit = True
        rtn = super().close()

        return rtn
