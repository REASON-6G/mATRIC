# -*- coding: utf-8 -*-
"""Message store wrapper around a database (plugin) connector."""

from typing import Dict
import uuid
import logging
from wiremq.extlib.err.sysmanagementexceptions import MessageStoreException
from wiremq.extlib.err.databaseexception import (
    DBInsertException,
    DBSelectException,
    DBUpdateException,
    DBDeleteException,
)


class MessageStore:
    """
    Message Store
    =============

    Message store wrapper around database (plugin) connector.

    Attributes
    ----------
    _config: Dict
        MessageStore configuration dictionary.
        db_conn: object
            The database connection object to use.
        db_table: str
            The name of the table to use within the database.
    _log: object
        Python logging instance.

    Methods
    -------
    _generate_id(): str
        Generates a unique id for the message store.
    config(): None
        Configures the message store.
    get(): Dict
        Retrieves message(s) from the message store.
    store(): int
        Stores a message in the message store.
    update(): bool
        Updates an existing message in the message store.
    remove(): int
        Removes a message from the message store.
    """

    def __init__(self, config: Dict = None) -> None:
        """Message store constructor.

        Assigns config and database connection variables.

        Parameters
        ----------
        config: Dict
            db_conn: object
                The database connection object to use.
            db_table: str
                The name of the table to use within the database.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> conn = sqlitedbconn.SQLiteDBConn(sqlitedbconn_config)
        >>> messagestore_config = {
        ...     "db_table": "messages",
        ...     "db_conn": conn
        ... }
        >>> ms = messagestore.MessageStore(messagestore_config)
        """
        self._config = None
        self._log = None
        self._id = self._generate_id()
        if config:
            self.config(config)

    def _generate_id(self) -> str:
        """Generates a unique id for the message store.

        Returns
        -------
        rtn: str
            The unique ID of the endpoint, cast from UUID4 to string.
        """
        self._id = uuid.uuid4()
        rtn = str(self._id)
        return rtn

    def config(self, config: dict) -> None:
        """Configures the message store.

        Parameters
        ----------
        config: Dict
            Message store configuration dictionary.
            db_conn: object
                The database connection object to use.
            db_table: str
                The name of the table to use within the database.
        """
        self._config = config
        self._log = logging.getLogger(config.get("logger", "basic_logger"))

    def get(
        self, where: Dict = None, limit: int = None, order_by: list = None
    ) -> Dict:
        """Retrieves message(s) from the message store.

        While the values are potentially optional, not all of them can be
        omitted. The get method needs to be called with either a where
        argument, or alternatively with both a limit and order_by argument.

        Parameters
        ----------
        where : Dict, optional
            A dictionary where the keys correspond to column names and the
            values to those values used when selecting from the message
            store's db.
        limit: int, optional
            The number of results to return, if not getting a single
            record by ID.
        order_by: list, optional
            The ordering of the results. The format of the parameter is a list
            of tuples, where the first tuple value is the column name, as a
            string, and the second value is one of the two strings, "ASC" or
            "DESC".

        Example
        -------
        ms = messagestore.MessageStore(ms_config)
        multiple_results = ms.get(
            limit=5,
            order_by=[
                ("col", "DESC"),
                ("col2", "ASC")
            ]
        )
        single_result = ms.get(message_id="3fa7d0")

        Returns
        -------
        message: Dict
            The message corresponding to the message_id argument.

        Raises
        ------
        MessageStoreException:
            Exception raising an error when the select query fails.
        """
        # self._log.args("%s: (message_id: %s, limit: %s, order_by: %s)"
        #                % (self, where, limit, order_by))

        try:
            rtn = self._config["db_conn"].select(
                _table=self._config["db_table"],
                _where=where,
                _order_by=order_by,
                _limit=limit
            )
        except DBSelectException as e:
            self._log.error(e)
            raise MessageStoreException(e)
        except Exception as e:
            self._log.error(e)
            raise MessageStoreException(e)
        self._log.rtn("success | rtn: %s" % rtn)
        return rtn

    def store(self, message: Dict) -> bool:
        """Stores a message in the message store.

        Parameters
        ----------
        message: dict
            The message to store in the message store.

        Returns
        -------
            A bool value representing success of insertion.

        Raises
        ------
        MessageStoreException:
            Exception raising an error when the insert query fails.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        try:
            _insert = self._config["db_conn"].insert(
                self._config["db_table"], message)
        except DBInsertException as e:
            self._log.error(e)
            raise MessageStoreException(e)
        self._log.rtn("success | _insert: %s" % _insert)
        return _insert

    def update(self, where: Dict, message: Dict) -> bool:
        """Updates an existing message in the message store.

        Parameters
        ----------
        where : Dict, optional
            A dictionary where the keys correspond to column names and the
            values to those values used for selecting a row when updating.
        message: Dict
            A dictionary where the keys correspond to column names and the
            values to the values to be set when updating the db values.

        Returns
        -------
            A bool value representing success of update.

        Raises
        ------
        MessageStoreException:
            Exception raising an error when the update query fails.
        """
        self._log.args("%s: (where: %s, message %s)" %
                       (self, where, message))
        try:
            _update = self._config["db_conn"].update(
                _table=self._config["db_table"],
                _set=message,
                _where=where,
            )
        except DBUpdateException as e:
            self._log.error(e)
            raise MessageStoreException(e)
        self._log.rtn("success | _update: %s" % _update)
        return _update

    def remove(self, where: Dict) -> bool:
        """Removes a message from the message store.

        Parameters
        ----------
        where : Dict, optional
            A dictionary where the keys correspond to column names and the
            values to those values used for selecting a row when removing.

        Returns
        -------
            A bool value representing success of deletion.

        Raises
        ------
        MessageStoreException:
            Exception raising an error when the delete query fails.
        """
        self._log.args("%s: (where: %s)" % (self, where))
        try:
            _delete = self._config["db_conn"].delete(
                self._config["db_table"], where
            )
        except DBDeleteException as e:
            self._log.error(e)
            raise MessageStoreException(e)
        self._log.rtn("success | _delete: %s" % _delete)
        return _delete
