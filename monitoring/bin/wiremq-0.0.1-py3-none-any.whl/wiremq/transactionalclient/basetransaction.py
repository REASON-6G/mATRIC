# -*- coding: utf-8 -*-

import logging
from typing import (
    Dict,
    Any
)
from hashlib import (
    sha256
)
from secrets import (
    token_bytes
)
from wiremq.transactionalclient import (
    abstracttransaction
)


class BaseTransaction(abstracttransaction.AbstractTransaction):
    """
    Base Transaction
    ================

    A transaction is an object that holds a set of defined procedures to be
    executed based on different types of tasks.

    Attributes
    ----------
    _config : Dict
        The data required for the transaction.
    _id : str
        The unique identifier for the instantiated transaction.
    _session : basesession.BaseSession
        The session object, for the tx to populate the message header
        fields
    _log: object
        Python logging instance.

    Methods
    -------
    config: None
        Configure the transaction with a dict argument
    get_config(self) : Dict
        Return the config dict
    execute : bool
        Calls appropriate method for the current stage of the transaction
    start : bool
        The initial method in the transaction
    finish : bool
        A method called once all procedures have been executed, to signify
        that the transaction has been completed and can be removed from the
        transaction list
    get_id : int
        Returns the unique id for the transaction
    _populate_payload : Dict
        Sets fields and values for the payload fields
    _set_message_id : str
        A helper method for _populate_payload
    _set_transaction_id : str
        A helper method for _populate_payload
    """

    def __init__(self, config: Dict) -> None:
        """Base transaction constructor

        Parameters
        ----------
        config : Dict
            The parameters required for a transaction
            type : string
                The string representation of the tx type; i.e. pingrequest
            session : basesession.BaseSession
                The session object, for the tx to populate the message header
                fields
            tx_id : str
                The tx id, used to populate the respective payload field
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        config = {
            "type": tx_type,
            "session": csession
            "tx_id" = tx_id
        }
        btx = basetransaction.BaseTransaction(config)
        """
        super().__init__()
        self._config = None
        self._id = None
        self._log = None
        if config:
            self.config(config)

    def config(self, config: Dict) -> None:
        """Config transaction with dict

        Parameters
        ----------
        config : Dict
            The parameters required for a transaction
            type : string
                The string representation of the tx type; i.e. pingrequest
            session : basesession.BaseSession
                The session object, for the tx to populate the message header
                fields
            tx_id : str
                The tx id, used to populate the respective payload field
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        config = {
            "type": tx_type,
            "session": csession
            "tx_id" = tx_id
        }
        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._id = config["tx_id"]
        self._config = config
        self._log.rtn("%s: success" % self)

    def get_config(self) -> Dict:
        """Return the transaction's config

        Returns
        -------
        _config : Dict
            The config of the transaction
        """
        self._log.info('get_tx_config')
        return self._config

    def execute(self, config: Dict = None) -> Any:
        """Execute procedure

        Parameters
        ----------
        config : Dict
            The data optionally required by some transations, in order to run.
            If not None, it usually contains a received message that's required
            to populate the payload of a message created in response

        Example
        -------
        config = {
            'protocol_version': '0.0.1',
            'timestamp': 1580131898.357799,
            'echo': 1580131941.151655,
            'sender_ip': '192.168.1.29',
            'sender_port': 65535,
            'sender_alias': "senderAlias",
            'sender_signature': "signature",
            'return_ip': '192.168.1.28',
            'return_port': 65535,
            'dest_ip': '192.168.1.28',
            'dest_port': 65535,
            'fdest_ip': '192.168.1.28',
            'fdest_port': 65535,
            'nonce': 'nonce2324',
            'payload': {
                'tx_id': 1,
                'message_id': 20,
                'correlation_id': None,
                'tx_correlation_id': None,
                'position_id': 1,
                'size': 1,
                'command': 1,
                'params': {
                    'type': 'core',
                    'mem': 1654821
                }
            }
        }

        Returns
        -------
        bool
            A transaction completion flag, signaling the end of the transaction
        """
        self._log.info('execute')
        return self._start(config)

    def _start(self, config: Dict = None) -> Any:
        """Execute initial procedures

        Parameters
        ----------
        config : Dict
            Parameters for the initial transaction procedure. See parameters
            section of the execute method above for full details

        Example
        -------
        For a full example, see the example in the execute method above,
        since that argument would be passed on to the start method

        Returns
        -------
        bool
            A transaction completion flag, signaling the end of the transaction
        """
        self._log.info('_start')
        return True

    def finish(self) -> Any:
        """Perform any final procedures after transaction has completed

        Returns
        -------
        bool
            Completion flag to signify the end of the transaction
        """
        self._log.info('finish')
        return {"finished": True}

    def get_id(self) -> int:
        """Return transaction id

        Returns
        -------
        int
            The unique id of the transaction
        """
        self._log.info('get_id')
        return self._id

    def _populate_payload(self, fields: Dict, msg: Dict = None) -> Dict:
        """Populate the keys of the payload with values

        Parameters
        ----------
        fields : Dict
            A dict containing the keys of the payload to be populated, as keys
            of the fields dict, and the values are a tuple consisiting of the
            associated method within the transaction object, and a flag for
            whether the function needs an argument passed.
            message_id : tuple
            tx_id : tuple
            correlation_id : tuple
            tx_correlation_id : tuple
            position : tuple
            size : tuple

        msg : Dict
            A dict containing the payload of a received message. This is then
            passed to any helper function that requires an argument, as
            indicated by a boolean flag in the tuple value of the fields dict
            above. A value may then be taken from a field of this dict, to be
            used in the final payload dict to be returned by this method.

        Example
        -------
        fields = {
            'message_id': ("_set_message_id", 0),
            'tx_id': ("_set_transaction_id", 0),
            'correlation_id': ("_set_correlation_id", 1),
            'tx_correlation_id': ("_set_transaction_correlation_id", 1),
            'position': ("_set_position", 0),
            'size': ("_set_size", 0)
        }

        msg = {
            'message_id': '19a0723ec9d04b01bba426092b60dc55ae3',
            'tx_id': 'c277c3135985002a7a26107358bc76ae834',
            'correlation_id': '',
            'tx_correlation_id': '',
            'position': 1,
            'size': 1,
            'command': 7
        }

        Returns
        -------
        _payload : Dict
            A dictionary with any required fields populated
        """
        self._log.info('_populate_payload')
        _payload = {}
        for k, val in fields.items():
            if hasattr(self, val[0]):
                if val[1] == 1:
                    _payload[k] = getattr(self, val[0])(msg)
                else:
                    _payload[k] = getattr(self, val[0])()
            else:
                _payload[k] = ""
        return _payload

    def _set_message_id(self) -> str:
        """Create a message id with sha256, to set the payload field

        Returns
        -------
        id : str
            An id, for use in message payloads, to uniquely identify messages.
        """
        self._log.info('_set_message_id')
        return sha256(token_bytes(32)).hexdigest()

    def _set_transaction_id(self) -> str:
        """Return the transaction id to set the payload field

        Returns
        -------
        _id : str
            The id of the transaction, used in the message payload to connect
            the message to the transaction that created/sent it.
        """
        self._log.info('_set_transaction_id')
        return self._id
