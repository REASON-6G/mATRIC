# -*- coding: utf-8 -*-
""" abstract transaction class """

from typing import (
    Dict
)
from abc import (
    ABC,
    abstractmethod
)


class AbstractTransaction(ABC):
    """
    Abstract Transaction
    ====================
    """

    def __init__(self):
        super().__init__()

    @abstractmethod
    def config_transaction(self, config: Dict) -> None:
        pass

    @abstractmethod
    def get_config(self) -> Dict:
        pass

    @abstractmethod
    def execute(self, config: Dict = None) -> bool:
        pass

    @abstractmethod
    def _start(self, config: Dict) -> bool:
        pass

    @abstractmethod
    def finish(self) -> bool:
        pass

    @abstractmethod
    def get_id(self) -> int:
        pass

    @abstractmethod
    def _populate_payload(self, fields: Dict, msg: Dict = None) -> Dict:
        pass

    @abstractmethod
    def _set_message_id(self) -> hash:
        pass

    @abstractmethod
    def _set_transaction_id(self) -> hash:
        pass
