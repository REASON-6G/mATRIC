# -*- coding: utf-8 -*-

from typing import (
    Dict,
    Any
)
from abc import (
    ABC,
    abstractmethod
)


class AbstractConsumer(ABC):
    """
    Abstract Consumer
    =================

    Abstract class which defines the required methods for any consumer.
    """

    def __init__(self, config: Dict = None):
        """Abstract consumer class constructor."""
        pass

    @abstractmethod
    def register(self, config: Dict) -> bool:
        """Register components from config."""
        pass

    @abstractmethod
    def get_config(self) -> Dict:
        """Gets the Consumer configuration."""
        pass

    @abstractmethod
    def poll_engine(self) -> Any:
        """Polls eventloop for events, returns a queue of tasks."""
        pass

    @abstractmethod
    def run(self) -> None:
        """Continuously run polling loop."""
        pass

    @abstractmethod
    def run_once(self) -> None:
        """Running polling loop once."""
        pass

    @abstractmethod
    def _loop(self) -> None:
        """Poll once for tasks and execute."""
        pass

    @abstractmethod
    def _execute_scheduled(self) -> None:
        """Execute tasks in the task queue."""
        pass

    @abstractmethod
    def _handle_task_results(self, results: list) -> None:
        """Helper method to separate successful from failed tasks."""
        pass

    @abstractmethod
    def _handle_success(self, task: Any) -> None:
        """Helper method to handle successful tasks."""
        pass

    @abstractmethod
    def _handle_failure(self, task: Any) -> None:
        """Helper method to handle failed tasks."""
        pass

    @abstractmethod
    def _store_message(self, message: Dict) -> bool:
        """Store message in a store."""
        pass

    @abstractmethod
    def _get_message(self, message_id: str) -> Any:
        """Retrieve a message from a message store."""
        pass

    @abstractmethod
    def _remove_message(self, message_id: str) -> bool:
        """Remove message from a store."""
        pass

    @abstractmethod
    def unregister(self) -> bool:
        """Unregisters consumer components from the baseconsumer."""
        pass

    @abstractmethod
    def close(self) -> bool:
        """Stops listening."""
        pass
