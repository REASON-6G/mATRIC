from wiremq.extlib.err import wmqexception


class QueueDispatcherException(wmqexception.WmqException):
    """
    Queue Dispatcher Exception
    ==========================

    Exception raised for errors relating to queue dispatcher errors.
    """

    def __init__(self, message: str) -> None:
        message = "[QueueDispatcherException] " + str(message)
        super().__init__(message)


class SocketDispatcherException(wmqexception.WmqException):
    """
    Socket Dispatcher Exception
    ===========================

    Exception raised for errors relating to socket dispatcher errors."""

    def __init__(self, message: str) -> None:
        message = "[SocketDispatcherException] " + str(message)
        super().__init__(message)
