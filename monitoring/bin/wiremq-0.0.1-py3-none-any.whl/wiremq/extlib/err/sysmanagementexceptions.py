from wiremq.extlib.err import wmqexception


class MessageStoreException(wmqexception.WmqException):
    """
    Message Store Exception
    =======================

    Exception raised for errors relating to message store errors."""

    def __init__(self, message: str) -> None:
        message = "[MessageStoreException] " + str(message)
        super().__init__(message)
