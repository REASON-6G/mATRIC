from wiremq.extlib.err import wmqexception


class HTTPRequestHandlerException(wmqexception.WmqException):
    """
    HTTP Request Handler Exception
    ==============================

    Exception raised for errors relating to queue dispatcher errors.
    """

    def __init__(self, message: str) -> None:
        message = "[HTTPRequestHandlerException] " + str(message)
        super().__init__(message)
