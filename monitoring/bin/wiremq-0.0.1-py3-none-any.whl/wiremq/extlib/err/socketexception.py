from wiremq.extlib.err import wmqexception


class SocketException(wmqexception.WmqException):
    """
    Socket Exception
    ================

    Exception raised when an OS error occurs on a socket.
    """
    def __init__(self, message: str):
        message = "[SocketException] " + str(message)
        super().__init__(message)


class SocketGAIException(wmqexception.WmqException):
    """
    Socket GAI Exception
    ====================

    Exception raised for address related errors.
    """
    def __init__(self, message: str):
        message = "[SocketGAIException] " + str(message)
        super().__init__(message)

    def _make_log(self):
        """Overrides wmqexception _make_log method to raise this exception as
        CRITICAL"""
        self._log.critical(self._message)


class SocketConnectionRefusedException(wmqexception.WmqException):
    """
    Socket Connection Refused Exception
    ===================================

    Exception raised when a socket connection is refused.
    """
    def __init__(self, message: str):
        message = "[SocketConnectionRefusedException] " + str(message)
        super().__init__(message)

    def _make_log(self):
        """Overrides wmqexception _make_log method to raise this exception as
        CRITICAL"""
        self._log.critical(self._message)


class SocketBrokenPipeException(wmqexception.WmqException):
    """
    Socket Broken Pipe Exception
    ============================

    Exception raised when sending to an offline/non-existent socket.
    """
    def __init__(self, message: str):
        self._log = None
        message = "[SocketBrokenPipeException] " + str(message)
        super().__init__(message)

    def _make_log(self):
        """Overrides wmqexception _make_log method to raise this exception as
        CRITICAL"""
        self._log.critical(self._message)


class SocketConnectionResetException(wmqexception.WmqException):
    """
    Socket Connection Reset Exception
    =================================

    Exception raised when socket connection is reset.

    This may occur when the receiving socket is receiving more bytes than it is
    configured to.
    """
    def __init__(self, message: str):
        message = "[SocketConnectionResetException] " + str(message)
        super().__init__(message)

    def _make_log(self):
        """Overrides wmqexception _make_log method to raise this exception as
        CRITICAL"""
        self._log.critical(self._message)


class SocketNotFoundException(wmqexception.WmqException):
    """
    Socket Not Found Exception
    ==========================

    Exception raised when trying to send a socket which does not exist.
    """
    def __init__(self, message: str):
        message = "[SocketNotFoundException] " + str(message)
        super().__init__(message)

    def _make_log(self):
        """Overrides wmqexception _make_log method to raise this exception as
        CRITICAL"""
        self._log.critical(self._message)
