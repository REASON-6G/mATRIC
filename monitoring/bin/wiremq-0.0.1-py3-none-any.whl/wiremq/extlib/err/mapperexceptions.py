from wiremq.extlib.err import wmqexception


class BaseMapperException(wmqexception.WmqException):
    """
    Base Mapper Exception
    =====================

    Exception raised when a mapper throws an error.
    """

    def __init__(self, message: str):
        message = "[BaseMapperException] " + str(message)
        super().__init__(message)
