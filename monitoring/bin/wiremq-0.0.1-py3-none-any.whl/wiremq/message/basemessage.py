# -*- coding: utf-8 -*-

""" base message class """

import uuid
from typing import (
    Dict,
    Any
)
from wiremq.message import abstractmessage


class BaseMessage(abstractmessage.AbstractMessage):
    """
    Base Message
    ============

    Obsolete. Use :

    Attributes
    ----------
    _header : Dict
        The header fields of a message, such as destination ip
    _payload : Dict
        The payload of a message

    Methods
    -------
    _init
        Extracts data from parameters passed to an initialised message
        object, in order to assign values to the class' three attributes.
    get_header
        Return the value stored in _header.
    get_payload
        Return the value stored in _payload.
    update_header
        Update the header dictionary with passed parameters
    update_payload
        Update the payload dictionary with passed parameters
    get_message
        Returns a dictionary consisting of the header and payload
    """

    def __init__(self, header: Dict = None, payload: Any = None) -> None:
        """Base message class

        Initialize an message. It can either be instantiated with a header
        and/or payload, or these can be added afterwards.

        Parameters
        ----------
        header: Dict, optional
            A dictionary containing the header information of a message,
            including fields like the destination ip address of a message.

        payload: Dict, optional
            A dictionary containing the command and any parameters to be
            executed by a consumer/receiver.

        Example
        -------
        header = {
            'protocol_version': '0.0.1',
            'timestamp': 1580131898.357799,
            'echo': 1580131941.151655,
            'sender_ip': '192.168.1.29',
            'sender_port': 65535,
            'sender_alias': "senderAlias",
            'sender_signature': "signature",
            'return_ip': '192.168.1.28',
            'return_port': 65535,
            'dest_ip': '192.168.1.28',
            'dest_port': 65535,
            'fdest_ip': '192.168.1.28',
            'fdest_port': 65535,
            'tx_id': 1,
            'message_id': 20,
            'correlation_id': None,
            'tx_correlation_id': None,
            'nonce': 'nonce2324',
            'position_id': 1,
            'size': 1,
        }

        payload = {
            'payload': {
                'command': 2,
                'params': {
                    'type': 'core',
                    'mem': 1654821
                }
            }
        }

        """
        super().__init__()
        self._id = self._generate_id()
        self._header = None
        self._payload = None
        self._init(header, payload)

    def __repr__(self):
        return str(self.get_header_and_payload())

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def _init(self, header: Dict, payload: Any) -> None:
        """Handle message when first initialised.

        See docstring for __init__ above for parameter, example, and
        return values
        """
        if header is None:
            header = {}
        if payload is None:
            payload = {}
        if self._header is None:
            self._header = {}
        if self._payload is None:
            self._payload = {}
        self.update_header(header)
        self.update_payload(payload)

    def get_header(self) -> Dict:
        """Return header value for message object

        Returns
        -------
        _header: dict
            Returns the message header dictionary
        """
        _header = self._header
        return _header

    def get_payload(self) -> Any:
        """Return payload value for message

        Returns
        -------
        _payload: Any
            Returns the message payload value
        """
        _payload = self._payload
        return _payload

    def get_message(self) -> Dict:
        """Returns a dictionary representation of the message, consisting of
        header and payload dictionaries combined

        Returns
        -------
        _env: dictionary
            Returns the header and payload in one dictionary
        """
        _env = self._header.copy()
        _env["payload"] = self._payload
        return _env

    def update_header(self, header: Dict = None) -> None:
        """Updates stored header of the message

        Parameters
        ----------
        header: Dict
            A dictionary containing the key-value pairs to add or update in
            the _header member

        Example
        -------
        header = {
            dest_port: 9999
        }
        """
        self._header.update(header)

    def update_payload(self, payload: Dict = None) -> None:
        """Updates stored payload of the message

        Parameters
        ----------
        payload: Dict
            A dictionary containing the key-value pairs to add or update in
            the payload

        Example
        -------
        payload = {"type": "access"}
        """
        self._payload.update(payload)
