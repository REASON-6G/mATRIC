# -*- coding: utf-8 -*-
import secrets
import uuid
from datetime import datetime
import logging


class MessageFactory:
    """
    Message Factory
    ===============

    Message factory class.

    This class is used to compose WireMQ messages, including commands an events.

    Note
    ----
    This class will be made obsolete soon and replaced by
    :ref:`Base Message Factory`.

    Attributes
    ----------
    _id: str
        Message factory identifier.
    _config:
        Message factory config, used to compose messages.

    Methods
    -------
    _add_basic_headers(): dict
        Adds basic header fields to a message.
    _add_datetime(): dict
        Adds the current datetime in epoch and in human-readable (UTC).
    _add_message_id(): dict
        Adds a unique message ID to the message.
    _add_nonce(): dict
        Adds a unique nonce to the message.
    _compose_command(): dict
        Composes a command message.
    _compose_event(): dict
        Composes an event message.
    _compose_acknowledgement(): dict
        Composes an acknowledgement message based on the received message.
    process(): dict
        Composes a wiremq message

    """
    def __init__(self, config: dict):
        """ Initializer for message factory

        Parameters
        ----------
        config: Dict
            The config containing data required to compose the message.The
            structure is different for each.
            type: str
                The message type to be constructed.
                  - command
                  - event

        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._id = self._generate_id()
        self._log.args("%s: ()" % self)
        self._config = None
        self._log.rtn("%s: success" % self)

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        self._log.rtn("success | data: %s" % _id)
        return _id

    def _add_headers(self, message: dict) -> dict:
        """Adds basic header fields to a message.

        Parameters
        ----------
        message: dict
            Message to be modified.

        Returns
        -------
        message: dict
            Modified message.

        """
        self._log.args("%s: (message: %s)" % (self, str(message)))
        message.update(
            {
                "timestamp": None,
                "datetime": None,
                "sender_ip": self._config.get("sender_ip", None),
                "sender_port": self._config.get("sender_port", None),
                "sender_alias": self._config.get("sender_alias", None),
                "dest_ip": self._config.get("dest_ip", None),
                "dest_port": self._config.get("dest_port", None),
                "message_id": None,
                "nonce": None
            }
        )
        self._log.rtn("%s: success | data: %s" % (self, message))
        return message

    def _add_datetime(self, message: dict) -> dict:
        """Adds the current datetime in epoch and in human-readable (UTC).

        Parameters
        ----------
        message: dict
            Message to be modified.

        Returns
        -------
        message: dict
            Modified message.

        """
        self._log.args("%s: (message: %s)" % (self, str(message)))
        dt = datetime.now()
        message["timestamp"] = datetime.timestamp(dt)
        message["datetime"] = dt.strftime("%Y-%m-%d %H:%M:%S.%f")
        self._log.rtn("%s: success | data: %s" % (self, message))
        return message

    def _add_message_id(self, message: dict) -> dict:
        """Adds a unique message ID to the message.

        Parameters
        ----------
        message: dict
            Message to be modified.

        Returns
        -------
        message: dict
            Modified message.

        """
        self._log.args("%s: (message: %s)" % (self, str(message)))
        message["message_id"] = str(uuid.uuid4())
        self._log.rtn("%s: success | data: %s" % (self, message))
        return message

    def _add_nonce(self, message: dict) -> dict:
        """Adds a unique nonce to the message.

        Parameters
        ----------
        message: dict
            Message to be modified.

        Returns
        -------
        message: dict
            Modified message.

        """
        self._log.args("%s: (message: %s)" % (self, str(message)))
        message["nonce"] = secrets.token_urlsafe()
        self._log.rtn("%s: success | data: %s" % (self, message))
        return message

    def _compose_command(self, message: dict) -> dict:
        """Composes a command message.

        Parameters
        ----------
        message: dict
            Message to be modified.

        Returns
        -------
        message: dict
            Modified message.
        """
        self._log.args("%s: (message: %s)" % (self, str(message)))
        message.update({
            "type": "command",
            "payload": self._config["payload"]
        })
        self._log.rtn("%s: success | data: %s" % (self, message))
        return message

    def _compose_event(self, message: dict) -> dict:
        """Composes an event message.

        When a payload is not present in the config, an acknowledgement is
        composed.

        Parameters
        ----------
        message: dict
            Message to be modified.

        Returns
        -------
        message: dict
            Modified message.
        """
        self._log.args("%s: (message: %s)" % (self, str(message)))
        message.update({
            "type": "event"
        })
        if "payload" in self._config:
            message.update({
                "payload": self._config["payload"]
            })
        else:
            message = self._compose_acknowledgement(message)
        self._log.rtn("%s: success | data: %s" % (self, message))
        return message

    def _compose_acknowledgement(self, message: dict):
        """Composes an acknowledgement message based on the received message.

        Takes the message ID from the received message and uses it as a
        correlation ID for the acknowledgement message.

        Notes
        -----
        self._config: dict
            type: str
                Message type (event).
            message: dict
                The message to be acknowledged.

        Returns
        -------
        message: dict
            The composed message.

        """
        self._log.args("%s: (message: %s)" % (self, str(message)))
        message.update({
            "correlation_id": self._config["message"]["message_id"],
            "dest_ip": self._config["message"]["sender_ip"],
            "dest_port": self._config["message"]["sender_port"]
        })
        self._log.rtn("%s: success | data: %s" % (self, message))
        return message

    def message(self, config: dict) -> dict:
        """Composes a wiremq message.

        This can either be:
          - A command message
          - An event message

        Parameters
        ----------
        config:
            Message factory config, used to compose messages.

        Returns
        -------
        message: dict
            Composed message
        """
        self._log.args("%s: (config: %s)" % (self, config))
        self._config = config
        message = {}
        message = self._add_headers(message)
        self._add_datetime(message)
        self._add_message_id(message)
        self._add_nonce(message)
        if self._config["type"] == "command":
            message = self._compose_command(message)
        elif self._config["type"] == "event":
            message = self._compose_event(message)
        self._log.rtn("success | data: %s" % message)
        return message

    def close(self) -> None:
        """Closes the message factory and clears its attributes.
        """
