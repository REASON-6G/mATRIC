# -*- coding: utf-8 -*-
""" abstract message class """

from typing import (
    Dict,
    Any
)
from abc import (
    ABC,
    abstractmethod
)


class AbstractMessage(ABC):
    """
    Abstract Message
    ================

    Obsolete.
    """

    def __init__(self) -> None:
        """Abstract class constructor."""
        super().__init__()

    @abstractmethod
    def _init(self, header: Dict, payload: Any) -> None:
        """Handle message when first initialised."""
        pass

    @abstractmethod
    def get_header(self) -> Dict:
        """Return header value for message object"""
        pass

    @abstractmethod
    def get_payload(self) -> Any:
        """Return payload value for message"""
        pass

    @abstractmethod
    def get_message(self) -> Dict:
        """Return raw message, as a dictionary including header and payload"""
        pass

    @abstractmethod
    def update_header(self, header: Dict = None) -> None:
        """Updates stored header of the message"""
        pass

    @abstractmethod
    def update_payload(self, payload: Any = None) -> None:
        """Updates stored payload of the message"""
        pass
