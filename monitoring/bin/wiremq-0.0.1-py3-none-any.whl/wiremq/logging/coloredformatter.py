# -*- coding: utf-8 -*-
"""Custom formatter for wiremq logger."""

from typing import Any
import logging
from copy import copy


class ColoredFormatter(logging.Formatter):
    """
    Colored Formatter
    =================

    Defines colors for different log levels. Adds color escape codes for
    colored console log printouts. Fields within the log are colored (e.g.
    module name, method name, line number, message), and log levels are colored
    according to their level.

    Attributes
    ----------
    STYLE_MAP: Dict
        Maps human-readable names to ANSI color codes.

    Methods
    -------
    format: Dict
        Overrides the default format method of logging.Formatter, adding color
        tags to some attributes.
    """
    STYLE_MAP = {
        "DEBUG": "",               # plain
        "STATS": "\033[0;32m",     # green
        'INFO': "\033[0;35m",      # blue
        'ARGS': "\033[0;96m",      # cyan
        'RTN': "\033[0;34m",       # cyan
        'DEV': "\033[0;42m",       # green bg
        'TEST': "\033[44m",        # blue bg
        'WARNING': "\033[0;33m",   # yellow
        'ERROR': "\033[0;31m",     # red
        'CRITICAL': "\033[41m",    # red bg
        "RESET": "\033[0m",        # reset
        "PURPLE": "\033[1;35m",    # purple
        "LTPURPLE": "\033[0;35m"   # light purple
    }

    def format(self, record: Any):
        """Overrides the default format method of logging.Formatter, adding
        color tags to some attributes.

        Parameters
        ----------
        record: object
            logging record object, contains each attribute which may be logged.

        Returns
        -------
        format: object
            Logging formatter object.
        """
        colored_record = copy(record)
        reset = ColoredFormatter.STYLE_MAP["RESET"]

        # Format log level
        level = colored_record.levelname
        style = ColoredFormatter.STYLE_MAP.get(level, "\033[0m")
        colored_record.levelname = "{0}{1}{2}".format(
            style, level, reset
        )

        # Format filename
        filename = colored_record.filename
        colored_record.filename = "{0}{1}{2}".format(
            ColoredFormatter.STYLE_MAP["PURPLE"], filename, reset
        )

        # Format lineno
        lineno = colored_record.lineno
        colored_record.lineno = "{0}{1}{2}".format(
            ColoredFormatter.STYLE_MAP["LTPURPLE"], lineno, reset
        )

        # Format module
        module = colored_record.module
        colored_record.module = "{0}{1}{2}".format(
            ColoredFormatter.STYLE_MAP["PURPLE"], module, reset
        )

        # Format function
        funcname = colored_record.funcName
        colored_record.funcName = "{0}{1}{2}".format(
            ColoredFormatter.STYLE_MAP["LTPURPLE"], funcname, reset
        )

        return super().format(colored_record)
