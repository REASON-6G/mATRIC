# -*- coding: utf-8 -*-
import secrets
from pathlib import Path
from typing import (
    Dict
)
from wiremq.utils import dbtools


class EndpointGateway:
    """
    Endpoint Gateway
    ================

    Gateway class for building endpoints, other endpoint gateway types inherit
    from this class.

    Methods
    -------
    _build_config():
        Assembles the entire config for an endpoint.
    _build_endpoint_config():
        Assembles the root level config for an endpoint.
    _build_logger_config():
        Assembles a configuration for the endpoint's logger.
    _build_queue_config(): Dict
        Generic method to build a queue configuration.
    _build_inbound_socket_config(): Dict
        Assembles a config for an Inbound Socket.
    _build_outbound_socket_config(): Dict
        Assembles a config for an Outbound Socket.
    _build_broadcast_socket_config(): Dict
        Assembles a configuration for a Broadcast Socket.
    _build_ioloop_config(): Dict
        Assembles the configuration for an IO loop.
    _build_contentrouter_config(): Dict
        Assembles a configuration for a Content Router.
    _build_recipientlist_config(): Dict
        Assembles a configuration for a Recipient List.
    _build_resequencer_config(): Dict
        Assembles a configuration for a Resequencer.
    _build_routingslip_config(): Dict
        Assembles a configuration for a Routing Slip.
    _build_sockdispatcher_config(): Dict
        Assembles a configuration for a Socket Dispatcher.
    _build_bsonencoder_config(): Dict
        Assembles a configuration for a BSON content decoder.
    _build_bsondecoder_config(): Dict
        Assembles a configuration for a BSON content encoder.
    _build_contentfilter_config(): Dict
        Assembles a configuration for a Content Filter.
    _build_envelopewrapper_config(): Dict
        Assembles a configuration for an Envelope Wrapper.
    _build_validator_config(): Dict
        Assembles a configuration for an Envelope Wrapper.
    _build_default_consumer_sockdispatcher_config(): Dict
        Assembles a default sockdispatcher configuration for an endpoint's
        consumer.
    _build_default_producer_sockdispatcher_config(): Dict
        Assembles a default sockdispatcher configuration for the outbound
        producer, to be inserted into a processor map config builder.
    _build_default_producer_envelopewrapper_config(): Dict
        Assembles a default envelope wrapper configuration for the outbound
        producer, to be inserted into a processor map config builder.
    _build_processor_map(): Dict
        Assembles a configuration for a processor map, used by process
        managers.
    _build_scheduler_config(): Dict
        Assembles the config for a Threaded Scheduler.
    _build_consumer_config(): Dict
        Assembles the configuration required to build a consumer.
    _build_producer_config(): Dict
        Assembles the configuration required to build a producer.
    _build_durable_store_config():
        Assembles the config for an endpoint's durable store.
    _build_idempotent_store_config():
        "Assembles the config for an endpoint's idempotent store.
    _make_host(): str
        Generates a random unix hostname.
    _log_color_map(): str
        Maps human readable colors to ascii codes.
    _generate_format_string(): str
        Adds the log color to the message in the format string.
    """

    def __init__(self, config: Dict):
        """

        Parameters
        ----------
        config: Dict
            name: str
                Human-readable name of the endpoint e.g. Battery receive
                channel.
            alias: str
                Unique machine-readable name for the endpoint e.g. battrecvch.
            internal_domain: str (optional)
                Local directory path where internal domain sockets will be
                located for this endpoint (defaults to
                ~/.wiremq/domain_sockets).
            db_path: str (optional)
                For sqlite-based message stores only, local directory path
                where databases will be stored (defaults to
                ~/.wiremq/message_db).
            max_connections: int (optional used for pubsub and bus only,
                default 10)
                Maximum number of sockets that the bus endpoint connect to.
            buffer_size: int (optional, default 2048)
                Maximum buffer size for socket data transfer.
            host: str
                Hostname for inbound communication, defaults to 0.0.0.0
            advertised_host: str (optional)
                Used if the binding consumer host is different to the host
                which will be placed in "sender_ip" in outgoing messages,
            port: int
                Port number for inbound communication.
            host: str (optional, for pubsub channel only)
                Hostname for the command messages, defaults to 0.0.0.0
            command_port: int (optional, for pubsub channel only)
                Port number for command messages.
            dest_host: str
                Destination host for the socket dispatcher in the producer
                (not required for message bus nor pubsub).
            dest_port: int
                Destination port for the socket dispatcher in the producer
                (not required for message bus not pubsub).
            durable: bool
                Flag to set whether endpoint durability is required
                (durable_config must be supplied).
            idempotent: bool
                Flag to set whether endpoint idempotency is required
                (idempotent_config must be supplied).
            auto_ack: bool
                Flag to set whether messages are automatically acknowledged
                internally by the endpoint
            add_message_id: bool (optional, default True)
                When True, adds a random 32 character hex string as a message
                id (not recommended when using service activator).
            durable_config: Dict (optional)
                Database connection configuration for the durable store.
                db_type: str
                    Type of database to use, must be one of (sqlite, mongodb,
                    mariadb, mysql)
                credentials: Dict (different for some db_types)
                    db_type=sqlite:
                    ---------------
                    db_file: str
                        Path to the sqlite database.
                    db_type!=sqlite:
                        database: str
                            Database name
                        user: str
                            Database username.
                        password: str
                            Database password.
                        host: str
                            Host name of the database.
                        port: int
                            Port number of the database.
            idempotent_config: Dict (optional)
                Database connection configuration for the idempotent store.
                Structure identical to durable_config.
            routing_table: Dict (required for router only)
                Address routing table, must be in form of sender:dest where
                each is an address with hostname:port. e.g.
                    "127.0.0.1:7051": "127.0.0.1:7052"
                    "127.0.0.1:7052": "127.0.0.1:7051"
            console_log_level: int (optional, default=21)
                Log level identifier for console logging(1: all, 10: debug,
                20: info, 21: dev, 22: test, 30: warning, 40: error,
                50: critical)
            console_log_color: str (optional)
                Controls the output color of messages in the console (black,
                red, green, yellow, blue, purple, cyan, white, bg_black,
                bg_red, bg_green, bg_yellow, bg_blue, bg_purple, bg_cyan,
                bg_white)
            file_log_level: int (optional, default 20)
                Log level identifier for file logging.
            file_log_path: str (optional)
                Destination path to output log file, if not supplied file
                logging is disabled.
        """
        self._type = "endpoint"
        self._config = config
        self._name = self._config["name"]
        self._alias = self._config["alias"]
        self._consumer_host = self._config["host"]
        self._consumer_port = self._config["port"]
        self._producer_dest_host = self._config.get("dest_host")
        self._producer_dest_port = self._config.get("dest_port")
        self._ioloop_host = self._make_host()
        self._producer_host = self._make_host()
        self._sockdspatcher_host = self._make_host()
        self._consumer_sockdispatcher_host = self._make_host()
        self._max_sockets = self._config.get("max_connections", 0)
        self._buffer_size = self._config.get("buffer_size", 2048)
        self._internal_domain = self._config.get(
            "internal_domain",
            "{}/.wiremq/domain_sockets/".format(Path.home())
        )
        self._db_path = self._config.get(
            "db_path",
            "{}/.wiremq/message_db/".format(Path.home())
        )

        self._build_config()

    def _build_config(self) -> None:
        """Assembles the entire config for an endpoint.

        Builds the root level config, then adds on the sub-components required
        for the endpoint.

        This method may be overridden with a super()._build_config() call to
        add endpoint-specific components (such as the handlers for a Service
        Activator.
        """
        self._build_endpoint_config()
        self._build_logger_config()
        self._endpoint_config["task_queue_config"] = \
            self._build_queue_config("task", self._config["alias"])
        self._endpoint_config["received_queue_config"] = \
            self._build_queue_config("received", self._config["alias"])
        self._endpoint_config["send_queue_config"] = \
            self._build_queue_config("send", self._config["alias"])
        self._endpoint_config["dispatch_queue_config"] = \
            self._build_queue_config("dispatch", self._config["alias"])
        self._endpoint_config["invalid_message_queue_config"] = \
            self._build_queue_config("invalid_message", self._config["alias"])
        self._endpoint_config["sockdispatcher_config"] = \
            self._build_sockdispatcher_config(
                self._config["alias"],
                "outboundsocket",
                "udp",
                "unix",
                self._producer_host,
                self._sockdspatcher_host
        )
        self._build_idempotent_store_config()
        self._build_durable_store_config()
        self._endpoint_config["ioloop_config"] = self._build_ioloop_config(
            self._config['alias'],
            "udp",
            "unix",
            self._ioloop_host
        )
        self._endpoint_config["consumer_config"] = self._build_consumer_config(
            self._config["alias"],
            "consumer",
            self._config.get("inbound_processors", {}),
            self._consumer_host,
            self._consumer_port
        )
        self._endpoint_config["producer_config"] = self._build_producer_config(
            self._config["alias"],
            self._config.get("outbound_processors", {})
        )

    def _build_endpoint_config(self) -> None:
        """Assembles the root level config for an endpoint.

        Other components are added to this config later.
        """
        self._endpoint_config = {
            "name": self._config["name"],
            "alias": self._config["alias"],
            "type": self._type,
            "durable": self._config.get("durable", False),
            "idempotent": self._config.get("idempotent", False),
            "consumer_host": self._config["host"],
            "consumer_port": self._config["port"],
            "internal_domain": self._internal_domain,
            "auto-ack": self._config.get("auto_ack", False),
            "db_path": self._db_path,
            "logger": f"{self._config['alias']}_logger"
        }

    def _build_logger_config(self) -> None:
        """Assembles a configuration for the endpoint's logger.

        The logging format is static but the coloring can be adjusted with the
        user config.

        The logging level for console and file output streams can be adjusted
        via the user config, The log file path can also be specified.

        """
        self._endpoint_config["logger_config"] = {
            "name": f"{self._config['name']} logger",
            "alias": f"{self._config['alias']}_logger",
            "console_level": self._config.get("log_level", 21),
            "file_level": self._config.get("file_level", 20),
            "console_format": self._generate_format_string(
                self._config.get("console_log_color", "")),
            "file_format": "%(asctime)s [%(levelname)s] (%(name)s) {%(module)s"
                           ":%(funcName)s:%(lineno)s} | %(message)s",
            "file_path": self._config.get(
                "log_path",
                f"{self._config['alias']}.log"
            )
        }

    def _build_queue_config(self, queue_type: str, parent_alias: str) -> Dict:
        """Generic method to build a queue configuration.

        Parameters
        ----------
        queue_type: str
            Prefix for the queue (e.g. "task" for task_queue).
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).

        Returns
        -------
        queue_config: Dict

        """
        return {
            "name": f"{queue_type} queue for {parent_alias}",
            "alias": f"{queue_type}queue_{parent_alias}",
            "logger": f"{self._config['alias']}_logger",
            "type": "fifoqueue",
            "ordering": "fifo",
            "maxsize": 0
        }

    def _build_inbound_socket_config(self,
                                     parent_alias: str,
                                     protocol: str,
                                     family: str,
                                     host: str,
                                     port: int = None
                                     ) -> Dict:
        """Assembles a config for an Inbound Socket.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        protocol: str
            Network protocol to use for the socket (must be one of "udp" or
            "tcp").
        family: str
            Socket family (must be one of "unix" or "inet").
        host: str
            Host of the socket.
        port: int (required only for INET family sockets)
            Port number of the socket.


        Returns
        -------
        inboundsocket_config: Dict
            Assembled configuration for an Inbound Socket.

        """
        config = {
            "name": f"Inbound socket for {parent_alias}",
            "alias": f"inboundsocket_{parent_alias}",
            "logger": f"{self._config['alias']}_logger",
            "type": "inboundsocket",
            "protocol": protocol,
            "family": family,
            "blocking": True,
            "buffer_size": self._buffer_size,
            "host": host,
        }
        if port:
            config["port"] = port

        return config

    def _build_outbound_socket_config(self,
                                      parent_alias: str,
                                      protocol: str,
                                      family: str,
                                      host: str
                                      ) -> Dict:
        """Assembles a config for an Outbound Socket.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        protocol: str
            Network protocol to use for the socket (must be one of "udp" or
            "tcp").
        family: str
            Socket family (must be one of "unix" or "inet").
        dest_ip: str (optional)
        host: str (optional)
            Host of the socket (required for UNIX family sockets only, TCP
            sockets assign themselves a host automatically).

        Returns
        -------
        outboundsocket_config: Dict
            Assembled configuration for an Outbound Socket.

        """
        config = {
            "name": f"Outbound socket for {parent_alias}",
            "alias": f"outboundsocket_{parent_alias}",
            "logger": f"{self._config['alias']}_logger",
            "type": "outboundsocket",
            "protocol": protocol,
            "family": family,
            "blocking": True,
            "buffer_size": self._buffer_size,
            "host": host,
        }

        return config

    def _build_broadcast_socket_config(self,
                                       parent_alias: str,
                                       protocol: str,
                                       family: str,
                                       max_sockets: int = 0
                                       ) -> Dict:
        """Assembles a configuration for a Broadcast Socket.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        protocol: str
            Network protocol to use for the socket (must be one of "udp" or
            "tcp").
        family: str
            Socket family (must be one of "unix" or "inet").
        max_sockets: int (optional, defaults to 0)
            Maximum number of sockets which can be assigned as destinations for
            the Broadcast Socket.

        Returns
        -------

        """
        config = {
            "name": f"Broadcast socket for {parent_alias}",
            "alias": f"broadcastsocket_{parent_alias}",
            "logger": f"{self._config['alias']}_logger",
            "type": "broadcastsocket",
            "protocol": protocol,
            "family": family,
            "blocking": True,
            "buffer_size": self._buffer_size,
            "max_sockets": max_sockets,
            "destinations": None
        }

        return config

    def _build_ioloop_config(self,
                             parent_alias: str,
                             protocol: str,
                             family: str,
                             host: str,
                             port: int = None
                             ) -> Dict:
        """Assembles the configuration for an IO loop.

        Includes configuration of the IO Loop's Poller and Inbound Socket.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        protocol: str
            Network protocol to use for the socket (must be one of "udp" or
            "tcp").
        family: str
            Socket family (must be one of "unix" or "inet")
        host: str
            Host address for the IO Loop's inbound socket.
        port: int (optional)
            Port number for the IO Loop's inbound socket, required only for
            INET family sockets

        Returns
        -------
        ioloop_config: Dict
            Assembled configuration for an IO loop
        """
        if protocol == "tcp":
            ioloop_type = "ioeventlooptcp"
        else:
            ioloop_type = "ioeventloopudp"

        config = {
            "name": f"IO loop for {parent_alias}",
            "alias": f"ioloop_{parent_alias}",
            "logger": f"{self._config['alias']}_logger",
            "type": ioloop_type,
            "terminator": "\r\r\r\r",  # TODO: make this bytes
            "max_con": self._max_sockets,
            "buffer_size": self._buffer_size,
            "listening": True
        }
        config["poller_config"] = {
            "name": f"Poller for {config['alias']}",
            "alias": f"poller_{config['alias']}",
            "logger": f"{self._config['alias']}_logger",
            "type": "iopoll",
            "transport_type": "channel"
        }
        config["inbound_socket_config"] = self._build_inbound_socket_config(
            config["alias"],
            protocol,
            family,
            host,
            port
        )

        return config

    def _build_contentrouter_config(self,
                                    parent_alias: str,
                                    attributes: Dict) -> Dict:
        """Assembles a configuration for a Content Router.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        attributes: Dict
            Routes and key mapping for the content router.
            routes: Dict
                The mapping of criteria to route, that is looked up and
                returned.  The criteria key is in the form of a tuple of
                message values.
            keys: Dict
                header: list
                    A list of field names from the message header, to look up
                    in the routes table.
                payload: list
                    A list of field names from the message payload, to look up
                    in the routes table.
        Returns
        -------
        contentrouter_config: Dict
            Assembled Content Router config.
        """
        return {
            "CR": {
                "processor": None,
                "config": {
                    "name": f"Content Router for {parent_alias}",
                    "alias": f"contentrouter_{parent_alias}",
                    "logger": f"{self._config['alias']}_logger",
                    "type": "contentrouter",
                    "transport_type": "queue",
                    "routes": attributes["routes"],
                    "keys": attributes["keys"]
                }
            }
        }

    def _build_recipientlist_config(self,
                                    parent_alias: str,
                                    attributes: Dict) -> Dict:
        """Assembles a configuration for a Recipient List.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        attributes: Dict
            Subscribers and operators for the recipientlist.
        Returns
        -------
        recipientlist_config: Dict
            Assembled Recipient List config.
        """
        return {
            "RL": {
                "processor": None,
                "config": {
                    "name": f"Recipient List for {parent_alias}",
                    "alias": f"recipientlist_{parent_alias}",
                    "logger": f"{self._config['alias']}_logger",
                    "type": "recipientlist",
                    "transport_type": "queue",
                    "subscribers": attributes["subscribers"],
                    "operators": attributes["operators"]
                }
            }
        }

    def _build_resequencer_config(self,
                                  parent_alias: str,
                                  attributes: Dict) -> Dict:
        """Assembles a configuration for a Resequencer.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        attributes: Dict
            message_store_config: Dict

            sequences: Dict
            A series of sequence descriptors
                sequence_size: int
                    The length of the sequence,
                cursor: int
                    The current position of the cursor.
        Returns
        -------
        resequencer_config: Dict
            Assembled Resequencer config.
        """
        if "message_store_config" not in attributes:
            db_type = "sqlitedbconn"
            credentials = {
                "db_file": f"{self._config['alias']}_resequencer.db"
            }
        else:
            db_type = attributes["db_type"]
            credentials = attributes["credentials"]
        ms_config = {
            "name": f"Resequencer message store for {self._config['alias']}",
            "alias": f"resequencer_messagestore_{self._config['alias']}",
            "logger": f"{self._config['alias']}_logger",
            "db_table": "sequences",
            "id_field": "sequence_id",
            "id_type": "CHAR(16)",
            "fields": [
                {"name": "sequence", "type": "CHAR"},
            ],
            "db_config": {
                "name": f"DB connection for idempotent_messagestore_"
                        f"{self._config['alias']}",
                "alias": f"durabledbconn_idempotent_messagestore_"
                         f"{self._config['alias']}",
                "logger": f"{self._config['alias']}_logger",
                "type": db_type,
                "credentials": credentials,
                "db": None,
            }
        }
        if ms_config["db_config"]["type"] == "sqlitedbconn":
            ms_config["db_config"]["check_same_thread"] = False
            dbtools.sqlite_create_table(
                ms_config,
                self._db_path
            )
        return {
            "RQ": {
                "processor": None,
                "config": {
                    "name": f"Resequencer for {parent_alias}",
                    "alias": f"resequencer_{parent_alias}",
                    "logger": f"{self._config['alias']}_logger",
                    "type": "resequencer",
                    "transport_type": "queue",
                    "messagestore_config": ms_config,
                    "message_store": None
                }
            }
        }

    def _build_routingslip_config(self,
                                  parent_alias: str,
                                  attributes: Dict) -> Dict:
        """Assembles a configuration for a Routing Slip.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        attributes: Dict
            routes: list
                List of routes, each formatted as a dict containing:
                    dest_ip: str
                    dest_port: int
        Returns
        -------
        routingslip_config: Dict
            Assembled Routing Slip config.
        """

        return {
            "RS": {
                "processor": None,
                "config": {
                    "name": f"Routing Slip for {parent_alias}",
                    "alias": f"routingslip_{parent_alias}",
                    "logger": f"{self._config['alias']}_logger",
                    "type": "routingslip",
                    "transport_type": "queue",
                    "routes": attributes["routes"]
                }
            }
        }

    def _build_sockdispatcher_config(self,
                                     parent_alias: str,
                                     socket_type: str,
                                     protocol: str,
                                     family: str,
                                     dest_ip: str = None,
                                     host: str = None,
                                     dest_port: int = None,
                                     from_msg: bool = False
                                     ) -> Dict:
        """Assembles a configuration for a Socket Dispatcher.

        This generic method builds configs for Socket Dispatchers using either
        an Outbound Socket or a Broadcast Socket.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        socket_type: str
            Type of socket to dispatch on (must be one of "outboundsocket" or
            "broadcastsocket").
        protocol: str
            Network protocol to use for the socket (must be one of "udp" or
            "tcp").
        family: str
            Socket family (must be one of "unix" or "inet").
        dest_ip: str (optional)
            Destination IP address of the socket, required for outbound socket
            in most situations (except for HTTP request handler, which
            assigns this dynamically).
        host: str (optional)
            Host of the socket (required for UNIX family sockets only, TCP
            sockets assign themselves a host automatically).
        dest_port: int (optional)
            Destination port number of the socket, required for outbound INET
            sockets in most situations.
        from_msg: bool (optional, default = False)
            Flag to denote whether dest_ip and dest_port are assigned from the
            message headers (required to be True for Router endpoints).

        Returns
        -------
        sockdispatcher_config: Dict
            Assembled socket dispatcher config.
        """
        config = {
            "name": f"Socket dispatcher for {parent_alias}",
            "alias": f"sockdispatcher_{parent_alias}",
            "logger": f"{self._config['alias']}_logger",
            "type": "sockdispatcher",
            "transport_type": "queue",
            "from_msg": from_msg
        }
        if dest_ip:
            config["dest_ip"] = dest_ip
        if dest_port:
            config["dest_port"] = dest_port
        if protocol == "udp":
            config["terminator"] = "\r\r\r\r"
        if socket_type == "outboundsocket":
            config["outbound_socket_config"] = \
                self._build_outbound_socket_config(
                    f"sockdispatcher_{parent_alias}",
                    protocol,
                    family,
                    host
            )
        elif socket_type == "broadcastsocket":
            config["outbound_socket_config"] = \
                self._build_broadcast_socket_config(
                    f"sockdispatcher_{parent_alias}",
                    protocol,
                    family,
                    self._config.get("max_sockets", 0)
            )

        return config

    def _build_bsondecoder_config(self, parent_alias: str) -> Dict:
        """Assembles a configuration for a BSON content decoder.

        The config for the BSON decoder is static and requires no parameters.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).

        Returns
        -------
        encoder_config: Dict
            Assembled decoder config.
        """
        return {
            "BD": {
                "processor": None,
                "config": {
                    "name": f"BSON content decoder for {parent_alias}",
                    "alias": f"bsondecoder_{parent_alias}",
                    "logger": f"{self._config['alias']}_logger",
                    "type": "bsoncontentdecoder",
                    "transport_type": "queue"
                }
            }
        }

    def _build_bsonencoder_config(self, parent_alias: str) -> Dict:
        """Assembles a configuration for a BSON content encoder.

        The config for the BSON encoder is static and requires no parameters.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).

        Returns
        -------
        encoder_config: Dict
            Assembled encoder config.
        """
        return {
            "BE": {
                "processor": None,
                "config": {
                    "name": f"BSON content encoder for {parent_alias}",
                    "alias": f"bsonencoder_{parent_alias}",
                    "logger": f"{self._config['alias']}_logger",
                    "type": "bsoncontentencoder",
                    "transport_type": "queue"
                }
            }
        }

    def _build_contentfilter_config(self,
                                    parent_alias: str,
                                    attributes: Dict
                                    ) -> Dict:
        """Assembles a configuration for a Content Filter.


        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        attributes: Dict
            Contains header and payload filter attributes
            header_filter: List
                List of key strings to remove from a message header.
            payload_filter: List
                List of key strings to remove from a message payload.

        Example
        -------
        >>> attributes = {
        ...   "header_filter": ["correlation_id", "tx_id"],
        ...   "payload_filter": ["command", "temp"]
        ... }

        Returns
        -------
        contentfilter_config: Dict
            Assembled Content Filter config.
        """
        return {
            "CF": {
                "processor": None,
                "config": {
                    "name": f"Content Filter for {parent_alias}",
                    "alias": f"contentfilter_{parent_alias}",
                    "logger": f"{self._config['alias']}_logger",
                    "type": "contentfilter",
                    "transport_type": "queue",
                    "filter": {
                        "header": attributes.get("header_filter", []),
                        "payload": attributes.get("payload_filter", [])
                    }
                }
            }
        }

    def _build_envelopewrapper_config(self,
                                      parent_alias: str,
                                      attributes: Dict
                                      ) -> Dict:
        """Assembles a configuration for an Envelope Wrapper.

        Built based on a provided attribute dictionary, and the following
        fields from the user config: "add_message_id", "add_timestamp".

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        attributes: Dict
            Contains header and payload attributes to wrap around the message.

        Example
        -------
        >>> attributes = {
        ...   "header": {
        ...     "sender_alias": "channel1",
        ...     "sender_ip": "127.0.0.1",
        ...     "sender_port": 8001
        ...   },
        ...   "payload": {
        ...     "aux": "hello"
        ...   }
        ... }

        Returns
        -------
        envelopewrapper_config: Dict
            Assembled envelope wrapper config.
        """
        return {
            "EW": {
                "processor": None,
                "config": {
                    "name": f"Envelope wrapper for {parent_alias}",
                    "alias": f"envelopewrapper_{parent_alias}",
                    "logger": f"{self._config['alias']}_logger",
                    "type": "envelopewrapper",
                    "transport_type": "queue",
                    "add_id": self._config.get("add_message_id", False),
                    "add_datetime": self._config.get("add_timestamp", True),
                    "header": attributes.get("header", {}),
                    "payload": attributes.get("payload", {})
                }
            }
        }

    def _build_validator_config(self,
                                parent_alias: str,
                                attributes: Dict
                                ) -> Dict:
        """Assembles a configuration for an Envelope Wrapper.

        Built based on a provided attribute dictionary, and the following
        fields from the user config: "add_message_id", "add_timestamp".

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        attributes: Dict
            Contains header and payload attributes to wrap around the message.
            hash_method: dict
                length: str
                    Length of the signature
                method: str
                    Hash method.
            recv_window: int
                How many seconds until the message is discarded
                Based on its original timestamp.
            known_commands: list
                List of known message commands
            version_list: list
                List of available versions
            header_format: dict
                Contains all the types of the message to be validated

        Example
        -------
        >>> attributes = {
        ...   "hash_method": {
        ...     "length": 32,
        ...     "function": "sha256"
        ...   },
        ...   "recv_window": 100000,
        ...   "known_commands": [1, 2, 3, 4],
        ...   "version_list": ["0.0.1"],
        ...   "header_format": {
        ...     "protocol_version": str,
        ...     "timestamp": float,
        ...     "echo": float,
        ...     "sender_ip": str,
        ...     "sender_port": int,
        ...     "sender_alias": str,
        ...     "sender_signature": str,
        ...     "return_ip": str,
        ...     "return_port": int,
        ...     "dest_ip": str,
        ...     "dest_port": int,
        ...     "fdest_ip": str,
        ...     "fdest_port": int,
        ...     "tx_id": str,
        ...     "message_id": str,
        ...     "correlation_id": str,
        ...     "tx_correlation_id": str,
        ...     "nonce": str,
        ...     "position_id": int,
        ...     "size": int,
        ...   }

        Returns
        -------
        validator_config: Dict
            Assembled Validator config.
        """
        return {
            "VA": {
                "processor": None,
                "config": {
                    "name": f"Validator for {parent_alias}",
                    "alias": f"validator_{parent_alias}",
                    "logger": f"{self._config['alias']}_logger",
                    "type": "validator",
                    "transport_type": "queue",
                    "hash_method": attributes.get("hash_method"),
                    "recv_window": attributes.get("recv_window"),
                    "known_commands": attributes.get("known_commands"),
                    "version_list": attributes.get("version_list"),
                    "header_format": attributes.get("header_format")
                }
            }
        }

    def _build_default_consumer_sockdispatcher_config(self,
                                                      parent_alias: str
                                                      ) -> Dict:
        """Assembles a default sockdispatcher configuration for an endpoint's
        consumer.

        Typically this method does not need to be overridden as consumers
        always point to an endpoint's IO loop.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).

        Returns
        -------
        sockdispatcher_config: Dict
            Assembled Socket Dispatcher config for Consumer to IO Loop comms.
        """
        return self._build_sockdispatcher_config(
            parent_alias,
            "outboundsocket",
            "udp",
            "unix",
            self._ioloop_host,
            self._consumer_sockdispatcher_host,
        )

    def _build_default_producer_sockdispatcher_config(self) -> Dict:
        """Assembles a default sockdispatcher configuration for the outbound
        producer, to be inserted into a processor map config builder.

        Used when a processor map is not provided for the producer. This
        default assumes a p2p connection such as a Channel, other endpoints
        which use the Broadcast Socket in their producer should override this
        method and return a default config using a Broadcast Socket.

        Returns
        -------
        sockdispatcher_config: Dict
            An assembled default sockdispatcher config for a producer.
        """
        return {
            "socket_type": "outboundsocket",
            "protocol": "udp",
            "family": "inet",
            "dest_ip": self._producer_dest_host,
            "dest_port": self._producer_dest_port
        }

    def _build_default_producer_envelopewrapper_config(self) -> Dict:
        """Assembles a default envelope wrapper configuration for the outbound
        producer, to be inserted into a processor map config builder.

        Used when a processor map is not provided for the producer, adds basic
        information about the sending endpoint to each message header.

        Returns
        -------
        envelopewrapper_config: Dict
            A default user config for an envelope wrapper.
        """

        return {
            "header": {
                "sender_ip": self._consumer_host,
                "sender_port": self._consumer_port,
                "sender_alias": self._config["alias"]
            }
        }

    def _build_processor_map(self,
                             parent_alias: str,
                             processors: Dict) -> Dict:
        """Assembles a configuration for a processor map, used by process
        managers.

        This method builds the full configs required by each processor, based
        on the simplified configs supplied by the user.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        processors: Dict
            Configs for each processor to be placed in the chain. The
            processing order is the same as that supplied in the config.
            Available processors are:
              - contentrouter
              - resquencer
              - routingslip
              - sockdispatcher
              - encoder
              - decoder
              - contentfilter
              - envelopewrapper
              - validator

        Example
        -------
        >>> processor_map = {
        ...   "decoder": {}
        ...   "envelope_wrapper": {
        ...     "add_message_id": False,
        ...     "add_datetime": True,
        ...     "headers": {
        ...       "sender_alias": "channel1",
        ...       "sender_ip": "86.212.100.2",
        ...       "sender_port": 8001
        ...     },
        ...     "payload": {
        ...       "hello": "world"
        ...     }
        ...   },
        ...   "encoder": {},
        ...   "sockdispatcher": {
        ...     "socket_type": "outboundsocket",
        ...     "protocol": "udp",
        ...     "family": "inet",
        ...     "dest_ip": "86.101.200,3",
        ...     "dest_port": 8001
        ...   }

        Returns
        -------
        processor_map_config: Dict
            Assembled configuration for a processor map.
        """
        config = {}
        for processor, processor_config in processors.items():
            if processor == "contentrouter":
                config.update(self._build_contentrouter_config(
                    parent_alias, processor_config))
            elif processor == "recipientlist":
                config.update(self._build_recipientlist_config(
                    parent_alias, processor_config))
            elif processor == "resequencer":
                config.update(self._build_resequencer_config(
                    parent_alias, processor_config))
            elif processor == "routingslip":
                config.update(self._build_routingslip_config(
                    parent_alias, processor_config))
            elif processor == "sockdispatcher":
                config.update({
                    "SD": {
                        "processor": None,
                        "config": self._build_sockdispatcher_config(
                            parent_alias,
                            processor_config["socket_type"],
                            processor_config["protocol"],
                            processor_config["family"],
                            processor_config.get("dest_ip"),
                            processor_config.get("host"),
                            processor_config.get("dest_port"),
                            processor_config.get("from_msg")
                        )
                    }
                })
            elif processor == "encoder":
                config.update(self._build_bsonencoder_config(parent_alias))
            elif processor == "decoder":
                config.update(self._build_bsondecoder_config(parent_alias))
            elif processor == "contentfilter":
                config.update(self._build_contentfilter_config(
                    parent_alias, processor_config))
            elif processor == "envelopewrapper":
                config.update(self._build_envelopewrapper_config(
                    parent_alias, processor_config
                ))
            elif processor == "validator":
                config.update(self._build_validator_config(
                    parent_alias, processor_config))

        return config

    def _build_scheduler_config(self,
                                parent_alias: str,
                                processors: Dict) -> Dict:
        """Assembles the config for a Threaded Scheduler.

        Most of the configuration is automatically generated however a
        processor dictionary must be provided. This method is generic and is
        used by consumers, producers and the http request handler.

        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. consumer_channel1).
        processors: Dict
            Configs for each processor to be placed in the chain. The
            processing order is the same as that supplied in the config.
            Available processors are:
              - contentrouter
              - recipientlist
              - resquencer
              - routingslip
              - sockdispatcher
              - encoder
              - decoder
              - contentfilter
              - envelopewrapper
              - validator

        Returns
        -------
        scheduler_config: Dict
            Assembled configuration for a scheduler.

        """
        config = {
            "name": f"Scheduler for {parent_alias}",
            "alias": f"scheduler_{parent_alias}",
            "logger": f"{self._config['alias']}_logger",
            "type": "threadedscheduler",
            "threadpool_config": {
                "name": f"Threadpool for scheduler_{parent_alias}",
                "alias": f"threadpool_scheduler_{parent_alias}",
                "logger": f"{self._config['alias']}_logger",
                "type": "basethreadpool",
                "max_threads": 1
            },
            "worker_map": {
                "io-task": {
                    "worker": "PM",
                    "config": "worker_config",
                    "method": "PM",
                    "queue_config": None
                }
            },
            "worker_config": {
                "name": f"Process manager for scheduler_{parent_alias}",
                "alias": f"processmanager_scheduler_{parent_alias}",
                "logger": f"{self._config['alias']}_logger",
                "type": "baseprocessmanager",
                "processor_queue": None,
                "processor_queue_config": self._build_queue_config(
                    "processor",
                    f"scheduler_{parent_alias}"
                )
            },
        }
        config["worker_config"]["processor_map"] = self._build_processor_map(
            f"processmanager_scheduler_{parent_alias}",
            processors
        )
        config["worker_config"]["processor_chain"] = \
            list(config["worker_config"]["processor_map"].keys())
        return config

    def _build_consumer_config(self,
                               parent_alias: str,
                               consumer_type: str,
                               processors: Dict,
                               host: str,
                               port: int
                               ) -> Dict:
        """Assembles the configuration required to build a consumer.

        Can be configured from the user supplied config, however a default is
        provided if the config is not specified.

        At minimum, a consumer should contain a sockdispatcher in its
        processor chain, to send messages to the endpoint's IO Loop.

        The default config for a consumer (when one is not supplied) contains:
          - A Socket Dispatcher


        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. channel1)
        processors: Dict
            Configs for each processor to be placed in the chain. The
            processing order is the same as that supplied in the config.
            Available processors are:
              - contentrouter
              - recipientlist
              - resquencer
              - routingslip
              - sockdispatcher
              - encoder
              - decoder
              - contentfilter
              - envelopewrapper
              - validator

        Returns
        -------
        consumer_config: Dict
            Configuration for a consumer.

        """
        # If sockdispatcher config not present, add a default
        if "sockdispatcher" not in processors:
            processors["sockdispatcher"] = {
                "socket_type": "outboundsocket",
                "protocol": "udp",
                "family": "unix",
                "dest_ip": self._ioloop_host,
                "host": self._consumer_sockdispatcher_host,
            }

        return {
            "name": f"{consumer_type} for {parent_alias}",
            "alias": consumer_type,
            "logger": f"{self._config['alias']}_logger",
            "type": consumer_type,
            "task_queue_config": self._build_queue_config("task",
                                                          parent_alias),
            "scheduler_config": self._build_scheduler_config(
                f"{consumer_type}_{parent_alias}",
                processors),
            "ioloop_config": self._build_ioloop_config(
                f"{consumer_type}_{parent_alias}",
                "udp",
                "inet",
                host,
                port
            )
        }

    def _build_producer_config(self,
                               parent_alias: str,
                               processors: Dict = None
                               ) -> Dict:
        """Assembles the configuration required to build a producer.

        Can be configured from the user supplied config, however a default is
        provided if the config is not specified.

        At minimum, a producer should contain a sockdispatcher in its
        processor chain. For the Channel, Service Activator and Router endpoint
        types, an Outbound Socket is used to dispatch messages. For the Message
        Bus and Pub-Sub Channel endpoints, a broadcast socket is used instead.

        The default config for a producer (when one is not supplied) contains:
          - A BSON decoder
          - An Envelope Wrapper (to add the endpoint's basic details to the
            message)
          - A BSON encoder
          - A Socket Dispatcher


        Parameters
        ----------
        parent_alias: str
            Alias of the parent component (e.g. channel1)
        processors: Dict
            Configs for each processor to be placed in the chain. The
            processing order is the same as that supplied in the config.
            Available processors are:
              - contentrouter
              - recipientlist
              - resquencer
              - routingslip
              - sockdispatcher
              - encoder
              - decoder
              - contentfilter
              - envelopewrapper
              - validator

        Returns
        -------
        producer_config: Dict
            Configuration for a producer.

        """
        # If processors not provided, provide defaults
        if not processors:
            processors["decoder"] = {},
            processors["envelopewrapper"] = \
                self._build_default_producer_envelopewrapper_config()
            processors["encoder"] = {}
        # If sockdispatcher not provided, add it
        if "sockdispatcher" not in processors:
            processors["sockdispatcher"] = \
                self._build_default_producer_sockdispatcher_config()
        return {
            "name": f"Producer for {parent_alias}",
            "alias": f"producer_{parent_alias}",
            "logger": f"{self._config['alias']}_logger",
            "type": "producer",
            "task_queue_config": self._build_queue_config("task",
                                                          parent_alias),
            "scheduler_config": self._build_scheduler_config(
                f"producer_{parent_alias}",
                processors
            ),
            "ioloop_config": self._build_ioloop_config(
                f"producer_{parent_alias}",
                "udp",
                "unix",
                self._producer_host
            ),
            "message_factory_config": {
                "name": f"Message factory for {parent_alias}",
                "alias": f"messagefactory_{parent_alias}"
            }
        }

    def _build_durable_store_config(self) -> None:
        """Assembles the config for an endpoint's durable store.

        If durability is disabled then this method does not alter the endpoint
        config.

        The internal structure of the database required for durability is
        pre-configured here.

        Durable store config is sourced from "durable_store_config" of
        the user supplied config. If a config is not supplied then a default
        sqlite database is used.

        The durable store config uses the following structure:

        db_type: str
            Type of database (one of sqlite, mongo, mysql, maria)
        credentials: Dict
            db_type==sqlite:
            ----------------
            db_file: str
                Path to the sqlite database file
            db_type!=sqlite:
            ----------------
            database: str
                Database name
            user: str
                Database username.
            password: str
                Database password.
            host: str
                Host name of the database.
            port: int
                Port number of the database.

        """

        if not self._config.get("durable", False):
            return
        messagestore_config = self._config.get("durable_config")
        if messagestore_config:
            db_type = f"{messagestore_config['db_type']}dbconn"
            credentials = messagestore_config["credentials"]
        else:
            db_type = "sqlitedbconn"
            credentials = {
                "db_file": f"{self._config['alias']}_durable.db"
            }
        config = {
            "name": f"Durable message store for {self._config['alias']}",
            "alias": f"durable_messagestore_{self._config['alias']}",
            "logger": f"{self._config['alias']}_logger",
            "db_table": "durable_messages",
            "id_field": "message_id",
            "id_type": "CHAR(16)",
            "fields": [
                {"name": "message_data", "type": "CHAR"},
                {"name": "message_time", "type": "CHAR"},
                {"name": "dest_ip", "type": "CHAR"},
                {"name": "dest_port", "type": "CHAR"}
            ],
            "db_config": {
                "name": f"DB connection for durable_messagestore_"
                        f"{self._config['alias']}",
                "alias": f"durabledbconn_durable_messagestore_"
                         f"{self._config['alias']}",
                "logger": f"{self._config['alias']}_logger",
                "type": db_type,
                "credentials": credentials,
                "db": None,
            }
        }
        if config["db_config"]["type"] == "sqlitedbconn":
            config["db_config"]["check_same_thread"] = False
            dbtools.sqlite_create_table(
                config,
                self._db_path
            )
        self._endpoint_config["durable_messagestore_config"] = config

    def _build_idempotent_store_config(self) -> None:
        """Assembles the config for an endpoint's idempotent store.

        If idempotency is disabled then this method does not alter the endpoint
        config.

        The internal structure of the database required for idempotency is
        pre-configured here.

        Idempotent store config is sourced from "idempotent_store_config" of
        the user supplied config. If a config is not supplied then a default
        sqlite database is used.

        The idempotent store config uses the following structure:

        db_type: str
            Type of database (one of sqlite, mongo, mysql, maria)
        credentials: Dict
            db_type==sqlite:
            ----------------
            db_file: str
                Path to the sqlite database file
            db_type!=sqlite:
            ----------------
            database: str
                Database name
            user: str
                Database username.
            password: str
                Database password.
            host: str
                Host name of the database.
            port: int
                Port number of the database.

        """
        if not self._config.get("idempotent", False):
            return
        messagestore_config = self._config.get("idempotent_config")
        if messagestore_config:
            db_type = f"{messagestore_config['db_type']}dbconn"
            credentials = messagestore_config["credentials"]
        else:
            db_type = "sqlitedbconn"
            credentials = {
                "db_file": f"{self._config['alias']}_idempotent.db"
            }
        config = {
            "name": f"Idempotent message store for {self._config['alias']}",
            "alias": f"idempotent_messagestore_{self._config['alias']}",
            "logger": f"{self._config['alias']}_logger",
            "db_table": "idempotent_messages",
            "id_field": "message_id",
            "id_type": "CHAR(16)",
            "fields": [
                {"name": "message", "type": "CHAR"},
            ],
            "db_config": {
                "name": f"DB connection for idempotent_messagestore_"
                        f"{self._config['alias']}",
                "alias": f"durabledbconn_idempotent_messagestore_"
                         f"{self._config['alias']}",
                "logger": f"{self._config['alias']}_logger",
                "type": db_type,
                "credentials": credentials,
                "db": None,
            }
        }
        if config["db_config"]["type"] == "sqlitedbconn":
            config["db_config"]["check_same_thread"] = False
            dbtools.sqlite_create_table(
                config,
                self._db_path
            )
        self._endpoint_config["idempotent_messagestore_config"] = config
        self._endpoint_config["idempotent_queue_config"] = \
            self._build_queue_config(self._config["alias"], "idempotent")
        self._endpoint_config["idempotentfilter_config"] = {
            "name": f"Idempotent Filter for {self._config['alias']}",
            "alias": f"idempotentfilter_{self._config['alias']}",
            "logger": f"{self._config['alias']}_logger",
            "type": "idempotentfilter",
            "messagestore": None
        }

    def _make_host(self) -> str:
        """Generates a random unix hostname.

        Returns
        -------
        rtn: str
            32 character hex string.
        """
        return str(secrets.token_hex(16))

    def _log_color_map(self, color_str: str) -> str:
        """Maps human readable colors to ascii codes.

        Returns
        -------
        color: str
            ASCII color code, by default returns the reset code

        """
        if color_str == "black":
            return """\x1b[30m"""
        elif color_str == "red":
            return "\x1b[31m"
        elif color_str == "green":
            return "\x1b[32m"
        elif color_str == "yellow":
            return "\x1b[33m"
        elif color_str == "blue":
            return "\x1b[34m"
        elif color_str == "purple":
            return "\x1b[35m"
        elif color_str == "cyan":
            return "\x1b[36m"
        elif color_str == "white":
            return "\x1b[37m"
        elif color_str == "bg_black":
            return "\x1b[40m"
        elif color_str == "bg_red":
            return "\x1b[41m"
        elif color_str == "bg_green":
            return "\x1b[42m"
        elif color_str == "bg_yellow":
            return "\x1b[43m"
        elif color_str == "bg_blue":
            return "\x1b[44m"
        elif color_str == "bg_purple":
            return "\x1b[45m"
        elif color_str == "bg_cyan":
            return "\x1b[46m"
        elif color_str == "bg_white":
            return "\x1b[47m"
        else:
            return "\x1b[0m"

    def _generate_format_string(self, color: str) -> str:
        """Adds the log color to the message in the format string.

        Parameters
        ----------
        color: str
            String literal containing the ASCII color code

        Returns
        -------
        format_string: str
            Logging format string
        """
        color_ascii = self._log_color_map(color)
        return "%(asctime)s [%(levelname)s] (%(name)s) {%(module)s:" \
               "%(funcName)s:%(lineno)s} | " + color_ascii + \
               "%(message)s\x1b[0m"
