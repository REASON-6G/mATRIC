# -*- coding: utf-8 - *-
"""Endpoint Director Class.


"""
import os
from typing import (
    Any,
    Dict
)
import operator
import uvicorn
from wiremq.logging import wmqlogger
from wiremq.utils.configtools import (
    initialize_unix_destinations,
    initialize_unix_sockets,
    initialize_terminator,
    initialize_db_paths
)
from wiremq.extlib.database import (
    sqlitedbconn,
    # mariadbconn,
    mysqldbconn,
    mongodbconn
)
from wiremq.sysmanagement import messagestore


class EndpointDirector:
    """
    Endpoint Director
    =================

    The endpoint director is a constructor which oversees the execution of an
    endpoint building sequence. Equipped with a set of known builders, when it
    receives build requests, it loads those builders for the build. The
    validation of types is done by its driving class.

    Methods
    -------
    builder()
        Property, set and get the builder.
    register_builders()
        Register the known set of builders.
    build()
        Public interface for building a endpoint.
    _build_service_activator(): Any
        Build service activator.
    _build_pub_sub_channel(): Any
        Build pub sub channel.
    _build_channel(): Any
        Build channel.
    _config(): None
        Configure endpoint.
    _register(): None
        Register components to endpoint.
    _set_builder()
        Set the builder. Builder string must be in `_known_builders`

    Attributes
    ----------
    _builder : AbstractEndpointBuilder, required
        The current builder being instructed.
    _known_builders : dict, required
        The current builder universe of builders.
    _endpoint_domain: str
        Root domain for sockets within the endpoint.

    Note
    ----
    For different builds, the director may instruct the
    builders differently.

    """

    def __init__(self) -> None:
        """Endpoint Director.

        The EndpointDirector class loads builders and builds endpoints from
        known types.

        Example
        -------

        >>> sab = serviceactivatorbuilder.ServiceActivatorBuilder
        >>> ep_director = endpointdirector.EndpointDirector()
        >>> ep_director.register_builders({"serviceactivatorbuilder": sab})
        >>> config["type"] = "serviceactivator"
        >>> sa = ep_director.build(config, "serviceactivator")
        """
        self._endpoint_domain = None
        super().__init__()
        self._known_builders = {}
        self._builder = None

    @property
    def builder(self) -> Any:
        """Return the current Directors' builder.

        Returns
        -------
        Builder : Builder
           This returns the current builder.
        """
        return self._builder

    @builder.setter
    def builder(self, builder: Any) -> None:
        """Set the Builder for the Director.

        Parameters
        ----------
        builder : Builder, required
            Set the Directors' builder.

        """
        self._builder = builder

    def register_builders(self, builder_conf: Dict) -> None:
        """Load the builder objects.

        The director provides the controlling code to register a set of known
        builder. Provide a config to do so.

        Parameters
        ---------
        builder_conf : dict, required
            Keys define type [endpoint|socket], value define their module.

        """
        for key, val in builder_conf.items():
            self._known_builders[key] = val()

    def build(self, build_config: Dict, btype: str) -> Any:
        """Generic endpoint build interface.

        Idempotent filter and store are initialized here.

        Unix sockets are initialized and terminator strings are converted to
        bytes before the endpoint is built.

        The build method determines which type of object and initial data field
        conditions. See section for details.

        Parameters
        ----------
        type : str, required
            Final result type. One of the following three:
            serviceactivator : str
                Service Activator endpoint.
            pubsub_channel : str
                PubSub Channel endpoint.
            channel : str
                Channel endpoint.

        build_config : dict, required
            The endpoint's corresponding creation config.
        """
        self._set_builder(btype)
        _endpoint_domain = build_config["internal_domain"]
        self._build_logger(build_config)
        build_config = initialize_terminator(build_config)
        build_config = initialize_unix_sockets(build_config, _endpoint_domain)
        build_config = \
            initialize_unix_destinations(build_config, _endpoint_domain)
        _is_idempotent = build_config.get("idempotent", False)
        _is_durable = build_config.get("durable", False)
        _db_path = build_config.get("db_path")
        build_config = self._build_resequencer_store(build_config)
        if _db_path:
            build_config = initialize_db_paths(build_config, _db_path)
        if _is_idempotent:
            build_config = self._build_idempotency(build_config)
        if _is_durable:
            build_config = self._build_durable(build_config)

        if (btype == 'serviceactivator'):
            return self._build_service_activator(build_config)
        elif (btype == 'pubsubchannel'):
            return self._build_pub_sub_channel(build_config)
        elif (btype == 'channel'):
            return self._build_channel(build_config)
        elif (btype == 'messagebus'):
            return self._build_bus(build_config)
        elif (btype == 'router'):
            return self._build_router(build_config)
        else:
            pass

    def _build_idempotency(self, build_config: dict) -> dict:
        """Builds configs and components required for an idempotent endpoint.

        Parameters
        ----------
        build_config: dict
            The build configuration dictionary.

        Returns
        -------
        build_config: dict
            Updated build config
        """
        if build_config["idempotent"]:
            idempotent_queue = self._builder.make_queue(
                build_config["idempotent_queue_config"]
            )
            idempotent_ms = self._make_messagestore(
                build_config["idempotent_messagestore_config"]
            )
            build_config["idempotent_queue"] = idempotent_queue
            build_config["idempotentfilter_config"]["message_store"] = \
                idempotent_ms
            build_config["idempotentfilter_config"]["processor_queue"] = \
                idempotent_queue
        return build_config

    def _build_resequencer_store(self, build_config: dict) -> dict:
        """If the consumer's processor chain contains a resequencer, a message
        store is created for it and inserted into the build config here.

        Parameters
        ----------
        build_config: dict
            The build configuration dictionary.

        Returns
        -------
        build_config: dict
            Updated build config

        """
        resequencer_config = build_config["consumer_config"][
            "scheduler_config"]["worker_config"]["processor_map"].get("RQ")
        if resequencer_config:
            resequencer_ms = self._make_messagestore(
                resequencer_config["config"]["messagestore_config"]
            )
            resequencer_config["message_store"] = resequencer_ms
            build_config["consumer_config"]["scheduler_config"][
                "worker_config"]["processor_map"]["RQ"]["config"][
                "message_store"] = resequencer_ms
        return build_config

    def _make_messagestore(self, ms_config: Dict) -> Any:
        """Creates a message store for the endpoint

        Parameters
        ----------
        ms_config: Dict
            Message store config, includes dbconn config.
            name: str
                Message store name.
            alias: str
                Message store alias.
            db_table: str
                Table name used for storing messages.
            id_field: str
                ID field used in the table.
            id_type: str
                ID type (e.g. CHAR).
            fields: list
                Other fields and their types in a list of tuples.
            db_config: Dict
                name: str
                    DB config name.
                alias: str
                    DB config alias.
                type: str
                    DB config type (one of sqlitedbconn, mariadbconn,
                    mysqldbconn, mongodbconn).
                check_same_thread: bool
                    For sqlite only, same thread enforcement flag.
                credentials: Dict
                    Credentials, format is different for each db type

        Returns
        -------
        ms: Message store

        """
        dbtype = ms_config["db_config"]["type"]
        if dbtype == "sqlitedbconn":
            db = sqlitedbconn.SQLiteDBConn(ms_config["db_config"])
        elif dbtype == "mariadbconn":
            db = mariadbconn.MariaDBConn(ms_config["db_config"])
        elif dbtype == "mysqldbconn":
            db = mysqldbconn.MySQLDBConn(ms_config["db_config"])
        elif dbtype == "mongodbconn":
            db = mongodbconn.MongoDBConn(ms_config["db_config"])
        ms_config["db_conn"] = db
        return messagestore.MessageStore(ms_config)

    def _build_durable(self, build_config: dict) -> dict:
        """ Builds configs and components required for a durable endpoint.

        Parameters
        ----------
        build_config: dict
            The build configuration dictionary.

        Returns
        -------
        build_config: dict
            Updated build config
        """
        if build_config["durable"]:
            build_config["durable_store"] = self._make_messagestore(
                build_config["durable_messagestore_config"]
            )
        return build_config

    def _initialize_terminator(self, build_config: dict) -> dict:
        """Converts terminator strings into bytes.

        Parameters
        ----------
        build_config: Dict
            Endpoint config (or sub-config when in recursion)
        """
        for k, v in build_config.items():
            if isinstance(v, dict):
                if "terminator" in v.keys() \
                        and isinstance(v["terminator"], str):
                    v["terminator"] = v["terminator"].encode("utf")
                else:
                    self._initialize_terminator(v)
        return build_config

    def _initialize_unix_sockets(self, build_config: dict) -> dict:
        """Initializes unix socket domains in a config.

        This recursive method parses through a config, identifies any hosts
        which are unix domains, then prefixes the endpoint's internal domain
        path and unlinks any existing socket at that domain.

        Parameters
        ----------
        build_config: Dict
            Endpoint config (or sub-config when in recursion)

        Returns
        -------
        build_config: dict
            modified config or sub-config

        """
        for k, v in build_config.items():
            if "socket_config" in k \
                    and v["family"] == "unix" \
                    and "host" in v.keys():
                if v["host"] is not None:
                    v["host"] = os.path.join(self._endpoint_domain, v["host"])
                    try:
                        os.unlink(v["host"])
                    except OSError:
                        pass
            if isinstance(v, dict):
                self._initialize_unix_sockets(v)
        return build_config

    def _initialize_unix_destinations(self, build_config: dict) -> dict:
        """Initializes unix socket domains in a config.

        This recursive method parses through a config, identifies any hosts
        which are unix domains, then prefixes the component's internal domain
        path and unlinks any existing socket at that domain.

        Parameters
        ----------
        build_config: Dict
            Component config (or sub-config when in recursion)

        Returns
        -------
        build_config: dict
            modified config or sub-config

        """
        for k, v in build_config.items():
            if k == "SD" and "outbound_socket_config" in v:
                if v["outbound_socket_config"]["family"] == "unix":
                    v["config"]["dest_ip"] = os.path.join(
                        self._endpoint_domain,
                        v["config"]["dest_ip"]
                    )
            if isinstance(v, dict):
                self._initialize_unix_destinations(v)

        return build_config

    def _build_logger(self, build_config: Dict) -> None:
        """Builds a logger based on the config, or a default basic logger.

        Parameters
        ----------
        build_config: Dict
            The build configuration dictionary
        """
        wmqlogger.WmqLogger(
            build_config.get(
                "logger_config",
                {"name": "Basic wiremq logger", "alias": "basic_logger"}
            )
        )

    def _build_service_activator(self, build_config: Dict) -> Any:
        """Build service activator.

        Parameters
        ----------
        build_config : dict, required
            The build configuration dictionary.
        """
        receivedqueue = self._builder.make_queue(
            build_config["received_queue_config"]
        )
        sendqueue = self._builder.make_queue(
            build_config["send_queue_config"]
        )
        taskqueue = self._builder.make_queue(
            build_config["task_queue_config"]
        )
        messagequeue = self._builder.make_queue(
            build_config["message_queue_config"]
        )
        if "QD" in build_config["producer_config"]["scheduler_config"][
            "worker_config"
        ]["processor_map"]:
            build_config["producer_config"]["scheduler_config"][
                "worker_config"]["processor_map"]["QD"]["config"][
                    "shared_queue"] = receivedqueue
        build_config["ioloop_config"]["task_queue"] = taskqueue
        eventloop = self._builder.make_eventloop(
            build_config["ioloop_config"]
        )
        consumer = self._builder.make_consumer(
            build_config["consumer_config"]
        )
        producer = self._builder.make_producer(
            build_config["producer_config"]
        )
        requesthandler, responsehandler = \
            self._builder.make_requesthandlers(
                build_config["request_handlers"]
            )
        transaction_ms = self._make_messagestore(
            build_config["transaction_messagestore_config"]
        )
        history_ms = self._make_messagestore(
            build_config["history_messagestore_config"]
        )
        services = build_config["services"]
        asgi_app = self._builder.make_httprequestserver(
            build_config["asgi_app_config"]
        )
        asgi_config = uvicorn.Config(
            asgi_app,
            host=build_config["asgi_app_config"].get("host", "127.0.0.1"),
            port=build_config["asgi_app_config"]["port"],
            log_level="error",
            ssl_certfile=build_config.get("ssl_certfile"),
            ssl_keyfile=build_config.get("ssl_keyfile")
        )
        server = uvicorn.Server(asgi_config)
        build_config.update({
            "task_queue": taskqueue,
            "request_handler": requesthandler,
            "response_handler": responsehandler,
            "eventloop": eventloop,
            "send_queue": sendqueue,
            "received_queue": receivedqueue,
            "message_queue": messagequeue,
            "transaction_store": transaction_ms,
            "history_store": history_ms,
            "consumers": [consumer],
            "producers": [producer],
            "services": services,
            "asgi_app": asgi_app,
            "httpserver": server
        })
        self._config(build_config)
        self._register(build_config)
        return self._builder.product

    def _build_pub_sub_channel(self, build_config: Dict) -> Any:
        """Build pub sub channel.

        Parameters
        ----------
        build_config : dict, required
            The build configuartion dictionary.
        """
        commandconsumer = self._builder.make_consumer(build_config[
            "commandconsumer_config"]
        )
        eventconsumer = self._builder.make_consumer(build_config[
            "consumer_config"]
        )
        producer = self._builder.make_producer(build_config["producer_config"])
        send_queue = self._builder.make_queue(build_config["send_queue_config"])
        task_queue = self._builder.make_queue(build_config["task_queue_config"])
        dispatch_queue = self._builder.make_queue(
            build_config["dispatch_queue_config"]
        )
        recipientlistqueue = self._builder.make_queue(
            build_config["recipientlist_queue_config"]
        )

        # Update ioloop config's queue
        build_config["ioloop_config"]["task_queue"] = task_queue
        eventloop = self._builder.make_eventloop(build_config["ioloop_config"])

        build_config["sockdispatcher_config"]["processor_queue"] = \
            dispatch_queue

        # Update recipientlist config
        build_config["recipientlist_config"]["operators"] = {
            'gt': operator.gt,
            'lt': operator.lt,
            'eq': operator.eq,
            'ge': operator.ge,
            'le': operator.le,
            'ni': operator.contains
        }
        build_config["recipientlist_config"]["processor_queue"] = \
            recipientlistqueue

        # Update the pubsub channel config
        build_config.update({
            "task_queue": task_queue,
            "eventloop": eventloop,
            "send_queue": send_queue,
            "dispatch_queue": dispatch_queue,
            "recipientlist_queue": recipientlistqueue,
            "consumers": [commandconsumer, eventconsumer],
            "producers": [producer]
        })

        if build_config["durable"]:
            durable_ms = self._make_messagestore(
                build_config["durable_messagestore_config"]
            )
            build_config["durable_store"] = durable_ms
        self._config(build_config)
        self._register(build_config)
        return self._builder.product

    def _build_channel(self, build_config: Dict) -> Any:
        """Build channel.

        Parameters
        ----------
        build_config : dict, required
            The build configuration dictionary.
        """
        # Consumer/producer
        consumer = self._builder.make_consumer(build_config[
            "consumer_config"]
        )
        producer = self._builder.make_producer(build_config[
            "producer_config"]
        )

        # Queues
        channel_send_queue = self._builder.make_queue(build_config[
            "send_queue_config"]
        )
        channel_received_queue = self._builder.make_queue(build_config[
            "received_queue_config"]
        )
        channel_task_queue = self._builder.make_queue(build_config[
            "task_queue_config"]
        )
        channel_dispatch_queue = self._builder.make_queue(build_config[
            "dispatch_queue_config"]
        )
        build_config["ioloop_config"]["task_queue"] = channel_task_queue
        eventloop = self._builder.make_eventloop(build_config[
            "ioloop_config"]
        )
        build_config["sockdispatcher_config"]["processor_queue"] = \
            channel_dispatch_queue

        channel_in_sock = build_config["ioloop_config"]["socket"]

        build_config.update({
            "consumers": [consumer],
            "producers": [producer],
            "eventloop": eventloop,
            "insocket": channel_in_sock,
            "task_queue": channel_task_queue,
            "received_queue": channel_received_queue,
            "send_queue": channel_send_queue,
            "dispatch_queue": channel_dispatch_queue
        })
        self._config(build_config)
        self._register(build_config)
        return self._builder.product

    def _build_router(self, build_config: Dict) -> Any:
        """Build router.

        Parameters
        ----------
        build_config : dict, required
            The build configuration dictionary.
        """
        # Consumer/producer
        consumer = self._builder.make_consumer(build_config[
            "consumer_config"]
        )
        producer = self._builder.make_producer(build_config[
            "producer_config"]
        )

        # Queues
        router_send_queue = self._builder.make_queue(build_config[
            "send_queue_config"]
        )
        router_received_queue = self._builder.make_queue(build_config[
            "received_queue_config"]
        )
        router_task_queue = self._builder.make_queue(build_config[
            "task_queue_config"]
        )
        router_dispatch_queue = self._builder.make_queue(build_config[
            "dispatch_queue_config"]
        )
        build_config["ioloop_config"]["task_queue"] = router_task_queue
        eventloop = self._builder.make_eventloop(build_config[
            "ioloop_config"]
        )
        build_config["sockdispatcher_config"]["processor_queue"] = \
            router_dispatch_queue

        router_in_sock = build_config["ioloop_config"]["socket"]

        build_config.update({
            "consumers": [consumer],
            "producers": [producer],
            "eventloop": eventloop,
            "insocket": router_in_sock,
            "task_queue": router_task_queue,
            "received_queue": router_received_queue,
            "send_queue": router_send_queue,
            "dispatch_queue": router_dispatch_queue
        })
        self._config(build_config)
        self._register(build_config)
        return self._builder.product

    def _build_bus(self, build_config: Dict) -> Any:
        """Build message bus.

        Parameters
        ----------
        build_config : dict, required
            The build configuration dictionary.
        """
        # Consumer/producer
        consumer = self._builder.make_consumer(build_config[
            "consumer_config"]
        )
        producer = self._builder.make_producer(build_config[
            "producer_config"]
        )

        # Queues
        bus_send_queue = self._builder.make_queue(build_config[
            "send_queue_config"]
        )
        bus_received_queue = self._builder.make_queue(build_config[
            "received_queue_config"]
        )
        bus_task_queue = self._builder.make_queue(build_config[
            "task_queue_config"]
        )
        bus_dispatch_queue = self._builder.make_queue(build_config[
            "dispatch_queue_config"]
        )
        bus_invalid_message_queue = self._builder.make_queue(build_config[
            "invalid_message_queue_config"]
        )
        build_config["ioloop_config"]["task_queue"] = bus_task_queue
        eventloop = self._builder.make_eventloop(build_config[
            "ioloop_config"]
        )
        build_config["sockdispatcher_config"]["processor_queue"] = \
            bus_dispatch_queue

        bus_in_sock = build_config["ioloop_config"]["socket"]

        connections = self._builder.set_connections(
            build_config.get("connections", []))

        build_config.update({
            "consumers": [consumer],
            "producers": [producer],
            "eventloop": eventloop,
            "insocket": bus_in_sock,
            "task_queue": bus_task_queue,
            "received_queue": bus_received_queue,
            "send_queue": bus_send_queue,
            "dispatch_queue": bus_dispatch_queue,
            "invalid_message_queue": bus_invalid_message_queue,
            "connections": connections
        })
        self._config(build_config)
        self._register(build_config)
        return self._builder.product

    def _config(self, attributes: Dict) -> None:
        """Configure endpoint.

        Part of the process for building an endpoint requires configuring its
        attributes.

        Parameters
        ----------
        attributes : dict, required
            The attributes for the endpoint.
            services: Dict
                A mapping of path to handler
        """
        self._builder.config(attributes)

    def _register(self, components: Dict) -> None:
        """Register components to endpoint.

        To complete the full endpoint construction we need to add its
        components.

        Parameters
        ----------
        components : dict, required
            The components to be added.
            task_queue: Queue, required
            response_handler: Handler, required
            eventloop: eventloop, required
            send_queue: Queue, required
            consumers: list, required
            producers: list, required
        """
        self._builder.register(components)

    def _set_builder(self, btype: str) -> None:
        """Set the builder.

        Parameters
        ----------
        btype : str, required
            The named type. [serviceactivator|pubsubchannel|channel]

        """
        _bldr_index = ''.join((btype, 'builder'))
        self._builder = self._known_builders[_bldr_index]
