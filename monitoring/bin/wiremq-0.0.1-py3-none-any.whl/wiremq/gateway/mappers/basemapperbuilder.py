# -*- coding: utf-8 -*-

from typing import Dict
from wiremq.processing import baseprocessmanager
from wiremq.extlib.queue import fifoqueue
from wiremq.mappers import basemapper


class BaseMapperBuilder:
    """
    Base Mapper Builder
    ===================

    Builder class for creating a Base Mapper.

    Methods
    -------
    _reset(): None
        Reset the config and create a fresh product instance.
    make_mapper(): None
        Create a mapper.
    config(): None
        Configure attributes of the mapper.
    """

    def __init__(self) -> None:
        """Base Mapper Builder constructor.

        Example
        -------
        See integration test files for mapper's config, which
        contains an example of the fields and values required.

        >>> mapper_builder = basemapperbuilder.BaseMapperBuilder()
        >>> mapper_builder.make_mapper(config)
        >>> mapper = mapper_builder.product
        """
        self._reset()

    def __str__(self):
        return 'Mapper-Builder Object'

    def _reset(self) -> None:
        """Reset the builder's product.

        This internal call refreshes the builder's current configured product
        and creates a fresh instance of the class. The builder can then accept
        new building requests.
        """
        self._mapper = basemapper.BaseMapper()

    @property
    def product(self) -> basemapper.BaseMapper:
        """This is the result of the building.

        Note
        ----
        Provided is the interface for retrieving the final product.
        After the retrieval of a configured product, the builder
        should be ready to accept new building requests. To account for
        this design, a call to the `product` property calls the internal
        `_reset()` method.
        """
        mapper = self._mapper
        self._reset()
        return mapper

    def make_mapper(self, mapper_opt: Dict) -> None:
        """Create a mapper.

        Parameters
        ----------
        mapper_opt : Dict, required
            The initial mapper configuration.
        """
        queue_config = mapper_opt["processor_queue_config"]
        process_manager_config = mapper_opt["process_manager_config"]
        processor_queue = fifoqueue.FifoQueue(queue_config)
        process_manager_config["processor_queue"] = processor_queue
        process_manager = baseprocessmanager.BaseProcessManager(
            process_manager_config)
        mapper_opt["processor_queue"] = processor_queue
        mapper_opt["process_manager"] = process_manager
        self.config(mapper_opt)

    def config(self, config: Dict = None) -> None:
        """Configure attributes for the mapper.

        Parameters
        ---------
        config : dict, required
            The attributes for the mapper.
        """
        self._mapper.config(config)
        self._mapper.register(config)
