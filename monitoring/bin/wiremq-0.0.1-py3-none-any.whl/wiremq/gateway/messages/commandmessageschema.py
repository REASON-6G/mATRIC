# -*- coding: utf-8 -*-
from typing import Dict
from wiremq.gateway.messages import basemessageschema


class CommandMessageSchema(basemessageschema.BaseMessageSchema):
    """
    Command Message Schema
    ======================

    Message schema for command messages. In addition to the requirements of the
    :ref:`Base Message Schema`, the payload of the command message must also
    contain:

    - command: int (see :ref:`WireMQ Command Codes`
    - params: dict (required parameters for the interface)


    Examples
    ========

    .. code-block:: python
        :linenos:
        :caption: Example command message

        import time, datetime, uuid, secrets

        {
            "type": "command",
            "sender_ip": "127.0.0.1",
            "sender_port": 5000,
            "sender_alias": "my_endpoint",
            "dest_ip": "127.0.0.1",
            "dest_port": 4001,
            "protocol_version": "0.0.1",
            "message_id": str(uuid.uuid4()),  # generated if omitted
            "timestamp": time.time(), # generated if omitted
            "datetime": str(datetime.datetime.now()),  # generated if omitted
            "nonce": secrets.token_urlsafe(),  # generated if omitted
            "payload": {
                "command": 21,
                "params": {
                    "alias": "my_endpoint",
                    "host": "127.0.0.1",
                    "port": 5000,
                    "topics": ["topic1", "topic2"],
                    "criteria": {
                        "topic1": {
                            "ram": ("gt", 15000000)
                            "cores": ("gt", 2),
                        },
                        "topic2": {
                            "ram": ("lt", 12000000)
                            "cores": ("gt", 6),
                        }
                    }
                }
            }
        }

    """
    def __init__(self, config: Dict = None) -> None:
        self._header_schema = None
        self._payload_schema = None
        super().__init__(config)

    def _build_header_schema(self) -> None:
        """Overrides the default _build_header_schema to enforce the command
        type in the headers.
        """
        super()._build_header_schema()
        self._header_schema.update({
            "type": {
                "type": str,
                "one_of": ["command"]
            }
        })

    def _build_payload_schema(self) -> None:
        """Overrides the default _build_payload_schema to enforce the command
        number in the base of the payload
        """
        super()._build_payload_schema()
        self._payload_schema.update({
            "command": {
                "type": int,
                "criteria": [("ge", 0)]
            },
            "params": {
                "type": dict
            }
        })
