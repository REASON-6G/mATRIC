# -*- coding: utf-8 -*-
from typing import Dict
from wiremq.gateway.messages import basemessageschema


class OnlineMessageSchema(basemessageschema.BaseMessageSchema):
    """
        Online Message Schema
        =====================

        Message schema for online notification messages. The online message
        is a type of Event Message and is used in durable endpoints for
        notifying a remote endpoint that it is online.

        When an online message is received, the remote endpoint checks its
        durable store for any pending messages and sends them to the endpoint.
        Messages are removed from the durable store when the message has been
        acknowledged.

        Examples
        ========

        .. code-block:: python
            :linenos:
            :caption: Example online notification message

            import time, datetime, uuid, secrets

            {
                "type": "event",
                "sender_ip": "127.0.0.1",
                "sender_port": 5000,
                "sender_alias": "my_endpoint",
                "dest_ip": "127.0.0.1",
                "dest_port": 4001,
                "protocol_version": "0.0.1",
                "message_id": str(uuid.uuid4()),  # generated if omitted
                "timestamp": time.time(), # generated if omitted
                "datetime": str(datetime.datetime.now()),  # generated if omitted
                "nonce": secrets.token_urlsafe(),  # generated if omitted
                "payload": {
                    "state": "online"
                }
            }

        """
    def __init__(self, config: Dict = None) -> None:
        self._header_schema = None
        self._payload_schema = None
        super().__init__(config)

    def _build_header_schema(self) -> None:
        """Overrides the default _build_header_schema to enforce the event
        type in the headers.
        """
        super()._build_header_schema()
        self._header_schema.update({
            "type": {
                "type": str,
                "one_of": ["event"]
            }
        })

    def _build_payload_schema(self) -> None:
        """Overrides the default _build_payload_schema to enforce the payload
        of the online message.
        """
        super()._build_payload_schema()
        self._payload_schema.update({
            "state": {
                "type": str,
                "oneof": ["online"]
            }
        })
