# -*- coding: utf-8 -*-
from typing import Dict
from wiremq.gateway.messages import basemessageschema


class EventMessageSchema(basemessageschema.BaseMessageSchema):
    """
    Event Message Schema
    ====================

    Message schema for event messages. There are no additional requirements
    for an event message over a :ref:`Base Message`, and the event message
    must have a payload.

    Examples
    ========

    .. code-block:: python
        :linenos:
        :caption: Example event message

        import time, datetime, uuid, secrets

        {
            "type": "event",
            "sender_ip": "127.0.0.1",
            "sender_port": 5000,
            "sender_alias": "my_endpoint",
            "dest_ip": "127.0.0.1",
            "dest_port": 4001,
            "protocol_version": "0.0.1",
            "message_id": str(uuid.uuid4()),  # generated if omitted
            "timestamp": time.time(), # generated if omitted
            "datetime": str(datetime.datetime.now()),  # generated if omitted
            "nonce": secrets.token_urlsafe(),  # generated if omitted
            "payload": {
                "topic": "cpu",
                "data": {
                    "percent": 40.0
                }
            }
        }

    """
    def __init__(self, config: Dict = None) -> None:
        self._config = None
        self._header_schema = None
        self._payload_schema = None
        super().__init__(config)

    def _build_header_schema(self) -> None:
        """Overrides the default _build_header_schema to enforce the command
        type in the headers.
        """
        super()._build_header_schema()
        self._header_schema.update({
            "type": {
                "type": str,
                "one_of": ["event"]
            }
        })
