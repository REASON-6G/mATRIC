# -*- coding: utf-8 -*
from typing import Dict
from wiremq.gateway.messages import basemessageschema


class SequenceSchema(basemessageschema.BaseMessageSchema):
    """
    Sequence Schema
    ===============

    This schema is supplemented onto any message type to also validate
    sequence attributes.

    Sequence data is interpreted by a :ref:`Resequencer` filter to ensure
    messages are received in the correct order. It requires:

    - sequence_size: int (length of the sequence)
    - sequence_id: str (unique reference ID for the sequence)
    - position_id: int (position in the sequence, starting at 0)

    Examples
    ========

    .. code-block:: python
        :linenos:
        :caption: Example message with sequence data
        {
            "type": "event",
            "sender_ip": "127.0.0.1",
            "sender_port": 5000,
            "sender_alias": "my_endpoint",
            "dest_ip": "127.0.0.1",
            "dest_port": 4001,
            "protocol_version": "0.0.1",
            "message_id": str(uuid.uuid4()),  # generated if omitted
            "timestamp": time.time(), # generated if omitted
            "datetime": str(datetime.datetime.now()),  # generated if omitted
            "nonce": secrets.token_urlsafe(),  # generated if omitted
            "sequence_id": "332072d0-d35a-4efa-bafd-99ac9d4cbd2f",
            "sequence_size": 4,
            "position_id": 0,
            "payload": {
                "topic": "data_dump",
                "data": {
                    "sensor_1": "7025553831, 3018644525, 7667712787"
                }
            }
        }
    """
    def __init__(self, config: Dict = None) -> None:
        self._config = None
        self._header_schema = None
        self._payload_schema = None
        super().__init__(config)

    def _build_header_schema(self) -> None:
        """Overrides the default _build_header_schema to only enforce sequence
        data.
        """
        super()._build_header_schema()
        self._header_schema = {
            "sequence_size": {
                "type": int
            },
            "sequence_id": {
                "type": str,
            },
            "position_id": {
                "type": int,
                "criteria": [("ge", 0)]
            }
        }
