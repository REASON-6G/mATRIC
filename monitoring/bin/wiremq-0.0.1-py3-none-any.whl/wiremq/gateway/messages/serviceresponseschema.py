# -*- coding: utf-8 -*-
from typing import Dict
from wiremq.gateway.messages import basemessageschema


class ServiceResponseSchema(basemessageschema.BaseMessageSchema):
    """
    Service Response Schema
    =======================

    Schema to validate responses to the service activator.

    A Service Response Message is sent from a service to a
    :ref:`Service Activator` when responding to requests. The payload is
    typically forwarded to the client which initiated the request.

    In addition to the requirements from the :ref:`Base Message Schema`, the
    Service Response Schema also requires transactional information to be
    present:

    - type: str ("event")
    - correlation_id: str (should be set to the `message_id` of the request it
                           is responding to)
    - tx_correlation_id: str (should be set to the `tx_id` of the request it is
                           responding to)
    - tx_id: str (a new transaction identifier)
    - error_code: int (HTTP status code, e.g. 200, 404)
    - error_message: str (HTTP status message, e.g. "OK", "Not found")


    """
    def __init__(self, config: Dict = None) -> None:
        self._header_schema = None
        self._payload_schema = None
        super().__init__(config)

    def _build_header_schema(self) -> None:
        """Overrides the default _build_header_schema to enforce the required
        identifiers for a service response message.
        """
        super()._build_header_schema()
        self._header_schema.update({
            "type": {
                "type": str,
                "one_of": ["event"]
            },
            "correlation_id": {
                "type": str
            },
            "tx_correlation_id": {
                "type": str
            },
            "tx_id": {
                "type": str
            },
            "error_code": {
                "type": int
            },
            "error_message": {
                "type": str
            }
        })
