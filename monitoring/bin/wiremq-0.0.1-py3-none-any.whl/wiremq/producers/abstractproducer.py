# -*- coding: utf-8 -*-

from abc import (
    ABC,
    abstractmethod
)

from typing import (
    Any,
    Dict
)


class AbstractProducer(ABC):
    """
    Abstract Producer
    =================
    """

    def __init__(self, config: Dict = None):
        """Abstract producer class constructor."""
        pass

    @abstractmethod
    def _execute_scheduled(self) -> list:
        pass

    @abstractmethod
    def _loop(self) -> None:
        pass

    @abstractmethod
    def _loop_once(self) -> list:
        pass

    @abstractmethod
    def _store_message(self, message: Dict) -> bool:
        pass

    @abstractmethod
    def _remove_message(self, id: str) -> bool:
        pass

    @abstractmethod
    def _get_message(self, id: str) -> Any:
        pass

    @abstractmethod
    def get_config(self) -> Dict:
        pass

    @abstractmethod
    def register(self, filter: Any) -> bool:
        pass

    @abstractmethod
    def unregister(self) -> bool:
        pass

    @abstractmethod
    def run(self) -> Any:
        pass

    @abstractmethod
    def run_once(self) -> Any:
        pass

    @abstractmethod
    def get_task_stack(self) -> list:
        pass
