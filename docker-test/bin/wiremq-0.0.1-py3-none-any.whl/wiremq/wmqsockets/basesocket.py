# -*- coding: utf-8 -*-
"""Base Socket Class"""

import os
import ssl
import socket
import uuid
from typing import (
    Dict,
    Any,
)
import logging
from wiremq.wmqsockets import abstractsocket


class BaseSocket(abstractsocket.AbstractSocket):
    """Base socket class

    Base socket inherits from the abstract socket class. Basic functionality of
    python's socket library is implemented and extended. Connect, send, receive
    methods are standardised for the different families and protocols.

    Attributes
    ----------
    _id : str
        The unique ID for the socket.
    _config : dict
        Socket configuration dictionary.
    _socket : object
        Socket object.
    _sslctx : object
        An SSLContext object for an encrypted socket
    _log: object
        Python logging instance.

    Methods
    -------
    generate_id(): None
        Generate a unique ID for the socket
    get_id(): str
        Return the socket's unique ID
    config() : bool
        Configures the socket.
    get_config() : Dict
        Returns the configuration of the socket.
    set_protocol(): Any
        Sets socket protocol.
    set_family(): Any
        Sets socket family.
    create_context() : None
        Create an SSL context.
    create_socket(): None
        Creates a socket.
    get_fd(): int
        Gets the file descriptor of a socket.
    update_buffer(): bool
        Updates buffer size of the channel.
    close(): None
        Closes a socket file descriptor.
    """

    def __init__(self, config: Dict = None):
        """Base Class Constructor.

        Initialize a base socket. Base soscket options are
        required to initialize the socket.

        Parameters
        ----------
        config: dict
            Base socket configuration dictionary.
            type : str
                Socket type.
            name : str
                Socket name.
            protocol : str
                Socket protocol. Values are tcp, udp, raw, rdm, seq.
            family : str
                Socket family, Values are unix, inet.
            blocking : bool
                True if socket is in blocking mode, False if in non-blocking.
            buffer_size : int
                Socket buffer size for the number of bytes to send and receive
            context : Dict, optional
                type : str
                    Type of sockets to be wrapped - server or client.
                version : float
                    The TLS version to be applied to the wrapped socket.
                    1.1, 1.2, or 1.3, depending on the lowest version required.
                    For example, "1.2" would allow only connections using
                    TLSv1.2 or higher, excluding any TLSv1 and v1.1 connections.
                peer_cert : bool
                    Flag to specify whether a certicifate is required or not.
                cert: str
                    Path to certificate file.
                key: str
                    Path to key file.
                hostname: str
                    Host name for a wrapped socket.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> config = {}
        >>> config["type"] = "basesocket"
        >>> config["protocol"] = "tcp"
        >>> config["family"] = "inet"
        >>> config["blocking"] = True
        >>> socket = basesocket.BaseSocket(config)
        """
        super().__init__(config)
        self._id = self._generate_id()
        self._config = None
        self._socket = None
        self._sslctx = None
        self._log = None
        self._id = self._generate_id()
        if config:
            self.config(config)

    def __str__(self):
        """Overrides __str__ method."""
        return f"<Object: {self.__class__.__name__} Id: {self._id}>"

    def __repr__(self):
        """Overrides __repr__ method."""
        if not self._config:
            blocking = "n/a"
        elif self._config["blocking"] is True:
            blocking = "blocking"
        else:
            blocking = "non-blocking"

        return f"<Object: {self.__class__.__name__} Id: " \
               f"{self._id} mode:{blocking}>"

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def get_id(self) -> str:
        """Returns the socket's unique ID

        Returns
        -------
        rtn: str
            The unique ID of the socket, cast from UUID4 to string
        """
        self._log.args("%s: ()" % self)
        rtn = str(self._id)
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def config(self, config: Dict) -> bool:
        """Configures the socket.

        Parameters
        ----------
        config: Dict
            The configuration of the base socket. See constructor for fields.

        Returns
        -------
        rtn: bool
            Returns True if successful
        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._config = config
        self.create_socket(config)
        if "context" in config:
            self.create_context(config["context"])
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def get_config(self) -> Dict:
        """Returns the configuration of the socket

        Returns
        -------
        rtn: Dict
            The configuration of the dictionary
        """
        self._log.args("%s: ()" % self)
        config = self._config
        self._log.rtn("%s: success | data: %s" % (self, config))
        return config

    def set_protocol(self, protocol: str) -> int:
        """Sets and returns the socket protocol.

        The following protocols are supported:
        1. A tcp (SOCK_STREAM) is a connection-based protocol. The connection
           is established and the two parties have a conversation until the
           conn is terminated by one of the parties or by a network error.
        2. A udp (SOCK_DGRAM) is a datagram-based protocol. You send one
           datagram and get one reply and then the connection terminates.
        3. A raw (SOCK_RAW) is used to receive raw packets. This means packets
           received at the Ethernet layer will directly pass to the raw socket.
           Stating it precisely, a raw socket bypasses the normal TCP/IP
           processing and sends the packets to the specific user application
        4. A reliable delivered message socket(SOCK_RDM) is similar to a
           datagram socket but provides in addition reliable datagram delivery.
        5. A sequenced packet socket(SOCK_SEQPACKET) is similar to a stream
           socket but retains data block boundaries.

        Returns
        -------
        _protocol : object
            The socket protocol object required to create each socket.

        """
        self._log.args("%s: (protocol: %s)" % (self, protocol))
        if protocol == "tcp":
            _protocol = socket.SOCK_STREAM
        elif protocol == "udp":
            _protocol = socket.SOCK_DGRAM
        elif protocol == "raw":
            _protocol = socket.SOCK_RAW
        elif protocol == "seq":
            _protocol = socket.SOCK_SEQPACKET
        elif protocol == "rdm":
            _protocol = socket.SOCK_RDM
        self._log.rtn("%s: success | data: %s" % (self, _protocol))
        return _protocol

    def set_family(self, family: str) -> int:
        """Sets and returns the socket family.

        The following families are supported:
        1. A unix(AF_UNIX) socket family is used to communicate between
           processes on the same machine efficiently.
        2. A inet(AF_INET) refers to Address from the Internet and it requires
           a pair of (host, port).

        Returns
        -------
        _family : Any
            Returns the socket family object required to create each socket.
        """
        self._log.args("%s: (family: %s)" % (self, family))
        if family == "inet":
            _family = socket.AF_INET
        elif family == "unix":
            _family = socket.AF_UNIX
        self._log.rtn("%s: success | data: %s" % (self, _family))
        return _family

    def create_context(self, config: Dict) -> None:
        """Creates an SSL context for an encrypted socket.

        Parameters
        ----------
        config: Dict
            SSL context configuration for server or client side.

            type: str
                Type of socket. Values is "server" and "client".
            version: str
                Version of ssl. only 1.3 version is supported.
            peer_cert_required: bool
                True if peer certificates are required, false otherwise.
                V1 supports only True.
            cert: str
                Server/Client certificate file location.
            key: str
                Server/Client key file location.
            client_cert: str
                Client certificate location. Required when type
                is type is "server".
            server_cert: str
                Server certificate location. Required when type
                is type is "client".
            server_sni_host: str
                Server sni hostname. Required when type
                is type is "client".
        """
        if config["type"] == "server":
            self._sslctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
            self._sslctx.verify_mode = ssl.CERT_REQUIRED
            self._sslctx.load_cert_chain(certfile=config["cert"], keyfile=config["key"])
            self._sslctx.load_verify_locations(cafile=config["client_cert"])
        else:
            self._sslctx = ssl.create_default_context(
                ssl.Purpose.SERVER_AUTH, cafile=config["server_cert"]
            )
            self._sslctx.load_cert_chain(certfile=config["cert"], keyfile=config["key"])

    def create_socket(self, config: dict) -> Any:
        """Creates and returns a socket object.

        Socket is created based on family and protocol.
        The socket is then set as blocking or non-blocking.
        Address is set to be re-usable.

        Parameters
        ----------
        config: dict
            Base socket configuration dictionary.
            type : str
                Socket type.
            protocol : str
                Socket protocol. Values are tcp, udp, raw, rdm, seq.
            family : str
                Socket family, Accepted values are unix, inet,
            blocking : bool
                True if socket is in blocking mode, False if in non-blocking.

        Returns
        -------
        _socket: object
            The created socket.
        """
        self._log.args("%s: (config: %s)" % (self, str(config)))
        _protocol = self.set_protocol(config["protocol"])
        _family = self.set_family(config["family"])
        self._socket = socket.socket(_family, _protocol)
        self._socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._socket.setblocking(config["blocking"])
        _socket = self._socket
        self._log.rtn("%s: success | data: %s" % (self, _socket))
        return _socket

    def get_fd(self) -> int:
        """Gets the file descriptor of the socket.

        Returns
        -------
        file_descriptor : int
            The socket's file descriptor (a small integer), or -1 on failure.
        """
        self._log.args("%s: ()" % self)
        file_descriptor = self._socket.fileno()
        self._log.rtn("%s: success | data: %s" % (self, file_descriptor))
        return file_descriptor

    def update_buffer(self, buffer: int) -> bool:
        """Updates buffer size of the channel.

        Parameters
        ----------
        buffer: int
            The new buffer size of the channel.

        Returns
        -------
        rtn: bool
            Returns true if successful, otherwise false.
        """
        self._log.args("%s: (buffer: %s)" % (self, buffer))
        self._config["buffer_size"] = buffer
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def close(self) -> None:
        """Closes a socket file descriptor, and unlinks domain for unix.
        sockets."""
        self._log.args("%s: ()" % self)
        if self._config["family"] == "unix":
            hostname = self._socket.getsockname()
            try:
                os.unlink(hostname)
            except OSError:
                pass
        self._socket.close()
        self._socket = None
        self._config = None
        self._sslctx = None
        self._log.rtn("%s: success" % self)
