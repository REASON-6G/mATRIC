# -*- coding: utf-8 -*-
"""Outbound Socket Class"""

import socket
from typing import Dict
from wiremq.wmqsockets import basesocket
from wiremq.extlib.err.socketexception import (
    SocketException,
    SocketConnectionRefusedException,
    SocketBrokenPipeException,
    SocketGAIException,
    SocketNotFoundException,
)


class OutboundSocket(basesocket.BaseSocket):
    """Outbound socket class

    Outbound socket inherits from the base socket class. Basic functionality
    of base socket is implemented and extended. Connect and send methods are
    implemented in the Outbound Socket class.

    Methods
    -------
    connect(self, host: str, port: int = None) -> bool:
        Connects to a remote socket.
    send(): int
        Sends data to a socket.

    Raises
    ------
    SocketConnectionRefusedException:
        Exception raised when a socket connection is refused.
    SocketBrokenPipeException:
        Exception raised when sending to an offline/non-existent socket.
    SocketGAIException:
        Exception raised for address related errors.
    SocketNotFoundException:
        Exception raised when trying to send a socket which does not exist.
    """

    def __init__(self, config: Dict = None):
        """Outbound Socket Class Constructor.

        Initialize an outbound socket. Outbound socket options are required to
        initialize the socket. They are typically the same as those used with a
        base socket.

        UDP/UNIX outboundsockets require a host attribute to be provided in the
        config.

        Parameters
        ----------
        config: dict
            Outbound socket configuration dictionary.
            id : hash
                A unique id using secrets lib with sha256 hashing.
            type : str
                Socket type.
            name : str
                Socket name.
            protocol : str
                Socket protocol. Values are tcp, udp, raw, rdm, seq.
            family : str
                Socket family, Values are unix, inet.
            blocking : bool
                True if socket is in blocking mode, False if in non-blocking.
            buffer_size : int
                Socket buffer size for the number of bytes to send and receive
            host: str
                Required for UDP/UNIX only, host name for the socket.
            context : Dict, optional
                type : str
                    Type of sockets to be wrapped - server or client.
                version : float
                    The TLS version to be applied to the wrapped socket.
                    1.1, 1.2, or 1.3, depending on the lowest version required.
                    For example, "1.2" would allow only connections using
                    TLSv1.2 or higher, excluding any TLSv1 and v1.1 connections.
                peer_cert : bool
                    Flag to specify whether a certicifate is required or not.
                cert: str
                    Path to certificate file.
                key: str
                    Path to key file.
                hostname: str
                    Host name for a wrapped socket.

        Example:
        -------
        >>> config = {}
        >>> config["type"] = "outboundsocket"
        >>> config["id"] = "6b724f14c9da00cae8ea1da9d4c8c0e5" +
        ...                "858bee1907e8eddfd1e0aeeef249c40f"
        >>> config["protocol"] = "tcp"
        >>> config["family"] = "inet"
        >>> config["blocking"] = True
        >>> socket = outboundsocket.OutboundSocket(config)
        """
        super().__init__(config)
        if self._log:
            self._log.args("%s: (config: %s)" % (self, config))
        if config["protocol"] == "udp" and config["family"] == "unix":
            self.bind(config["host"])
        if self._log:
            self._log.rtn("%s: success" % self)

    def connect(self, host: str, port: int = None) -> bool:
        """Connects to a remote socket.

        Parameters
        ----------
        host: str
            Ip address of the socket to connect.
        port: int
            Port address the socket to connect is listening.

        Raises
        ------
        SocketConnectionRefusedException:
            Raised when the socket cannot connect to another socket.

        """
        self._log.args("%s: ()" % self)
        try:
            if self._sslctx:
                self._socket = self._sslctx.wrap_socket(
                    self._socket,
                    server_side=False,
                    server_hostname=self._config["context"]["server_sni_host"]
                )
            if self._config["family"] == "unix":
                self._socket.connect(host)
            else:
                self._socket.connect((host, port))
        except ConnectionRefusedError as e:
            self._log.error(e)
            raise SocketConnectionRefusedException(e)
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def send(self, data: bytes, host: str = None, port: int = None) -> int:
        """Sends data to a socket.

        For TCP connections, the socket must already be connected. For UDP
        connections the destination address must be provided in this method's
        arguments. Raises a SocketBrokenPipeException when attempting to write
        to a closed pipe, raises a SocketGAIException for address-related
        errors, raises SocketNotFoundException when attempting to send to
        a domain that is unreachable/does not exist.

        Parameters
        ----------
        data : bytes
            Data to be transmitted to the socket.
        host: str
            Target hostname for senders using UDP sockets.
        port: int
            Target port for senders using UDP/INET sockets.

        Returns
        -------
        data : int
            Returns the number of bytes sent.

        Raises
        ------
        SocketBrokenPipeException:
            Raised when trying to write on a pipe where the other end is
            closed.
        SocketGAIException:
            Address-related errors by getaddrinfo() and getnameinfo()
        SocketNotFoundException:
            Raised when a requested directory/domain does not exist.
        """
        self._log.args("%s: (data: %s, host: %s, port: %s)" %
                       (self, data, host, port))
        try:
            if self._config["protocol"] == "udp":
                if self._config["family"] == "unix":
                    self._socket.sendto(data, host)
                elif self._config["family"] == "inet":
                    self._socket.sendto(data, (host, port))
            elif self._config["protocol"] == "tcp":
                self._socket.send(data)
            _sent = len(data)
        except BrokenPipeError as e:
            self._log.error(e)
            raise SocketBrokenPipeException(e)
        except socket.gaierror as e:
            self._log.error(e)
            raise SocketGAIException(e)
        except FileNotFoundError as e:
            self._log.error(e)
            raise SocketNotFoundException(e)
        except ConnectionRefusedError as e:
            self._log.error(e)
            raise SocketConnectionRefusedException(e)
        self._log.info("%s: %s bytes sent" % (self, _sent))
        self._log.rtn("%s: success | data: %s" % (self, _sent))
        return _sent

    def bind(self, host: str, port: int = None) -> None:
        """Binds the socket to an address.

        The socket must not already be bound.


        Parameters
        ----------
        host : str
            Host address of the socket, either a UNIX domain, IP or URL.
        port : int
            Port number of socket (TCP sockets only).

        Raises
        ------
        SocketException:
            Raises a SocketException when the binding address is invalid (wrong
            hostname, domain etc). Required for TCP or UNIX sockets so that a
            conn address is available to the other end.
        """
        try:
            if self._config["family"] == "unix":
                self._socket.bind(host)
            else:
                self._socket.bind((host, port))
        except OSError as e:
            raise SocketException("%s | %s : %s" % (e, host, port))

    def shutdown(self) -> bool:
        """Shuts down the socket, so that it can no longer read or write.

        Returns
        -------
        rtn : bool
            Returns True once the socket has been shut down.
        """
        self._log.args("%s: ()" % self)
        if self._config["protocol"] == "tcp":
            self._socket.shutdown(socket.SHUT_RDWR)
        _rtn = True
        self._log.rtn("%s: success | data: %s" % (self, _rtn))
        return _rtn
