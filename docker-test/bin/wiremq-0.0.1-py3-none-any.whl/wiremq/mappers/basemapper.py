# -*- coding: utf-8 -*-

import uuid
import logging
from typing import Dict
from wiremq.extlib.err.queueexception import (
    QueueEmptyException,
    QueueFullException
)
from wiremq.extlib.err.mapperexceptions import BaseMapperException
from wiremq.utils.configtools import (
    get_dict_value,
    set_dict_value
)
from wiremq.mappers import abstractmapper


class BaseMapper(abstractmapper.AbstractMapper):
    """
    Base Mapper
    ===========

    A mapper takes an incoming message, and uses filters / wrappers to
    convert it into a wiremq style message.

    The mapper loads the message into a processor queue, then the process
    manager passes it through the processing chain, which transforms the
    message.

    Attributes
    ----------
    _config: Dict
        The data required for the transaction.
    _process_manager: baseprocessmanager
        The process manager used to transform messages.
    _processor_queue: fifoqueue
        The processor queue used to load messages into the process manager.


    Methods
    -------
    config(): bool
        Configures the mapper.
    register(): bool
        Registers the process manager to the mapper.
    map(): Dict:
        Converts the message into a wiremq message using the process
        manager.
    unregister(): bool
        Unregisters all components from the mapper.

    """

    def __init__(self, config: Dict = None) -> None:
        """Base mapper constructor.

        Parameters
        ----------
        config : Dict
            Mapper configuration dictionary.
            name: str
                Name of the mapper.
            alias: str
                Alias for the mapper.
            type: str
                Component type (basemapper).
            process_manager: baseprocessmanager
                The process manager used to process messages.
            processor_queue: fifoqueue
                The queue used by the process manager.
        Example
        -------
        >>> processor_queue = fifoqueue.FifoQueue(processor_queue_config)
        >>> pm_config["processor_queue"] = processor_queue
        >>> pm = baseprocessmanager.BaseProcessManager(pm_config)
        >>> config = {
        ...     "name": "Test Mapper",
        ...     "alias": "test_mapper",
        ...     "type": "basemapper",
        ...     "process_manager": pm,
        ...     "processor_queue": processor_queue
        ... }
        >>> mapper = basemapper.BaseMapper(config)
        """
        self._config = None
        self._process_manager = None
        self._processor_queue = None
        self._id = self._generate_id()
        self._log = None
        if config:
            self.config(config)
            self.register(config)

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def _generate_id(self) -> str:
        """Generates a unique id for the mapper.

        Returns
        -------
        rtn: str
            The unique ID of the mapper, cast from UUID4 to string.
        """
        self._id = uuid.uuid4()
        rtn = str(self._id)
        return rtn

    def config(self, config: Dict) -> bool:
        """Config transaction with dict

        Parameters
        ----------
        config : Dict
            Mapper configuration dictionary.
            name: str
                Name of the mapper.
            alias: str
                Alias for the mapper.
            type: str
                Component type (basemapper).
            process_manager: baseprocessmanager
                The process manager used to process messages.
            processor_queue: fifoqueue
                The queue used by the process manager.

        Returns
        -------
        rtn: bool
            True if successful.


        Example
        -------
        >>> config = {
        ...     "name": "Test Mapper",
        ...     "alias": "test_mapper",
        ...     "id": "c5a101f409f4ae74e368899f0cc42ee8",
        ...     "type": "basemapper",
        ...     "process_manager": pm,
        ...     "processor_queue": processor_queue
        ... }
        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._config = config

        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def register(self, config: Dict) -> bool:
        """Registers components to the mapper.

        Parameters
        ----------
        config: Dict
            Mapper configuration dictionary.
            name: str
                Name of the mapper.
            alias: str
                Alias for the mapper.
            id: str
                Mapper ID.
            type: str
                Component type (basemapper).
            process_manager: baseprocessmanager
                The process manager used to process messages.
            processor_queue: fifoqueue
                The queue used by the process manager.

        Returns
        -------
        rtn: bool
            True if successful.
        """
        self._processor_queue = config["processor_queue"]
        self._process_manager = config["process_manager"]

        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def map(self, msg: Dict) -> Dict:
        """Converts the message into a wiremq message using the process
        manager.

        Parameters
        ----------
        msg: Dict
            Incoming message to be translated into a wiremq message.

        Returns
        -------
        message: Dict
            A mapped wiremq message.

        """
        # Map the required message attributes
        mapping = self._config["mapping"]
        mapped_msg = {}
        for dest_path, source_path in mapping.items():
            value = get_dict_value(msg, source_path)
            mapped_msg = set_dict_value(mapped_msg, dest_path, value)

        try:
            self._processor_queue.put(mapped_msg)
        except QueueFullException as e:
            self._log.error(e)
            raise BaseMapperException(e)

        self._process_manager.process()

        try:
            message = self._processor_queue.get()
        except QueueEmptyException as e:
            self._log.error(e)
            raise BaseMapperException(e)

        self._log.rtn("%s: success | data: %s" % (self, mapped_msg))
        return message

    def unregister(self) -> bool:
        """Unregisters all components from the mapper.

        Returns
        -------
        rtn: bool
            True if successful.
        """
        self._processor_queue = None
        self._process_manager = None

        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
