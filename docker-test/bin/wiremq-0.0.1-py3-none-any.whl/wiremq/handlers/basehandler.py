# -*- coding: utf-8 -*-

import uuid
from typing import (
    Any,
    Dict
)
import logging
from wiremq.handlers import abstracthandler


class BaseHandler(abstracthandler.AbstractHandler):
    """
    Base Handler
    ============

    Base handler is the skeleton of all wiremq handlers. It provides the
    functionality required for message handling during its life cycle.
    Handlers use dispatchers to dispatch messages after they've been handled.

    Attributes
    ----------
    _id: str
        Unique ID for the handler.
    _config: Dict
        Configuration for processor.
    _dispatcher: object
        Dispatcher for sending a message after handling.
    _outsocket_fd: int
        The file descriptor for the dispatcher's outbound socket.
    _dest_host: str
        The destination IP/host address to dispatch messages to.
    _dest_port: int, optional
        The destination port number to dispatch messages to.

    Methods
    -------
    _generate_id(): str
        Generates a unique id.
    _handle(): Message
        Helper method for handle(). To be overridden by sub-classes.
    config(): bool
        Initial setup of the handler.
    handle(): None
        Handles a message.
    finish(): None
        Performs teardown/cleanup of the handler.
    close(): bool
        Closes the dispatcher used by the handler.
    """
    def __init__(self, config: Dict = None):
        """Base processor class constructor.

        Parameters
        ----------
        config: Dict
            name: str
                Name of handler.
            uid: hash
                Handler identification number.
            dispatcher: object
                Dispatcher for sending a message after handling.
            outsocket_fd: int
                The file descriptor for the dispatcher's outbound socket.
            host: str
                The destination IP/host addresss to dispatch messages to.
            port: int, optional
                The destination port number to dispatch messages to.

        Example
        -------
        >>> tdispatcher = transportdispatcher.TransportDispatcher(td_config)
        >>> config = {
        ...     "dispatcher": "tdispatcher",
        ...     "name": "Base Handler",
        ...     "uid": "616251e047993b9da10745c4d06126c" +
        ...            "79ad730dcd36844aeba1072386e652f187",
        ...     "outsocket_fd": 8,
        ...     "host": 38f3b02sc918d312cd83a
        ... }
        >>> bh = basehandler.BaseHandler(config)
        """
        super().__init__()
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._id = self._generate_id()
        self._log.args("%s: (config: %s)" % (self, config))
        self._config = None
        self._dispatcher = None
        self._outsocket_fd = None
        self._dest_host = None
        self._dest_port = None
        if config:
            self.config(config)

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        self._log.rtn("success | data: %s" % _id)
        return _id

    def _handle(self, message: Any) -> None:
        """Helper method for handle(). To be overridden by sub-classes.

        Parameters
        ----------
        message: Any
            Message/data to be handled.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        data = {
            "message": message,
            "dest_ip": self._dest_host,
            "dest_port": self._dest_port
        }
        self._dispatcher.dispatch(self._outsocket_fd, data)
        self._log.rtn("%s: success" % self)

    def config(self, config: Dict) -> bool:
        """Initial setup of the handler.

        Initializes the handler config, dispatcher, outsocket fd, host, and
        port attributes.

        Returns
        -------
        bool
            Returns 'True' once attribute assignment has been completed.
        """
        self._log.args("%s: (config: %s)" % (self, config))
        self._config = config
        self._dispatcher = self._config["dispatcher"]
        self._outsocket_fd = self._config["outsocket_fd"]
        self._dest_host = self._config["dest_ip"]
        self._dest_port = self._config.get("dest_port")
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def handle(self, message: Any) -> None:
        """Handles a message, calls the _handle method implemented by child
        classes.

        Parameters
        ----------
        message: Any
            Message/data to be handled.
        """
        self._log.args("%s (message: %s)" % (self, message))
        self._handle(message)
        self._log.rtn("%s: success" % self)

    def finish(self) -> bool:
        """Performs teardown/cleanup of the handler.

        Returns
        -------
        rtn: bool
            Returns 'True' once the method has completed.
        """
        self._log.args("%s: ()" % self)
        self._id = None
        self._config = None
        self._dispatcher = None
        self._outsocket_fd = None
        self._dest_host = None
        self._dest_port = None
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def close(self) -> bool:
        """Closes the dispatcher used by the handler.

        Returns
        -------
        rtn: bool
            True if successful, False otherwise.
        """
        self._dispatcher.close()
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
