# -*- coding: utf-8 -*-

from typing import (
    Dict,
    Any
)
from abc import (
    ABC,
    abstractmethod
)


class AbstractEndpoint(ABC):
    """
    Abstract Endpoint
    =================

    Abstract class which defines the required methods for any endpoint.
    """

    def __init__(self, config: Dict = None):
        """Abstract endpoint class constructor."""
        pass

    @abstractmethod
    def _generate_id(self) -> str:
        """Generate a unique id for the endpoint."""
        pass

    @abstractmethod
    def _store_message(self, query: Dict) -> bool:
        """Store message in a store."""
        pass

    @abstractmethod
    def _get_message(self, query: Dict) -> Any:
        """Retrieve a message from a message store"""
        pass

    @abstractmethod
    def _remove_message(self, query: Dict) -> bool:
        """Remove message from a store"""
        pass

    @abstractmethod
    def _handle_inbound(self) -> None:
        """Handles incoming messages and performs general tasks."""
        pass

    @abstractmethod
    def _handle_outbound(self) -> None:
        """Retrieves items from the send queue and processes them."""
        pass

    @abstractmethod
    def _process_message_inbound(self, message: Dict) -> None:
        """Endpoint-specific inbound message processing, to be overwritten by
        child classes."""
        pass

    @abstractmethod
    def _process_message_outbound(self, message: Dict) -> None:
        """Endpoint-specific outbound message processing, to be overwritten by
        child classes."""
        pass

    @abstractmethod
    def _execute_scheduled(self) -> None:
        """Execute tasks in the task queue."""
        pass

    @abstractmethod
    def _handle_ack(self, message: Dict) -> None:
        """Handles the return of an acknowledgement by removing the message
        from the durable store."""
        pass

    @abstractmethod
    def _handle_online_state(self, data: Dict) -> list:
        """Retrieves unacknowledged messages from the durable store and queues
        them for re-sending."""
        pass

    @abstractmethod
    def _handle_task_results(self, results: list) -> None:
        """Helper method to separate successful from failed tasks."""
        pass

    @abstractmethod
    def _handle_success(self, task: Any) -> None:
        """Helper method to handle successful tasks."""
        pass

    @abstractmethod
    def _handle_failure(self, task: Any) -> None:
        """Helper method to handle failed tasks."""
        pass

    @abstractmethod
    def get_id(self) -> str:
        """Return the id of the endpoint."""
        pass

    @abstractmethod
    def config(self, config: Dict) -> bool:
        """Configure endpoint"""
        pass

    @abstractmethod
    def get_config(self) -> Dict:
        """Gets the Endpoint configuration."""
        pass

    @abstractmethod
    def register(self, config: Dict) -> bool:
        """Register components from config"""
        pass

    @abstractmethod
    def register_consumers(self, consumers: list) -> bool:
        """Helper method to register consumer"""
        pass

    @abstractmethod
    def register_producers(self, producers: list) -> bool:
        """Helper method to register producer"""
        pass

    @abstractmethod
    def consume(self, consumer: str) -> None:
        """Run the consumer once."""
        pass

    @abstractmethod
    def produce(self, producer: str) -> None:
        """Run the producer once."""
        pass

    @abstractmethod
    def process(self) -> None:
        """The endpoint's main loop, to be implemented in child classes."""
        pass

    @abstractmethod
    def run(self) -> None:
        """Continuously run polling loop."""
        pass

    @abstractmethod
    def close(self) -> bool:
        """Stops listening."""
        pass
