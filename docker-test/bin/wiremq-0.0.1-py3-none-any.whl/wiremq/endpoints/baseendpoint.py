# -*- coding: utf-8 -*-

import json
import bson
import threading
import datetime
from typing import (
    Dict,
    Any
)
import uuid
import logging
from wiremq.endpoints import abstractendpoint
from wiremq.filters import idempotentfilter
from wiremq.extlib.err.endpointexceptions import EndpointException


class BaseEndpoint(threading.Thread, abstractendpoint.AbstractEndpoint):
    """
    Base Endpoint
    =============

    Base endpoint is the skeleton of all wiremq endpoints. It can consist
    of a consumer and/or producer; message stores for durability, persistency,
    and/or idempotency; and has a transactional client and scheduler.

    The following classes inherit from BaseEndpoint:

    - :ref:`Channel`
    - :ref:`Message Bus`
    - :ref:`Publisher-Subscriber Channel`
    - :ref:`Service Activator`
    - :ref:`Base Router`

    Attributes
    ----------
    _id: str
        Endpoint identifier.
    _config: Dict
        Configuration dictionary for the endpoint.
    _registered: bool
        Flag to denote whether the endpoint components have been registered.
    _durable: bool
        Flag to denote whether the endpoint is durable.
    _persistent: bool
        Flag to denote whether the endpoint is persistent.
    _idempotent: bool
        Flag to denote whether the endpoint is idempotent.
    _auto_ack: bool
        Flag to denote whether automatic acknowledgements are sent.
    _running: event
        Threading event to indicate whether the endpoint is running.
    _consumer: Dict
        The endpoint's consumers.
    _producer: Dict
        The endpoint's producers.
    _eventloop: IOEventLoop
        The endpoint's eventloop.
    _dispatch_queue: Queue
        Used to hold messages ready to be dispatched by a sockdispatcher.
    _idempotent_queue: Queue (optional)
        Used to temporarily hold messages to be processed by the idempotent
        filter, shared with idempotentfilter.IdempotentFilter() in
        self._handle_idempotency
    _invalid_message_queue: Queue
        Used to hold messages which have been rejected by the endpoint.
    _received_queue: Queue
        Queue used for holding received and processed messages, used in
        self._receive() for the application to extract received messages.
    _send_queue: Queue
        Used to hold messages which are to be processed and dispatched
    _task_queue: Queue
        Queue used for holding incoming tasks, shared with self._eventloop
    _durable_store: MessageStore
        The durability message store.
    _history_store: MessageStore
        The history message store.
    _idempotent_store: MessageStore
        The idempotency message store.
    _persistent_store: MessageStore
        The persistency message store.
    _scheduler: ThreadedScheduler
        Schedules tasks asynchronously.
    _transactional_client: TransactionalClient
        The transactional client for the endpoint.
    _transactions: list
        A list of available transactions, performable by the endpoint.
    _subscribers: Dict
        The subscribers to the endpoint.
    _max_subscribers: int
        The maximum number of subscribers allowable by the endpoint.
    _started: Threading.Event
        From the super() threading class, used to check if the endpoint is
        currently running as a thread.
    _log: object
        Python logging instance.
    listening: bool
        Flag to control whether the endpoint receives messages, the task_queue
        is not polled when set to True.

    Methods
    -------
    _generate_id(): str
        Generates a unique id for the endpoint.
    _store_message(): bool
        Store message in a store.
    _get_message(): Any
        Retrieve a message from a message store
    _update_message(): bool
        Updates a message in a store.
    _remove_message(): bool
        Remove message from a store.
    _handle_inbound(): None
        Handles incoming messages and performs general tasks.
    _handle_outbound(): None
        Retrieves items from the send queue and processes them.
    _process_message_inbound(): None
        Endpoint-specific inbound message processing, to be overwritten by
        child classes.
    _process_message_outbound(): None
        Endpoint-specific outbound message processing, to be overwritten by
        child classes.
    _execute_scheduled(): None
        Execute tasks in the task queue.
    _update_message_history(): None
        Store newly formed WireMQ messages into history store.
    _handle_ack(): None
        Handles the return of an acknowledgement by removing the message
        from the durable store.
    _handle_online_state(): None
        Retrieves unacknowledged messages from the durable store and queues
        them for re-sending. Called when an offline endpoint informs this
        endpoint that is back online, or, when this endpoint comes online.
    _store_durable(): None
        Stores an item in the durable store.
    _handle_idempotency: bool
        Manages endpoint idempotency.
    _handle_task_results(): None
        Helper method to separate successful from failed tasks.
    _handle_success(): None
        Helper method to handle successful tasks.
    _handle_failure(): None
        Helper method to handle failed tasks.
    get_id(): str
        Returns the id of the endpoint.
    config(): bool
        Configures the endpoint, called as part of init if config is
        supplied.
    get_config(): Dict
        Gets the Endpoint configuration.
    register(): bool
        Registers components from the config.
    register_consumers(): bool
        Registers consumers, using consumer type as its map key.
    register_producers(): bool
        Registers producers, using producer type as its map key.
    add_subscriber(): bool
        Registers a subscriber, if doing so doesn't exceed max subscribers.
    update_subscriber(): bool
        Updates a subscriber.
    remove_subscriber(): bool
        Removes a subscriber.
    get_subscribers(): Dict
        Return the endpoint's subscribers.
    consume(): None
        Runs a consumer once.
    produce(): None
        Runs a producer once.
    process(): None
        The endpoint's main loop, to be implemented in child classes.
    run(): None
        Continuously runs the polling loop, initiated by threading.Thread
        class.
    get_message_history() list:
        Retrieves messages from the history store.
    send_online(): None
        Composes and sends a message to another endpoint stating that this
        endpoint is online.
    send(): None
        Adds a message to the send queue, to be implemented in child
        classes.
    receive(): None
        Extracts messages from the received queue, to be implemented in child
        classes.
    start(): Any
        Starts the endpoint (Implemented in threading.Thread class).
    stop(): Dict
        Stops the endpoint thread by invoking the set event in the Thread
        class.
    is_stopped(): bool
        Checks if the thread's running variable is set.
    close(): bool
        Closes down the endpoint and all consumers/producers, stops the
        thread.
    """

    def __init__(self, config: Dict = None):
        """Base endpoint class constructor.

        Parameters
        ----------
        config: Dict (fields required unless otherwise stated)
            name: str
                Endpoint name.
            alias: str
                Endpoint alias.
            type: str
                Endpoint type.
            auto-ack: bool, optional
                Flag to indicate whether automatic acknowledgements are enabled,
                defaults to False.
            consumer_host: str
                Host address of the endpoint's consumer
            consumer_port: int
                Host port of the endpoint's consumer
            durable: bool
                Flag to indicate whether the endpoint is durable.
            persistent: bool
                Flag to indicate whether the endpoint is persistent.
            idempotent: bool
                Flag to indicate whether the endpoint is idempotent.
            max_subscribers: int
                The maximum number of subscribers allowable by the endpoint.
            subscribers: dict
                Subscription configuration dictionary, contains topics and
                criteria.
            logger: str, optional
                Name of the logger instance.
            durable_store: MessageStore
                The durability message store.
            history_store: MessageStore
                The history message store.
            idempotent_store: MessageStore
                The idempotency message store.
            persistent_store: MessageStore
                The persistency message store.
            consumer: Consumer
                The endpoint's consumer.
            producer: Producer
                The endpoint's producer.
            eventloop: IOPoller
                The endpoint's IO event loop.
            scheduler: Scheduler
                The scheduler used to schedule and execute tasks.
            tx_client: TransactionalClient, optional
                The endpoint's transactional client.
            dispatch_queue: Queue
                Queue used for dispatching messages to the producer.
            idempotent_queue: Queue
                Queue used for handling endpoint idempotency.
            received_queue: Queue
                Queue for received messages.
            send_queue: Queue, optional
                Queue for outgoing messages.
            task_queue: Queue, optional
                Queue used and populated by the endpoint's eventloop.
            _invalid_message_queue: Queue
                Queue used to hold messages which are invalid.

        Example
        -------
        >>> endpoint_config = {}
        >>> endpoint_config["consumer"] = consumer
        >>> endpoint_config["durable_store"] = durable_ms
        >>> endpoint_config["persistent_store"] = persistent_ms
        >>> endpoint_config["idempotent_store"] = idempotent_ms
        >>> endpoint_config["eventloop"] = eventloop
        >>> endpoint_config["insocket"] = in_socket
        >>> endpoint_config["outsocket"] = out_socket
        >>> endpoint_config["scheduler"] = scheduler
        >>> endpoint_config["received_queue"] = received_queue
        >>> endpoint_config["send_queue"] = send_queue
        >>> endpoint_config["durable"] = True
        >>> endpoint_config["persistent"] = True
        >>> endpoint_config["idempotent"] = False
        >>> endpoint_config["consumer"] = consumer
        >>> endpoint_config["producer"] = producer
        >>> endpoint_config["tx_client"] = tx_cient
        >>> endpoint_config["max_subscribers"] = 100
        >>> ep = baseendpoint.BaseEndpoint(endpoint_config)
        """
        self._started = None
        super().__init__()
        self._id = self._generate_id()
        self._config = None
        self._registered = False
        self._durable = False
        self._persistent = False
        self._idempotent = False
        self._auto_ack = False
        self._running = threading.Event()
        self._consumer = {}
        self._producer = {}
        self._eventloop = None
        self._dispatch_queue = None
        self._idempotent_queue = None
        self._invalid_message_queue = None
        self._received_queue = None
        self._send_queue = None
        self._task_queue = None
        self._durable_store = None
        self._history_store = None
        self._idempotent_store = None
        self._persistent_store = None
        self._scheduler = None
        self._transactional_client = None
        self._transactions = []
        self._subscribers = None
        self._max_subscribers = None
        self._log = None
        self.listening = True
        if config:
            self.config(config)
            self.register(config)

    def _generate_id(self) -> str:
        """Generate a unique id for the endpoint.

        Returns
        -------
        rtn: str
            The unique ID of the endpoint, cast from UUID4 to string.
        """
        self._id = uuid.uuid4()
        rtn = str(self._id)
        return rtn

    def _store_message(self, query: Dict) -> bool:
        """Store message in a store.

        Parameters
        ----------
        query: Dict
            The store, and the message to be stored.
            store: MessageStore
                The messagestore where the message will be stored
            data: Dict
                The message to be stored.
        Returns
        -------
        rtn: bool
            The result of the operation.
        """
        self._log.args("%s: (query: %s)" % (self, query))
        _store = query["store"]
        rtn = _store.store(query["data"])
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _get_message(self, query: Dict) -> Any:
        """Retrieve a message from a message store.

        Parameters
        ----------
        query: Dict
            store: MessageStore
                MessageStore to get the messages from.
            where: dict
                WHERE condition for the query.
            limit: int
                Maximum number of items that may be returned from the query.
            order: str
                Column to order the query results by.

        Returns
        -------
        message: Any
            The message retrieved from the message store.
        """
        self._log.args("%s: (query: %s)" % (self, query))
        _store = query["store"]
        _where = query.get("where")
        _limit = query.get("limit")
        _order = query.get("order")
        query_result = _store.get(where=_where, limit=_limit, order_by=_order)
        if len(query_result) == 0:
            rtn = []
        else:
            rtn = []
            for row in query_result:
                newrow = list(row)
                newrow[1] = json.loads(newrow[1])
                rtn.append(newrow)
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _update_message(self, query: Dict) -> bool:
        """Updates a message in a store.

        Parameters
        ----------
        message: Dict
            The message to store in the message store.

        Returns
        -------
        rtn: bool
            The result of the operation.
        """
        self._log.args("%s: (query: %s)" % (self, query))
        _store = query["store"]
        rtn = _store.update(query["where"], query["data"])
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _remove_message(self, query: Dict) -> bool:
        """Remove message from a store.

        Parameters
        ----------
        message_id: str
            The message_id for the message to be removed.

        Returns
        -------
        rtn: bool
            The result of the removal.
        """
        self._log.args("%s: (query: %s)" % (self, query))
        _store = query["store"]
        rtn = _store.remove(query["where"])
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _handle_inbound(self) -> None:
        """Handles incoming messages and performs general tasks.

        This method handles the following where configured to:
          - Storing into message history
          - Handling idempotency
          - Handling acknowledgements and removing from durable store
          - Processing endpoint-specific functions
        """
        if not self._task_queue.empty() and self.listening:
            _task = self._task_queue.get()
            _buf = _task.get_buffer()
            try:
                message = bson.BSON.decode(_buf)
            except bson.errors.InvalidBSON as e:
                self._log.error(e)
                raise EndpointException(e)
            self._task_queue.item_processed()

            # Send acknowledgement
            if self._auto_ack and "payload" in message:
                self._producer["producer"].send_ack(message)

            # Update message history
            if self._history_store:
                self._update_message_history(message)

            # Handle idempotency
            _idempotent = self._handle_idempotency(message)
            if not _idempotent:
                self._log.info(message)
                return

            # Handle acknowledgements
            if self._durable:
                if "payload" not in message:
                    # Receive acknowledgement
                    self._handle_ack(message)
                elif self._durable and "state" in message["payload"] \
                        and message["payload"]["state"] == "online":
                    # Retrieve unacknowledged messages and re-send them
                    stored_messages = self._handle_online_state({
                        "where": {
                            "dest_ip": message["sender_ip"],
                            "dest_port": message["sender_port"],
                        }
                    })
                    for msg in stored_messages:
                        self._process_message_outbound(msg)

            # Endpoint-specific message processing
            self._process_message_inbound(message)

    def _handle_outbound(self) -> None:
        """Retrieves items from the send queue and processes them.

        Verifies if the message has expired before dispatching it
        """
        if not self._send_queue.empty():
            message = self._send_queue.get()
            self._process_message_outbound(message)
            self._send_queue.item_processed()

    def _process_message_inbound(self, message: Dict) -> None:
        """Endpoint-specific inbound message processing, to be overwritten by
        child classes.

        Parameters
        ----------
        message: Dict
            Message to be processed
        """
        pass

    def _process_message_outbound(self, message: Dict) -> None:
        """Endpoint-specific outbound message processing, to be overwritten by
        child classes.

        Parameters
        ----------
        message: Dict
            Message to be processed
        """
        pass

    def _execute_scheduled(self) -> None:
        """Execute tasks in the task queue."""
        self._log.args("%s: ()" % self)
        results = self._scheduler.schedule()
        self._handle_task_results(results)
        self._log.rtn("%s: success" % self)

    def _update_message_history(self, data: Dict) -> None:
        """Store newly formed WireMQ messages into history store."""
        self._log.args("%s: ()" % self)
        self._store_message(
            {
                "store": self._history_store,
                "data": {
                    "message_id": data["message_id"],
                    "message_data": json.dumps(data),
                    "message_time": datetime.datetime.now().strftime(
                        "%Y-%m-%d %H:%M:%S.%f"
                    ),
                }
            }
        )
        self._log.rtn("%s: success" % self)

    def _handle_ack(self, message: Dict) -> None:
        """Handles the return of an acknowledgement by removing the message
        from the durable store.

        Parameters
        ----------
        message: Dict
            Message to be acknowledged

        """
        self._log.args("%s: (data: %s)" % (self, message))
        _where = {
            "message_id": message["correlation_id"],
            "dest_ip": message["sender_ip"],
            "dest_port": message["sender_port"]
        }
        query = {
            "store": self._durable_store,
            "where": _where
        }
        self._remove_message(query)
        self._log.rtn("%s: success" % self)

    def _handle_online_state(self, data: Dict) -> list:
        """Retrieves unacknowledged messages from the durable store and queues
        them for re-sending. Called when an offline endpoint informs this
        endpoint that is back online, or, when this endpoint comes online.

        Retrieves unacknowledged messages and queues them for output.

        Parameters
        ----------
        data: Dict
            query data for retrieving messages from the durable store.

        Returns
        -------
        rtn: list
            A list of messages which have not yet received an acknowledgement.

        """
        self._log.args("%s: (data: %s)" % (self, data))
        query = {
            "store": self._durable_store,
            "where": data["where"]
        }
        messages = self._get_message(query)
        rtn = []
        for message in messages:
            rtn.append(message[1])
            self._remove_message(
                {
                    "store": self._durable_store,
                    "where": {"message_id": message[0]}
                }
            )
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _store_durable(self, message: dict, dest: tuple) -> None:
        """Stores an item in the durable store.

        Parameters
        ----------
        message: dict
            Message to be stored
        dest: tuple
            (dest_ip, dest_port)
        """
        self._log.args("%s: (message: %s, dest: %s)" % (self, message, dest))
        self._store_message(
            {
                "store": self._durable_store,
                "data": {
                    "message_id": message["message_id"],
                    "message_data": json.dumps(message),
                    "message_time": message["datetime"],
                    "dest_ip": dest[0],
                    "dest_port": dest[1],
                }
            }
        )
        self._log.rtn("%s: success" % self)

    def _handle_idempotency(self, message: dict) -> bool:
        """Manages endpoint idempotency.

        Incoming messages are stored in the idempotent store, then new incoming
        messages are checked to see if they have been received before. If a
        message_id has been received previously, the message is discarded.

        Parameters
        ----------
        message: dict
            Message to be checked for idempotency.

        Returns
        -------
        rtn: bool
            True if idempotency check passes (either idempotency disabled, or
            message is unique).

        """
        if self._idempotent:
            self._idempotent_queue.put(message)
            idempotentfilter.IdempotentFilter(
                self._config["idempotentfilter_config"])
            idempotent_result = self._idempotent_queue.get()
            self._idempotent_queue.item_processed()
            if idempotent_result["status"] == "failure":
                self._log.warning(f"Idempotency check failed, discarding "
                                  f"message {message['message_id']}")
                rtn = False
            else:
                rtn = True
            self._log.rtn("%s: success | data: %s" % (self, rtn))
        else:
            rtn = True
        return rtn

    def _handle_task_results(self, results: list) -> None:
        """Helper method to separate successful from failed tasks.

        Parameters
        ----------
        results: list
            The results from executing scheduled tasks through the scheduler.
        """
        self._log.args("%s: (results: %s)" % (self, results))
        # Extract task IDs for successfully completed tasks
        success_ids = []
        for result in results:
            if result["status"] == "success":
                success_ids.append(result["task_id"])

        # Handle both successes and failures
        if not self._received_queue.empty():
            _task = self._received_queue.get()
            if _task.get_id() in success_ids:
                self._handle_success(_task)
            else:
                self._handle_failure(_task)
        self._log.rtn("%s: success" % self)

    def _handle_success(self, task: Any) -> None:
        """Helper method to handle successful tasks.

        Parameters
        ----------
        task: Task
            A successfully completed task.
        """
        self._log.args("%s: (task: %s)" % (self, task))
        # self._received_queue.item_processed()
        self._log.rtn("%s: success" % self)

    def _handle_failure(self, task: Any) -> None:
        """Helper method to handle failed tasks.

        Parameters
        ----------
        task: Task
            An unsuccessfully completed (failed) task.
        """
        self._log.error(task)

    def get_id(self) -> str:
        """Return the id of the endpoint.

        Returns
        -------
        rtn: str
            The unique ID of the endpoint, cast from UUID4 to string.
        """
        self._log.args("%s: ()" % self)
        rtn = str(self._id)
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def config(self, config: Dict) -> bool:
        """Configures the endpoint, called as part of init if config is
        supplied.

        Parameters
        ----------
        config: Dict
            Endpoint configuration dictionary
            auto-ack: bool, optional
                Flag to indicate whether automatic acknowledgements are enabled,
                defaults to False.
            durable: bool
                Flag to indicate whether the endpoint is durable.
            persistent: bool
                Flag to indicate whether the endpoint is persistent.
            idempotent: bool
                Flag to indicate whether the endpoint is idempotent.
            max_subscribers: int
                The maximum number of subscribers allowable by the endpoint.
            subscribers: dict
                Subscription configuration dictionary, contains topics and
                criteria.
            logger: str, optional
                Name of the logger instance.

        Returns
        -------
        rtn: bool
            True if successful
        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._config = config
        self._auto_ack = config.get("auto-ack", False)
        self._durable = self._config.get("durable")
        self._persistent = self._config.get("persistent")
        self._idempotent = self._config.get("idempotent")
        self._max_subscribers = config.get("max_subscribers")
        self._subscribers = config.get("subscribers", {})
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def get_config(self) -> Dict:
        """Gets the Endpoint configuration.

        Returns
        -------
        rtn: Dict
            The configuration of the endpoint.
        """
        if self._log:
            self._log.args("%s: ()" % self)
        config = self._config
        if self._log:
            self._log.rtn("%s: success | data: %s" % (self, config))
        return config

    def register(self, config: Dict) -> bool:
        """Registers components from the config.

        Parameters
        ----------
        config: Dict (fields required unless otherwise stated)
            durable_store: MessageStore
                The durability message store.
            history_store: MessageStore
                The history message store.
            idempotent_store: MessageStore
                The idempotency message store.
            persistent_store: MessageStore
                The persistency message store.
            consumer: Consumer
                The endpoint's consumer.
            producer: Producer
                The endpoint's producer.
            eventloop: IOPoller
                The endpoint's IO event loop.
            scheduler: Scheduler
                The scheduler used to schedule and execute tasks.
            tx_client: TransactionalClient, optional
                The endpoint's transactional client.
            dispatch_queue: Queue
                Queue used for dispatching messages to the producer.
            idempotent_queue: Queue
                Queue used for handling endpoint idempotency.
            received_queue: Queue
                Queue for received messages.
            send_queue: Queue, optional
                Queue for outgoing messages.
            task_queue: Queue, optional
                Queue used and populated by the endpoint's eventloop.
            _invalid_message_queue: Queue
                Queue used to hold messages which are invalid.

        Returns
        -------
        rtn: bool
            True if successful
        """
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._durable_store = self._config.get("durable_store")
        self._history_store = config.get("history_store")
        self._idempotent_store = self._config.get("idempotent_store")
        self._persistent_store = self._config.get("persistent_store")
        self.register_consumers(config["consumers"])
        self.register_producers(config["producers"])
        self._eventloop = config.get("eventloop")
        self._transactional_client = self._config.get("tx_client")
        self._dispatch_queue = config.get("dispatch_queue")
        self._idempotent_queue = config.get("idempotent_queue")
        self._invalid_message_queue = config.get("invalid_message_queue")
        self._received_queue = self._config.get("received_queue")
        self._send_queue = config.get("send_queue")
        self._task_queue = config.get("task_queue")
        self._registered = True
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def register_consumers(self, consumers: list) -> bool:
        """Register consumers, using consumer type as its map key.

        Parameters
        ----------
        consumers: list
            Instantiated consumer objects to be registered.

        Returns
        -------
        rtn: bool
            True if successful
        """
        self._log.args("%s: (consumers: %s)" % (self, consumers))
        for consumer in consumers:
            self._consumer[consumer.get_config()["type"]] = consumer
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def register_producers(self, producers: list) -> bool:
        """Register producers, using producer type as its map key.

        Parameters
        ----------
        producers: list
            Instantiated producer objects to be registered.

        Returns
        -------
        rtn: bool
            True if successful
        """
        self._log.args("%s: (producers: %s)" % (self, producers))
        for producer in producers:
            self._producer[producer.get_config()["type"]] = producer
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def add_subscriber(self, subscriber: Dict) -> bool:
        """Registers a subscriber, if doing so doesn't exceed max subscribers.

        Parameters
        ----------
        subscriber: Dict
            The subscriber to add, with keys for id, host, and port

        Example
        -------
        >>> subscriber = {
        ...     "id": "sub1",
        ...     "host": "106.12.205.32",
        ...     "port": 11002,
        ...     "criteria": {
        ...         "ram": ("gt", 15000000)
        ...         "cores": ("gt", 2),
        ...     }
        ... }

        Returns
        -------
        rtn: bool
            True if the subscriber was registered, false otherwise
        """
        self._log.args("%s: (subscriber: %s)" % (self, subscriber))
        if len(self._subscribers) < self._max_subscribers:
            self._subscribers[subscriber["id"]] = {
                "host": subscriber["host"],
                "port": subscriber["port"],
                "criteria": subscriber["criteria"],
            }
            rtn = True
        else:
            rtn = False
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def update_subscriber(self, subscriber: Dict) -> bool:
        """Update a subscriber.

        Used to modify the address details and/or the topic criteria

        Parameters
        ----------
        subscriber: Dict
            The subscriber to update, with keys for id, host, and port

        Examples
        --------
        .. code-block:: python
            :linenos:

            subscriber = {
                "id": "sub1",
                "host": "106.12.205.32",
                "port": 11001,
                "criteria": {
                    "ram": ("gt", 15000000)
                    "cores": ("gt", 2),
                }
            }

        Returns
        -------
        rtn: bool
            True if the subscriber was updated, false otherwise
        """
        self._log.args("%s: (subscriber: %s)" % (self, subscriber))
        self._subscribers[subscriber["id"]] = {
            "host": subscriber["host"],
            "port": subscriber["port"],
            "criteria": subscriber["criteria"],
        }
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def remove_subscriber(self, subscriber_id: str) -> bool:
        """Removes a subscriber.

        Parameters
        ----------
        subscriber_id: str
            The id of the subscriber to remove.

        Returns
        -------
        rtn: bool
            True if the subscriber was removed, false otherwise
        """
        self._log.args("%s: (subscriber_id: %s)" % (self, subscriber_id))
        del self._subscribers[subscriber_id]
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def consume(self, consumer: str) -> None:
        """
        Runs a consumer once.

        Parameters
        ----------
        consumer: str
            The alias of the consumer in the config (usually "producer")
        """
        self._consumer[consumer].run_once()

    def produce(self, producer: str) -> None:
        """
        Runs a producer once.

        Parameters
        ----------
        producer: str
            The alias of the producer in the config (usually "producer")
        """
        self._producer[producer].run_once()

    def process(self) -> None:
        """The endpoint's main loop, to be implemented in child classes

        At minimum, should call:
          - All consumers' consume() method
          - self._handle_inbound()
          - self._handle_outbound()
          - All producers' produce() method
        """
        pass

    def run(self) -> None:
        """Continuously runs the polling loop, initiated by threading.Thread
        class."""
        self._log.args("%s: ()" % self)
        import time
        while not self.is_stopped():
            self.process()
            time.sleep(0.001)
        self._log.rtn("%s: success" % self)

    def get_message_history(self) -> list:
        """Retrieves messages from the history store.

        The number of messages to be retrieved is specified in the endpoint's
        config.

        Returns
        -------
        rtn: List
            A list of messages from the history store.
        """
        self._log.args("%s: ()" % self)
        rtn = self._get_message(
            {
                "store": self._history_store,
                "limit": self._config["history_get_limit"],
                "order_by": [("message_time", "DESC")]
            }
        )
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def send_online(self, dest_ip: str = None, dest_port: str = None) -> None:
        """Composes and sends a message to another endpoint stating that this
        endpoint is online.

        Parameters
        ----------
        dest_ip: str (optional)
            Destination host for the message, used when the
            producer's sockdispatcher is utilizing the from_msg sending mode.
        dest_port: int (optional)
            Destination port for the message, used when the
            producer's sockdispatcher is utilizing the from_msg sending mode.

        """
        online_config = {
            "type": "event",
            "payload": {
                "state": "online"
            }
        }
        if dest_ip:
            online_config["dest_ip"] = dest_ip
            online_config["dest_port"] = dest_port
        self._producer["producer"].produce(online_config)

    def send(self, data: Dict) -> None:
        """Adds a message to the send queue, to be implemented in child
        classes with a super().send() call at the start.
        """
        if not self._started.is_set():
            self.process()

    def receive(self) -> list:
        """Extracts messages from a received queue, to be implemented in child
        classes with a super().send() call at the start.
        """
        if not self._started.is_set():
            self.process()

    def stop(self) -> bool:
        """Stops the endpoint thread by invoking the set event in the Thread
        class.

        Returns
        -------
        rtn: bool
            True if successful
        """
        self._running.set()
        return True

    def is_stopped(self) -> bool:
        """Checks if the thread's running variable is set.

        Returns
        -------
        rtn: bool
            True if the internal is_set flag is true.
        """
        return self._running.is_set()

    def close(self) -> bool:
        """Closes down the endpoint and all consumers/producers, and if the
        endpoint is being run as a thread, stops the thread."""
        self._log.args("%s: ()" % self)
        if self._started.is_set():
            self.stop()
            self.join()
        for prod in self._producer.values():
            prod.close()
        for cons in self._consumer.values():
            cons.close()
        self._eventloop.close()
        self._config = None
        self._consumer.clear()
        self._producer.clear()
        self._transactional_client = None
        self._received_queue = None
        self._send_queue = None
        self._task_queue = None
        self._idempotent_queue = None
        self._registered = False
        self._transactions = []
        self._subscribers.clear()
        self._max_subscribers = None
        self._durable_store = None
        self._persistent_store = None
        self._idempotent_store = None
        self._durable = False
        self._persistent = False
        self._idempotent = False
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        self._id = None
        return True
