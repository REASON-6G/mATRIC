# -*- coding: utf-8 -*-

from typing import (
    Any,
    Dict
)
from wiremq.processing import baseprocessor


class RecipientList(baseprocessor.BaseProcessor):
    """
    Recipient List
    ==============

    The recipient list takes a message, examines its header and/or
    payload, and looks up and retrieves recipients with matching criteria.

    Attributes
    ----------
    _config : dict
        Configuration of the recipient list.

    Methods
    -------
    _process() : Dict
        Overrides method of base processor, holds the processor logic. After
        checking criteria for all subscribers, it appends any applicable
        subscribers to the recipient list and then returns it.
    _check_keys(): bool
        Check to see if any specified keys exist within the message, for one
        subscriber. Checks the header, and then the payload, for any specified
        keys. If there are no criteria check failures, and at lease one of the
        subscriber's criteria is met, this method returns True. Otherwise,
        False is returned.
    _compare_criteria(): bool
        Compares message and subscriber criteria. Returns True if the
        criteria check succeeds, otherwise False.
    """

    def __init__(self, config: Dict = None):
        """Recipient List class constructor.

        Parameters
        ----------
        config: Dict
            type: str
                The processor type
            alias: str
                Alias of the recipient list
            name: str
                Name of the recipient list
            uid: hash
                Identification number
            processor_queue: object
                Queue object for receiving and sending messages for processing.
            subscribers: Dict
                The mapping of subscriber address to a dictionary of criteria
                for the subscriber. The key of that dictionary is the field to
                examine, and the value is a tuple where the first element is
                the comparison operator to use, and the second element the
                value to compare
            operators: Dict
                A mapping of string representations of comparison operators to
                their respective static methods.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> config = {
        ...    "alias": "Recipient List",
        ...    "name": "RLIST Filter",
        ...    "type": "recipientlist",
        ...    "processor_queue": basequeue.BaseQueue(),
        ...    "subscribers": {
        ...         "sub_id1": {
        ...             "ram": ("gt", 15000000)
        ...             "cores": ("gt", 2),
        ...         },
        ...         "sub_id2": {
        ...             "ram": ("gt", 8000000)
        ...             "type": ("ni", None)
        ...         },
        ...         "sub_id3": {
        ...             "ram": ("gt", 12000000)
        ...         }
        ...     },
        ...    "operators": {
        ...        'gt': operator.gt,
        ...        'lt': operator.lt,
        ...        'eq': operator.eq,
        ...        'ge': operator.ge,
        ...        'le': operator.le
        ...    }
        ... }
        >>> rlist = recipientlist.RecipientList(config)
        """
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._log.rtn("%s: success" % self)

    def _process(self, message: Dict) -> Dict:
        """Overrides _process method of base processor with recipientlist
        logic.

        Takes a message, examines its header and/or payload, and looks up and
        retrieves recipients with matching criteria.

        If no criteria are provided for the topic

        Parameters
        ----------
        message: Dict
            The message to examine. The header data should be at the root level
            of the Dict and the payload should be in a "payload" nested Dict.

        Returns
        -------
        rtn: Dict
            status: str
                The status of the processing, "success" or "failure".
            recipient_list: list
                A list of addresses for recipients with matching criteria.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        _recipient_list = []
        for sub_id, sub_criteria in self._config["subscribers"].items():
            if self._check_keys(message, sub_criteria.get("criteria")):
                _recipient_list.append(sub_id)
        rtn = {"status": "success", "data": _recipient_list}
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _check_keys(self, message: Dict, sub_criteria: Dict) -> bool:
        """Check to see if any specified keys exist within the message.

        Checks the header, and then the payload, for any specified keys. If a
        specified key exists, and the value meets the subscriber's criteria,
        this method returns True. Otherwise, or in the case that a key
        exists in the message that is required to be absent, False is returned.

        Parameters
        ----------
        message: Dict
            The message to check for included keys. The message's header,
            payload, and payload param fields are checked, and any values
            extracted to be matched with the subscriber's criteria.
        sub_criteria: Dict
            A subscriber's criteria, to be compared with any config-specified
            keys.

        Returns
        -------
        rtn: bool
            True, if a specified key within the message matches a subscriber's
            criteria. False, otherwise.
        """
        self._log.args("%s: (message: %s, sub_criteria: %s)"
                       % (self, message, sub_criteria))
        # If no criteria have been specified for any sub-topics, always return
        # True
        if not sub_criteria:
            rtn = True
            self._log.rtn("%s: success | data: %s" % (self, rtn))
            return rtn

        rtn = False
        for sub_key, sub_criteria_tuple in sub_criteria.items():
            # Determine which level of the message the key is in:
            if sub_key in message:
                # Set message level to top-level (header):
                value_to_compare = message[sub_key]
            elif sub_key in message["payload"]:
                # Set message level to 2nd-level (payload):
                value_to_compare = message["payload"][sub_key]
            elif sub_key in message["payload"]["params"]:
                # Set message level to 3rd-level (payload params):
                value_to_compare = message["payload"]["params"][sub_key]
            else:
                # If key is not in message, continue to next key in criteria:
                continue

            # If the criteria check involves an "ni" ("not in") operation:
            if sub_criteria_tuple[0] == "ni":
                rtn = False
                break

            if self._compare_criteria(value_to_compare, sub_criteria_tuple):
                # A success sets the return flag to True, and iterates the loop
                rtn = True
            else:
                # A failure, for even a single key, immediately returns False:
                rtn = False
                break
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _compare_criteria(self,
                          value_to_compare: Any,
                          sub_criteria: Any) -> bool:
        """Compares message and subscriber criteria.

        Parameters
        ----------
        value_to_compare: Any
            The message value to compare to the subscriber's criteria value.
        sub_criteria: tuple
            The first element is a string representation of the comparison
            operation to perform. The second is the specified value to compare
            against.

        Examples
        --------
        Greater than:
            value_to_compare = 1000
            sub_criteria = ("gt", 900)
            return: True, as 1000 is greater than 900

        Returns
        -------
        rtn: bool
            True, if the comparison operation succeeds. False, otherwise.
        """
        self._log.args("%s: (value_to_compare: %s, sub_criteria: %s)"
                       % (self, value_to_compare, sub_criteria))
        sub_op, sub_value = sub_criteria
        # Get the comparison operation for the criteria check:
        _subscriber_operation = self._config["operators"][sub_op]
        rtn = _subscriber_operation(value_to_compare, sub_value)
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
