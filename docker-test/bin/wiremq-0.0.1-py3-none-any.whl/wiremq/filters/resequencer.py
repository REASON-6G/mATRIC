# -*- coding: utf-8 -*-

import json
from typing import (
    Any,
    Dict
)

from wiremq.processing import baseprocessor


class Resequencer(baseprocessor.BaseProcessor):
    """
    Resequencer
    ===========

    A Resequencer pattern is a stateful message filter that collects and
    reorders out-of-order messages. Messages are received by the processor
    queue and are returned when they are in order. The order is enforced via
    each message's 'position_id' attribute.

    For example, if messages are received in the following order:
        4, 1, 0, 3, 2
    The resequencer will return the following lists
        [], [], [0, 1], [], [2, 3, 4]

    Messages are stored in a buffer which is set in the resequencer's config.

    The position_id message attribute is assumed to be base zero.

    Attributes
    ----------
    config: Dict
        alias: str
            Alias for the resequencer.
        name: str
            Name for the resequencer.
        type: str
            Type of processor (resequencer).
        uid: hex
            Unique identifier for the resequencer.
        processor_queue:
            Queue object.
        message_store: Object
            Message store object, used for stateful message storage.
        sequences: Dict
            A series of sequence descriptors
            sequence_size: int
                The length of the sequence,
            cursor: int
                The current position of the cursor.
        logger: str, optional
            Name of the logger instance.

    Methods
    -------
    sequence: list
        Sequences a message within a set of messages.
    _process: Dict
        Overrides _process method of Base Processor with filter logic.
    """

    def __init__(self, config: Dict = None):
        """Base processor class constructor.

        Parameters
        ----------
        config: Dict
            alias: str
                Alias for the resequencer.
            name: str
                Name for the resequencer.
            type: str
                Type of processor (resequencer).
            uid: hex
                Unique identifier for the resequencer.
            processor_queue:
                Queue object.
            message_store: Object
                Message store object, used for stateful message storage.
            sequences: Dict
                A series of sequence descriptors
                sequence_size: int
                    The length of the sequence,
                cursor: int
                    The current position of the cursor.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> resequencer_config = {
        ...     "alias": "Message Resequencer",
        ...     "name": "Resequencer filter",
        ...     "type": "resequencer",
        ...     "uid": "a8f43e278bd249cc239d32ab280e35f1",
        ...     "processor_queue": None,
        ...     "message_store": None
        ... }
        >>> queue = fifoqueue.FifoQueue(queue_config)
        >>> resequencer_config["processor_queue"] = queue
        >>> queue.put(msg)
        >>> resequencer.Resequencer(resequencer_config)
        >>> res = queue.get()
        >>> queue.item_processed()

        """
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._log.rtn("%s: success" % self)

    def _process(self, message: Any) -> Dict:
        """Overrides _process method of Base Processor with filter logic.

        Parameters
        ----------
        message: Any
            Message object to be sent to the sequencing method. Must contain
            sequence_id, sequence_size and position_id attributes in the
            header.

        Returns
        -------
        _res: Dict
            Dictionary containing the results of the resequencing. When a
            sub-sequence is not available the data field is an empty list, when
            a sub-sequence is complete it is returned as a list of messages.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        # Check if the message contains sequencing data
        if "sequence_id" in message:
            # Sequence the message
            messages = self._sequence(message)

            # Check if the sequence is complete
            if messages and messages[-1]["position_id"] == \
                    message["sequence_size"] - 1:
                _status = "success"
            else:
                _status = "ongoing"
        else:
            _status = "success"
            messages = message
        rtn = {"status": _status, "data": messages}
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _sequence(self, msg: Dict, ) -> list:
        """ Sequences a message within a set of messages.

        Messages are returned when they are in sequence, this includes
        partially complete sequences (subsequences). The current position in
        the sequence is denoted by a cursor. Sequence data and messages are
        stored statefully in a message store.

        When a sub-sequence is complete it is returned, and any messages that
        form a part of the sub-sequence are removed from the message store.

        When the entire sequence is complete, all the sequence's messages
        should have been returned in order and the messages, and any sequence
        configuration are removed from the store.

        Parameters
        ----------
        msg: Dict
            Message to be sequenced by its position_id attribute

        Returns
        -------
        rtn: list
            A list of sequenced messages.
        """
        self._log.args("%s: (msg: %s)" % (self, msg))
        # Initialize and query the store for the current sequence
        rtn = []
        message_store = self._config["message_store"]
        query = message_store.get({"sequence_id": msg["sequence_id"]})

        # If sequence does not exist, create a new DB entry for the sequence
        if len(query) == 0:
            sequence = {
                "sequence_size": msg["sequence_size"],
                "cursor": 0,
                "messages": {}
            }
            message_store.store({
                "sequence_id": msg["sequence_id"],
                "sequence": json.dumps(sequence)
            })
        else:
            sequence = json.loads(query[0][1])

        # Add the message to the sequence
        sequence["messages"][str(msg["position_id"])] = msg

        # Check for subsequent items, add them to the return list and remove
        # from the stored sequence if found.
        for i in range(sequence["cursor"], sequence["sequence_size"]):
            message = sequence["messages"].get(str(i))
            if message:
                rtn.append(message)
                sequence["cursor"] += 1
                del sequence["messages"][str(i)]
            else:
                break

        # When the sequence is complete, remove it entirely from the store,
        # otherwise update the store with the current sequence.
        if sequence["cursor"] == sequence["sequence_size"]:
            message_store.remove({"sequence_id": msg["sequence_id"]})
        else:
            message_store.update(
                {"sequence_id": msg["sequence_id"]},
                {"sequence": json.dumps(sequence)}
            )

        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
