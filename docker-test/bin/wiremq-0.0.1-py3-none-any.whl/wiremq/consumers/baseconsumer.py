# -*- coding: utf-8 -*-

import json
import uuid
from typing import (
    Dict,
    Any
)
import logging
from wiremq.consumers import abstractconsumer
from wiremq.extlib.err.processingexception import ThreadedSchedulerException
from wiremq.extlib.err.consumerexceptions import BaseConsumerException


class BaseConsumer(abstractconsumer.AbstractConsumer):
    """
    Base Consumer
    =============

    Base consumer is the skeleton of all wiremq consumers. It polls the
    eventloop, either once or continuously, and obtains, schedules, and
    executes tasks, during its life cycle.

    Attributes
    ----------
    _config: Dict
        A configuration.
    _message_store: MessageStore
        The consumer's message store.
    _eventloop: eventloop
        The eventloop for the consumer; polls for events and returns tasks.
    _scheduled_tasks: Queue
        Used to store tasks after polling through the eventloop.
    _scheduler: Scheduler
        The scheduler used to schedule and execute tasks.
    _transactional_client: transactional client
        The transactional client for the consumer
    _registered: bool
        Flag to indicate whether the consumer is registered or not.
    _log: object
        Python logging instance.

    Methods
    -------
    _generate_id(): str
        Generates a unique id.
    _loop(): none
        Poll once for tasks and execute."
    _execute_scheduled(): none
        Execute tasks in the task queue.
    _handle_task_results(): none
        Helper method to separate successful from failed tasks.
    _handle_success(): none
        Helper method to handle successful tasks.
    _handle_failure(): none
        Helper method to handle failed tasks.
    _store_message(): bool
        Stores message in a store.
    _get_message(): dict
        Retrieves a message from a message store.
    _remove_message(): bool
        Removes message from a store.
    register(): bool
        Register components from config
    get_config(): dict
        Gets the Consumer configuration.
    poll_engine(): none
        Polls the eventloop for events.
    run(): Any
        Continuously run the polling loop.
    run_once(): Any
        Runs polling loop once.
    unregister(): bool
        Unregisters consumer components from the baseconsumer.
    close(): bool
        Closes the consumer's scheduler and event loop.
    """

    def __init__(self, config: Dict = None):
        """Base consumer class constructor.

        Parameters
        ----------
        config: Dict (fields required unless otherwise stated)
            message_store: MessageStore
                The consumer's message store.
            eventloop: IOEventLoop
                The consumer's eventloop.
            scheduler: Scheduler
                The consumer's scheduler.
            tx_client: TransactionalClient, optional
                The consumer's transactional client.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> config = {
        ...     "type": "baseconsumer",
        ...     "name": "Base Consumer",
        ...     "uid": "616251e047993b9da10745c4d06126c" +
        ...            "79ad730dcd36844aeba1072386e652f187",
        ...     "message_store": None,
        ...     "eventloop": None,
        ...     "scheduler": None,
        ...     "tx_client": None,
        ...     "logger": "basic_logger"
        ... }
        >>> transactional_client = transactionalclient.TransactionalClient(
        ...     txcconfig
        ... )
        >>> message_store = messagestore.MessageStore(msconfig)
        >>> eventloop = ioeventloopudp.IOEventLoopUDP(evloopconfig)
        >>> scheduler = threadedscheduler.ThreadedScheduler(tsconfig)
        >>> config["message_store"] = message_store
        >>> config["eventloop"] = eventloop
        >>> config["scheduler"] = scheduler
        >>> config["transactional_client"] = tx_client
        >>> cons = baseconsumer.BaseConsumer()
        >>> cons.config_consumer()
        >>> cons.register(config)
        """
        self._id = self._generate_id()
        self._config = None
        self._message_store = None
        self._eventloop = None
        self._scheduler = None
        self._transactional_client = None
        self._scheduled_tasks = None
        self._registered = False
        self._listening = False
        self._log = None
        if config:
            self.register(config)

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def _loop(self) -> None:
        """Poll once for tasks and execute."""
        self.poll_engine()
        if not self._scheduled_tasks.empty():
            self._log.info("%s: task scheduled" % self)
            self._execute_scheduled()

    def _execute_scheduled(self) -> None:
        """Execute tasks in the task queue."""
        self._log.args("%s: ()" % self)
        results = self._scheduler.schedule()
        self._handle_task_results(results)
        self._log.rtn("%s: success" % self)

    def _handle_task_results(self, results: list) -> None:
        """Helper method to separate successful from failed tasks.

        Parameters
        ----------
        results: list
            The results from executing scheduled tasks through the scheduler.
        """
        self._log.args("%s: (results: %s)" % (self, results))
        # Extract task IDs for successfully completed tasks
        success_ids = []
        for result in results:
            if result["status"] == "success":
                success_ids.append(result["task_id"])

        # Handle both successes and failures
        if not self._scheduled_tasks.empty():
            _task = self._scheduled_tasks.get()
            if _task.get_id() in success_ids:
                self._handle_success(_task)
            else:
                self._handle_failure(_task)
        self._log.rtn("%s: success" % self)

    def _handle_success(self, task: Any) -> None:
        """Helper method to handle successful tasks.

        Parameters
        ----------
        task: Task
            A successfully completed task.
        """
        self._log.args("%s: (task: %s)" % (self, task))
        self._scheduled_tasks.item_processed()
        self._log.rtn("%s: success" % self)

    def _handle_failure(self, task: Any) -> None:
        """Helper method to handle failed tasks.

        Parameters
        ----------
        task: Task
            An unsuccessfully completed (failed) task.
        """
        self._log.error("%s: (task: %s, buffer: %s)" %
                        (self, task, task.get_buffer()))

    def _store_message(self, message: Dict) -> bool:
        """Stores message in a store.

        Parameters
        ----------
        message: Dict
            The message to store in the message store.

        Returns
        -------
        rtn: bool
            The result of the operation.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        rtn = self._message_store.store({
            "message_id": message["message_id"],
            "dest_ip": message["dest_ip"],
            "dest_port": message["dest_port"],
            "message": json.dumps(message)
        })
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _get_message(self, message_id: str) -> Any:
        """Retrieves a message from a message store.

        Parameters
        ----------
        message_id: str
            The message_id for the message to be retrieved.

        Returns
        -------
        message: Any
            The message retrieved from the message store
        """
        self._log.args("%s: (message_id: %s)" % (self, message_id))
        query_result = self._message_store.get(message_id)
        if len(query_result) == 0:
            message = None
        else:
            message = json.loads(query_result[0])
        self._log.rtn("%s: success | data: %s" % (self, message))
        return message

    def _remove_message(self, message_id: str) -> bool:
        """Removes message from a store.

        Parameters
        ----------
        message_id: str
            The message_id for the message to be removed.

        Returns
        -------
        rtn: bool
            The result of the removal.
        """
        self._log.args("%s: (message_id: %s)" % (self, message_id))
        rtn = self._message_store.remove(message_id)
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def register(self, config: Dict) -> bool:
        """Register components from config.

        Parameters
        ----------
        config: Dict (fields required unless otherwise stated)
            eventloop: IOEventLoop
                The consumer's eventloop.
            scheduler: Scheduler
                The consumer's scheduler.
            task_queue: FifoQueue
                The queue used to store tasks to be processed.
            message_store: MessageStore, optional
                The consumer's message store.
            tx_client: TransactionalClient, optional
                The consumer's transactional client.
        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._config = config
        self._message_store = self._config.get("message_store")
        self._eventloop = self._config["eventloop"]
        self._scheduled_tasks = self._config["task_queue"]
        self._scheduler = self._config["scheduler"]
        self._transactional_client = self._config.get("tx_client")
        self._registered = True
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def get_config(self) -> Dict:
        """Gets the Consumer configuration.

        Returns
        -------
        config: Dict
            The configuration of the consumer.
        """
        self._log.args("%s: ()" % self)
        config = self._config
        self._log.rtn("%s: success | data: %s" % (self, config))
        return config

    def poll_engine(self) -> None:
        """Polls the eventloop for events,

        Returns
        -------
        rtn: Any
            A queue of scheduled tasks (may be empty).
        """
        self._eventloop.run_once()

    def run(self) -> None:
        """Continuously run the polling loop."""
        self._listening = True
        while self._listening:
            self._loop()

    def run_once(self) -> None:
        """Runs the polling loop once."""
        try:
            self._loop()
        except ThreadedSchedulerException as e:
            self._log.error(e)
            raise BaseConsumerException(e)

    def unregister(self) -> bool:
        """Unregisters consumer components from the baseconsumer.

        Returns
        -------
        rtn: bool
            Returns True if successful
        """
        self._log.args("%s: ()" % self)
        self._config = None
        self._message_store = None
        self._eventloop = None
        self._scheduled_tasks = None
        self._scheduler = None
        self._transactional_client = None
        self._registered = False
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def close(self) -> bool:
        """Closes the consumer's event loop.

        Returns
        -------
        rtn: bool
            Returns True if successful
        """
        if self._eventloop:
            self._eventloop.close()
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
