# -*- coding: utf-8 -*-

from typing import (
    Dict,
    Any
)
from wiremq.utils.configtools import (
    initialize_unix_destinations,
    initialize_unix_sockets,
    initialize_terminator
)
from wiremq.wmqsockets import (
    inboundsocket,
    outboundsocket,
    broadcastsocket
)
from wiremq.processing import (
    baseprocessmanager,
    threadedscheduler,
    basethreadpool
)
from wiremq.processing.methods import pmmethod
from wiremq.extlib.queue import fifoqueue
from wiremq.extlib.asynchronous.eventloops import (
    ioeventloopudp,
    ioeventlooptcp
)
from wiremq.extlib.asynchronous.iopollers import iopoll
from wiremq.filters import sockdispatcher
from wiremq.consumers import baseconsumer
from wiremq.translators import (
    httpparser,
    httpformatter,
    bsoncontentdecoder,
    bsoncontentencoder,
)


class BaseConsumerBuilder:
    """
    Base Consumer Builder
    =====================

    Builder class for creating a Base Consumer.

    Methods
    -------
    _reset(): None
        Reset the config and create a fresh channel instance.
    consumer: object
        Returns configured consumer object.
    make_consumer(): None
        Create a consumer's components and registers them.
    make_queue() None
        Create a queue.
    make_eventloop(): None
        Create an eventloop.
    make_poller(): None
        Create a poller.
    make_scheduler(): None
        Create a scheduler.
    make_threadpool(): Any
        Create a threadpool.
    make_socket(): None
        Create a socket.
    register(): None
        Register the components to the consumer.

    Attributes
    ----------
    _config : dict, optional
        This holds socket and channel configurations.
    """

    def __init__(self) -> None:
        """Consumer Builder constructor.

        Example
        -------
        See integration test director for consumer's config, which
        contains an example of the fields and values required.

        >>> c_builder = baseconsumerbuilder.BaseConsumerBuilder()
        >>> c_builder.make_consumer(consumer_config)
        >>> consumer = c_builder.consumer
        """
        super().__init__()
        self._processor_module_map = {
            "SD": sockdispatcher.SockDispatcher,
            "HF": httpformatter.HTTPFormatter,
            "HP": httpparser.HTTPParser,
            "CD": bsoncontentdecoder.BSONContentDecoder,
            "CE": bsoncontentencoder.BSONContentEncoder
        }
        self._task_map = {
            "PM": {
                "worker": baseprocessmanager.BaseProcessManager,
                "method": pmmethod.execute,
            }
        }
        self._reset()

    def __str__(self):
        return 'Consumer-Builder Object'

    def _reset(self) -> None:
        """Reset the builder's component.

        This internal call refreshes the builder's current configured consumer
        and creates a fresh instance of the class. The builder can then accept
        new building requests.
        """
        self._consumer = baseconsumer.BaseConsumer()

    @property
    def consumer(self) -> baseconsumer.BaseConsumer:
        """This is the result of the building.

        Note
        ----
        Provided is the interface for retrieving the final product.
        After the retrieval of a configured consumer, the builder
        should be ready to accept new building requests. To account for
        this design, a call to the `consumer` property calls the internal
        `_reset()` method.
        """
        consumer = self._consumer
        self._reset()
        return consumer

    def make_consumer(self, consumer_opt: Dict) -> None:
        """Create a consumer's components.

        Parameters
        ----------
        consumer_opt : Dict, required
            The initial consumer configuration.
        """
        _consumer_domain = consumer_opt.get("internal_domain")
        consumer_opt = initialize_terminator(consumer_opt)
        consumer_opt = initialize_unix_sockets(consumer_opt, _consumer_domain)
        consumer_opt = \
            initialize_unix_destinations(consumer_opt, _consumer_domain)
        _task_queue = self.make_queue(consumer_opt["task_queue_config"])
        consumer_opt["ioloop_config"]["task_queue"] = _task_queue
        consumer_opt["scheduler_config"]["task_queue"] = _task_queue
        _scheduler = self.make_scheduler(consumer_opt["scheduler_config"])
        _eventloop = self.make_eventloop(consumer_opt["ioloop_config"])
        consumer_opt["eventloop"] = _eventloop
        consumer_opt["task_queue"] = _task_queue
        consumer_opt["scheduler"] = _scheduler
        self.register(consumer_opt)

    def make_queue(self, queue_opt: Dict) -> Any:
        """Create a queue.

        Parameters
        ----------
        queue_opt : Dict, required
            The initial queue configuration.

        Returns
        -------
        rtn: object
            Built fifo queue object
        """
        return fifoqueue.FifoQueue(queue_opt)

    def make_eventloop(self, eventloop_opt: Dict) -> Any:
        """Create an eventloop.

        Parameters
        ----------
        eventloop_opt : Dict, required
            The initial eventloop configuration.

        Returns
        -------
        rtn: obj
            Build and initialized eventloop object
        """
        eventloop_opt["socket"] = self.make_socket(
            eventloop_opt["inbound_socket_config"]
        )
        eventloop_opt["poller"] = self.make_poller(
            eventloop_opt["poller_config"]
        )
        if eventloop_opt["type"] == "ioeventloopudp":
            _eventloop = ioeventloopudp.IOEventLoopUDP(eventloop_opt)
        elif eventloop_opt["type"] == "ioeventlooptcp":
            _eventloop = ioeventlooptcp.IOEventLoopTCP(eventloop_opt)
        _eventloop.initialize()
        return _eventloop

    def make_poller(self, poller_opt: Dict) -> Any:
        """Create a poller.

        Parameters
        ----------
        poller_opt : Dict, required
            The initial poller configuration.

        Returns
        -------
        rtn: obj
            Built iopoll object
        """
        return iopoll.IOPoll(poller_opt)

    def make_scheduler(self, scheduler_opt: Dict) -> Any:
        """Create a scheduler.

        Parameters
        ----------
        scheduler_opt : Dict, required
            The initial scheduler configuration.

        Returns
        -------
        rtn: obj
            Built scheduler object
        """
        pmmap = scheduler_opt["worker_config"]["processor_map"]
        for proc in pmmap.keys():
            pmmap[proc]["processor"] = self._processor_module_map[proc]
        for task in scheduler_opt["worker_map"]:
            scheduler_opt["worker_map"][task] = {
                "worker": self._task_map[scheduler_opt["worker_map"][
                    task]["worker"]]["worker"],
                "config": scheduler_opt["worker_config"],
                "method": self._task_map[scheduler_opt["worker_map"][
                    task]["method"]]["method"],
                "queue_config": scheduler_opt["worker_config"][
                    "processor_queue_config"]
            }
        _threadpool = self.make_threadpool(scheduler_opt["threadpool_config"])
        _scheduler = threadedscheduler.ThreadedScheduler(
            scheduler_opt, _threadpool, scheduler_opt["task_queue"]
        )
        return _scheduler

    def make_threadpool(self, threadpool_opt: Dict) -> Any:
        """Create a threadpool.

        Parameters
        ----------
        threadpool_opt : Dict, required
            The initial threadpool configuration.

        Returns
        -------
        Built base thread pool object
        """
        return basethreadpool.BaseThreadPool(threadpool_opt)

    def make_socket(self, socket_config: Dict) -> Any:
        """Create a socket.

        Parameters
        ----------
        socket_config: Dict
            Socket configuration

        Returns
        -------
        Built socket
        """
        if socket_config["type"] == "inboundsocket":
            _socket = inboundsocket.InboundSocket(socket_config)
        elif socket_config["type"] == "outboundsocket":
            _socket = outboundsocket.OutboundSocket(socket_config)
        elif socket_config["type"] == "broadcastsocket":
            _socket = broadcastsocket.BroadcastSocket(socket_config)
        return _socket

    def register(self, components: Dict = None) -> None:
        """Register the components to the consumer.

        Parameters
        ----------
        components : dict, required
        """
        self._consumer.register(components)
