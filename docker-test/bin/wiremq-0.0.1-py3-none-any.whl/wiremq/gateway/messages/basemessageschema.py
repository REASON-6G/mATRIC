# -*- coding: utf-8 -*-
from typing import Dict


class BaseMessageSchema:
    """
    Base Message Schema
    ===================

    Message schema which other schemas are based on. This schema holds
    attribute criteria common to all schemas. Each method may be overridden
    by child classes to customise the schemas.

    Attributes may be excluded entirely from validation by
    using the `excluded_header_keys` config.

    Attribute schemas may also be modified or added by providing entries
    to the `header_schema` or `payload_schema` dictionaries.

    The format for each schema modification entry is as follows:

    .. code-block:: python
        :linenos:
        :caption: Template schema for an attribute

        {
          "<attribute>": {
            "type": "<type>",
            "criteria": [("<operator>", value1), ("<operator>", value2)],
            "format": "<format_id>",
            "oneof": ["<option_1>", "<option_2>"]
          }
        }

    At least one validation should be specified.

    type:
        Should be an inbuilt python type or from typing library
        (e.g. str, int, bool, list, dict, typing.Dict, typing.LiteralString)
    criteria:
        A list of binary operators. The `<operator>` should be one of:
            - "lt": less than
            - "gt": greater than
            - "eq": equal to
            - "ne": not equal to
            - "ge": greater than or equal to
            - "le": less than or equal to
    format:
        A reference to a pre-configured regex map in `BaseValidator`, one
        of:
            - ip: IP address (192.168.0.241)
            - datetime: YYYY-MM-DD HH:MM:SS
            - hex: A hex string of any length
            - urlsafe: A URL safe string (containing no unsafe symbols)
            - uuid: uuid4 format (e.g. 4e36fac0-0f08-4000-808e-bb6e57885e45)

    Examples
    --------
    .. code-block:: python
        :linenos:
        :caption: Example usage for Base Message Schema

        from wiremq.gateway.messages import basemessageschema

        schema_config = {
          "name": "Test schema",
          "alias": "test_schema",
          "type": "baseschema",
          "is_sequence": False,
          "excluded_header_keys": [
            "sequence_size",
            "sequence_id",
            "position_id"
          ],
          "header_schema": {
            "sender_port": {
              "type": int,
              "criteria": [("gt", 4000), ("lt", 6000)],
            }
          }
          "payload_schema": {
            "my_param": {
              "type": str
             }
            }
          }
        }
        ms = basemessageschema.BaseMessageSchema(schema_config)

    .. code-block:: python
        :linenos:
        :caption: Example base message

        {
            "sender_ip": "127.0.0.1",
            "sender_port": 5000,
            "sender_alias": "my_endpoint",
            "dest_ip": "127.0.0.1",
            "dest_port": 4001,
            "protocol_version": "0.0.1",
            "message_id": str(uuid.uuid4()),  # generated if omitted
            "timestamp": time.time(), # generated if omitted
            "datetime": str(datetime.datetime.now()),  # generated if omitted
            "nonce": secrets.token_urlsafe(),  # generated if omitted
            "payload": {
                "data": "Hello world",
            }
        }

    """
    def __init__(self, config: Dict = None) -> None:
        """

        Parameters
        ----------
        config: Dict
            Schema configuration
            name: str
                Name of the schema.
            alias: str
                Alias for the schema.
            type: str
                Type of object (basemessageschema).
            is_sequence: bool
                Whether the message is part of a sequence, if True will check
                for sequence_size, sequence_id, position_id attributes.
            excluded_header_keys: list
                List of strings denoting header keys to be excluded from
                validation.
            excluded_payload_keys: list
                List of strings denoting payload keys to be excluded from
                validation.
            header_schema: Dict
                Custom header schema (if overriding default), see example.
            payload_schema: Dict
                Custom payload schema (if overriding default), see example.
        """
        self._header_schema = None
        self._payload_schema = None
        self._excluded_header_keys = []
        self._excluded_payload_keys = []
        self._is_sequence = None
        self._config = None
        if config:
            self.config(config)
        self._build_header_schema()
        self._build_payload_schema()

    def _build_header_schema(self) -> None:
        """Creates the default header schema and updates with user-defined
        configs and keys which are excluded from validation.
        """
        self._header_schema = {
            "protocol_version": {
                "type": str
            },
            "message_id": {
                "type": str,
                "format": "uuid"
            },
            "timestamp": {
                "type": float
            },
            "datetime": {
                "type": str,
                "format": "datetime"
            },
            "sender_ip": {
                "type": str,
                "format": "ip"
            },
            "sender_port": {
                "type": int,
                "criteria": [("gt", 0)]
            },
            "dest_ip": {
                "type": str,
                "format": "ip"
            },
            "dest_port": {
                "type": int,
                "criteria": [("gt", 0)]
            },
            "nonce": {
                "type": str,
                "format": "urlsafe"
            }
        }
        if self._is_sequence:
            self._header_schema.update({
                "sequence_size": {
                    "type": int
                },
                "sequence_id": {
                    "type": str,
                },
                "position_id": {
                    "type": int,
                    "criteria": [("ge", 0)]
                }
            })
        if self._config and "header_schema" in self._config:
            self._update_header_schema(self._config.get("header_schema"))
        for key in self._excluded_header_keys:
            self._header_schema.pop(key, None)

    def _build_payload_schema(self) -> None:
        """Assembles the payload schema, updating it with the custom config if
        provided.
        """

        self._payload_schema = {}
        if self._config and "payload_schema" in self._config:
            self._update_payload_schema(self._config.get("payload_schema"))
        for key in self._excluded_payload_keys:
            del self._payload_schema[key]

    def _update_header_schema(self, header_config: Dict) -> None:
        """Modifies the default header schema.

        The format of each entry must match the normal schema.

        Parameters
        ----------
        header_config: Dict
            Attributes to update (may be overriding existing attributes, or
            creating new attributes).

        """
        self._header_schema.update(header_config)

    def _update_payload_schema(self, payload_config: Dict) -> None:
        """Modifies the default payload schema.

        The format of each entry must match the normal schema.

        Parameters
        ----------
        payload_config: Dict
            Attributes to update (may be overriding existing attributes, or
            creating new attributes).

        """
        self._payload_schema.update(payload_config)

    def config(self, config: Dict) -> None:
        """Configures the schema

        Parameters
        ----------
        config: Dict
            Schema configuration dictionary.
            excluded_header_keys: list (optional)
                List of keys to exclude from header validation.
            excluded_payload_keys: list (optional)
                List of keys to exclude from payload validation.
            header_schema: Dict (optional)
                Custom header schema to update the default schema with.
            payload_schema: Dict (optional)
                Custom payload schema to update the default schema with.
            is_sequence: bool (optional)
                Whether the message is a part of a sequence (requires sequence
                data if True)

        """
        self._config = config
        self._excluded_header_keys = config.get("excluded_header_keys", [])
        self._excluded_payload_keys = config.get("excluded_payload_keys", [])
        self._is_sequence = config.get("is_sequence", False)

    def get_header_schema(self) -> Dict:
        """Getter function for the header schema.

        Returns
        -------
        header_schema: Dict
            Header validation schema.
        """

        return self._header_schema

    def get_payload_schema(self) -> Dict:
        """Getter function for the payload schema.

        Returns
        -------
        payload_schema: Dict
            Payload validation schema.
        """
        return self._payload_schema
