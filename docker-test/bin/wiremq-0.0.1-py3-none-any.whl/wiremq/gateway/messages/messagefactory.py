# -*- coding: utf-8 -*-
import uuid
import time
from datetime import datetime as dt
import secrets
from typing import (
    Dict,
    Tuple,
    Union
)
from wiremq.gateway.messages import (
    abstractmessagefactory,
    basemessageschema,
    commandmessageschema,
    eventmessageschema,
    serviceresponseschema,
    ackschema,
    onlinemessageschema,
    sequenceschema,
    basevalidator
)
from wiremq.utils import wmqcode


class MessageFactory(abstractmessagefactory.AbstractMessageFactory):
    """
    Message Factory
    ===============

    Generates a message based on a config.

    Methods
    -------
    _update_header():
        Adds attributes to the message header.
    _validate(): Tuple
        Validates the message with the registered validator.
    _register():
        Registers schemas and validator to the message factory.
    _message(): Dict
        Helper method for generating messages.
    update_schemas():
        Mutator method to update the message schemas.
    basemessage(): Dict
        Generates and validates a base message.
    eventmessage(): Dict
        Generates and validates an event message.
    commandmessage(): Dict
        Generates and validates a command message.
    addsubscribermessage(): Dict
        Generates and validates an Add Subscriber message.
    updatesubscribermessage(): Dict
        Generates and validates an Update Subscriber message.
    removesubscribermessage(): Dict
        Generates and validates a Remove Subscriber message.
    addbusconnectionmessage(): Dict
        Generates and validates an Add Bus Connection message.
    removebusconnectionmessage(): Dict
        Generates and validates an Add Bus Connection message.
    serviceresponsemessage(): Dict
        Generates and validates a service response message.
    ackmessage(): Dict
        Generates and validates an acknowledgement message.
    onlinemessage(): Dict
        Generates and validates an online message.

    Examples
    --------
    >>> mf = basemessagefactory.BaseMessageFactory()
    >>> header = {
    ...   "protocol_version": "0.0.1",
    ...   "sender_ip": "127.0.0.1",
    ...   "sender_port": 8001,
    ...   "dest_ip": "127.0.0.1",
    ...   "dest_port": 8002,
    ...   "type": "event"
    ... }
    >>> payload = {
    ...   "topic": "cpu",
    ...   "data": {
    ...     "percent": 51.1,
    ...     "cpu1_temp": 40.2
    ...   }
    ... }
    >>> message = mf.eventmessage(header, payload)
    """
    def __init__(self):
        super().__init__()
        self._log = None
        self._validator = None
        self._schemas = None
        self._register()

    def _update_header(self, message: Dict) -> Dict:
        """Adds attributes to the message header.

        Some of the attributes can optionally be generated automatically if not
        provided, these are:
          - timestamp
          - datetime
          - message_id
          - nonce

        Parameters
        ----------
        message: Dict
            The message to be populated with header attributes.
            type: str
                Message type (e.g. command, event)
            sender_ip: str
                IP address of the message sender.
            sender_port: int
                Port number of the message sender.
            sender_alias: str
                Alias of the message sender.
            dest_ip: str
                IP address of the message recipient.
            dest_port: int
                Port number of the message recipient.
            protocol_version: str
                Version of the protocol (e.g. 0.0.1).
            timestamp: float
                UNIX epoch timestamp, if not provided this is automatically
                generated.
            datetime: str
                Human readable date-time stamp, e.g. 2023-11-17 20:51:35.620139
            correlation_id: str
                Correlation ID.
            tx_correlation_id: str
                Transaction correlation ID.
            tx_id: str
                Transaction ID.
            message_id: str
                Message ID, if not provided this is automatically generated.
            nonce: str
                Message nonce, if not provided this is automatically generated.

        """
        if "timestamp" not in message or not message["timestamp"]:
            message["timestamp"] = time.time()
        if "datetime" not in message or not message["datetime"]:
            message["datetime"] = str(dt.now())
        if "message_id" not in message or not message["message_id"]:
            message["message_id"] = str(uuid.uuid4())
        if "nonce" not in message or not message["nonce"]:
            message["nonce"] = secrets.token_urlsafe()
        return message

    def _validate(self,
                  message: Dict,
                  schema: Union[basemessageschema.BaseMessageSchema,
                                eventmessageschema.EventMessageSchema,
                                commandmessageschema.CommandMessageSchema,
                                serviceresponseschema.ServiceResponseSchema,
                                ackschema.AckSchema,
                                onlinemessageschema.OnlineMessageSchema,
                                sequenceschema.SequenceSchema],
                  is_sequence: bool = False) -> Tuple:
        """Validates the message with the registered validator.

        Parameters
        ----------
        message: Dict
            Message to be validated.
        schema: BaseMessageSchema (or child classes)
            Message schema to be validated against.
        is_sequence: bool (default=False)
            Whether the message is a part of a sequence (requires sequence
            data if True).

        Returns
        -------
        result, prompt: (bool, str)
            True if validation successful, False otherwise; Validation prompt.
        """
        if is_sequence:
            sequence_validation = self._validator.validate(
                message,
                schema,
                sequence_schema=self._schemas["sequence"]
            )
            return sequence_validation
        else:
            return self._validator.validate(message, schema)

    def _register(self) -> None:
        """Registers schemas and validator to the message factory.
        """
        self._validator = basevalidator.BaseValidator()
        self._schemas = {
            "basemessage": basemessageschema.BaseMessageSchema(),
            "event": eventmessageschema.EventMessageSchema(),
            "command": commandmessageschema.CommandMessageSchema(),
            "serviceresponse": serviceresponseschema.ServiceResponseSchema(),
            "ack": ackschema.AckSchema(),
            "online": onlinemessageschema.OnlineMessageSchema(),
            "sequence": sequenceschema.SequenceSchema()
        }

    def _message(self,
                 schema_type: str,
                 header: Dict,
                 payload: Dict = None,
                 is_sequence: bool = None) -> Dict:
        """Helper method for generating messages.

        Parameters
        ----------
        schema_type: str
            Name of the schema to use (one of basemessage, event, command, ack,
            serviceresponse, online)
        header: Dict
            Message header
        payload: Dict
            Message payload
        is_sequence: bool (default=False)
            Whether the message is a part of a sequence (requires sequence
            data if True).

        Returns
        -------
        message: Dict
            If validation passed, returns the composed message.
            If validation failed, returns a status report.

        """
        message = {}
        message.update(header)
        if payload:
            message["payload"] = payload
        message = self._update_header(message)
        validation = self._validate(message,
                                    self._schemas[schema_type],
                                    is_sequence)
        if validation[0]:
            return message
        else:
            return {"status": "failure", "data": validation[1]}

    def update_schemas(self, schemas: Dict) -> None:
        """Mutator method to update the message schemas.

        Parameters
        ----------
        schemas: Dict
            Custom message schemas. key: value, where
                key: name of the schema
                value: BaseMessageSchema (or child objects)
        """
        self._schemas.update(schemas)

    def basemessage(self,
                    header: Dict,
                    payload: Dict = None,
                    is_sequence: bool = False) -> Dict:
        """Generates and validates a base message.

        Base message enforces the generic header schema only, the payload may
        use any format.

        Parameters
        ----------
        header: Dict
            msg_type: str
                Message type (e.g. command, event)
            sender_ip: str
                IP address of the message sender.
            sender_port: int
                Port number of the message sender.
            sender_alias: str
                Alias of the message sender.
            dest_ip: str
                IP address of the message recipient.
            dest_port: int
                Port number of the message recipient.
            protocol_version: str
                Version of the protocol (e.g. 0.0.1).
            timestamp: float
                UNIX epoch timestamp, if not provided this is automatically
                generated.
            datetime: str
                Human readable date-time stamp, e.g. 2023-11-17 20:51:35.620139
            message_id: str
                Message ID, if not provided this is automatically generated.
            nonce: str
                Message nonce, if not provided this is automatically generated.
        payload: Dict
            Message payload.
        is_sequence: bool (default=False)
            Whether the message is a part of a sequence (requires sequence
            data if True).

        Examples
        --------
        >>> header = {
        ...   "protocol_version": "0.0.1",
        ...   "sender_ip": "127.0.0.1",
        ...   "sender_port": 8001,
        ...   "dest_ip": "127.0.0.1",
        ...   "dest_port": 8002,
        ...   "type": "event"
        ... }
        >>> payload = {
        ...   "data": "test"
        ... }

        Returns
        -------
        message: Dict
            If validation passed, returns the composed message.
            If validation failed, returns a status report.

        """
        return self._message(
            "basemessage",
            header,
            payload=payload,
            is_sequence=is_sequence)

    def eventmessage(self,
                     header: Dict,
                     payload: Dict = None,
                     is_sequence: bool = False) -> Dict:
        """Generates and validates an event message.

        Parameters
        ----------
        header: Dict
            See basemessage for additional header attributes.
        payload: Dict (optional)
            Message payload.
        is_sequence: bool (optional, default=False)
            Whether the message is a part of a sequence (requires sequence
            data if True).

        Examples
        --------
        >>> header = {
        ...   "protocol_version": "0.0.1",
        ...   "sender_ip": "127.0.0.1",
        ...   "sender_port": 8001,
        ...   "dest_ip": "127.0.0.1",
        ...   "dest_port": 8002,
        ...   "type": "event"
        ... }
        >>> payload = {
        ...   "data": "test"
        ... }

        Returns
        -------
        message: Dict
            If validation passed, returns the composed message.
            If validation failed, returns a status report.

        """
        header["type"] = "event"
        return self._message(
            "event",
            header,
            payload=payload,
            is_sequence=is_sequence)

    def commandmessage(self,
                       header: Dict,
                       payload: Dict = None,
                       is_sequence: bool = False) -> Dict:
        """Generates and validates a command message.

        Command numbers currently supported in WireMQ are outlined as follows:

        Add subscriber: 21
        Update subscriber: 22
        Remove subscriber: 23
        Add bus connection: 31
        Remove bus conection: 32

        Parameters
        ----------
        header: Dict
            See basemessage for additional header attributes.
        payload: Dict
            Message payload.
            command: int
                Command number (see wiremq.utils.wmqcode).
            params: Dict
                Parameters for the command.
        is_sequence: bool (optional, default=False)
            Whether the message is a part of a sequence (requires sequence
            data if True).

        Examples
        --------
        >>> header = {
        ...   "protocol_version": "0.0.1",
        ...   "sender_ip": "127.0.0.1",
        ...   "sender_port": 8001,
        ...   "sender_alias": "subscriber_1",
        ...   "dest_ip": "127.0.0.1",
        ...   "dest_port": 8002,
        ... }
        >>> payload = {
        ...   "command": 21,
        ...   "params": {
        ...     "alias": "channel1",
        ...     "host": "127.0.0.1",
        ...     "port": 8803,
        ...     "topics": ["cpu"],
        ...     "criteria": {
        ...       "cpu": {
        ...         "cpu_percent": ("gt", 5.0)
        ...       }
        ...     }
        ...   }
        ... }

        Returns
        -------
        message: Dict
            If validation passed, returns the composed message.
            If validation failed, returns a status report.

        """
        header["type"] = "command"
        return self._message(
            "command",
            header,
            payload=payload,
            is_sequence=is_sequence)

    def addsubscribermessage(self,
                             header: Dict,
                             payload: Dict = None,
                             is_sequence: bool = False) -> Dict:
        """Generates and validates an Add Subscriber message.

        Parameters
        ----------
        header: Dict
            See basemessage for additional header attributes.
        payload: Dict
            Message payload.
            params: Dict
                Parameters for the command.
        is_sequence: bool (optional, default=False)
            Whether the message is a part of a sequence (requires sequence
            data if True).

        Returns
        -------
        message: Dict
            If validation passed, returns the composed message.
            If validation failed, returns a status report.

        """
        payload["command"] = wmqcode.ADD_SUBSCRIBER
        return self.commandmessage(header, payload, is_sequence)

    def updatesubscribermessage(self,
                                header: Dict,
                                payload: Dict = None,
                                is_sequence: bool = False) -> Dict:
        """Generates and validates an Update Subscriber message.

        Parameters
        ----------
        header: Dict
            See basemessage for additional header attributes.
        payload: Dict
            Message payload.
            params: Dict
                Parameters for the command.
        is_sequence: bool (optional, default=False)
            Whether the message is a part of a sequence (requires sequence
            data if True).

        Returns
        -------
        message: Dict
            If validation passed, returns the composed message.
            If validation failed, returns a status report.

        """
        payload["command"] = wmqcode.UPDATE_SUBSCRIBER
        return self.commandmessage(header, payload, is_sequence)

    def removesubscribermessage(self,
                                header: Dict,
                                payload: Dict = None,
                                is_sequence: bool = False) -> Dict:
        """Generates and validates a Remove Subscriber message.

        Parameters
        ----------
        header: Dict
            See basemessage for additional header attributes.
        payload: Dict
            Message payload.
            params: Dict
                Parameters for the command.
        is_sequence: bool (optional, default=False)
            Whether the message is a part of a sequence (requires sequence
            data if True).

        Returns
        -------
        message: Dict
            If validation passed, returns the composed message.
            If validation failed, returns a status report.

        """
        payload["command"] = wmqcode.REMOVE_SUBSCRIBER
        return self.commandmessage(header, payload, is_sequence)

    def addbusconnectionmessage(self,
                                header: Dict,
                                payload: Dict = None,
                                is_sequence: bool = False) -> Dict:
        """Generates and validates an Add Bus Connection message.

        Parameters
        ----------
        header: Dict
            See basemessage for additional header attributes.
        payload: Dict
            Message payload.
            params: Dict
                Parameters for the command.
        is_sequence: bool (optional, default=False)
            Whether the message is a part of a sequence (requires sequence
            data if True).

        Returns
        -------
        message: Dict
            If validation passed, returns the composed message.
            If validation failed, returns a status report.

        """
        payload["command"] = wmqcode.ADD_BUS_CONNECTION
        return self.commandmessage(header, payload, is_sequence)

    def removebusconnectionmessage(self,
                                   header: Dict,
                                   payload: Dict = None,
                                   is_sequence: bool = False) -> Dict:
        """Generates and validates an Add Bus Connection message.

        Parameters
        ----------
        header: Dict
            See basemessage for additional header attributes.
        payload: Dict
            Message payload.
            params: Dict
                Parameters for the command.
        is_sequence: bool (optional, default=False)
            Whether the message is a part of a sequence (requires sequence
            data if True).

        Returns
        -------
        message: Dict
            If validation passed, returns the composed message.
            If validation failed, returns a status report.

        """
        payload["command"] = wmqcode.REMOVE_BUS_CONNECTION
        return self.commandmessage(header, payload, is_sequence)

    def serviceresponsemessage(self,
                               header: Dict,
                               payload: Dict = {},
                               is_sequence: bool = False) -> Dict:
        """Generates and validates a service response message.

        This is a message which responds to the service activator, the data
        that is sent back to the client. It must contain transaction
        information to match it against the incoming transaction ID, and an
        error code and message.

        Parameters
        ----------
        header: Dict
            See basemessage for additional header attributes
            correlation_id: str
                Correlation ID.
            tx_correlation_id: str
                Transaction correlation ID.
            tx_id: str
                Transaction ID (generated automatically if not supplied).
            error_code: int
                HTTP status code.
            error_message: str
                HTTP status message
        payload: Dict
            Message payload.
        is_sequence: bool (optional, default=False)
            Whether the message is a part of a sequence (requires sequence
            data if True).

        Examples
        --------
        >>> msgs = channel.recv()
        >>> for msg in msgs:
        >>>   return_header = {
        ...     "correlation_id": msg["message_id"],
        ...     "tx_id": str(uuid.uuid4()),
        ...     "tx_correlation_id": msg["tx_id"]
        ...     "error_code": 200,
        ...     "error_message": "OK",
        ...     "sender_ip": "127.0.0.1",
        ...     "sender_port": 8000,
        ...     "sender_alias": "monitoring_channel",
        ...     "dest_ip": "127.0.0.1",
        ...     "dest_port": 10827
        ...   }
        >>>   return_payload = {
        ...     "data": "example"
        ...   }

        Returns
        -------
        message: Dict
            If validation passed, returns the composed message.
            If validation failed, returns a status report.

        """
        header["type"] = "event"
        if "tx_id" not in header or not header["tx_id"]:
            header["tx_id"] = str(uuid.uuid4())
        return self._message(
            "serviceresponse",
            header,
            payload=payload,
            is_sequence=is_sequence)

    def ackmessage(self, header: Dict) -> Dict:
        """Generates and validates an acknowledgement message.

        Acknowledgements are event messages with no payload. The correlation_id
        should correspond to the acknowledged message's message_id

        Parameters
        ----------
        header: Dict
            See basemessage for header attributes.

        Examples
        --------
        >>> msgs = channel.receive()
        >>> for msg in msgs:
        >>>   header = {
        ...     "correlation_id": msg["message_id"],
        ...     "error_code": 200,
        ...     "error_message": "OK",
        ...     "sender_ip": "127.0.0.1",
        ...     "sender_port": 8000,
        ...     "sender_alias": "monitoring_channel",
        ...     "dest_ip": "127.0.0.1",
        ...     "dest_port": 10827
        ...   }
        >>>   ack = messagefactory.ackmessage(header)
        >>>   channel.send(ack)

        Returns
        -------
        message: Dict
            If validation passed, returns the composed message.
            If validation failed, returns a status report.

        """
        header["type"] = "ack"
        return self._message(
            "ack",
            header,
            payload=None,
            is_sequence=False)

    def onlinemessage(self, header: Dict) -> Dict:
        """Generates and validates an online message.

        This message is consumed by durable endpoints to prompt a re-sending
        of any un-acknowledged messages.

        Parameters
        ----------
        header: Dict
            See basemessage for other attributes.

        Examples
        --------
        >>> header = {
        ...   "protocol_version": "0.0.1",
        ...   "sender_ip": "127.0.0.1",
        ...   "sender_port": 8001,
        ...   "sender_alias": "channel1",
        ...   "dest_ip": "127.0.0.1",
        ...   "dest_port": 8002,
        ... }

        Returns
        -------
        message: Dict
            If validation passed, returns the composed message.
            If validation failed, returns a status report.

        """
        header["type"] = "event"
        payload = {"state": "online"}
        return self._message(
            "event",
            header,
            payload=payload,
            is_sequence=False)
