# -*- coding: utf-8 -*-
from abc import (
    ABC,
    abstractmethod
)
from typing import (
    Dict,
    Tuple,
    Any
)


class AbstractMessageFactory(ABC):
    """
    Abstract Message Factory
    ========================

    Abstract class which defines the required methods for any message factory.
    """
    def __init__(self):
        """Message constructor."""
        pass

    @abstractmethod
    def _update_header(self, message: Dict) -> Dict:
        """Adds automatically generated attributes to the message header."""
        pass

    @abstractmethod
    def _validate(self,
                  message: Dict,
                  schema: Any) -> Tuple:
        """Validates the message with the registered validator."""
        pass

    @abstractmethod
    def _register(self) -> None:
        """Registers schemas and validator to the message factory."""
        pass

    @abstractmethod
    def basemessage(self, header: Dict, payload: Dict = None) -> Dict:
        """Creates a message"""
        pass

    # @abstractmethod
    # def eventmessage(self, header: Dict, payload: Dict = None) -> Dict:
    #     """Getter for the message dictionary."""
    #     pass
    #
    # @abstractmethod
    # def commandmessage(self, header: Dict, payload: Dict = None) -> Dict:
    #     """Getter for the message dictionary."""
    #     pass
    #
    # @abstractmethod
    # def serviceresponsemessage(self, header: Dict, payload: Dict = None) -> Dict:
    #     """Getter for the message dictionary."""
    #     pass
    #
    # @abstractmethod
    # def ackmessage(self, header: Dict, payload: Dict = None) -> Dict:
    #     """Getter for the message dictionary."""
    #     pass
