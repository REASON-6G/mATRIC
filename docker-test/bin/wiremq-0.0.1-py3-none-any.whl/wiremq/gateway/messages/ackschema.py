# -*- coding: utf-8 -*-
from typing import Dict
from wiremq.gateway.messages import basemessageschema


class AckSchema(basemessageschema.BaseMessageSchema):
    """
    Acknowledgement Schema
    ======================

    Message schema for an acknowledgement.

    An acknowledgement should contain the attributes from the base message. It
    should also contain no payload.

    """
    def __init__(self, config: Dict = None) -> None:
        self._config = None
        self._included_keys = None
        self._excluded_keys = None
        self._header_schema = None
        self._payload_schema = None
        super().__init__(config)

    def _build_header_schema(self) -> None:
        """Overrides the default _build_header_schema to enforce the command
        type in the headers.
        """
        super()._build_header_schema()
        self._header_schema.update({
            "type": {
                "type": str,
                "one_of": "ack"
            }
        })
