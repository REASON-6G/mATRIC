# -*- coding: utf-8 -*-
from typing import (
    Any,
    Dict,
    Tuple,
    Union
)
import uuid
import operator
import re
from wiremq.gateway.messages import (
    basemessageschema,
    eventmessageschema,
    commandmessageschema,
    serviceresponseschema,
    ackschema,
    sequenceschema
)


class BaseValidator:
    """
    Base Validator
    ==============

    The Base Validator is used to validate messages according to a
    provided schema.

    Messages are validated in two parts:

    1. First, the message is checked to ensure all the keys specified in
       the schema are present in the message
    2. Secondly, the values for each of the attributes are checked for
      a. type (i.e. str, int, float etc)
      b. format (comparison against regex)
      c. criteria (e.g. greater than or equal to 0)
      d. one_of (check if value is one of a list of known items)

    Typically, a validator is pre-loaded into the message factory, but it can
    be used independently.

    Examples
    --------
    .. code-block:: python
        :linenos:
        :caption: validator_example.py

        from wiremq.gateway.messages import (
            basevalidator,
            eventmessageschema
        )

        schema_config = {
            "name": "Test schema",
            "alias": "test_schema",
            "type": "eventschema",
            "excluded_header_keys": [],
            "header_schema": {
                "sender_port": {
                    "type": int,
                    "criteria": [("gt", 4000), ("lt", 9000)]
                }
            },
            "is_sequence": False
        }

        message = {
                "type": "event",
                "sender_ip": "127.0.0.1",
                "sender_port": 5000,
                "sender_alias": "my_endpoint",
                "dest_ip": "127.0.0.1",
                "dest_port": 4001,
                "protocol_version": "0.0.1",
                "payload": {
                    "topic": "cpu",
                    "data": {
                        "percent": 40.0
                    }
                }
            }

        ms = eventmessageschema.EventMessageSchema(schema_config)
        validator = basevalidator.BaseValidator()
        print(validator.validate(message, ms))


    .. code-block:: console

        $ python validator_example.py $ (False, 'Header validation failed:
        missing attributes: missing headers: message_id, timestamp,
        datetime, nonce')

    .. rubric:: Methods

    """

    operator_map = {
        "lt": operator.lt,
        "gt": operator.gt,
        "eq": operator.eq,
        "ne": operator.ne,
        "ge": operator.ge,
        "le": operator.le
    }
    regex_map = {
        "ip": r"^(?:(?:25[0-5]|2[0-4]\d|1?\d{1,2})(?:\.(?!$)|$)){4}$",
        "datetime": r"^([0-9]{4})-([0-1][0-9])-([0-3][0-9])\s([0-1][0-9]|[2]"
                    r"[0-3]):([0-5][0-9]):([0-5][0-9])?(.[0-9]+)$",
        "hex": r"(^(?:[0-9a-fA-F]{1})*([0-9a-fA-F]{0})+$)",
        "urlsafe": r"^[\-\_a-zA-Z0-9]+$",
        "uuid": r"^[a-fA-F\d]{8}(?:\-[a-fA-F\d]{4}){3}\-[a-fA-F\d]{12}$"
    }

    def __init__(self) -> None:
        self._id = self._generate_id()
        self._log = None

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def _check_keys(self, message: Dict, schema: Dict) -> Tuple:
        """Ensures all the keys specified in the schema are present in the
        message header/payload.

        Parameters
        ----------
        message: Dict
            Message to be validated
        schema: Dict
            The header or payload schema to validate against.

        Returns
        -------
        result, prompt: (bool, str)
            True if validation successful, False otherwise. Validation prompt.
        """
        missing_headers = []
        result = True
        for key in schema:
            if key not in message:
                result = False
                missing_headers.append(key)

        if result:
            prompt = "header valid"
        else:
            prompt = f"missing headers: {', '.join(missing_headers)}"

        return result, prompt

    def _check_type(self, key: str, value: Any, attr_schema: Dict) -> Tuple:
        """Ensures all the attributes with type requirements are satisfied.

        Parameters
        ----------
        key: str
            Key of the attribute to check.
        value: Any
            Value of the attribute to check
        attr_schema: Dict
            Schema for the attribute to be checked.

        Returns
        -------
        result, prompt: (bool, str)
            True if validation successful, False otherwise. Validation prompt.

        """
        if "type" not in attr_schema:
            return True, ""

        if type(value) != attr_schema["type"]:
            return False, f"invalid type for {key}: {value} ({type(value)}, " \
                          f"expected {attr_schema['type']}"
        return True, "type valid"

    def _check_format(self, key: str, value: Any, attr_schema: Dict) -> Tuple:
        """Checks the format of the attribute matches the schema.

        Parameters
        ----------
        key: str
            Key of the attribute to check.
        value: Any
            Value of the attribute to check
        attr_schema: Dict
            Schema for the attribute to be checked.

        Returns
        -------
        result, prompt: (bool, str)
            True if validation successful, False otherwise. Validation prompt.

        """
        if "format" not in attr_schema:
            return True, ""

        regex_rule = self.regex_map[attr_schema["format"]]
        match = re.search(regex_rule, value)
        if not match:
            return False, f"invalid format in {key}: {value}"
        return True, "format valid"

    def _check_criteria(self,
                        key: str,
                        value: Any,
                        attr_schema: Dict) -> Tuple:
        """Checks arithmetic criteria (e.g. 1.0 ge 2.0?).

        First checks if the value is numeric, otherwise operator comparison
        throws an exception.

        Parameters
        ----------
        key: str
            Key of the attribute to check.
        value: Any
            Value of the attribute to check
        attr_schema: Dict
            Schema for the attribute to be checked.

        Returns
        -------
        result, prompt: (bool, str)
            True if validation successful, False otherwise. Validation prompt.

        """
        failed_criteria = []
        if "criteria" not in attr_schema:
            return True, ""

        if type(value) != int and type(value) != float:
            failed_criteria.append(
                f"criteria for {key} cannot be compared "
                f"because {value} ({type(value)}) is not numeric")
        else:
            for criterion in attr_schema["criteria"]:
                operator = self.operator_map[criterion[0]]
                result = operator(value, criterion[1])
                if not result:
                    failed_criteria.append(f"criteria check failed for {key}: "
                                           f"{value} (expecting {criterion[0]}"
                                           f" {criterion[1]})")
        if failed_criteria:
            return False, f"failed criteria: {', '.join(failed_criteria)}"
        else:
            return True, "criteria met"

    def _check_oneof(self, key: str, value: Any, attr_schema: Dict) -> Tuple:
        """Checks if the attribute is part of a list of accepted terms.

        Parameters
        ----------
        key: str
            Key of the attribute to check.
        value: Any
            Value of the attribute to check
        attr_schema: Dict
            Schema for the attribute to be checked.

        Returns
        -------
        result, prompt: (bool, str)
            True if validation successful, False otherwise. Validation prompt.

        """
        failed_oneof = []
        if "one_of" not in attr_schema:
            return True, ""

        one_of = attr_schema["one_of"]
        if value not in one_of:
            failed_oneof.append(f"one of check failed for {key}: {value} "
                                f"(expecting {', '.join(one_of)})")

        if failed_oneof:
            return False, f"failed one of check: {', '.join(failed_oneof)}"
        else:
            return True, "one of met"

    def _check_values(self, message: Dict, schema: Dict) -> Tuple:
        """Checks all values against the schema.

        Checks each for type, format, criteria and one_of.

        Parameters
        ----------
        message: Dict
            The message to be validated
        schema: Dict
            The header or payload schema to validate against.

        Returns
        -------
        result, prompt: (bool, str)
            True if validation successful, False otherwise. Validation prompt.
        """
        invalid_attributes = []
        result = True
        for key, attr_schema in schema.items():
            is_valid_type, type_prompt = \
                self._check_type(key, message[key], attr_schema)
            is_valid_format, format_prompt = \
                self._check_format(key, message[key], attr_schema)
            is_valid_criteria, criteria_prompt = \
                self._check_criteria(key, message[key], attr_schema)
            is_valid_oneof, oneof_prompt = \
                self._check_oneof(key, message[key], attr_schema)
            if not is_valid_type:
                result = False
                invalid_attributes.append(type_prompt)
            if not is_valid_format:
                result = False
                invalid_attributes.append(format_prompt)
            if not is_valid_criteria:
                result = False
                invalid_attributes.append(criteria_prompt)
            if not is_valid_oneof:
                result = False
                invalid_attributes.append(oneof_prompt)

        if result:
            return result, "values valid"
        else:
            return result, f"values invalid: {invalid_attributes}"

    def _validate_header(self,
                         message: Dict,
                         schema: Union[
                             basemessageschema.BaseMessageSchema,
                             eventmessageschema.EventMessageSchema,
                             commandmessageschema.CommandMessageSchema,
                             serviceresponseschema.ServiceResponseSchema,
                             ackschema.AckSchema]) -> Tuple:
        """Main control method to validate the header.

        First checks if all required header attributes are present.

        If one or more header keys are missing, this method returns False.

        Next, checks the header values against the schema for each header.

        All invalid attributes are stored into a list and prompts are included
        in the return.

        If all attributes are valid then True is returned.

        Parameters
        ----------
        message: Dict
            The message to be validated.
        schema: BaseSchema (or child classes)
            The schema to be validated against
        sequence_schema: SequenceSchema (optional)
            If provided, the header is also validated against the sequence
            schema.


        Returns
        -------
        result, prompt: (bool, str)
            True if validation successful, False otherwise. Validation prompt.

        """
        header_schema = schema.get_header_schema()
        valid_header_keys, valid_header_keys_prompt = \
            self._check_keys(message, header_schema)
        if not valid_header_keys:
            return False, f"missing attributes: {valid_header_keys_prompt}"

        valid_header_values, valid_header_values_prompt = \
            self._check_values(message, header_schema)

        if not valid_header_values:
            return False, f"invalid attributes: {valid_header_values_prompt}"

        return True, ""

    def _validate_payload(self,
                          message: Dict,
                          schema: basemessageschema.BaseMessageSchema
                          ) -> Tuple:
        """Main control method to validate the payload.

        First checks if all required payload attributes are present.

        If one or more payload keys are missing, this method returns False.

        Next, checks the payload values against the schema for each payload
        attribute.

        All invalid attributes are stored into a list and prompts are included
        in the return.

        If all attributes are valid then True is returned.

        For acknowledgement messages, if a payload is present then the message
        is marked as invalid.

        Parameters
        ----------
        message: Dict
            The message to be validated.
        schema: BaseMessageSchema (or child classes)
            Schema to validate the message against.

        Returns
        -------
        result, prompt: (bool, str)
            True if validation successful, False otherwise. Validation prompt.

        """
        payload = message.get("payload")
        payload_schema = schema.get_payload_schema()
        if message.get("type") == "ack":
            if payload:
                return False, "acknowledgement messages should have no payload"
            else:
                return True, ""
        if payload:
            valid_payload_keys, valid_payload_keys_prompt = \
                self._check_keys(payload, payload_schema)
            if not valid_payload_keys:
                return False, f"missing attributes: " \
                              f"{valid_payload_keys_prompt}"

            valid_payload_values, valid_payload_values_prompt = \
                self._check_values(payload, payload_schema)

            if not valid_payload_values:
                return False, f"invalid attributes: " \
                              f"{valid_payload_values_prompt}"

        return True, "valid payload"

    def _validate_sequence(self,
                           message: Dict,
                           sequence_schema: sequenceschema.SequenceSchema
                           ) -> Tuple:
        """If a message is part of a sequence, the sequence attributes are
        validated here.

        Checks the necessary headers are present, and checks the position

        Parameters
        ----------
        message: Dict
            The message to be validated.
        sequence_schema: SequenceSchema
            The sequence schema to validate sequence data against.

        Returns
        -------
        result, prompt: (bool, str)
            True if validation successful, False otherwise. Validation prompt.

        """
        sequence_validation = self._validate_header(message, sequence_schema)
        if not sequence_validation[0]:
            return sequence_validation

        if message["position_id"] >= message["sequence_size"]:
            return False, f"Sequence position beyond range, position_id = " \
                          f"{message['position_id']}, sequence_size = " \
                          f"{message['sequence_size']} (zero-based numbering)"
        return True, ""

    def validate(self,
                 message: Dict,
                 schema: Union[basemessageschema.BaseMessageSchema,
                               eventmessageschema.EventMessageSchema,
                               commandmessageschema.CommandMessageSchema,
                               serviceresponseschema.ServiceResponseSchema,
                               ackschema.AckSchema],
                 sequence_schema: sequenceschema.SequenceSchema = None
                 ) -> Tuple:
        """Validates the message header and payload.

        If `sequence_schema` is provided then the message is also validated
        against a message sequence schema. Typically this would contain
        definitions of sequence length, sequence ID, and the position in the
        sequence.

        Parameters
        ----------
        message: Dict
            The message to be validated.
        schema: BaseMessageSchema
            The schema to validate the message against.
        sequence_schema: SequenceSchema
            Schema for messages which are part of a sequence.

        Returns
        -------
        result, prompt: (bool, str)
            True if validation successful, False otherwise. Validation prompt.

        """
        header_validation = self._validate_header(message, schema)
        payload_validation = self._validate_payload(message, schema)
        if not header_validation[0]:
            return False, f"Header validation failed: {header_validation[1]}"
        if not payload_validation[0]:
            return False, f"Payload validation failed: {payload_validation[1]}"
        if sequence_schema:
            sequence_validation = \
                self._validate_sequence(message, sequence_schema)
            if not sequence_validation[0]:
                return False, f"Sequence validation failed: {sequence_validation[1]}"
        return True, "Message valid"
