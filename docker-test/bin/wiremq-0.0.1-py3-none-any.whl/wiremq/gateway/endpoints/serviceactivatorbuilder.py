# -*- coding: utf-8 -*-

from typing import (
    Dict,
    Any
)
from wiremq.endpoints import serviceactivator as sa
from wiremq.wmqsockets import (
    inboundsocket,
    outboundsocket
)
from wiremq.processing import (
    baseprocessmanager,
    threadedscheduler,
    basethreadpool
)
from wiremq.processing.methods import pmmethod
from wiremq.handlers import (
    basehandler,
    responsehandler,
    httprequesthandler
)
from wiremq.extlib.queue import fifoqueue
from wiremq.extlib.asynchronous.eventloops import (
    ioeventloopudp,
    ioeventlooptcp
)
from wiremq.extlib.asynchronous.iopollers import iopoll
from wiremq.filters import (
    idempotentfilter,
    resequencer,
    queuedispatcher,
    sockdispatcher
)
from wiremq.dispatchers import transportdispatcher
from wiremq.consumers import baseconsumer
from wiremq.producers import baseproducer
from wiremq.translators import (
    httpparser,
    httpformatter,
    bsoncontentdecoder,
    bsoncontentencoder,
    envelopewrapper,
    validator
)
from wiremq.message import messagefactory


class ServiceActivatorBuilder():
    """
    Service Activator Builder
    =========================

    Builder class for creating a Service Activator.


    Methods
    -------
    _reset(): None
        Reset the config and create a fresh endpoint instance.
    endpoint: object
        Returns configured endpoint object.
    make_consumer(): None
        Create a consumer for the endpoint.
    make_producer(): None
        Create a producer for the endpoint.
    make_queue() None
        Create a queue for the endpoint.
    make_eventloop(): None
        Create an eventloop for the endpoint.
    make_poller(): None
        Create a poller for the endpoint.
    make_scheduler(): None
        Create a scheduler for the endpoint.
    make_threadpool(): Any
        Create a threadpool for the endpoint.
    make_socket(): None
        Create a socket.
    make_requesthandler(): None
        Create a request handler for the endpoint.
    config(): None
        Configure attributes of the service activator.
    register(): None
        Register the components to the service activator.

    Attributes
    ----------
    _config : dict, optional
        This holds the endpoint's configurations.
    """

    def __init__(self) -> None:
        """Service Activator Builder constructor.

        Example
        -------
        See integration test director for service activator's config, which
        contains an example of the fields and values required.

        >>> sa_builder = serviceactivatorbuilder.ServiceActivatorBuilder
        >>> sa_builder.config(attributes)
        >>> sa_builder.register(components)
        >>> service_activator = sa_builder.product
        """
        super().__init__()
        self._terminator = b"\r\r\r\r"
        self._handler_map = {
            "request": basehandler.BaseHandler,
            "response": responsehandler.ResponseHandler
        }
        self._processor_module_map = {
            "SD": sockdispatcher.SockDispatcher,
            "BD": bsoncontentdecoder.BSONContentDecoder,
            "BE": bsoncontentencoder.BSONContentEncoder,
            "VA": validator.Validator,
            "EW": envelopewrapper.EnvelopeWrapper,
            "IF": idempotentfilter.IdempotentFilter,
            "RQ": resequencer.Resequencer,
            "QD": queuedispatcher.QueueDispatcher,
            "HP": httpparser.HTTPParser,
            "HF": httpformatter.HTTPFormatter
        }
        self._task_map = {
            "PM": {
                "worker": baseprocessmanager.BaseProcessManager,
                "method": pmmethod.execute,
            }
        }
        self._reset()

    def __str__(self):
        return 'ServiceActivator-Builder Object'

    def _reset(self) -> None:
        """Reset the builder's endpoint.

        This internal call refreshes the builder's current configured endpoint
        and creates a fresh instance of the class. The builder can then accept
        new building requests.
        """
        self._service_activator = sa.ServiceActivator()

    @property
    def product(self) -> sa.ServiceActivator:
        """This is the result of the building.

        Note
        ----
        Provided is the interface for retrieving the final product.
        After the retrieval of a configured endpoint, the builder
        should be ready to accept new building requests. To account for
        this design, a call to the `endpoint` property calls the internal
        `_reset()` method.
        """
        service_activator = self._service_activator
        self._reset()
        return service_activator

    def make_consumer(self, consumer_opt: Dict) -> None:
        """Create a consumer for the endpoint.

        Parameters
        ----------
        consumer_opt : Dict, required
            The initial consumer configuration.
        """
        _task_queue = self.make_queue(consumer_opt["task_queue_config"])
        consumer_opt["ioloop_config"]["task_queue"] = _task_queue
        consumer_opt["scheduler_config"]["task_queue"] = _task_queue
        _scheduler = self.make_scheduler(consumer_opt["scheduler_config"])
        _eventloop = self.make_eventloop(consumer_opt["ioloop_config"])
        consumer_opt["eventloop"] = _eventloop
        consumer_opt["task_queue"] = _task_queue
        consumer_opt["scheduler"] = _scheduler
        _consumer = baseconsumer.BaseConsumer(consumer_opt)
        return _consumer

    def make_producer(self, producer_opt: Dict) -> None:
        """Create a producer for the endpoint.

        Parameters
        ----------
        producer_opt : Dict, required
            The initial producer configuration.
        """
        _task_queue = self.make_queue(producer_opt["task_queue_config"])
        producer_opt["ioloop_config"]["task_queue"] = _task_queue
        producer_opt["scheduler_config"]["task_queue"] = _task_queue
        _eventloop = self.make_eventloop(producer_opt["ioloop_config"])
        _scheduler = self.make_scheduler(producer_opt["scheduler_config"])
        producer_opt["eventloop"] = _eventloop
        producer_opt["task_queue"] = _task_queue
        producer_opt["scheduler"] = _scheduler
        messagefactory_opt = producer_opt["message_factory_config"]
        _messagefactory = messagefactory.MessageFactory(messagefactory_opt)
        producer_opt["message_factory"] = _messagefactory
        _producer = baseproducer.BaseProducer(producer_opt)
        return _producer

    def make_queue(self, queue_opt: Dict) -> None:
        """Create a queue for the endpoint.

        Parameters
        ----------
        queue_opt : Dict, required
            The initial queue configuration.
        """
        return fifoqueue.FifoQueue(queue_opt)

    def make_eventloop(self, eventloop_opt: Dict) -> None:
        """Create an eventloop for the endpoint.

        Parameters
        ----------
        eventloop_opt : Dict, required
            The initial eventloop configuration.
        """
        eventloop_opt["socket"] = self.make_socket(
            eventloop_opt["inbound_socket_config"]
        )
        eventloop_opt["poller"] = self.make_poller(
            eventloop_opt["poller_config"]
        )
        if "terminator" in eventloop_opt:
            eventloop_opt["terminator"] = self._terminator
        if eventloop_opt["type"] == "ioeventloopudp":
            _eventloop = ioeventloopudp.IOEventLoopUDP(eventloop_opt)
        elif eventloop_opt["type"] == "ioeventlooptcp":
            _eventloop = ioeventlooptcp.IOEventLoopTCP(eventloop_opt)
        _eventloop.initialize()
        return _eventloop

    def make_poller(self, poller_opt: Dict) -> None:
        """Create a poller for the endpoint.

        Parameters
        ----------
        poller_opt : Dict, required
            The initial poller configuration.
        """
        return iopoll.IOPoll(poller_opt)

    def make_scheduler(self, scheduler_opt: Dict) -> None:
        """Create a scheduler for the endpoint.

        Parameters
        ----------
        scheduler_opt : Dict, required
            The initial scheduler configuration.
        """
        pmmap = scheduler_opt["worker_config"]["processor_map"]
        for proc in pmmap.keys():
            pmmap[proc]["processor"] = self._processor_module_map[proc]
            if proc == "SD" and "terminator" in pmmap[proc]["config"]:
                pmmap[proc]["config"]["terminator"] = self._terminator
        for task in scheduler_opt["worker_map"]:
            scheduler_opt["worker_map"][task] = {
                "worker": self._task_map[scheduler_opt["worker_map"][
                    task]["worker"]]["worker"],
                "config": scheduler_opt["worker_config"],
                "method": self._task_map[scheduler_opt["worker_map"][
                    task]["method"]]["method"],
                "queue_config": scheduler_opt["worker_config"][
                    "processor_queue_config"]
            }
        _threadpool = self.make_threadpool(scheduler_opt["threadpool_config"])
        _scheduler = threadedscheduler.ThreadedScheduler(
            scheduler_opt, _threadpool, scheduler_opt["task_queue"]
        )
        return _scheduler

    def make_threadpool(self, threadpool_opt: Dict) -> Any:
        """Create a threadpool for the endpoint.

        Parameters
        ----------
        threadpool_opt : Dict, required
            The initial threadpool configuration.
        """
        return basethreadpool.BaseThreadPool(threadpool_opt)

    def make_socket(self, socket_config: Dict) -> None:
        """Create a socket.

        Parameters
        ----------
        socket_config: Dict
            Socket configuration
        """
        if socket_config["type"] == "inboundsocket":
            _socket = inboundsocket.InboundSocket(socket_config)
        elif socket_config["type"] == "outboundsocket":
            _socket = outboundsocket.OutboundSocket(socket_config)
        return _socket

    def make_requesthandlers(self, requesthandler_opt: Dict) -> Any:
        """Create request handlers for the endpoint.

        Parameters
        ----------
        request_handler_opt : Dict, required
            The initial request handler configuration.
        """
        response_handler = None
        for val in requesthandler_opt.values():
            if "dispatcher_config" in val and "outsocket_config" in val[
               "dispatcher_config"]:
                sock = self.make_socket(
                    val["dispatcher_config"]["outsocket_config"]
                )
                val["dispatcher_config"]["terminator"] = self._terminator
                _td = transportdispatcher.TransportDispatcher(
                    val["dispatcher_config"]
                )
                _td.add(sock)
                val["dispatcher"] = _td
                val["outsocket_fd"] = sock.get_fd()
            if val["path"] == "request":
                request_handler = self._handler_map[val["path"]](val)
                continue
            if val["path"] == "response":
                response_handler = self._handler_map[val["path"]](val)
                continue
        return request_handler, response_handler

    def make_httprequestserver(self, httprequesthandler_opt: Dict) -> Any:
        """Create a httprequesthandler for the endpoint.

        Parameters
        ----------
        httprequesthandler_opt : Dict, required
            The initial httprequesthandler configuration.
        """
        _server = httprequesthandler.HTTPRequestHandler(httprequesthandler_opt)
        return _server

    def config(self, attributes: Dict = None) -> None:
        """Configure attributes for the service activator.

        Parameters
        ---------
        attributes : dict, required
            The attributes for the endpoint.
            services: Dict
                A mapping of path to handler
        """
        self._service_activator.config(attributes)

    def register(self, components: Dict = None) -> None:
        """Register the components to the service activator.

        Parameters
        ----------
        copmponents : dict, required
            The components to be added.
            task_queue: Queue, required
            response_handler: Handler, required
            eventloop: eventloop, required
            send_queue: Queue, required
            consumers: list, required
            producers: list, required
        """
        self._service_activator.register(components)
