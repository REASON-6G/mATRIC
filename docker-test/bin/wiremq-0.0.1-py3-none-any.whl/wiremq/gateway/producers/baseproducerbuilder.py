# -*- coding: utf-8 -*-

from typing import (
    Dict,
    Any
)
from wiremq.utils.configtools import (
    initialize_unix_destinations,
    initialize_unix_sockets,
    initialize_terminator
)
from wiremq.wmqsockets import (
    inboundsocket,
    outboundsocket,
    broadcastsocket
)
from wiremq.processing import (
    baseprocessmanager,
    threadedscheduler,
    basethreadpool
)
from wiremq.processing.methods import pmmethod
from wiremq.extlib.queue import fifoqueue
from wiremq.extlib.asynchronous.eventloops import (
    ioeventloopudp,
    ioeventlooptcp
)
from wiremq.extlib.asynchronous.iopollers import iopoll
from wiremq.filters import sockdispatcher
from wiremq.producers import baseproducer
from wiremq.translators import (
    httpparser,
    httpformatter,
    bsoncontentdecoder,
    bsoncontentencoder,
)


class BaseProducerBuilder:
    """
    Base Producer Builder
    =====================

    Builds a producer.


    Methods
    -------
    _reset(): None
        Reset the config and create a fresh producer instance.
    producer: object
        Returns configured producer object.
    make_producer(): None
        Create a producer's components and registers them.
    make_queue() None
        Create a queue.
    make_eventloop(): None
        Create an eventloop.
    make_poller(): None
        Create a poller.
    make_scheduler(): None
        Create a scheduler.
    make_threadpool(): Any
        Create a threadpool.
    make_socket(): None
        Create a socket.
    register(): None
        Register the components to the producer.
    """

    def __init__(self) -> None:
        """Producer Builder constructor.

        Example
        -------
        See integration test director for producer's config, which
        contains an example of the fields and values required.

        >>> p_builder = baseproducerbuilder.BaseProducerBuilder()
        >>> p_builder.make_producer(producer_config)
        >>> producer = p_builder.producer
        """
        super().__init__()
        self._terminator = b"\r\r\r\r"
        self._processor_module_map = {
            "SD": sockdispatcher.SockDispatcher,
            "HF": httpformatter.HTTPFormatter,
            "HP": httpparser.HTTPParser,
            "CD": bsoncontentdecoder.BSONContentDecoder,
            "CE": bsoncontentencoder.BSONContentEncoder
        }
        self._task_map = {
            "PM": {
                "worker": baseprocessmanager.BaseProcessManager,
                "method": pmmethod.execute,
            }
        }
        self._reset()

    def __str__(self):
        return 'Producer-Builder Object'

    def _reset(self) -> None:
        """Reset the builder's component.

        This internal call refreshes the builder's current configured producer
        and creates a fresh instance of the class. The builder can then accept
        new building requests.
        """
        self._producer = baseproducer.BaseProducer()

    @property
    def producer(self) -> baseproducer.BaseProducer:
        """This is the result of the building.

        Note
        ----
        Provided is the interface for retrieving the final product.
        After the retrieval of a configured producer, the builder
        should be ready to accept new building requests. To account for
        this design, a call to the `producer` property calls the internal
        `_reset()` method.
        """
        producer = self._producer
        self._reset()
        return producer

    def make_producer(self, producer_opt: Dict) -> None:
        """Create a producer's components and register them.

        Parameters
        ----------
        producer_opt : Dict, required
            The initial producer configuration.
        """
        _producer_domain = producer_opt.get("internal_domain")
        producer_opt = initialize_terminator(producer_opt)
        producer_opt = initialize_unix_sockets(producer_opt, _producer_domain)
        producer_opt = \
            initialize_unix_destinations(producer_opt, _producer_domain)
        _task_queue = self.make_queue(producer_opt["task_queue_config"])
        producer_opt["ioloop_config"]["task_queue"] = _task_queue
        producer_opt["scheduler_config"]["task_queue"] = _task_queue
        _eventloop = self.make_eventloop(producer_opt["ioloop_config"])
        _scheduler = self.make_scheduler(producer_opt["scheduler_config"])
        producer_opt["eventloop"] = _eventloop
        producer_opt["task_queue"] = _task_queue
        producer_opt["scheduler"] = _scheduler
        self.register(producer_opt)

    def make_queue(self, queue_opt: Dict) -> Any:
        """Create a queue.

        Parameters
        ----------
        queue_opt : Dict, required
            The initial queue configuration.

        Returns
        -------
        rtn: obj
            FIFO queue object
        """
        return fifoqueue.FifoQueue(queue_opt)

    def make_eventloop(self, eventloop_opt: Dict) -> Any:
        """Create an eventloop.

        Parameters
        ----------
        eventloop_opt : Dict, required
            The initial eventloop configuration.

        Returns
        -------
        rtn: obj
            Event loop
        """
        eventloop_opt["socket"] = self.make_socket(
            eventloop_opt["inbound_socket_config"]
        )
        eventloop_opt["poller"] = self.make_poller(
            eventloop_opt["poller_config"]
        )
        if "terminator" in eventloop_opt and not eventloop_opt["terminator"]:
            eventloop_opt["terminator"] = self._terminator
        if eventloop_opt["type"] == "ioeventloopudp":
            _eventloop = ioeventloopudp.IOEventLoopUDP(eventloop_opt)
        elif eventloop_opt["type"] == "ioeventlooptcp":
            _eventloop = ioeventlooptcp.IOEventLoopTCP(eventloop_opt)
        _eventloop.initialize()
        return _eventloop

    def make_poller(self, poller_opt: Dict) -> Any:
        """Create a poller.

        Parameters
        ----------
        poller_opt : Dict, required
            The initial poller configuration.

        Returns
        -------
        rtn: obj
            Poller object
        """
        return iopoll.IOPoll(poller_opt)

    def make_scheduler(self, scheduler_opt: Dict) -> Any:
        """Create a scheduler.

        Parameters
        ----------
        scheduler_opt : Dict, required
            The initial scheduler configuration.

        Returns
        -------
        rtn: obj
            Scheduler object
        """
        pmmap = scheduler_opt["worker_config"]["processor_map"]
        for proc in pmmap.keys():
            pmmap[proc]["processor"] = self._processor_module_map[proc]
            if proc == "SD" and "terminator" in pmmap[proc]["config"]:
                pmmap[proc]["config"]["terminator"] = self._terminator
        for task in scheduler_opt["worker_map"]:
            scheduler_opt["worker_map"][task] = {
                "worker": self._task_map[scheduler_opt["worker_map"][
                    task]["worker"]]["worker"],
                "config": scheduler_opt["worker_config"],
                "method": self._task_map[scheduler_opt["worker_map"][
                    task]["method"]]["method"],
                "queue_config": scheduler_opt["worker_config"][
                    "processor_queue_config"]
            }
        _threadpool = self.make_threadpool(scheduler_opt["threadpool_config"])
        _scheduler = threadedscheduler.ThreadedScheduler(
            scheduler_opt, _threadpool, scheduler_opt["task_queue"]
        )
        return _scheduler

    def make_threadpool(self, threadpool_opt: Dict) -> Any:
        """Create a threadpool.

        Parameters
        ----------
        threadpool_opt : Dict, required
            The initial threadpool configuration.

        Returns
        -------
        rtn: obj
            Base threadpool object
        """
        return basethreadpool.BaseThreadPool(threadpool_opt)

    def make_socket(self, socket_config: Dict) -> Any:
        """Create a socket.

        Parameters
        ----------
        socket_config: Dict
            Socket configuration

        Returns
        -------
        rtn: obj
            Socket object (inbound, outbound or broadcast)
        """
        if socket_config["type"] == "inboundsocket":
            _socket = inboundsocket.InboundSocket(socket_config)
        elif socket_config["type"] == "outboundsocket":
            _socket = outboundsocket.OutboundSocket(socket_config)
        elif socket_config["type"] == "broadcastsocket":
            _socket = broadcastsocket.BroadcastSocket(socket_config)
        return _socket

    def register(self, components: Dict = None) -> None:
        """Register the components to the producer.

        Parameters
        ----------
        components : dict, required
        """
        self._producer.register(components)
