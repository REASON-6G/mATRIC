from wiremq.extlib.err import wmqexception


class BaseProducerException(wmqexception.WmqException):
    """
    Base Producer Exception
    =======================

    Exception raised when a base producer throws an error.
    """

    def __init__(self, message: str):
        message = "[BaseProducerException] " + str(message)
        super().__init__(message)
