from wiremq.extlib.err import wmqexception


class BaseConsumerException(wmqexception.WmqException):
    """
    Base Consumer Exception
    =======================

    Exception raised when a base consumer encounters an error."""

    def __init__(self, message: str):
        message = "[BaseConsumerException] " + str(message)
        super().__init__(message)
