from typing import Any


class WmqException(Exception):
    """
    WireMQ Exception
    ================

    Generic exception for WireMQ components, to be inherited by all WireMQ
    exception classes.
    """
    def __init__(self, message: Any):
        """WmqException initialization.

        Takes a message and sends it to the logger for handling.

        Parameters
        ----------
        message: str
            Exception message.
        """
        self._message = message
        super().__init__(self._message)

    def __str__(self):
        return self._message
