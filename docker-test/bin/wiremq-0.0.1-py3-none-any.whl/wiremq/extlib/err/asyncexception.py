from wiremq.extlib.err import wmqexception


class IOLoopUnregisterFDException(wmqexception.WmqException):
    """
    IO Loop Unregister File Descriptor Exception
    ============================================

    Exception raised when unregistering a file descriptor from the poller
    that does not exist.
    """

    def __init__(self, message: str):
        message = "[IOLoopUnregisterFDException] " + str(message)
        super().__init__(message)


class IOEventLoopException(wmqexception.WmqException):
    """
    IO Event Loop Exception
    =======================

    Exception raised when binding a socket to the io loop.
    """

    def __init__(self, message: str):
        message = "[IOEventLoopException] " + str(message)
        super().__init__(message)


class IOEventLoopInitException(wmqexception.WmqException):
    """
    IO Event Loop Initialization Exception
    ======================================

    Exception raised when io loop fails to initialize.
    """

    def __init__(self, message: str):
        message = "[IOEventLoopInitException] " + str(message)
        super().__init__(message)


class IOEventLoopRunException(wmqexception.WmqException):
    """
    IO Event Loop Run Exception
    ===========================

    Exception raised when io loop fails to run.
    """

    def __init__(self, message: str):
        message = "[IOEventLoopRunException] " + str(message)
        super().__init__(message)
