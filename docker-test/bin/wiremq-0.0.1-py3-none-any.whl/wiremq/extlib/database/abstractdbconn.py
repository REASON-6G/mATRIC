# -*- coding: utf-8 -*-
"""Base class for Queue database connectivity """

from abc import (
    ABC,
    abstractmethod
)


class AbstractDBConn(ABC):
    """
    Abstract DB Connection
    ======================

    Abstract class which defines the required methods for any DB connection.
    """

    def __init__(self):
        super(AbstractDBConn, self).__init__()
        self._database = None
        self._connection = None  # represents the database
        self._cursor = None

    @abstractmethod
    def select(self, kwargs: dict) -> None:
        """Read one or more entries from table."""
        pass

    @abstractmethod
    def insert(self, kwargs: dict) -> None:
        """Insert into table"""
        pass

    @abstractmethod
    def update(self, kwargs: dict) -> None:
        """Update table entry"""
        pass

    @abstractmethod
    def delete(self, kwargs: dict) -> None:
        """Remove an entry from the database"""
        pass
