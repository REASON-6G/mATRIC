# -*- coding: utf-8 -*-
"""Database (plugin) connector for Maria DB."""

from typing import (
    Any,
    Dict
)
import mariadb
from wiremq.extlib.database import basedbconn
from wiremq.extlib.err.databaseexception import (
    DBOperationalException,
    DBProgrammingException,
    DBInsertException,
    DBSelectException,
    DBUpdateException,
    DBDeleteException
)


class MariaDBConn(basedbconn.BaseDBConn):
    """
    MariaDB Connection
    ==================

    Connection object used for interfacing with MariaDB. This should be loaded
    into the config of a MessageStore.

    Attributes
    ----------
    _connection: object
        Database connection object.
    _cursor: object
        Database cursor to execute queries.
    _config: dict
        Database configuration dictionary.
    _log: object
        Python logging instance.

    Methods
    -------
    config_database(): None
        Configures database connection object.
    get_database_config(): Dic
        Returns the configuration of the database connection.
    connect(): Any
        Creates a connection to the database.
    query(): None
        Executes an SQL Query.
    select(): list
        Select implements the SELECT statement from the database.
    insert(): None
        Insert implements INSERT statement.
    update(): int
        Update implements UPDATE statement.
    delete(): None
        Delete implements DELETE to remove data from a database table.
    create_db(): bool
        Create a new database.
    create_table(): None
        Create a new database table.
    delete_table(): bool
        Deletes specified table from a database.
    _commit_query(): None
        Commit the database query.
    _add_attributes(): str
        Helper method for query attributes.
    _add_where(): Any
        Helper method for query where filter clause.
    _add_set(): str
        Helper method for set method.
    close(): None
        Closes a database connection.

    Raises
    ------
    DBOperationalException:
        Exception raised an operational error occurs in database interactions.
    DBProgrammingException:
        Exception raised when a programming error occurs when interacting with
        a database.
    DBInsertException:
        Exception raised when executing an INSERT query.
    DBSelectException:
        Exception raised when executing a SELECT query.
    DBUpdateException:
        Exception raised when executing an UPDATE query.
    DBDeleteException:
        Exception raised when executing a DELETE query.

    """

    def __init__(self, config: Dict = None) -> None:
        """Maria database connection constructor.

        Initializes a MariaDB connection with the SQL lite database.

        Parameters
        ----------
        config: Dict
            type: str
                Database connection type.
            credentials: Dict
                user: str
                    User name, user must exists in the database.
                password: str
                    Password of user.
                port: int
                    Port number.
                host: str
                    Host ip.
                database: str
                    Database name

        Example
        -------
        >>> config = {}
        >>> config[type] = "MariaDB",
        >>> config[credentials] = {}
        >>> config[credentials][user] = "weaverusr"
        >>> config[credentials][pasword] = "weaverpass"
        >>> config[credentials][port] = 3306
        >>> config[credentials][host] = "localhost"
        >>> config[credentials][database] = "user": "weaverdb"
        >>> mariadb = mariadbconn.MariaDBConn(config)
        """
        super().__init__(config)
        if config:
            self.config(config)

    def __enter__(self) -> object:
        """Magic method. Make the Maria DB connection and return it."""
        self._log.args("%s: ()" % self)
        self._connection = self.connect()
        self._cursor = self._connection.cursor()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Magic method. Close the database connection."""
        self._log.args("%s: (exc_type: %s, exc_val: %s, exc_tb: %s)"
                       % (self, exc_type, exc_val, exc_tb))
        try:
            self._cursor.close()
            if isinstance(exc_val, Exception):
                self._connection.rollback()
            else:
                self._connection.commit()
            self._connection.close()
        except Exception as e:
            self._log.critical("%s: failure | message: %s" % (self, str(e)))

    def config(self, config: Dict) -> None:
        """Configures database connection object.

        Parameters
        ----------
        config: Dict
            type: str
                Database connection type.
            credentials: Dict
                user: str
                    User name, user must exists in the database.
                password: str
                    Password of user.
                port: int
                    Port number.
                host: str
                    Host ip.
                database: str
                    Database name
        """
        super().config(config)
        self._log.args("%s: (config: %s)" % (self, config))
        self._connection = self.connect()
        self._cursor = self._connection.cursor()

    def get_database_config(self) -> Dict:
        """Returns the configuration of the database connection

        Returns
        -------
        config: Dict
            type: str
                Database connection type.
            credentials: Dict
                user: str
                    User name, user must exists in the database.
                password: str
                    Password of user.
                port: int
                    Port number.
                host: str
                    Host ip.
                database: str
                    Database name
        """
        self._log.args("%s: ()" % self)
        config = self._config
        self._log.rtn("%s: success | data: %s" % (self, config))
        return self._config

    def connect(self) -> Any:
        """Creates a connection to the database. Raises DBOperationalException
        for operational errors (such as credential or connection issues), also
        raises DBProgrammingException for syntax errors in queries for example.

        Returns
        -------
        dbconn: Any
            Database connection object.

        Raises
        ------
        DBOperationalException:
            Exception raised an operational error occurs in database
            interactions.
        DBProgrammingException:
            Exception raised when a programming error occurs when interacting
            with a database.
        """
        self._log.args("%s: ()" % self)
        _cred = self._config['credentials']
        try:
            return mariadb.connect(user=_cred["user"],
                                   password=_cred["password"],
                                   host=_cred["host"],
                                   port=_cred["port"],
                                   database=_cred["database"])
        except mariadb.OperationalError as e:
            raise DBOperationalException(str(e))
        except mariadb.ProgrammingError as e:
            raise DBProgrammingException(str(e))

    def query(self, query: str, values: tuple = None) -> None:
        """Executes an SQL Query.

        Parameters
        ----------
        query: str
            The SQL query to be executed.
        values: tuple
            All the values of the query.

        Returns
        -------
        res: Any
            Database result of each call.
        """
        self._log.args("%s: (query: %s, values: %s)" % (self, query, values))
        self._cursor.execute(query, values)
        self._log.rtn("%s: success" % self)

    def select(self, _table: str, _attrs: list = None,
               _where: str = None, _distinct: bool = False,
               _group_by: list = None, _order_by: list = False,
               _limit: int = None) -> list:
        """Select implements the SELECT statement from the database. Raises
        a DBSelectException if there is an error in completing this operation.

        Parameters
        ----------
        _table: str
            Name of the database table.
        _attrs: list, optional
            The attributes to select.
            If not specified all attrs are selected.
        _where: str, optional
            Where clause of a database query. Restrict the return
            base on column data.
        _distinct: str, optional
            This flag determines whether the results should have repeated
            elements.
        _group_by: list
            Group the result into given column(s)
        _order_by: list
            Order results by column(s).
        _limit: int
            Specify the number of results from the database.

        Returns
        -------
        res: list
            The results from the select query as a list.

        Raises
        ------
        DBSelectException:
            Exception raised when an operational or programming error occurs
            with the dbconn when issuing a SELECT query.
        """
        self._log.args("%s: (_table: %s, _attrs: %s, _where: %s, "
                       "_distinct: %r, _group_by: %s, _order_by: %s, "
                       "_limit: %s)" % (self, _table, _attrs, _where,
                                        _distinct, _group_by, _order_by,
                                        _limit))
        _values = ()
        q = "SELECT "

        if _distinct:
            q += "DISTINCT "

        if _attrs:
            q += self._add_attributes(_attrs)
        else:
            q += " * "

        q += " FROM " + _table

        if _where:
            _values += tuple(_where.values())
            q += self._add_where(_where)

        if _group_by:
            q += " GROUP BY "
            q += self._add_attributes(_group_by)

        if _order_by:
            q += " ORDER BY "
            q += self._add_ordering(_order_by)

        if _limit:
            q += " LIMIT {}".format(_limit)

        q += ";"

        try:
            self.query(q, _values)
        except mariadb.ProgrammingError as e:
            self._log.error(e)
            raise DBSelectException(e)
        except mariadb.OperationalError as e:
            self._log.error(e)
            raise DBSelectException(e)
        res = self._cursor.fetchall()
        self._log.rtn("%s: success | data: %s" % (self, res))
        return res

    def insert(self, _table: str, attr_val_dict: Dict) -> None:
        """Insert implements INSERT statement to insert records to a database
        table. Raises a DBDeleteException if there is an error in completing
        this operation.

        Parameters
        ----------
        _table: str
            The name of the database table.
        attr_val_dict: dict
            column: column name
                Column name as key of dictionary.
            column_value: str
                Data value for each column to be added in database.

        Returns
        -------
        rowcount: int
            Rows affected in the database.

        Raises
        ------
        DBInsertException:
            Exception raised when an operational or programming error occurs
            with the dbconn when issuing an INSERT query.
        """
        self._log.args("%s: (_table: %s, attr_val_dict: %s)"
                       % (self, _table, attr_val_dict))
        _values = tuple(attr_val_dict.values())

        q = "INSERT INTO " + _table
        _columns = self._add_attributes(list(attr_val_dict.keys()))
        q += "(" + _columns + ") "
        q += "VALUES("
        q += ",".join(["?" for x in attr_val_dict.values()])
        q += ")"

        try:
            self.query(q, _values)
        except mariadb.ProgrammingError as e:
            self._log.error(e)
            raise DBInsertException(e)
        except mariadb.OperationalError as e:
            self._log.error(e)
            raise DBInsertException(e)
        self._commit_query()
        rowcount = self._cursor.rowcount
        self._log.rtn("%s: success | data: %d" % (self, rowcount))
        return rowcount

    def update(self, _table: str, _set: Dict, _where: str = None) -> int:
        """Update implements UPDATE statement, to update database records.
        Raises a DBUpdateException if there is an error in completing this
        operation.

        Parameters
        ----------
        _table: str
            The name of the table.
        _where: str, optional
            Where clause of a database query. Restrict the return
            base on column data.
        _set: dict
            column: column name
                Column name as key of dictionary.
            column_value: str
                Data value for each column.

        Returns
        -------
        rowcount: int
            Rows affected in the database.

        Raises
        ------
        DBUpdateException:
            Exception raised when an operational or programming error occurs
            with the dbconn when issuing an UPDATE query.

        """
        self._log.args("%s: (_table: %s, _set: %s, _where: %s)"
                       % (self, _table, _set, _where))
        q = "UPDATE " + _table

        _values = tuple(_set.values())
        q += self._add_set(_set)

        if _where:
            _values += tuple(_where.values())
            q += self._add_where(_where)

        try:
            self.query(q, _values)
        except mariadb.ProgrammingError as e:
            self._log.error(e)
            raise DBUpdateException(e)
        except mariadb.OperationalError as e:
            self._log.error(e)
            raise DBUpdateException(e)
        self._commit_query()
        rowcount = self._cursor.rowcount
        self._log.rtn("%s: success | data: %d" % (self, rowcount))
        return rowcount

    def delete(self, _table: str, _where: Dict = None) -> None:
        """Delete implements DELETE to remove data from a database table.
        Raises a DBDeleteException if there is an error in completing this
        operation.

        Parameters
        ----------
        _table: str
            The name of the table.
        _where: str, optional
            Where clause of a database query. Restrict the return
            base on column data.

        Returns
        -------
        rowcount: int
            Rows affected in the database.

        Raises
        ------
        DBDeleteException:
            Exception raised when an operational or programming error occurs
            with the dbconn when issuing a DELETE query.

        """
        self._log.args("%s: (_table: %s, _where: %s)" % (self, _table, _where))
        q = "DELETE FROM " + _table
        if _where:
            _values = tuple(_where.values())
            q += self._add_where(_where)

        try:
            self.query(q, _values)
        except mariadb.ProgrammingError as e:
            self._log.error(e)
            raise DBDeleteException(e)
        except mariadb.OperationalError as e:
            self._log.error(e)
            raise DBDeleteException(e)
        self._commit_query()
        rowcount = self._cursor.rowcount
        self._log.rtn("%s: success | data: %d" % (self, rowcount))
        return rowcount

    def create_db(self, db_name: str) -> bool:
        """Create a new database. Raises DBOperationalException for operational
        errors (such as credential or connection issues), also raises
        DBProgrammingException for syntax errors in queries for example.

        Parameters
        ----------
        _db_name: str
            The name of the database.

        Returns
        -------
        created: bool
            True if the database was created successfully.

        Raises
        ------
        DBProgrammingException:
            Exception raised when a programming error occurs when interacting
            with a database.
        DBOperationalException:
            Exception raised an operational error occurs in database
            interactions.
        """
        self._log.args("%s: (db_name: %s)" % (self, db_name))
        query = "CREATE DATABASE " + db_name
        try:
            created = self.query(query)
        except mariadb.ProgrammingError as e:
            self._log.error(e)
            raise DBProgrammingException(e)
        except mariadb.OperationalError as e:
            self._log.error(e)
            raise DBOperationalException(e)
        self._log.rtn("%s: success | data: %r" % (self, created))
        return created

    def create_table(self, _query: str) -> None:
        """Create a new database table. Raises DBOperationalException for
        operational errors (such as credential or connection issues), also
        raises DBProgrammingException for syntax errors in queries for example.

        Parameters
        ----------
        _query: str
            The query to create the database table.

        Raises
        ------
        DBProgrammingException:
            Exception raised when a programming error occurs when interacting
            with a database.
        DBOperationalException:
            Exception raised an operational error occurs in database
            interactions.

        """
        self._log.args("%s: (_query: %s)" % (self, _query))
        q = "CREATE TABLE IF NOT EXISTS " + _query
        try:
            self.query(q)
        except mariadb.ProgrammingError as e:
            self._log.error(e)
            raise DBProgrammingException(e)
        except mariadb.OperationalError as e:
            self._log.error(e)
            raise DBOperationalException(e)
        self._log.rtn("%s: success" % self)

    def delete_table(self, table: str) -> bool:
        """Delete a table with a table name and a list of attributes. Raises
        DBOperationalException for operational errors (such as credential or
        connection issues), also raises DBProgrammingException for syntax
        errors in queries for example.

        Parameters
        ----------
        table: str
            Table name to be dropped.

        Return
        ------
        deleted: bool
            True if the database table was deleted successfully.

        Raises
        ------
        DBProgrammingxception:
            Exception raised when a programming error occurs when interacting
            with a database.
        DBOperationalException:
            Exception raised an operational error occurs in database
            interactions.
        """
        self._log.args("%s: (table: %s" % (self, table))
        q = "DROP TABLE IF EXISTS " + table
        try:
            self.query(q)
        except mariadb.ProgrammingError as e:
            self._log.error(e)
            raise DBProgrammingException(e)
        except mariadb.OperationalError as e:
            self._log.error(e)
            raise DBOperationalException(e)
        self._log.rtn("%s: success" % self)

    def _commit_query(self) -> None:
        """Commit the database query.

        Ends the current transaction and make all the changes
        to the database permanent.
        """
        self._log.args("%s: ()" % self)
        self._connection.commit()
        self._log.rtn("%s: success" % self)

    def _add_attributes(self, attr: list) -> str:
        """Helper method for query attributes.

        This method adds the required columns to select from
        or insert into the database

        Returns
        -------
        rtn: str

        """
        self._log.args("%s: (attr: %s" % (self, attr))
        rtn = ",".join(attr)
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _add_ordering(self, ordering: list) -> str:
        """Helper method for query ordering.

        This method adds the required columns and ordering to select from
        the database
        """
        self._log.args("%s: (ordering: %s" % (self, ordering))
        order_by = ""
        dlen = len(ordering)
        i = 0
        for item in ordering:
            i += 1
            order_by += item[0] + " " + item[1]
            if i < dlen:
                order_by += ", "
        self._log.rtn("%s: success | data: %s" % (self, order_by))
        return order_by

    def _add_where(self, where: Dict) -> Any:
        """Helper method for query where filter clause.

        This method add the required columns to select from
        or insert into the database
        """
        self._log.args("%s: (where: %s" % (self, where))
        _where = " WHERE "
        _key_list = []
        for key in where.keys():
            element = "{}=%s".format(key)
            _key_list.append(element)
        _where += " and ".join(_key_list)
        self._log.rtn("%s: success | data: %s" % (self, _where))
        return _where

    def _add_set(self, _set: Dict) -> str:
        """Helper method for set method.

        This method add the required columns to select from
        or insert into the database
        """
        self._log.args("%s: (_set: %s" % (self, _set))
        _set_stmt = " SET "
        _key_list = []
        for key in _set.keys():
            element = "{}=%s".format(key)
            _key_list.append(element)
        _set_stmt += self._add_attributes(_key_list)
        self._log.rtn("%s: success | data: %s" % (self, _set_stmt))
        return _set_stmt

    def close(self) -> None:
        """Closes a database connection."""
        self._log.args("%s: ()" % self)
        self._cursor.close()
        self._connection.close()
        self._log.rtn("%s: success" % self)
