# -*- coding: utf-8 - * -
"""Abstract async adapter"""

from typing import Dict
from abc import (
    ABC,
    abstractmethod
)


class AbstractAsyncAdapter(ABC):
    """
    Abstract Async Adapter
    ======================

    Abstract class which defines the required methods for any async adapter.
    """

    @abstractmethod
    def __init__(self, config: Dict, mask_map: Dict = None, fds: Dict = None):
        """Select engine async adapter class constructor."""
        pass

    @abstractmethod
    def close(self) -> bool:
        """Closes the adapter and unregisters components."""
        pass

    @abstractmethod
    def get_adapter_fd(self) -> int:
        """Gets the adapter's file descriptor."""
        pass

    @abstractmethod
    def get_registered_fds(self) -> list:
        """Gets the file descriptors registered to the adapter."""

    @abstractmethod
    def config(self, config: Dict) -> None:
        """Configures the async adapter."""
        pass

    @abstractmethod
    def get_config(self) -> Dict:
        """Getter method for async adapter configuration."""
        pass

    @abstractmethod
    def register(self, fd: int, event_mask: str) -> bool:
        """Registers a file descriptor to the adapter."""
        pass

    @abstractmethod
    def unregister(self, fd: int) -> bool:
        """Unregisters a file descriptor from the adapter."""
        pass

    @abstractmethod
    def poll(self, timeout: float) -> list:
        """Runs the select loop."""
        pass
