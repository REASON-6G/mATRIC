# -*- coding: utf-8 -*-
"""Epoll async adapter"""

import select
from typing import Dict
from wiremq.extlib.asynchronous.iopollers import iobasepoller
from wiremq.extlib.err.asyncexception import IOLoopUnregisterFDException


class IOEPoll(iobasepoller.IOBasePoller):
    """
    Epoll Async Adapter
    ===================

    Poller using epoll, compatible with Linux architectures.

    epoll is a Linux-specific system call that excels in I/O multiplexing. It
    provides efficient handling of a large number of file descriptors and
    supports both edge-triggered and level-triggered modes. It is not portable
    to other Unix-like systems.

    Attributes
    ----------
    _config: Dict
        Async adapter configuration.
    poller: object
        Polling object.
    _log: object
        Python logging instance.

    Methods
    -------
    register(): bool
        Registers a file descriptor to the adapter.
    unregister(): bool
        Unregisters a file descriptor from the adapter.
    poll(): list
        Runs the polling engine

    Raises
    ------
    IOLoopUnregisterFDException:
        Exception raised when unregistering a file descriptor from the poller
        that does not exist.

    """

    mask_map = {
        "IN": select.EPOLLIN,
        "OUT": select.EPOLLOUT
    }

    def __init__(self, config: Dict = None) -> None:
        """Epoll engine async adapter class constructor.

        Initializes an epoll adapter.

        Parameters
        ----------
        config: Dict
            type: string
                Adapter type. e.g. epolladapter.
            name: string
                Human readable name for the epoll adapter.
            alias: string
                Short readable name for the adapter.
            id: hex
                Unique identifier for the epoll adapter.
            logger: str, optional
                Name of the logger instance.
        Example
        -------
        >>> config = {
        ...     "type": "epolladapter",
        ...     "name": "Epoll Async Adapter",
        ...     "alias": "Test Async Adapter",
        ...     "uid": "0868bc20384ad8cbf15b03350ce5671" +
        ...            "10e97940d10c44736e3121c36b4ae6a38",
        ...     "max_events": -1
        ... }
        >>> epoll_adapter = ioepoll.IOEPoll(config)
        """
        super().__init__(config)
        self.poller = select.epoll()
        self.adapter_fd = self.poller.fileno()

    def register(self, fd: int, event_mask: str) -> bool:
        """Registers a file descriptor to the adapter."""
        self._log.args("%s: (fd: %s, event_mask: %s)" % (self, fd, event_mask))
        super().register(fd, event_mask)
        self.poller.register(fd, IOEPoll.mask_map[event_mask])
        self._log.rtn("%s: success" % self)

    def unregister(self, fd: int) -> None:
        """Unregisters a file descriptor from the adapter. Raises
        IOLoopUnregisterFDException when attempting to remove a file descriptor
        which does not exist

        Parameters
        ----------
        fd: int
            File descriptor.

        Raises
        ------
        IOLoopUnregisterFDException:
            Exception raised when unregistering a file descriptor from the
            poller that does not exist.
        """
        self._log.args("%s: (fd: %s)" % (self, fd))
        super().unregister(fd)
        try:
            self.poller.unregister(fd)
        except KeyError as e:
            self._log.error(e)
            raise IOLoopUnregisterFDException(e)
        except PermissionError as e:
            self._log.error(e)
            raise IOLoopUnregisterFDException(e)
        except FileNotFoundError as e:
            self._log.error(e)
            raise IOLoopUnregisterFDException(e)
        self._log.rtn("%s: success" % self)

    def poll(self, timeout: float = None) -> list:
        """Returns registered file descriptors when the corresponding
        registered events occur.

        Parameters
        ----------
        timeout: float
            Time-out interval for polling.

        Returns
        -------
        events: list
            Contains a list file descriptors that have events to report.
        """
        max_events = self._config.get("max_events", -1)
        events = self.poller.poll(timeout, max_events)
        rtn = [_tuple[0] for _tuple in events]
        if events:
            self._log.args("%s: (timeout: %s)" % (self, timeout))
            self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
