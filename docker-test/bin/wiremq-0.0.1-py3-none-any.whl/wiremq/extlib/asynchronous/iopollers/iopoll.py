# -*- coding: utf-8 -*-
"""Poll async adapter"""

import select
from typing import Dict
from wiremq.extlib.asynchronous.iopollers import iobasepoller
from wiremq.extlib.err.asyncexception import IOLoopUnregisterFDException


class IOPoll(iobasepoller.IOBasePoller):
    """
    Poll Async Adapter
    ==================

    Poller using poll, not compatible with all operating systems.

    Similar to select, poll is a Unix mechanism for I/O multiplexing. It
    overcomes some limitations of select, offering better scalability by
     avoiding FD_SET size restrictions. However, it may not be as efficient as
      more advanced mechanisms.

    Attributes
    ----------
    _config: Dict
        Async adapter configuration.
    poller: object
        Polling object.
    _log: object
        Python logging instance.

    Methods
    -------
    register(): bool
        Registers a file descriptor to the adapter.
    unregister(): bool
        Unregisters a file descriptor from the adapter.
    poll(): list
        Runs the polling engine

    Raises
    ------
    IOLoopUnregisterFDException:
        Exception raised when unregistering a file descriptor from the poller
        that does not exist.

    """

    mask_map = {
        "IN": select.POLLIN,
        "OUT": select.POLLOUT
    }

    def __init__(self, config: Dict = None) -> None:
        """Poll engine async adapter class constructor.

        Initializes a poll adapter.

        Parameters
        ----------
        config: Dict
            type: string
                Adapter type. e.g. polladapter.
            name: string
                Human readable name for the poll adapter.
            alias: string
                Short readable name for the adapter.
            id: hex
                Unique identifier for the poll adapter.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> config = {
        ...     "type": "polladapter",
        ...     "name": "Poll Async Adapter",
        ...     "alias": "Test Async Adapter",
        ...     "uid": "0868bc20384ad8cbf15b03350ce5671" +
        ...            "10e97940d10c44736e3121c36b4ae6a38"
        ... }
        >>> poll_adapter = iopoll.IOPoll(config)
        """
        super().__init__(config)
        self.poller = select.poll()

    def register(self, fd: int, event_mask: str) -> bool:
        """Registers a file descriptor to the adapter."""
        self._log.args("%s: (fd: %s, event_mask: %s)" % (self, fd, event_mask))
        super().register(fd, event_mask)
        self.poller.register(fd, IOPoll.mask_map[event_mask])
        self._log.rtn("%s: success" % self)

    def unregister(self, fd: int) -> None:
        """Unregisters a file descriptor from the adapter. Raises
        IOLoopUnregisterFDException when attempting to remove a file descriptor
        which does not exist

        Parameters
        ----------
        fd: int
            File descriptor.

        Raises
        -------
        IOLoopUnregisterFDException:
            Exception raised when unregistering a file descriptor from the
            poller that does not exist.
        """
        self._log.args("%s: (fd: %s)" % (self, fd))
        super().unregister(fd)
        try:
            self.poller.unregister(fd)
        except KeyError as e:
            self._log.error(e)
            raise IOLoopUnregisterFDException(e)
        self._log.rtn("%s: success" % self)

    def poll(self, timeout: float) -> list:
        """Returns registered file descriptors when the corresponding
        registered events occur.

        Parameters
        ----------
        timeout: float
            Time-out interval for polling.

        Returns
        -------
        events: list
            Contains a list file descriptors that have events to report.
        """
        events = self.poller.poll(timeout)
        rtn = [_tuple[0] for _tuple in events]
        if events:
            self._log.args("%s: (timeout: %s)" % (self, timeout))
            self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
