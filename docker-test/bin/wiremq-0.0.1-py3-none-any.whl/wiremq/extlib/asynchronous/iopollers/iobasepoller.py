# -*- coding: utf-8 -*-
"""Base async adapter"""

import uuid
from typing import Dict
import logging
from wiremq.extlib.asynchronous.iopollers import abstractasyncadapter


class IOBasePoller(abstractasyncadapter.AbstractAsyncAdapter):
    """
    Base IO Poller
    ==============

    Attributes
    ----------
    _config: Dict
        Async adapter configuration.
    _log: object
        Python logging instance.

    Methods
    -------
    _generate_id(): str
        Generates a unique id.
    config(): None
        Configures the base poller.
    get_id(): str
        Returns the id of the poller.
    get_config(): Dict
        Getter method for async adapter configuration.
    get_adapter_fd(): int
        Gets the adapter's file descriptor
    get_registered_fds(): list
        Gets the file descriptors registered to the adapter.
    register(): bool
        Registers a file descriptor to the adapter.
    unregister(): bool
        Unregisters a file descriptor from the adapter.
    poll(): list
        Runs the polling engine, to be overridden by child classes.
    close(): bool
        Closes the adapter and unregisters components.
    """

    def __init__(self, config: Dict = None) -> None:
        """Base async adapter class constructor.

        Parameters
        ----------
        config: dict
            type: string
                Adapter type. e.g. selectasyncadapter.
            name: string
                Human readable name for the select adapter.
            alias: string
                Short readable name for the adapter.
            id: hex
                Unique identifier for the select adapter.
            timeout: float
                Time in seconds to wait before poll engine will return if
                relevant events do not occur on registered file descriptors.
            mask_map: dict
                Mapping of file descriptors and their direction code.
        Example
        -------
        >>> config = {
        ...     "type": "iobasepoller",
        ...     "name": "Base Async Adapter",
        ...     "alias": "Test Async Adapter",
        ...     "uid": "0868bc20384ad8cbf15b03350ce5671" +
        ...            "10e97940d10c44736e3121c36b4ae6a38"
        ... }
        >>> base_adapter = iobasepoller.IOBasePoller(config)
        """
        super().__init__(config)
        self._id = self._generate_id()
        self._config = None
        self._log = None
        self.adapter_fd = None
        self.fds = []
        if config:
            self.config(config)

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def config(self, config: Dict) -> None:
        """Configures the base poller.

        Parameters
        ----------
        config: Dict
            Poller configuration

        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._config = config

    def get_config(self) -> Dict:
        """Getter method for async adapter configuration.
        Returns
        -------
        config: Dict
            Async adapter configuration dictionary
        """
        self._log.args("%s: ()" % self)
        config = self._config
        self._log.rtn("%s: success | data: %s" % (self, config))
        return config

    def get_id(self) -> str:
        """Returns the id of the poller.

        Returns
        -------
        id: str
            Identifier of task.
        """
        self._log.args("%s: ()" % self)
        _id = str(self._id)
        self._log.rtn("%s: success | data: %s" % (self, _id))
        return _id

    def get_adapter_fd(self) -> int:
        """Gets the adapter's file descriptor."""
        self._log.args("%s: ()" % self)
        adapter_fd = self.adapter_fd
        self._log.rtn("%s: success | data: %s" % (self, adapter_fd))
        return adapter_fd

    def get_registered_fds(self) -> list:
        """Gets the file descriptors registered to the adapter.

        Returns
        -------
        fds: list
            List of file descriptors.
        """
        self._log.args("%s: ()" % self)
        fds = self.fds
        self._log.rtn("%s: success | data: %s" % (self, fds))
        return fds

    def register(self, fd: int, event_mask: str) -> bool:
        """Registers a file descriptor to the adapter.

        Parameters
        ----------
        fd: int
            File descriptor,
        event_mask: str
            Event mask
        """
        self._log.args("%s (fd: %s, event_mask: %s)" % (self, fd, event_mask))
        self.fds.append((fd, event_mask))
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def unregister(self, fd: int) -> bool:
        """Unregisters a file descriptor from the adapter.

        Parameters
        ----------
        fd: int
            File descriptor.

        Returns:
        rtn: bool
            True if successful
        """
        self._log.args("%s: (fd: %s)" % (self, fd))
        res = [t for t in self.fds if t[0] == fd]
        self.fds = [item for item in self.fds if item not in res]
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def poll(self, timeout: float) -> list:
        """Runs the polling engine, to be overridden by child classes.
        """
        self._log.args("%s: (timeout: %s)" % (self, timeout))
        pass

    def close(self) -> bool:
        """Closes the adapter and unregisters components."""
        self._log.args("%s: ()" % self)
        self._config = None
        self.fds = None
        self._log.rtn("%s: success" % self)
