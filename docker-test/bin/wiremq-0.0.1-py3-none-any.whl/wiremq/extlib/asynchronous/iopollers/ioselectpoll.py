# -*- coding: utf-8 -*-
"""Select async adapter"""

import select
from typing import Dict
from wiremq.extlib.asynchronous.iopollers import iobasepoller


class IOSelectPoll(iobasepoller.IOBasePoller):
    """
    Select Async Adapter
    ====================

    Poller using select, compatible with most operating systems.

    select is a traditional Unix mechanism for I/O multiplexing. It monitors
    multiple file descriptors simultaneously to check for I/O events. However,
    it becomes less efficient as the number of file descriptors increases, and
    it has limitations on the maximum number of descriptors.

    Attributes
    ----------
    _config: Dict
        Async adapter configuration.
    _log: object
        Python logging instance.

    Methods
    -------
    poll(): list
        Returns registered file descriptors when the corresponding
        registered events occur.

    """

    def __init__(self, config: Dict = None) -> None:
        """Select engine async adapter class constructor.

        Initializes a select adapter.

        Parameters
        ----------
        config: Dict
            type: string
                Adapter type. e.g. selectadapter.
            name: string
                Human readable name for the select adapter.
            alias: string
                Short readable name for the adapter.
            id: hex
                Unique identifier for the select adapter.
            logger: str, optional
                Name of the logger instance.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> config = {
        ...     "type": "ioselectpoll",
        ...     "name": "Select Async Adapter",
        ...     "alias": "Test Async Adapter",
        ...     "uid": "0868bc20384ad8cbf15b03350ce5671" +
        ...            "10e97940d10c44736e3121c36b4ae6a38"
        ... }
        >>> poll_adapter = ioselectpoll.IOSelectPoll(config)
        """
        super().__init__(config)

    def poll(self, timeout: float) -> list:
        """Returns registered file descriptors when the corresponding
        registered events occur.

        Parameters
        ----------
        timeout: float
            Time-out interval for polling.

        Returns
        -------
        events: list
            Contains a list file descriptors that have events to report.
        """
        readable = [_tuple[0] for _tuple in self.fds if _tuple[1] == "IN"]
        writable = [_tuple[0] for _tuple in self.fds if _tuple[1] == "OUT"]
        r, w, _ = select.select(readable, writable, [], timeout)
        events = r + w
        if events:
            self._log.args("%s: (timeout: %s)" % (self, timeout))
            self._log.rtn("%s: success | data: %s" % (self, events))
        return events
