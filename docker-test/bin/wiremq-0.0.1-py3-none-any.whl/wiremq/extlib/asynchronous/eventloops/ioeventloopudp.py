# -*- coding: utf-8 -*-

from typing import Dict
from wiremq.extlib.asynchronous.eventloops import baseioeventloop
from wiremq.utils import iotask
from wiremq.extlib.err.socketexception import SocketException
from wiremq.extlib.err.asyncexception import IOEventLoopInitException


class IOEventLoopUDP(baseioeventloop.BaseIOEventLoop):
    """
    UDP IO Event loop
    =================

    This component works in conjunction with the wmqsocket, Task, Scheduler
    and IOBasePoller. The event loop aims to handle io tasks within a single
    thread.

    Attributes
    ----------
    _config : Dict
        The configuration dictionary.
    _terminator : bytes
        The termination sequence as a byte string.

    Methods
    -------
    _loop() : None
        This is the main event loop. Polls the kernel, Returns the events,
        handles and schedules for execution.
    _handle_events() : None
        Handles all the fd in the events list.
    _handle_request() : None
        UDP Handler. Handles a connection request.
    _terminated() : bool
        Determines which active fdid buffers are complete.
    _has_terminator() : bool
        Searches for the termination character in a bytestring.
    _remove_terminator(): None
        Removes terminator bytes from a buffer.
    _handle_close() : None
        Handles the closing of a connection.
    _accept_request() : tuple
        Accepts the request on the socket.
    _schedule_task() : None
        Schedules a task. checks the ready list, extracts the fd, retrieve
        bytes, creates a task object and instantiates with the bytes in the
        buffer.
    _create_task() : Task
        Creates a single IO-Task.
    config(): None
        Configures the event loop.
    initialize() : None
        Initializes the event loop.
    """

    def __init__(self, config: Dict = None):
        """IOEventLoopUDP constructor.

        Initialize with the configuration dictionary as follows:

        Parameters
        ----------
        config: dict
            IOEventloopUDP configuration dictionary.
            poller : BaseIOPoller
                BaseIOPoller object type.
            terminator : bytes
                The termination sequence (as byte string)
            scheduler : Scheduler
                A BaseScheduler type object.
            socket : Inboundsocket
                An inbound (UDP) wmq socket.
            host : str
                The host IP as a string.
            port : int
                The port to bind to as an integer.
            max_con : int
                Specify the maximum allowable connections (at a time).

        Example:
        -------
        >>> config = {}
        >>> config["poller"] = iopoller
        >>> config["terminator"] = b'\r\r\r\r'
        >>> config["scheduler"] = None
        >>> config["socket"] = wmqsocket
        >>> config["buffer_size"] = 1024
        >>> config["listening"] = True
        >>> config["host"] = "127.0.0.1"
        >>> config["port"] = 60081
        >>> config["max_con"] = 202
        >>> evloop = ioeventloopudp.IOEventLoopUDP(config)
        """
        self._terminator = None
        super().__init__(config)

    def _loop(self, timeout: float = 0.0) -> None:
        """This is the main event loop. Polls the kernel, Returns the events,
        handles and schedules for execution.

        Parameters
        ----------
        timeout: float
            Polling timeout in seconds.
        """
        events = self._io.poll(timeout)

        for e in events:
            self._log.info("%s: [event]: %s" % (self, e))
            self._handle_event(e)

        # For completed buffers, create the task
        self._schedule_task()

        # For ready tasks in the task queue, execute.
        if self._scheduler:
            self._execute_scheduled()

    def _handle_event(self, _e: int) -> None:
        """Handles all the fd in the events list.

        Parameters
        ----------
        _e : int
            The file descriptor representing the event.
        """
        self._log.args("%s (_e: %s)" % (self, _e))
        self._handle_request(_e)
        self._handle_close()
        self._log.rtn("%s: success" % self)

    def _handle_request(self, _req: int) -> None:
        """UDP Handler. Handles a connection request.

        Accept a request and return the socket and address tuple. The returned
        socket objects fd is appended to the active fd list and registered to
        the poller. A mapping is then created for the request.

        Parameters
        ----------
        req : int
           The file descriptor the connection request occurred on.
        """
        self._log.args("%s (_req: %s)" % (self, _req))
        _data, _conn = self._accept_request()
        _fdid = self._generate_fdid(_conn)
        if _fdid not in self._active:
            self._active.append(_fdid)
            self._add_mapping(
                _indx=_fdid, _t=self._terminator, _fd=None, _b=_data, _c=_conn
            )
            self._log.info("%s: _active: %s" % (self, self._active))
        else:
            self._update_mapping(_indx=_fdid, _b=_data)
        self._log.rtn("%s: success" % self)

    def _terminated(self, _fdid: str) -> bool:
        """Determines which active fdid buffers are complete.

        Removes terminator bytes from the buffer.

        Parameters
        ----------
        _fdid : str
            The file descriptor identifier.

        Returns
        -------
        rtn : bool
            Return True if termination is found, False, otherwise.
        """
        self._log.args("%s (_fdid: %s)" % (self, _fdid))
        rtn = self._has_terminator(
            _t=self._map[_fdid]["terminator"], _b=self._map[_fdid]["buffer"]
        )
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _has_terminator(self, _t: str, _b: bytes) -> bool:
        """Searches for the termination character in a bytestring.

        Parameters
        ----------
        _t : bytes
            The termination bytes string.
        _b : bytes
            The byte string to be searched.

        Returns
        -------
        rtn : bool
            Return True if termination is found, False, otherwise.
        """
        self._log.args("%s (_t: %s, _b: %s)" % (self, _t, _b))
        _lt = len(_t)
        _bl1 = _b[-_lt:]  # Slice the byte string from len(terminator) to EOS
        rtn = False
        if _t == _bl1:
            rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _remove_terminator(self, _fdid: str) -> None:
        """Removes terminator bytes from a buffer.

        Parameters
        ----------
        _fdid: str
            The file descriptor identifier.

        """
        self._log.args("%s (_fdid: %s)" % (self, _fdid))
        self._map[_fdid].update({"buffer": self._map[_fdid]["buffer"].replace(
            self._map[_fdid]["terminator"],
            b""
        )})
        self._log.rtn("%s: success" % self)

    def _handle_close(self) -> None:
        """Handles the closing of a connection.

        Closing in UDP requires first a check for termination character in the
        buffered bytes. This is followed with the removal of the `_fdid` from
        active connections list, unregistering the file descriptor from the
        iopoller object appending the fd to the ready for scheduling list and
        finally closing the connection object associated with the descriptor.
        """
        self._log.args("%s: ()" % self)
        for _fdid in self._active:
            if self._terminated(_fdid):
                self._active.remove(_fdid)
                self._ready.append(_fdid)
                self._log.info("%s: _active: %s" % (self, self._active))
                self._log.info("%s: _ready: %s" % (self, self._ready))
                self._remove_terminator(_fdid)
        self._log.rtn("%s: success" % self)

    def _accept_request(self) -> tuple:
        """Accepts the request on the socket.

        Returns
        -------
        rtn : tuple
           sock : object
              The connection object.
           addr : tuple
              The address and port of the requestor.
        """
        self._log.args("%s: ()" % self)
        _r = self._wmqsocket.recv()
        self._log.info("%s: address %s received %s bytes"
                       % (self, _r[1], len(_r[0])))
        self._log.rtn("%s: success | data: %s" % (self, (_r[0], _r[1])))
        return _r[0], _r[1]

    def _schedule_task(self) -> None:
        """Schedules a task. checks the ready list, extracts the fd, retrieve
        bytes, creates a task object and instantiates with the bytes in the
        buffer.

        Scheduling a task by first checking the ready list, extracting the fd,
        retrieving the bytes buffer from the map and instantiating a task with
        the acquired buffer. Afterwards, remove the fd from the ready list,
        append the task to the scheduled list and delete the mapping (indexed
        by the file descriptor identifier).
        """
        for _fdid in self._ready:
            _t = self._create_task(_b=self._map[_fdid]["buffer"])
            self._log.info("%s: [Task-Created]: %s" % (self, _t.get_id()))
            self._scheduled.put(_t)
            self._del_mapping(_fdid)
            self._log.info("%s: [Task-Scheduled]: %s" % (self, self._scheduled))
            self._ready.remove(_fdid)

    def _create_task(self, _b: bytes) -> object:
        """Creates a single IO-Task.

        Parameters
        ----------
        _b  : bytes object
           The byte string received.
        """
        self._log.args("%s (_b: %s)" % (self, _b))
        task = iotask.IOTask(name="io-task", buff=_b)
        self._log.rtn("%s: success | data: %s" % (self, task))
        return task

    def _log_stats(self, events: list = None) -> None:
        self._log.info("%s: events: %s" % (self, events))
        self._log.info("%s: active: %s" % (self, self._active))
        self._log.info("%s: map: %s" % (self, self._map))
        self._log.info("%s: ready: %s" % (self, self._ready))
        self._log.info("%s: scheduled %s" % (self, self._scheduled))

    def config(self, config: Dict) -> None:
        """Configures the event loop.

        Parameters
        ----------
        config: dict
            BaseIOEventloop configuration dictionary.
            poller : BaseIOPoller
                BaseIOPoller object type.
            terminator : bytes
                The termination sequence (as byte string)
            scheduler : Scheduler
                A BaseScheduler type object.
            socket : Inboundsocket
                An inbound wmq socket.
            host : str
                The host IP as a string.
            port : int
                The port to bind to as an integer.
            max_con : int
                Specify the maximum allowable connections (at a time).
            logger: str, optional
                Name of the logger instance.

        """
        super().config(config)
        self._terminator = config["terminator"]
        self._log.rtn("%s: success" % self)

    def initialize(self) -> None:
        """Initializes the event loop.

        Bind and listen on the socket. Register the socket to the socket map
        the io poller.

        Raises
        ------
        IOEventLoopInitException
            Exception handling the failure of initialization the io loop.
        """
        self._log.args("%s: ()" % self)
        try:
            self._bind_and_listen()
            self._io.register(self._wmqsocket_fd, "IN")
            self._add_mapping(
                _indx=self._wmqsocket_id,
                _t=None,
                _fd=self._wmqsocket_fd,
                _c=self._wmqsocket,
            )
        except SocketException as e:
            self._log.error(e)
            raise IOEventLoopInitException(e)
        self._log.rtn("%s: success" % self)
