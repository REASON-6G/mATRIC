# -*- coding: utf-8 - *-
"""Wire MQ logger.

This module configures python's logging module to use custom settings.

Several formatters, handlers, and loggers are defined here.

File logging is optional and is performed via a queue handler and queue
listener. The queue listener service is started here.
"""
import logging
import queue
import logging.handlers
import logging.config
from wiremq.logging import coloredformatter


class WmqLogger:
    """Logger for wiremq endpoints.

    A logger is instantiated based on a config, this class wraps the standard
    python logging module.

    Attributes
    ----------
    _alias: str
        Alias of the logger, used as the python logger name, ideally one alias
        per endpoint.
    _log_path: str
        Path to the destination of the log file.
    _backup_count: int
        Number of log file backups to store for log file rotation.
    _max_bytes: int
        Maximum number of bytes per log file.
    _file_level: int
        Log level for file logging.
    _file_format: str
        Format string for file logging.
    _file_handler: object
        File handler from python logging library.
    _console_level: int
        Log level for console logging.
    _console_forma: str
        Format string for console logging.
    _console_handler: object
        Stream handler from python logging library.
    _queue_handler: object
        Used for asynchronous logging to files.
    _queue_listener: object
        Service which listens for queue events and logs them.

    _logger
        Logger from python logging library

    Methods
    -------
    config: None
        Configures the logger.
    register: None
        Registers the handlers and logger.
    _register_file_handler: None
        Initializes and registers a file handler, and configures its
        formatter and level.
    _register_console_handler: None
        Initializes and registers a console handler, and configures its
        formatter and level.
    args: None
        Custom log level handler for object method return values.
    rtn: None
        Custom log level handler for object method return values.
    dev: None
        Custom log level handler for developer logs.

    """

    ARGS = logging.INFO - 1
    RTN = logging.INFO - 2
    DEV = logging.INFO + 1

    def __init__(self, config: dict):
        """Logger class constructor

        Parameters
        ----------
        config: dict
            name: str
                Name of the logger.
            alias: str
                Alias of the logger, used as the python logger name, ideally
                one alias per endpoint.
            log_path: str
                Path to the destination of the log file.
            backup_count: str (optional, default 10)
                Number of log file backups to store for log file rotation.
            max_bytes: int (optional, default 1048560)
                Maximum number of bytes per log file.
            file_level: int (optional, default logging.DEBUG=1)
                Log level for file logging.
            file_format: str (optional)
                Format string for file logging.
            console_level: int (optional, default logging.INFO=20)
                Log level for console logging.
            console_format: str (optional)
                Format string for console logging.
        """
        self._alias = None
        self._log_path = None
        self._backup_count = None
        self._max_bytes = None
        self._file_level = None
        self._file_format = None
        self._file_handler = None
        self._console_level = None
        self._console_format = None
        self._console_handler = None
        self._queue_handler = None

        self.config(config)
        self.register()

        # Custom log levels
        logging.addLevelName(WmqLogger.ARGS, "ARGS")
        logging.addLevelName(WmqLogger.RTN, "RTN")
        logging.addLevelName(WmqLogger.DEV, "DEV")

    def config(self, config: dict) -> None:
        """Configures the logger.

        Parameters
        ----------
        config: dict
            Logging configuration dictionary.

        """
        self._alias = config["alias"]
        self._log_path = config.get("log_path")
        self._backup_count = config.get("backup_count", 10)
        self._max_bytes = config.get("max_bytes", 10485600)
        self._file_level = config.get("file_level", 1)
        self._file_format = config.get(
            "file_format",
            "%(asctime)s [%(levelname)s] {%(module)s:%(funcName)s:"
            "%(lineno)s} | %(message)s"
        )
        self._console_level = config.get("console_level", 20)
        self._console_format = config.get(
            "console_format",
            "%(asctime)s [%(levelname)s] (%(name)s) {%(module)s:%(funcName)s:"
            "%(lineno)s} | %(message)s"
        )

    def register(self) -> None:
        """Registers the handlers and logger"""
        self._logger = logging.getLogger(self._alias)
        for handler in self._logger.handlers[:]:
            self._logger.removeHandler(handler)
        self._register_file_handler()
        self._register_queue_handler()
        self._register_console_handler()

    def _register_queue_handler(self) -> None:
        """Initializes and registers a queue handler, which is used for
        asynchronous file logging."""
        if self._log_path:
            self._log_queue = queue.Queue(-1)
            self._queue_handler = logging.handlers.QueueHandler(self._log_queue)
            self._queue_listener = logging.handlers.QueueListener(
                self._log_queue,
                self._file_handler,
                respect_handler_level=True
            )
            self._queue_listener.start()
            self._logger.addHandler(self._queue_handler)

    def _register_file_handler(self) -> None:
        """Initializes and registers a file handler, and configures its
        formatter and level.
        """
        if self._log_path:
            self._file_handler = logging.handlers.RotatingFileHandler(
                filename=self._log_path,
                backupCount=self._backup_count,
                maxBytes=self._max_bytes,
            )
            self._file_handler.setLevel(self._file_level)
            self._file_handler.setFormatter(
                logging.Formatter(self._file_format)
            )

    def _register_console_handler(self) -> None:
        """Initializes and registers a console handler, and configures its
        formatter and level.
        """
        self._console_handler = logging.StreamHandler()
        self._console_handler.setLevel(self._console_level)
        self._console_handler.setFormatter(
            coloredformatter.ColoredFormatter(self._console_format)
        )
        self._logger.addHandler(self._console_handler)
