# -*- coding: utf-8 -*-

from typing import Dict
from wiremq.processing import baseprocessor
from wiremq.extlib.err.filterexceptions import QueueDispatcherException
from wiremq.extlib.err.queueexception import QueueFullException


class QueueDispatcher(baseprocessor.BaseProcessor):
    """Queue Dispatcher class

    The queue dispatcher takes a message, and sends it to its intended
    recipient.

    Attributes
    ----------
    _config : dict
        Configuration of the queue dispatcher.

    Methods
    -------
    _process() : Dict
        Overrides method of base processor, holds the processor logic.
    -------
    """

    def __init__(self, config: Dict = None):
        """Queue dispatcher class constructor.

        Parameters
        ----------
        config: Dict
            type: str
                The processor type.
            alias: str
                Alias of the queue dispatcher.
            name: str
                Name of the queue dispatcher.
            uid: hash
                Identification number.
            processor_queue: object
                Queue object for receiving & sending messages for processing.
            outbound: object
                Outbound queue for dispatching messages.
            shared_queue:
                The shared queue that messages are dispatched to.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> shared_queue = basequeue.BaseQueue()
        >>> config = {
        ...    "alias": "Queue dispatcher",
        ...    "name": "QueueDispatcher",
        ...    "type": "queuedispatcher",
        ...    "processor_queue": basequeue.BaseQueue(),
        ...    "shared_queue": shared_queue
        ... }
        >>> qdispatcher = queuedispatcher.QueueDispatcher(config)
        """
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._log.rtn("%s: success" % self)

    def _process(self, message: bytes) -> Dict:
        """Overrides _process method of base processor.

        Takes a message, and puts it into the shared queue.

        Parameters
        ----------
        message: Dict
            The message to dispatch.

        Returns
        -------
        rtn: Dict
            The status and message information.

        Raises
        ------
        QueueDispatcherException
            Throws exception whn queue is full.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        timeout = self._config.get("timeout", None)

        try:
            self._config["shared_queue"].put(message, timeout)
        except QueueFullException as e:
            raise QueueDispatcherException(e)
        rtn = {"status": "success", "data": message}
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
