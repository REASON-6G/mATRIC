# -*- coding: utf-8 - *-
""" Routing slip.

"""
from typing import Dict
from wiremq.processing import baseprocessor


class RoutingSlip(baseprocessor.BaseProcessor):
    """Routing slip class.

    A Routing Slip pattern is a predetermined routing scheme (list of required
    processing steps) attached within a message, without a need to go through a
    central router to determine the next route.

    The routing slip wraps a message with routing information for each route in
    its config.

    Methods
    -------
    _process: Dict
        Overrides _process method, holding the routing slip logic.
    """

    def __init__(self, config: Dict):
        """Routing slip class constructor.

        Parameters
        ----------
        config: dict
            type: str
                The type of the processor.
            alias: str
                Routing slip's alias.
            name: str
                Routing slip's name.
            uid: hex
                Unique id using secrets lib with sha256 hashing.
            processor_queue: object
                queue object for receiving and sending messages for processing.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> inbound_queue = fifoqueue.FifoQueue(inbound_queue_config)
        >>> outbound_queue = fifoqueue.FifoQueue(outbound_queue_config)
        >>> routingslip_config = {
        >>> "type": "routingslip",
        >>> "alias": "Routing slip",
        >>> "name": "My routing slip",
        >>> "uid": "0868bc20384ad8cbf15b03350ce5672",
        >>> "routes": [
        >>>     {
        >>>         "dest_ip": "192.168.1.22",
        >>>         "dest_port": 1234
        >>>     },
        >>>     {
        >>>         "dest_ip": "192.168.1.42",
        >>>         "dest_port": 8081
        >>>     }
        >>> ],
        >>> "processor_queue": processor_queue
        >>> }
        >>> inbound_queue.put(message)
        >>> routingslip = routingslip.RoutingSlip(routingslip_config)
        >>> wrapped_message = outbound_queue.get(message)
        >>> outbound_queue.item_processed()
        """
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._log.rtn("%s: success" % self)

    def _process(self, message: Dict) -> Dict:
        """ Overrides _process method, holding the routing slip logic.

        The message is wrapped for each route in the routing slip's config.

        The header from the original message is preserved in each wrapped
        message, however the attributes supplied in the routing slips' config
        are overwritten.

        Parameters
        ----------
        message: Dict
            The message to be wrapped with the routing information.

        Returns
        -------
        wrapped_msg: Dict
            A message wrapped with routing information.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        wrapped_msg = message.copy()
        for route in reversed(self._config["routes"]):
            wrapped_msg["payload"] = wrapped_msg.copy()
            wrapped_msg.update(route)

        rtn = {"status": "success", "data": wrapped_msg}
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
