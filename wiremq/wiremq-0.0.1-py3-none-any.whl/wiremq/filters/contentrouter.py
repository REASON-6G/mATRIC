# -*- coding: utf-8 -*-

from typing import Dict
from wiremq.processing import baseprocessor


class ContentRouter(baseprocessor.BaseProcessor):
    """Content Router class

    The content-based router takes a message, examines its header and/or
    payload, and looks up and selects the correct route for the message.

    Attributes
    ----------
    _config : dict
        Configuration of the content router.

    Methods
    -------
    _process() : Dict
        Overrides method of base processor, holds the processor logic.
    -------
    """

    def __init__(self, config: Dict = None):
        """Content Router class constructor.

        Parameters
        ----------
        config: Dict
            type: str
                The processor type
            alias: str
                Alias of the content router
            name: str
                Name of the content router
            uid: hash
                Identification number.
            processor_queue: object
                Queue object for receiving and sending messages for processing.
            routes: Dict
                The mapping of criteria to route, that is looked up and
                returned.  The criteria key is in the form of a tuple of
                message values.
            keys: Dict
                header: list
                    A list of field names from the message header, to look up
                    in the routes table
                payload: list
                    A list of field names from the message payload, to look up
                    in the routes table
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> config = {
        ...    "alias": "Content Router",
        ...    "name": "CROUTER Filter",
        ...    "type": "contentrouter",
        ...    "processor_queue": basequeue.BaseQueue(),
        ...    "routes": {
        ...         ("106.125.6.35", "1",): route1,
        ...         ("106.125.6.35", "2",): route2,
        ...         ("214.5.125.98", "1",): route3
        ...     },
        ...    "keys": {
        ...        "header": ["key2"],
        ...        "payload": ["plkey2"]
        ...    }
        ... }
        >>> crouter = contentrouter.ContentRouter(config)

        """
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, config))
        self._log.rtn("%s: success" % self)

    def _process(self, message: Dict) -> Dict:
        """Overrides _process method of base processor.

        Takes a message, examines its header and/or payload, and looks up and
        selects the correct route for the message.

        Parameters
        ----------
        message: Dict
            The message to route. The header data should be at the root level
            of the Dict and the payload should be in a "payload" nested Dict.

        Returns
        -------
        rtn: Dict
            The selected route and status information.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        _lookup_data = self._get_lookup_data(message)
        route = self._config["routes"].get(_lookup_data)
        if route:
            status = "success"
            data = route
        else:
            status = "failure"
            data = "No routing information available"
        rtn = {"status": status, "data": data}
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _get_lookup_data(self, message: Dict) -> tuple:
        """Returns a tuple that will be used to look up any matching route.

        Parameters
        ----------
        message: Dict
            The message to route. The header data should be at the root level
            of the Dict and the payload should be in a "payload" nested Dict.

        Returns
        -------
        rtn: tuple
            A tuple of values from the config-specified message keys to be
            used as a key when looking up a route in the routing table.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        _lookup_data = []
        for header_key in self._config["keys"]["header"]:
            if header_key in message:
                _lookup_data.append(message[header_key])
        for payload_key in self._config["keys"]["payload"]:
            if payload_key in message["payload"]:
                _lookup_data.append(message["payload"][payload_key])
        rtn = tuple(_lookup_data)
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
