# -*- coding: utf-8 -*-
from abc import (
    ABC,
    abstractmethod
)
from typing import (
    Dict,
    Tuple
)


class AbstractMessageFactory(ABC):
    """Template class for messages."""
    def __init__(self, config: Dict):
        """Message constructor."""
        pass

    @abstractmethod
    def _update_header(self, message: Dict) -> Dict:
        """Adds automatically generated attributes to the message header."""
        pass

    @abstractmethod
    def _validate(self, message: Dict) -> Tuple:
        """Validates the message with the registered validator."""
        pass

    @abstractmethod
    def config(self, config: Dict) -> None:
        """Configures the message."""
        pass

    @abstractmethod
    def message(self, header: Dict, payload: Dict = None) -> Dict:
        """Getter for the message dictionary."""
        pass
