# -*- coding: utf-8 -*-
from typing import Dict
from wiremq.gateway.messages import basemessageschema


class EventMessageSchema(basemessageschema.BaseMessageSchema):
    def __init__(self, config: Dict = None) -> None:
        self._config = None
        self._header_schema = None
        self._payload_schema = None
        super().__init__(config)

    def _build_header_schema(self) -> None:
        """Overrides the default _build_header_schema to enforce the command
        type in the headers.
        """
        super()._build_header_schema()
        self._header_schema.update({
            "type": {
                "type": str,
                "one_of": ["event"]
            }
        })
