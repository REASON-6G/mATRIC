# -*- coding: utf-8 -*-
from typing import Dict


class BaseMessageSchema:
    def __init__(self, config: Dict = None) -> None:
        """Base Schema initialization

        Examples
        --------
        >>> schema_config = {
        ...   "name": "Test schema",
        ...   "alias": "test_schema",
        ...   "type": "baseschema",
        ...   "excluded_header_keys": [
        ...     "sequence_size",
        ...     "sequence_id",
        ...     "position_id"
        ...   ],
        ...   "header_schema": {
        ...     "sender_port": {
        ...       "type": int,
        ...       "criteria": [("gt", 4000), ("lt", 6000)]
        ...     }
        ...     "payload_schema": {
        ...       "my_param": {
        ...         "type": str
        ...        }
        ...     }
        ...   }
}

        Parameters
        ----------
        config
        """
        self._header_schema = None
        self._payload_schema = None
        self._excluded_header_keys = []
        self._excluded_payload_keys = []
        self._config = None
        if config:
            self.config(config)
        self._build_header_schema()
        self._build_payload_schema()

    def _build_header_schema(self) -> None:
        """Creates the default header schema and updates with user-defined
        configs and keys which are excluded from validation.
        """
        self._header_schema = {
            "protocol_version": {
                "type": str
            },
            "message_id": {
                "type": str,
                "format": "uuid"
            },
            "timestamp": {
                "type": float
            },
            "datetime": {
                "type": str,
                "format": "datetime"
            },
            "sender_ip": {
                "type": str,
                "format": "ip"
            },
            "sender_port": {
                "type": int
            },
            "dest_ip": {
                "type": str,
                "format": "ip"
            },
            "dest_port": {
                "type": int
            },
            "correlation_id": {
                "type": str,
                "format": "hex"
            },
            "tx_correlation_id": {
                "type": str,
                "format": "hex"
            },
            "tx_id": {
                "type": str,
                "format": "hex"
            },
            "nonce": {
                "type": str,
                "format": "urlsafe"
            },
            "sequence_size": {
                "type": int
            },
            "sequence_id": {
                "type": str,
            },
            "position_id": {
                "type": int,
                "criteria": [("ge", 0)]
            },
            "type": {
                "type": str,
                "one_of": ["command", "event", "ack"]
            }
        }
        if self._config and "header_schema" in self._config:
            self._update_header_schema(self._config.get("header_schema"))
        for key in self._excluded_header_keys:
            del self._header_schema[key]

    def _build_payload_schema(self) -> None:
        """Assembles the payload schema, updating it with the custom config if
        provided.
        """

        self._payload_schema = {}
        if "payload_schema" in self._config:
            self._update_payload_schema(self._config.get("payload_schema"))
        for key in self._excluded_payload_keys:
            del self._payload_schema[key]

    def _update_header_schema(self, header_config: Dict) -> None:
        """Modifies the default header schema.

        The format of each entry must match the normal schema.

        Parameters
        ----------
        header_config: Dict
            Attributes to update (may be overriding existing attributes, or
            creating new attributes).

        """
        self._header_schema.update(header_config)

    def _update_payload_schema(self, payload_config: Dict) -> None:
        """Modifies the default payload schema.

        The format of each entry must match the normal schema.

        Parameters
        ----------
        payload_config: Dict
            Attributes to update (may be overriding existing attributes, or
            creating new attributes).

        """
        self._payload_schema.update(payload_config)

    def config(self, config: Dict) -> None:
        """Configures the schema

        Parameters
        ----------
        config: Dict
            Schema configuration dictionary.
            excluded_header_keys: list (optional)
                List of keys to exclude from header validation.
            excluded_payload_keys: list (optional)
                List of keys to exclude from payload validation.
            header_schema: Dict (optional)
                Custom header schema to update the default schema with.
            payload_schema: Dict (optional)
                Custom payload schema to update the default schema with.

        """
        self._config = config
        self._excluded_header_keys = config.get("excluded_header_keys", [])
        self._excluded_payload_keys = config.get("excluded_payload_keys", [])

    def get_header_schema(self) -> Dict:
        """Getter function for the header schema.

        Returns
        -------
        header_schema: Dict
            Header validation schema.
        """

        return self._header_schema

    def get_payload_schema(self) -> Dict:
        """Getter function for the payload schema.

        Returns
        -------
        payload_schema: Dict
            Payload validation schema.
        """
        return self._payload_schema
