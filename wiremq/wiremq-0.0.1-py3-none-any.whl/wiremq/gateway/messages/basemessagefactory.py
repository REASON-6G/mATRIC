# -*- coding: utf-8 -*-
import uuid
import time
from datetime import datetime as dt
import secrets
from typing import (
    Dict,
    Tuple
)
from wiremq.gateway.messages import (
    abstractmessagefactory,
    basemessageschema
)


class BaseMessageFactory(abstractmessagefactory.AbstractMessageFactory):
    """Creates a standard wiremq message.

    Methods
    -------
    _update_header():
        Adds attributes to the message header.
    _validate(): Tuple
        Validates the message with the registered validator.
    config():
        Configures the message factory.
    update_schema():
        Mutator method to update the message schema.
    message(): Dict
        Generates and validates a message.

    Example
    -------
    >>> schema = basemessageschema.BaseMessageSchema(schema_config)
    >>> validator = basevalidator.BaseValidator(validator_config)
    >>> config = {
    ...   "name": "Message factory 1",
    ...   "alias": "messagefactory1",
    ...   "type": "basemessagefactory",
    ...   "schema": schema,
    ...   "validator": validator
    ... }
    >>> mf = basemessagefactory.BaseMessageFactory(config)
    >>> header = {
    ...   "protocol_version": "0.0.1",
    ...   "sender_ip": "127.0.0.1",
    ...   "sender_port": 8001,
    ...   "dest_ip": "127.0.0.1",
    ...   "dest_port": 8002,
    ...   "type": "event"
    ... }
    >>> payload = {
    ...   "topic": "cpu",
    ...   "data": {
    ...     "percent": 51.1,
    ...     "cpu1_temp": 40.2
    ...   }
    ... }
    >>> message = mf.message(header, payload)
    """
    def __init__(self, config: Dict):
        super().__init__(config)
        self._message = {}
        self._validator = None
        self._schema = None
        self._config = None
        if config:
            self.config(config)

    def _update_header(self, message: Dict) -> Dict:
        """Adds attributes to the message header.

        Some of the attributes can optionally be generated automatically if not
        provided, these are:
          - timestamp
          - datetime
          - message_id
          - nonce

        Parameters
        ----------
        message: Dict
            The message to be populated with header attributes.
            type: str
                Message type (e.g. command, event)
            sender_ip: str
                IP address of the message sender.
            sender_port: int
                Port number of the message sender.
            sender_alias: str
                Alias of the message sender.
            dest_ip: str
                IP address of the message recipient.
            dest_port: int
                Port number of the message recipient.
            protocol_version: str
                Version of the protocol (e.g. 0.0.1).
            timestamp: float
                UNIX epoch timestamp, if not provided this is automatically
                generated.
            datetime: str
                Human readable date-time stamp, e.g. 2023-11-17 20:51:35.620139
            correlation_id: str
                Correlation ID.
            tx_correlation_id: str
                Transaction correlation ID.
            tx_id: str
                Transaction ID.
            message_id: str
                Message ID, if not provided this is automatically generated.
            nonce: str
                Message nonce, if not provided this is automatically generated.

        """
        if "timestamp" not in message or not message["timestamp"]:
            message["timestamp"] = time.time()
        if "datetime" not in message or not message["datetime"]:
            message["datetime"] = str(dt.now())
        if "message_id" not in message or not message["message_id"]:
            message["message_id"] = str(uuid.uuid4())
        if "nonce" not in message or not message["nonce"]:
            message["nonce"] = secrets.token_urlsafe()
        return message

    def _validate(self, message: Dict) -> Tuple:
        """Validates the message with the registered validator.

        Parameters
        ----------
        message: Dict
            Message to be validated.

        Returns
        -------
        result, prompt: (bool, str)
            True if validation successful, False otherwise; Validation prompt.
        """
        return self._validator.validate(message, self._schema)

    def config(self, config: Dict) -> None:
        """Configures the message.

        Parameters
        ----------
        config: Dict
            Message factory configuration.
            name: str
                Name of the message.
            alias: str
                Alias of the message.
            type: str
                Object type (basemessagefactory).
            validator: BaseValidator
                Validator object.
            schema: MessageSchema
                Message schema object.

        """
        self._config = config
        self._validator = config["validator"]
        self._schema = config["schema"]

    def update_schema(self,
                      schema: basemessageschema.BaseMessageSchema) -> None:
        """Mutator method to update the message schema.

        Parameters
        ----------
        schema: MessageSchema
            Base message schema (or child schema classes).
        """
        self._schema = schema

    def message(self, header: Dict, payload: Dict = None) -> Dict:
        """Generates and validates a message.

        Parameters
        ----------
        header: Dict
            msg_type: str
                Message type (e.g. command, event)
            sender_ip: str
                IP address of the message sender.
            sender_port: int
                Port number of the message sender.
            sender_alias: str
                Alias of the message sender.
            dest_ip: str
                IP address of the message recipient.
            dest_port: int
                Port number of the message recipient.
            protocol_version: str
                Version of the protocol (e.g. 0.0.1).
            timestamp: float
                UNIX epoch timestamp, if not provided this is automatically
                generated.
            datetime: str
                Human readable date-time stamp, e.g. 2023-11-17 20:51:35.620139
            correlation_id: str
                Correlation ID.
            tx_correlation_id: str
                Transaction correlation ID.
            tx_id: str
                Transaction ID.
            message_id: str
                Message ID, if not provided this is automatically generated.
            nonce: str
                Message nonce, if not provided this is automatically generated.
        payload: Dict
            Message payload.

        Returns
        -------
        message: Dict
            If validation passed, returns the composed message.
            If validation failed, returns a status report.

        """
        message = {}
        message.update(header)
        if payload:
            message["payload"] = payload
        message = self._update_header(message)
        validation = self._validate(message)
        if validation[0]:
            return message
        else:
            return {"status": "failure", "data": validation[1]}
