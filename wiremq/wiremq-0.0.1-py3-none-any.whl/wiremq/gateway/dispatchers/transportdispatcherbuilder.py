# -*- coding: utf-8 -*-

from typing import Dict
from wiremq.wmqsockets import (
    inboundsocket,
    outboundsocket,
)
from wiremq.dispatchers import transportdispatcher


class TransportDispatcherBuilder():
    """Build a transport dispatcher.


    Methods
    -------
    _reset(): None
        Reset the config and create a fresh dispatcher instance.
    dispatcher: object
        Returns configured dispatcher object.
    config(): None
        Configure attributes of the transport dispatcher.
    register(): None
        Register the components to the transport dispatcher.
    """

    def __init__(self) -> None:
        """Service Activator Builder constructor.

        Example
        -------
        See integration test files for an example config for the transport
        dispatcher.

        >>> td_builder = transportdispatcherbuilder.TransportDispatcherBuilder
        >>> td_builder.config(attributes)
        >>> td_builder.register(components)
        >>> transport_dispatcher = td_builder.dispatcher
        """
        super().__init__()
        self._terminator = b"\r\r\r\r"
        self._reset()

    def __str__(self):
        return 'TransportDispatcher-Builder Object'

    def _reset(self) -> None:
        """Reset the builder's component.

        This internal call refreshes the builder's currently configured
        dispatcher and creates a fresh instance of the class. The builder
        can then accept new building requests.
        """
        self._transport_dispatcher = transportdispatcher.TransportDispatcher()

    @property
    def dispatcher(self) -> transportdispatcher.TransportDispatcher:
        """This is the result of the building.

        Note
        ----
        Provided is the interface for retrieving the final product.
        After the retrieval of a configured dispatcher, the builder
        should be ready to accept new building requests. To account for
        this design, a call to the `dispatcher` property calls the internal
        `_reset()` method.
        """
        dispatcher = self._transport_dispatcher
        self._reset()
        return dispatcher

    def make_dispatcher(self, dispatcher_config: Dict) -> None:
        """Create a dispatcher and add any sockets to it.

        Parameters
        ----------
        dispatcher_config: Dict
            Transport dispatcher configuration
        """
        self.config(dispatcher_config)
        for socket_conf in dispatcher_config["sockets"]:
            self.make_socket(socket_conf)

    def make_socket(self, socket_config: Dict) -> None:
        """Create a socket.

        Parameters
        ----------
        socket_config: Dict
            Socket configuration
        """
        if socket_config["type"] == "inboundsocket":
            _socket = inboundsocket.InboundSocket(socket_config)
        elif socket_config["type"] == "outboundsocket":
            _socket = outboundsocket.OutboundSocket(socket_config)
        self._transport_dispatcher.add(_socket)

    def config(self, attributes: Dict = None) -> None:
        """Configure attributes for the transport dispatcher.

        Parameters
        ---------
        attributes : dict, required
            The attributes for the dispatcher.
            terminator: bytes
                The terminator string for messages sent via the dispatcher.
        """
        self._transport_dispatcher.config(attributes)
