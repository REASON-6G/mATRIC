# -*- coding: utf-8 -*-
import json
import yaml
import secrets
from importlib import resources
from pathlib import Path
from typing import (
    Any,
    Dict
)
from wiremq import configs


class Endpoint:
    """Base endpoint templating class.

    Holds common methods for:
        - setting endpoint name and alias throughout config
        - setting internal unix socket domains throughout config
        - setting external consumer and producer hosts and ports
        - configuring message stores

    """

    def __init__(self, config: Dict):
        """

        Parameters
        ----------
        config: Dict
            name: str
                Human-readable name of the endpoint e.g. Battery receive
                channel.
            alias: str
                Unique machine-readable name for the endpoint e.g. battrecvch.
            internal_domain: str (optional)
                Local directory path where internal domain sockets will be
                located for this endpoint (defaults to
                ~/.wiremq/domain_sockets).
            db_path: str (optional)
                For sqlite-based message stores only, local directory path
                where databases will be stored (defaults to
                ~/.wiremq/message_db).
            max_connections: int (optional used for pubsub and bus only,
                default 10)
                Maximum number of sockets that the bus endpoint connect to.
            buffer_size: int (optional, default 2048)
                Maximum buffer size for socket data transfer.
            host: str
                Hostname for inbound communication, defaults to 0.0.0.0
            advertised_host: str (optional)
                Used if the binding consumer host is different to the host
                which will be placed in "sender_ip" in outgoing messages,
            consumer_port: int
                Port number for inbound communication.
            command_host: str (optional, for pubsub channel only)
                Hostname for the command messages, defaults to 0.0.0.0
            command_port: int (optional, for pubsub channel only)
                Port number for command messages.
            producer_dest_host: str
                Destination host for the socket dispatcher in the producer
                (not required for message bus).
            producer_dest_port: int
                Destination port for the socket dispatcher in the producer
                (not required for message bus).
            durable: bool
                Flag to set whether endpoint durability is required
                (durable_config must be supplied).
            idempotent: bool
                Flag to set whether endpoint idempotency is required
                (idempotent_config must be supplied).
            auto_ack: bool
                Flag to set whether messages are automatically acknowledged
                internally by the endpoint
            add_message_id: bool (optional, default True)
                When True, adds a random 32 character hex string as a message
                id (not recommended when using service activator).
            durable_config: Dict (optional)
                Database connection configuration for the durable store.
                db_type: str
                    Type of database to use, must be one of (sqlite, mongodb,
                    mariadb, mysql)
                credentials: Dict (different for some db_types)
                    db_type=sqlite:
                    ---------------
                    db_file: str
                        Path to the sqlite database.
                    db_type!=sqlite:
                        database: str
                            Database name
                        user: str
                            Database username.
                        password: str
                            Database password.
                        host: str
                            Host name of the database.
                        port: int
                            Port number of the database.
            idempotent_config: Dict (optional)
                Database connection configuration for the idempotent store.
                Structure identical to durable_config.
            routing_table: Dict (required for router only)
                Address routing table, must be in form of sender:dest where
                each is an address with hostname:port. e.g.
                    "127.0.0.1:7051": "127.0.0.1:7052"
                    "127.0.0.1:7052": "127.0.0.1:7051"
            console_log_level: int (optional, default=21)
                Log level identifier for console logging(1: all, 10: debug,
                20: info, 21: dev, 22: test, 30: warning, 40: error,
                50: critical)
            console_log_color: str (optional)
                Controls the output color of messages in the console (black,
                red, green, yellow, blue, purple, cyan, white, bg_black,
                bg_red, bg_green, bg_yellow, bg_blue, bg_purple, bg_cyan,
                bg_white)
            file_log_level: int (optional, default 20)
                Log level identifier for file logging.
            file_log_path: str (optional)
                Destination path to output log file, if not supplied file
                logging is disabled.
        """
        self._config = config
        self._endpoint_config = self._get_template_config()
        self._update_attributes()
        self._endpoint_config = self._revert_ints(self._endpoint_config)
        self._endpoint_config = self._revert_bools(self._endpoint_config)
        self._add_durable()
        self._add_idempotent()

    def _get_template_config(self) -> Dict:
        """Gets the template config.

        Returns
        -------
        template_config: Dict


        """
        config_file = (resources.files(configs) / self._template_name)
        with config_file.open("rt") as f:
            config = yaml.safe_load(f)

        return config

    def _replace_item(self, placeholder: str, replacement: Any) -> None:
        config_str = json.dumps(self._endpoint_config)
        config_str = config_str.replace(placeholder, str(replacement))
        self._endpoint_config = json.loads(config_str)

    def _revert_ints(self, endpoint_config: Dict) -> Dict:
        """During conversion back and forth between string and dict, integers
        are converted to strings. This method parses the config, replacing
        attributes with their integer counterparts.

        This is a recursive method which calls itself in order to parse the
        nested dictionary.

        Parameters
        ----------
        endpoint_config: Dict
            The endpoint configuration dictionary.

        Returns
        -------
        endpoint_config: Dict
            The endpoint configuration dictionary required values converted
            back to integers.
        """
        for k, v in endpoint_config.items():
            if isinstance(v, dict):
                endpoint_config[k] = self._revert_ints(v)

            elif "port" in k and v.isdigit() or \
                    "console_level" in k and v.isdigit() or \
                    "file_level" in k and v.isdigit() or \
                    k == "buffer_size" and v.isdigit():
                endpoint_config[k] = int(v)
        return endpoint_config

    def _revert_bools(self, endpoint_config: Dict) -> Dict:
        """During conversion back and forth between string and dict, bools
        are converted to strings. This method parses the config, replacing
        attributes with their boolean counterparts.

        This is a recursive method which calls itself in order to parse the
        nested dictionary.

        Parameters
        ----------
        endpoint_config: Dict
            The endpoint configuration dictionary.

        Returns
        -------
        endpoint_config: Dict
            The endpoint configuration dictionary required values converted
            back to booleans.
        """
        for k, v in endpoint_config.items():
            if isinstance(v, dict):
                endpoint_config[k] = self._revert_bools(v)

            elif k == "add_id":
                endpoint_config[k] = v == "True"
        return endpoint_config

    def _make_host(self) -> str:
        """Generates a random unix hostname.

        Returns
        -------
        rtn: str
            32 character hex string.
        """
        return str(secrets.token_hex(16))

    def _log_color_map(self, color_str: str) -> str:
        """Maps human readable colors to ascii codes.

        Returns
        -------
        color: str
            ASCII color code, by default returns the reset code

        """
        if color_str == "black":
            return """\x1b[30m"""
        elif color_str == "red":
            return "\x1b[31m"
        elif color_str == "green":
            return "\x1b[32m"
        elif color_str == "yellow":
            return "\x1b[33m"
        elif color_str == "blue":
            return "\x1b[34m"
        elif color_str == "purple":
            return "\x1b[35m"
        elif color_str == "cyan":
            return "\x1b[36m"
        elif color_str == "white":
            return "\x1b[37m"
        elif color_str == "bg_black":
            return "\x1b[40m"
        elif color_str == "bg_red":
            return "\x1b[41m"
        elif color_str == "bg_green":
            return "\x1b[42m"
        elif color_str == "bg_yellow":
            return "\x1b[43m"
        elif color_str == "bg_blue":
            return "\x1b[44m"
        elif color_str == "bg_purple":
            return "\x1b[45m"
        elif color_str == "bg_cyan":
            return "\x1b[46m"
        elif color_str == "bg_white":
            return "\x1b[47m"
        else:
            return "\x1b[0m"

    def _generate_format_string(self, color: str):
        """Adds the log color to the message in the format string.

        Parameters
        ----------
        color: str
            String literal containing the ASCII color code

        Returns
        -------
        format_string: str
            Logging format string
        """
        return "%(asctime)s [%(levelname)s] (%(name)s) {%(module)s:" \
               "%(funcName)s:%(lineno)s} | " + color + "%(message)s\x1b[0m"

    def _update_attributes(self) -> None:
        """Replaces items common to all endpoints using regex replacement.

        This method should be overridden with a super() call to add
        endpoint-specific terms.
        """
        # Endpoint identifiers
        self._replace_item("EP_NAME", self._config["name"])
        self._replace_item("EP_ALIAS", self._config["alias"])

        # Address attributes
        self._replace_item("CONSUMER_HOST", self._config["host"])
        self._replace_item("CONSUMER_PORT", self._config["port"])
        self._replace_item(
            "CONSUMER_ADVERTISED_HOST",
            self._config.get(
                "advertised_host",
                self._config["host"]
            )
        )
        self._replace_item("SOCKDISPATCHER_HOST", self._make_host())
        self._replace_item("IOLOOP_HOST", self._make_host())
        self._replace_item("CONSUMER_OUTSOCK_HOST", self._make_host())
        self._replace_item("PRODUCER_HOST", self._make_host())
        self._replace_item(
            "BUFFER_SIZE", self._config.get("buffer_size", 2048))

        # Logging attributes
        self._replace_item(
            "CONSOLE_LOG_LEVEL", self._config.get("console_log_level", 21))
        self._replace_item(
            "FILE_LOG_LEVEL", self._config.get("file_log_level", 20))
        self._replace_item(
            "FILE_LOG_PATH", self._config.get("file_log_path"))

        # General configuration
        self._endpoint_config["internal_domain"] = self._config.get(
            "internal_domain",
            "{}/.wiremq/domain_sockets/".format(Path.home())
        )
        self._endpoint_config["db_path"] = self._config.get(
            "db_path",
            "{}/.wiremq/message_db/".format(Path.home())
        )

        # Other features
        self._replace_item(
            "ADD_MESSAGE_ID", self._config.get("add_message_id", True))

        # Logging
        file_log_path = self._config.get("file_log_path")
        if file_log_path:
            self._endpoint_config["logger_config"]["log_path"] = file_log_path
        log_ascii_code = \
            self._log_color_map(self._config.get("console_log_color"))
        log_format = self._generate_format_string(log_ascii_code)
        self._endpoint_config["logger_config"]["console_format"] = log_format

    def _add_durable(self) -> None:
        """Builds the durable message store config if required. Removes the
        template from the config if not required.
        """
        if self._config.get("durable", False):
            ms_config = self._endpoint_config["durable_messagestore_config"]

            # Add credentials to the messagestore config
            ms_config["db_config"]["credentials"] = \
                self._config["durable_config"]

            # Append "dbconn" to the db type
            ms_config["db_config"]["type"] = \
                self._config["durable_config"]["db_type"] + "dbconn"
        else:
            del self._endpoint_config["durable_messagestore_config"]

    def _add_idempotent(self) -> None:
        """Builds the idempotent message store config if required. Removes the
        template from the config if not required.
        """
        if self._config.get("idempotent", False):
            ms_config = self._endpoint_config["idempotent_messagestore_config"]

            # Add credentials to the messagestore config
            ms_config["db_config"]["credentials"] = \
                self._config["idempotent_config"]

            # Append "dbconn" to the db type
            ms_config["db_config"]["type"] = \
                self._config["idempotentconfig"]["db_type"] + "dbconn"
        else:
            del self._endpoint_config["idempotent_messagestore_config"]
