# -*- coding: utf-8 -*-

from typing import (
    Dict,
    Any
)
from wiremq.endpoints import messagebus
from wiremq.wmqsockets import (
    basesocket,
    inboundsocket,
    outboundsocket
)
from wiremq.processing import (
    baseprocessmanager,
    threadedscheduler,
    basethreadpool
)
from wiremq.processing.methods import pmmethod
from wiremq.extlib.queue import fifoqueue
from wiremq.extlib.asynchronous.eventloops import (
    baseioeventloop,
    ioeventloopudp,
    ioeventlooptcp
)
from wiremq.extlib.asynchronous.iopollers import iopoll
from wiremq.filters import (
    idempotentfilter,
    resequencer,
    queuedispatcher,
    sockdispatcher
)
from wiremq.consumers import baseconsumer
from wiremq.producers import baseproducer
from wiremq.translators import (
    bsoncontentdecoder,
    bsoncontentencoder,
    envelopewrapper,
    validator
)
from wiremq.message import messagefactory


class MessageBusBuilder:
    """Build a message bus.


    Methods
    -------
    _reset(): None
        Reset the config and create a fresh bus instance.
    endpoint: object
        Returns configured endpoint object.
    make_consumer(): None
        Create a consumer for the endpoint.
    make_producer(): None
        Create a producer for the endpoint.
    make_queue() None
        Create a queue for the endpoint.
    make_eventloop(): None
        Create an eventloop for the endpoint.
    make_poller(): None
        Create a poller for the endpoint.
    make_scheduler(): None
        Create a scheduler for the endpoint.
    make_threadpool(): Any
        Create a threadpool for the endpoint.
    make_socket(): None
        Create a socket.
    config(): None
        Configure attributes of the endpoint.
    register(): None
        Register the components to the endpoint.

    Attributes
    ----------
    _config : dict, optional
        Holds bus configurations.
    """

    def __init__(self) -> None:
        """Bus Builder constructor.

        Example
        -------
        See integration test director for bus' config, which
        contains an example of the fields and values required.

        >>> b_builder = messagebusbuilder.MessageBusBuilder
        >>> b_builder.config(attributes)
        >>> b_builder.register(components)
        >>> bus = b_builder.product
        """
        super().__init__()
        self._terminator = b"\r\r\r\r"
        self._processor_module_map = {
            "SD": sockdispatcher.SockDispatcher,
            "BD": bsoncontentdecoder.BSONContentDecoder,
            "BE": bsoncontentencoder.BSONContentEncoder,
            "VA": validator.Validator,
            "EW": envelopewrapper.EnvelopeWrapper,
            "IF": idempotentfilter.IdempotentFilter,
            "RQ": resequencer.Resequencer,
            "QD": queuedispatcher.QueueDispatcher
        }
        self._task_map = {
            "PM": {
                "worker": baseprocessmanager.BaseProcessManager,
                "method": pmmethod.execute,
            }
        }
        self._validator_type_map = {
            "int": int,
            "str": str
        }
        self._reset()

    def __str__(self):
        return 'Bus-Builder Object'

    def _reset(self) -> None:
        """Reset the builder's endpoint.

        This internal call refreshes the builder's current configured endpoint
        and creates a fresh instance of the class. The builder can then accept
        new building requests.
        """
        self._bus = messagebus.MessageBus()

    @property
    def product(self) -> messagebus.MessageBus:
        """This is the result of the building.

        Note
        ----
        Provided is the interface for retrieving the final product.
        After the retrieval of a configured endpoint, the builder
        should be ready to accept new building requests. To account for
        this design, a call to the `product` property calls the internal
        `_reset()` method.
        """
        bus = self._bus
        self._reset()
        return bus

    def make_consumer(self, consumer_opt: Dict) -> Any:
        """Create a consumer for the endpoint.

        Parameters
        ----------
        consumer_opt : Dict, required
            The initial consumer configuration.
        """
        _task_queue = self.make_queue(consumer_opt["task_queue_config"])
        consumer_opt["ioloop_config"]["task_queue"] = _task_queue
        consumer_opt["scheduler_config"]["task_queue"] = _task_queue
        _scheduler = self.make_scheduler(consumer_opt["scheduler_config"])
        _eventloop = self.make_eventloop(consumer_opt["ioloop_config"])
        consumer_opt["eventloop"] = _eventloop
        consumer_opt["task_queue"] = _task_queue
        consumer_opt["scheduler"] = _scheduler
        _consumer = baseconsumer.BaseConsumer(consumer_opt)
        return _consumer

    def make_producer(self, producer_opt: Dict) -> Any:
        """Create a producer for the endpoint.

        Parameters
        ----------
        producer_opt : Dict, required
            The initial producer configuration.
        """
        _task_queue = self.make_queue(producer_opt["task_queue_config"])
        producer_opt["ioloop_config"]["task_queue"] = _task_queue
        producer_opt["scheduler_config"]["task_queue"] = _task_queue
        _eventloop = self.make_eventloop(producer_opt["ioloop_config"])
        _scheduler = self.make_scheduler(producer_opt["scheduler_config"])
        producer_opt["eventloop"] = _eventloop
        producer_opt["task_queue"] = _task_queue
        producer_opt["scheduler"] = _scheduler
        messagefactory_opt = producer_opt["message_factory_config"]
        _messagefactory = messagefactory.MessageFactory(messagefactory_opt)
        producer_opt["message_factory"] = _messagefactory

        _producer = baseproducer.BaseProducer(producer_opt)
        return _producer

    def make_queue(self, queue_opt: Dict) -> fifoqueue.FifoQueue:
        """Create a queue for the endpoint.

        Parameters
        ----------
        queue_opt : Dict, required
            The initial queue configuration.
        """
        return fifoqueue.FifoQueue(queue_opt)

    def make_eventloop(self, eventloop_opt: Dict) -> \
            baseioeventloop.BaseIOEventLoop:
        """Create an eventloop for the endpoint.

        Parameters
        ----------
        eventloop_opt : Dict, required
            The initial eventloop configuration.
        """
        eventloop_opt["socket"] = self.make_socket(
            eventloop_opt["inbound_socket_config"])
        eventloop_opt["poller"] = self.make_poller(
            eventloop_opt["poller_config"])
        if "terminator" in eventloop_opt:
            eventloop_opt["terminator"] = self._terminator
        if eventloop_opt["type"] == "ioeventloopudp":
            _eventloop = ioeventloopudp.IOEventLoopUDP(eventloop_opt)
        elif eventloop_opt["type"] == "ioeventlooptcp":
            _eventloop = ioeventlooptcp.IOEventLoopTCP(eventloop_opt)
        _eventloop.initialize()
        return _eventloop

    def make_poller(self, poller_opt: Dict) -> iopoll.IOPoll:
        """Create a poller for the endpoint.

        Parameters
        ----------
        poller_opt : Dict, required
            The initial poller configuration.
        """
        return iopoll.IOPoll(poller_opt)

    def make_scheduler(self, scheduler_opt: Dict) -> \
            threadedscheduler.ThreadedScheduler:
        """Create a scheduler for the endpoint.

        Parameters
        ----------
        scheduler_opt : Dict, required
            The initial scheduler configuration.
        """
        for task in scheduler_opt["worker_map"]:
            task_config = scheduler_opt["worker_map"][task]
            worker_config_name = task_config.get("config")
            if not worker_config_name:
                worker_config_name = "worker_config"
            pmmap = scheduler_opt[worker_config_name]["processor_map"]
            for proc in pmmap.keys():
                pmmap[proc]["processor"] = self._processor_module_map[proc]
                if proc == "SD":
                    pmmap[proc]["config"]["terminator"] = self._terminator
            if task_config["method"] == "PM":
                worker_class = baseprocessmanager.BaseProcessManager
                worker_method = pmmethod.execute
            scheduler_opt["worker_map"][task] = {
                "worker": worker_class,
                "config": scheduler_opt[worker_config_name],
                "method": worker_method,
                "queue_config": scheduler_opt[worker_config_name][
                    "processor_queue_config"]
            }
        _threadpool = self.make_threadpool(scheduler_opt["threadpool_config"])
        _scheduler = threadedscheduler.ThreadedScheduler(
            scheduler_opt, _threadpool, scheduler_opt["task_queue"]
        )
        return _scheduler

    def make_threadpool(self, threadpool_opt: Dict) -> \
            basethreadpool.BaseThreadPool:
        """Create a threadpool for the endpoint.

        Parameters
        ----------
        threadpool_opt : Dict, required
            The initial threadpool configuration.
        """
        return basethreadpool.BaseThreadPool(threadpool_opt)

    def make_socket(self, socket_config: Dict) -> basesocket.BaseSocket:
        """Create a socket.

        Parameters
        ----------
        socket_config: Dict
            Socket configuration
        """
        if socket_config["type"] == "inboundsocket":
            _socket = inboundsocket.InboundSocket(socket_config)
        elif socket_config["type"] == "outboundsocket":
            _socket = outboundsocket.OutboundSocket(socket_config)
        return _socket

    def make_processmanager(self, processmanager_opt: Dict) -> \
            baseprocessmanager.BaseProcessManager:
        """Create a process manager for the endpoint.

        Parameters
        ----------
        processmanager_opt : Dict, required
            The initial process manager configuration.
        """
        pmmap = processmanager_opt["processor_map"]
        for proc in pmmap.keys():
            pmmap[proc]["processor"] = self._processor_module_map[proc]
            if proc == "SD" and "terminator" in pmmap[proc]["config"]:
                pmmap[proc]["config"]["terminator"] = self._terminator
        pm = baseprocessmanager.BaseProcessManager(processmanager_opt)
        return pm

    def set_connections(self, connections_opt: list) -> list:
        """Converts the list of destinations from a list of strings to a list
        of tuples

        Parameters
        ----------
        connections_opt: list
            List of strings representing the initial destinations for the
            message bus, e.g. ['127.0.0.1:7000']

        Returns
        -------
        destinations: list
            List of tuples containing the destination addresses. e.g.
            [('127.0.0.1', 7000)]
        """
        connections = []
        for connection in connections_opt:
            host, port = connection.split(":")
            port = int(port)
            connections.append((host, port))
        return connections

    def config(self, attributes: Dict = None) -> None:
        """Configure attributes for the endpoint.

        Parameters
        ---------
        attributes : dict, required
            The attributes for the endpoint.
        """
        self._bus.config(attributes)

    def register(self, components: Dict = None) -> None:
        """Register the components to the endpoint.

        Parameters
        ----------
        components : dict, required
            The components to be added.
            task_queue: Queue, required
            response_handler: Handler, required
            eventloop: eventloop, required
            send_queue: Queue, required
            consumers: list, required
            producers: list, required
        """
        self._bus.register(components)
