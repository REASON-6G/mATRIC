# -*- coding: utf-8 -*-
from typing import (
    Dict
)

from wiremq.gateway.endpoints import (
    endpointdirector,
    messagebusbuilder
)
from wiremq.endpoints import messagebus
from wiremq.gateway.endpoints import endpoint


class MessageBus(endpoint.Endpoint):
    """Base endpoint templating class.

    Holds common methods for:
        - setting endpoint name and alias throughout config
        - setting internal unix socket domains throughout config
        - setting external consumer and producer hosts and ports
        - configuring message stores

    """

    def __init__(self, config: Dict):
        """

        Parameters
        ----------
        config: Dict
            name: str
                Human-readable name of the endpoint e.g. Battery receive
                channel.
            alias: str
                Unique machine-readable name for the endpoint e.g. battrecvch.
            connections: list
                A list of pre-configured connections for the other bus
                endpoints. Each list entry must follow the format "host:port",
                e.g. "127.0.0.1:8000".
            max_connections: int (optional, default 10)
                Maximum number of sockets that the bus can connect to.
            buffer_size: int (optional, default 2048)
                Maximum buffer size for socket data transfer.
            internal_domain: str (optional)
                Local directory path where internal domain sockets will be
                located for this endpoint (defaults to
                ~/.wiremq/domain_sockets).
            db_path: str (optional)
                For sqlite-based message stores only, local directory path
                where databases will be stored (defaults to
                ~/.wiremq/message_db).
            consumer_host: str
                Hostname for the consumer, defaults to 0.0.0.0
            advertised_consumer_host: str (optional)
                Used if the binding consumer host is different to the host
                which will be placed in "sender_ip" in outgoing messages,
            consumer_port: int
                Port number for the consumer.
            commandconsumer_host: str (optional, for pubsub channel only)
                Hostname for the command consumer, defaults to 0.0.0.0
            commandconsumer_port: int (optional, for pubsub channel only)
                Port number for the command consumer.
            producer_dest_host: str
                Destination host for the socket dispatcher in the producer
                (not required for message bus).
            producer_dest_port: int
                Destination port for the socket dispatcher in the producer
                (not required for message bus).
            durable: bool
                Flag to set whether endpoint durability is required
                (durable_config must be supplied).
            idempotent: bool
                Flag to set whether endpoint idempotency is required
                (idempotent_config must be supplied).
            auto_ack: bool
                Flag to set whether messages are automatically acknowledged
                internally by the endpoint.
            add_message_id: bool (optional, default True)
                When True, adds a random 32 character hex string as a message
                id (not recommended when using service activator).
            durable_config: Dict (optional)
                Database connection configuration for the durable store.
                db_type: str
                    Type of database to use, must be one of (sqlite, mongodb,
                    mariadb, mysql)
                credentials: Dict (different for some db_types)
                    db_type=sqlite:
                    ---------------
                    db_file: str
                        Path to the sqlite database.
                    db_type!=sqlite:
                        database: str
                            Database name
                        user: str
                            Database username.
                        password: str
                            Database password.
                        host: str
                            Host name of the database.
                        port: int
                            Port number of the database.
            idempotent_config: Dict (optional)
                Database connection configuration for the idempotent store.
                Structure identical to durable_config.
            console_log_level: int (optional, default=21)
                Log level identifier for console logging(1: all, 10: debug,
                20: info, 21: dev, 22: test, 30: warning, 40: error,
                50: critical)
            console_log_color: str (optional)
                Controls the output color of messages in the console (black,
                red, green, yellow, blue, purple, cyan, white, bg_black,
                bg_red, bg_green, bg_yellow, bg_blue, bg_purple, bg_cyan,
                bg_white)
            file_log_level: int (optional, default 20)
                Log level identifier for file logging.
            file_log_path: str (optional)
                Destination path to output log file, if not supplied file
                logging is disabled.
        """
        self._template_name = "messagebus_template.yaml"
        self._endpoint_config = None
        super().__init__(config)

    def build(self) -> messagebus.MessageBus:
        """Uses the config and the endpoint director to build the endpoint.

        Returns
        -------

        """
        messagebus_builder = messagebusbuilder.MessageBusBuilder
        endpoint_director = endpointdirector.EndpointDirector()
        endpoint_director.register_builders({
            "messagebusbuilder": messagebus_builder
        })
        messagebus = endpoint_director.build(self._endpoint_config, "messagebus")
        return messagebus

    def _update_attributes(self) -> None:
        """Adds messagebus-specific replacements to the config.
        """
        super()._update_attributes()
        self._endpoint_config["connections"] = self._config["connections"]
        self._replace_item(
            "MAX_SOCKETS", self._config.get("max_connections", 10))
