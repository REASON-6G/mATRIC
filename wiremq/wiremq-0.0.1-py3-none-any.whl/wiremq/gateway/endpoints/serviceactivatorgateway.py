# -*- coding: utf-8 -*-
from pathlib import Path
from typing import (
    Dict
)
from wiremq.utils import dbtools
from wiremq.gateway.endpoints import (
    endpointdirector,
    serviceactivatorbuilder
)
from wiremq.endpoints import serviceactivator
from wiremq.gateway.endpoints import endpointgateway


class ServiceActivatorGateway(endpointgateway.EndpointGateway):
    """Service activator templating class.

    Uses the base endpoint building class and supplements with
    serviceactivator-specific attributes.

    Methods
    -------
    _build_asgi_app_config(): Dict
        Assembles the config for the ASGI app/HTTP request handler.
    _build_transaction_store_config(): Dict
        Assembles the configuration for the Transaction Store of the Service
        Activator.
    _build_history_store_config(): Dict
        Assembles the configuration for the History Store of the Service
        Activator.
    _build_requesthandlers_config(): Dict
        Assembles the configuration for the Request Handler and the
        Response Handler.
    _build_default_producer_envelopewrapper_config(): Dict
        Assembles a default user configuration for the Producer's Envelope
        Wrapper.
    _build_config():
        Overrides the _build_config method of the main endpoint gateway,
        adds configs for the ASGI app, additional message stores, and other
        Service Activator specific attributes.
    build(): ServiceActivator
        Uses the config and the endpoint director to build the endpoint.
    """
    def __init__(self, config: Dict):
        """

        Parameters
        ----------
        config: Dict
            name: str
                Human-readable name of the endpoint e.g. Battery receive
                channel.
            alias: str
                Unique machine-readable name for the endpoint e.g. battrecvch.
            http_host: str
                Host name for the HTTP facing interface.
            http_port: int
                Port number for the HTTP facing interface
            use_http: bool (optional, default = False)
                Flag to denote use of HTTPS (True: HTTPS, False, HTTP).
            ssl_keyfile: str (only required if use_http==True)
                Full path to SSL Key File.
            ssl_certfile: str( only required if use_http==True)
                Full path to SSL Certificate File.
            services: dict
                Describes the API for services and takes the form of a 2-level
                dictionary. The first level is the general topic, then the
                second layer is made up of a list of strings which form the
                specific interfaces. For example:
                    {
                      "battery": ["get_voltage", "get_current"],
                      "ue": ["ue_paired", "ue_unpair"]
                    }
                Requests which fall outside these parameters are automatically
                rejected. The application implements the logic of these
                interfaces.
            internal_domain: str (optional)
                Local directory path where internal domain sockets will be
                located for this endpoint (defaults to
                ~/.wiremq/domain_sockets).
            db_path: str (optional)
                For sqlite-based message stores only, local directory path
                where databases will be stored (defaults to
                ~/.wiremq/message_db).
            consumer_host: str
                Hostname for the consumer, defaults to 0.0.0.0
            advertised_consumer_host: str (optional)
                Used if the binding consumer host is different to the host
                which will be placed in "sender_ip" in outgoing messages,
            consumer_port: int
                Port number for the consumer.
            producer_dest_host: str
                Destination host for the socket dispatcher in the producer
                (not required for message bus).
            producer_dest_port: int
                Destination port for the socket dispatcher in the producer
                (not required for message bus).
            durable: bool
                Flag to set whether endpoint durability is required
                (durable_config must be supplied).
            idempotent: bool
                Flag to set whether endpoint idempotency is required
                (idempotent_config must be supplied).
            auto_ack: bool
                Flag to set whether messages are automatically acknowledged
                internally by the endpoint.
            add_message_id: bool (optional, default True)
                When True, adds a random 32 character hex string as a message
                id (not recommended when using service activator).
            durable_config: Dict (optional)
                Database connection configuration for the durable store.
                db_type: str
                    Type of database to use, must be one of (sqlite, mongodb,
                    mariadb, mysql)
                credentials: Dict (different for some db_types)
                    db_type=sqlite:
                    ---------------
                    db_file: str
                        Path to the sqlite database.
                    db_type!=sqlite:
                        database: str
                            Database name
                        user: str
                            Database username.
                        password: str
                            Database password.
                        host: str
                            Host name of the database.
                        port: int
                            Port number of the database.
            idempotent_config: Dict (optional)
                Database connection configuration for the idempotent store.
                Structure identical to durable_config.
            console_log_level: int (optional, default=21)
                Log level identifier for console logging(1: all, 10: debug,
                20: info, 21: dev, 22: test, 30: warning, 40: error,
                50: critical)
            console_log_color: str (optional)
                Controls the output color of messages in the console (black,
                red, green, yellow, blue, purple, cyan, white, bg_black,
                bg_red, bg_green, bg_yellow, bg_blue, bg_purple, bg_cyan,
                bg_white)
            file_log_level: int (optional, default 20)
                Log level identifier for file logging.
            file_log_path: str (optional)
                Destination path to output log file, if not supplied file
                logging is disabled.

        """
        self._endpoint_config = None
        self._internal_domain = None
        self._db_path = None
        self._requesthandler_host = self._make_host()
        self._requesthandler_outsock_host = self._make_host()
        self._responsehandler_outsock_host = self._make_host()
        super().__init__(config)

    def _build_asgi_app_config(self, parent_alias: str) -> Dict:
        """Assembles the config for the ASGI app/HTTP request handler.

        The ASGI app is configured with a BSON encoder and a Socket Dispatcher
        which forwards messages to the Service Activator's IO Loop.

        Parameters
        ----------
        parent_alias:
            Alias of the parent component (e.g. serviceactivator1)

        Returns
        -------
        asgi_app_config: Dict
            Assembled configuration for the ASGI app.

        """
        processors = {
            "encoder": {},
            "sockdispatcher": {
                "socket_type": "outboundsocket",
                "protocol": "udp",
                "family": "unix",
                "dest_ip": self._ioloop_host,
                "host": self._make_host()
            }
        }
        internal_domain = self._config.get(
            "internal_domain",
            "{}/.wiremq/domain_sockets/".format(Path.home())
        )
        config = {
            "name": f"ASGI server for {parent_alias}",
            "alias": f"asgi_app_{parent_alias}",
            "logger": f"{self._config['alias']}_logger",
            "host": self._config["http_host"],
            "port": self._config["http_port"],
            "allow_cross_site": True,
            "internal_domain": internal_domain,
            "processmanager_config": {
                "name": f"Process manager for asgi_app_{parent_alias}",
                "alias": f"processmanager_asgi_app_{parent_alias}",
                "logger": f"{self._config['alias']}_logger",
                "transport_type": "channel",
                "processor_map": self._build_processor_map(
                    f"asgi_app_{parent_alias}",
                    processors),
                "processor_chain": ["BE", "SD"],
                "processor_queue_config": self._build_queue_config(
                    "processor", self._config["alias"]),
                "processor_queue": None
            },
            "ioloop_config": self._build_ioloop_config(
                f"asgi_app_{parent_alias}",
                "udp",
                "unix",
                ""
            ),
            "task_queue_config": self._build_queue_config(
                "task",
                f"asgi_app_{parent_alias}"
            )
        }
        return config

    def _build_transaction_store_config(self) -> Dict:
        """Assembles the configuration for the Transaction Store of the Service
        Activator.

        The user config for the transaction store is optional, if not provided
        then a default sqlite database is created at ~/.wiremq/message_db

        Returns
        -------
        transactionstore_config: Dict
            Assembled transaction store config.
        """
        messagestore_config = self._config.get("transaction_store_config")
        if messagestore_config:
            db_type = f"{messagestore_config['db_type']}dbconn"
            credentials = messagestore_config["credentials"]
        else:
            db_type = "sqlitedbconn"
            credentials = {
                "db_file": f"{self._config['alias']}_transactions.db"
            }
        config = {
            "name": f"Transaction message store for {self._config['alias']}",
            "alias": f"transaction_messagestore_{self._config['alias']}",
            "logger": f"{self._config['alias']}_logger",
            "db_table": "transactions",
            "id_field": "transaction_id",
            "id_type": "CHAR(16)",
            "fields": [
                {"name": "transaction_data", "type": "CHAR"},
                {"name": "transaction_time", "type": "CHAR"}
            ],
            "db_config": {
                "name": f"DB connection for transaction_messagestore_"
                        f"{self._config['alias']}",
                "alias": f"transactiondbconn_transaction_messagestore_"
                         f"{self._config['alias']}",
                "logger": f"{self._config['alias']}_logger",
                "type": db_type,
                "credentials": credentials,
                "db": None,
            },
        }
        if config["db_config"]["type"] == "sqlitedbconn":
            config["db_config"]["check_same_thread"] = False
            dbtools.sqlite_create_table(
                config,
                self._db_path
            )
        return config

    def _build_history_store_config(self) -> Dict:
        """Assembles the configuration for the History Store of the Service
        Activator.

        The user config for the history store is optional, if not provided
        then a default sqlite database is created at ~/.wiremq/message_db

        Returns
        -------
        historystore_config: Dict
            Assembled history store config.
        """
        messagestore_config = self._config.get("history_store_config")
        if messagestore_config:
            db_type = f"{messagestore_config['db_type']}dbconn"
            credentials = messagestore_config["credentials"]
        else:
            db_type = "sqlitedbconn"
            credentials = {
                "db_file": f"{self._config['alias']}_history.db"
            }
        config = {
            "name": f"History message store for {self._config['alias']}",
            "alias": f"history_messagestore_{self._config['alias']}",
            "logger": f"{self._config['alias']}_logger",
            "db_table": "history",
            "id_field": "message_id",
            "id_type": "CHAR(16)",
            "fields": [
                {"name": "message_data", "type": "CHAR"},
                {"name": "message_time", "type": "CHAR"}
            ],
            "db_config": {
                "name": f"DB connection for history_messagestore_"
                        f"{self._config['alias']}",
                "alias": f"transactiondbconn_history_messagestore_"
                         f"{self._config['alias']}",
                "logger": f"{self._config['alias']}_logger",
                "type": db_type,
                "credentials": credentials,
                "db": None,
            }
        }
        if config["db_config"]["type"] == "sqlitedbconn":
            config["db_config"]["check_same_thread"] = False
            dbtools.sqlite_create_table(
                config,
                self._db_path
            )
        return config

    def _build_requesthandlers_config(self) -> Dict:
        """"Assembles the configuration for the Request Handler and the
        Response Handler.

        No user config is required for these components, this method connects
        various internal components together.

        Returns
        -------
        requesthandlers_config: Dict
            Assembled configuration for the request handlers.
        """
        config = {
            "requesthandler_config": {
                "name": f"Request handler for {self._config['alias']}",
                "alias": f"requesthandler_{self._config['alias']}",
                "logger": f"{self._config['alias']}_logger",
                "type": "requesthandler",
                "path": "request",
                "dest_ip": self._producer_host,
                "inbound_socket_config": self._build_inbound_socket_config(
                    f"requesthandler_{self._config['alias']}",
                    "udp",
                    "unix",
                    self._requesthandler_host
                ),
                "dispatcher_config": {
                    "name": f"Transport dispatcher for requesthandler_"
                            f"{self._config['alias']}",
                    "alias": f"dispatcher_requesthandler_"
                             f"{self._config['alias']}",
                    "logger": f"{self._config['alias']}_logger",
                    "type": "transportdispatcher",
                    "transport_type": "socket",
                    "terminator": "\r\r\r\r",
                    "outsocket_config": self._build_outbound_socket_config(
                        f"dispatcher_requesthandler_{self._config['alias']}",
                        "udp",
                        "unix",
                        self._requesthandler_outsock_host
                    )
                }
            },
            "responsehandler_config": {
                "name": f"Response handler for {self._config['alias']}",
                "alias": f"responsehandler_{self._config['alias']}",
                "logger": f"{self._config['alias']}_logger",
                "path": "response",
                "dispatcher_config": {
                    "name": f"Transport dispatcher for responsehandler_"
                            f"{self._config['alias']}",
                    "alias": f"dispatcher_responsehandler_"
                             f"{self._config['alias']}",
                    "logger": f"{self._config['alias']}_logger",
                    "type": "transportdispatcher",
                    "transport_type": "socket",
                    "terminator": "\r\r\r\r",
                    "outsocket_config": self._build_outbound_socket_config(
                        f"dispatcher_responsehandler_{self._config['alias']}",
                        "udp",
                        "unix",
                        self._responsehandler_outsock_host
                    )
                }
            }
        }
        return config

    def _build_default_producer_envelopewrapper_config(self) -> Dict:
        """Assembles a default user configuration for the Producer's Envelope
        Wrapper.

        Returns
        -------
        envelopewrapper_config: Dict
            Default Envelope Wrapper config.
        """
        return {
            "add_message_id": False,
            "header": {
                "sender_ip": self._consumer_host,
                "sender_port": self._consumer_port,
                "sender_alias": self._config["alias"],
                "dest_ip": self._config["dest_host"],
                "dest_port": self._config["dest_port"],
            }
        }

    def _build_config(self) -> None:
        """Overrides the _build_config method of the main endpoint gateway,
        adds configs for the ASGI app, additional message stores, and other
        Service Activator specific attributes.
        """
        super()._build_config()
        self._endpoint_config["http_host"] = self._config["http_host"]
        self._endpoint_config["http_port"] = self._config["http_port"]
        self._endpoint_config["httpserver_config"] = {
            "host": self._config["http_host"],
            "port": self._config["http_port"]
        }
        self._endpoint_config["use_https"] = \
            self._config.get("use_https", False)
        self._endpoint_config["ssl_keyfile"] = \
            self._config.get("ssl_keyfile")
        self._endpoint_config["ssl_certfile"] = \
            self._config.get("ssl_certfile")
        self._endpoint_config["asgi_app_config"] = \
            self._build_asgi_app_config(self._config["alias"])
        self._endpoint_config["transaction_messagestore_config"] = \
            self._build_transaction_store_config()
        self._endpoint_config["history_messagestore_config"] = \
            self._build_history_store_config()
        self._endpoint_config["message_queue_config"] = \
            self._build_queue_config("message", self._config["alias"])
        self._endpoint_config["request_handlers"] = \
            self._build_requesthandlers_config()
        self._endpoint_config["services"] = self._config["services"]
        self._endpoint_config["asgi_app_config"]["internal_domain"] = \
            self._internal_domain
        self._endpoint_config["asgi_app_config"]["ioloop_config"][
            "internal_domain"] = self._internal_domain

    def build(self) -> serviceactivator.ServiceActivator:
        """Uses the config and the endpoint director to build the endpoint.

        Returns
        -------
        serviceactivator: ServiceActivator
            Service Activator endpoint instance.
        """
        serviceactivator_builder = \
            serviceactivatorbuilder.ServiceActivatorBuilder
        endpoint_director = endpointdirector.EndpointDirector()
        endpoint_director.register_builders({
            "serviceactivatorbuilder": serviceactivator_builder
        })
        serviceactivator = \
            endpoint_director.build(self._endpoint_config, "serviceactivator")
        return serviceactivator
