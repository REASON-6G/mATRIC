# -*- coding: utf-8 -*-

from typing import Dict
from wiremq.utils.configtools import initialize_unix_sockets
from wiremq.wmqsockets import inboundsocket
from wiremq.extlib.asynchronous.eventloops import ioeventloopudp
from wiremq.extlib.asynchronous.iopollers import iopoll


class IOEventLoopUDPBuilder:
    """Build a UDP IOEventLoop.

    Methods
    -------
    _reset(): None
        Reset the config and create a fresh product instance.
    product: object
        Returns configured eventloop object.
    make_eventloop(): None
        Create an eventloop.
    config(): None
        Configure attributes of the eventloop.
    """

    def __init__(self) -> None:
        """IOEventLoopUDP Builder constructor.

        Example
        -------
        See integration test files for IOEventLoopUDP's config, which
        contains an example of the fields and values required.

        >>> el_builder = ioeventloopbuilder.IOEventLoopUDPBuilder
        >>> el_builder.make_eventloop(eventloop_config)
        >>> eventloop = el_builder.product
        """
        super().__init__()
        self._reset()

    def __str__(self):
        return 'IOEventLoopUDP-Builder Object'

    def _reset(self) -> None:
        """Reset the builder's endpoint.

        This internal call refreshes the builder's current configured product
        and creates a fresh instance of the class. The builder can then accept
        new building requests.
        """
        self._eventloop = ioeventloopudp.IOEventLoopUDP()

    @property
    def product(self) -> ioeventloopudp.IOEventLoopUDP:
        """This is the result of the building.

        Note
        ----
        Provided is the interface for retrieving the final product.
        After the retrieval of a configured endpoint, the builder
        should be ready to accept new building requests. To account for
        this design, a call to the `product` property calls the internal
        `_reset()` method.
        """
        eventloop = self._eventloop
        self._reset()
        return eventloop

    def make_eventloop(self, eventloop_opt: Dict) -> None:
        """Create an eventloop.

        For unix sockets, the domain is initialized.

        Terminator is converted to bytes.

        Parameters
        ----------
        eventloop_opt : Dict, required
            The initial eventloop configuration.
        """
        if eventloop_opt["inbound_socket_config"]["family"] == "unix":
            _eventloop_domain = eventloop_opt["internal_domain"]
            eventloop_opt = \
                initialize_unix_sockets(eventloop_opt, _eventloop_domain)
        eventloop_opt["socket"] = inboundsocket.InboundSocket(
            eventloop_opt["inbound_socket_config"]
        )
        eventloop_opt["poller"] = iopoll.IOPoll(
            eventloop_opt["poller_config"]
        )
        if "terminator" in eventloop_opt:
            if isinstance(eventloop_opt["terminator"], str):
                eventloop_opt["terminator"] = \
                    eventloop_opt["terminator"].encode("utf")
            else:
                eventloop_opt["terminator"] = b"\r\r\r\r"
        self.config(eventloop_opt)

    def config(self, attributes: Dict = None) -> None:
        """Configure attributes for the product.

        Parameters
        ---------
        attributes : dict, required
            The attributes for the product.
        """
        self._eventloop.config(attributes)
