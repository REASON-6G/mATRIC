# -*- coding: utf-8 -*-

from typing import Dict
from wiremq.processing import baseprocessmanager
from wiremq.filters import (
    idempotentfilter,
    resequencer,
    sockdispatcher
)
from wiremq.translators import (
    httpparser,
    httpformatter,
    bsoncontentdecoder,
    bsoncontentencoder,
    envelopewrapper,
    validator
)


class BaseProcessManagerBuilder():
    """Build a base process manager.

    Methods
    -------
    _reset(): None
        Reset the config and create a fresh product instance.
    make_processmanager(): None
        Create a process manager.
    config(): None
        Configure attributes of the process manager.
    """

    def __init__(self) -> None:
        """Base Process Manager Builder constructor.

        Example
        -------
        See integration test files for process manager's config, which
        contains an example of the fields and values required.

        >>> pm_builder = baseprocessmanagerbuilder.BaseProcessManagerBuilder
        >>> pm_builder.make_processmanager(config)
        >>> process_manager = pm_builder.product
        """
        super().__init__()
        self._terminator = b"\r\r\r\r"
        self._processor_module_map = {
            "SD": sockdispatcher.SockDispatcher,
            "HF": httpformatter.HTTPFormatter,
            "HP": httpparser.HTTPParser,
            "BD": bsoncontentdecoder.BSONContentDecoder,
            "BE": bsoncontentencoder.BSONContentEncoder,
            "VA": validator.Validator,
            "EW": envelopewrapper.EnvelopeWrapper,
            "IF": idempotentfilter.IdempotentFilter,
            "RQ": resequencer.Resequencer
        }
        self._reset()

    def __str__(self):
        return 'ProcessManager-Builder Object'

    def _reset(self) -> None:
        """Reset the builder's product.

        This internal call refreshes the builder's current configured product
        and creates a fresh instance of the class. The builder can then accept
        new building requests.
        """
        self._process_manager = baseprocessmanager.BaseProcessManager()

    @property
    def product(self) -> baseprocessmanager.BaseProcessManager:
        """This is the result of the building.

        Note
        ----
        Provided is the interface for retrieving the final product.
        After the retrieval of a configured product, the builder
        should be ready to accept new building requests. To account for
        this design, a call to the `product` property calls the internal
        `_reset()` method.
        """
        process_manager = self._process_manager
        self._reset()
        return process_manager

    def make_processmanager(self, processmanager_opt: Dict) -> None:
        """Create a process manager.

        Parameters
        ----------
        processmanager_opt : Dict, required
            The initial process manager configuration.
        """
        pmmap = processmanager_opt["processor_map"]
        for proc in pmmap.keys():
            pmmap[proc]["processor"] = self._processor_module_map[proc]
            if proc == "SD" and "terminator" in pmmap[proc]["config"]:
                pmmap[proc]["config"]["terminator"] = self._terminator
        self.config(processmanager_opt)

    def config(self, attributes: Dict = None) -> None:
        """Configure attributes for the process manager.

        Parameters
        ---------
        attributes : dict, required
            The attributes for the process manager.
        """
        self._process_manager.config(attributes)
