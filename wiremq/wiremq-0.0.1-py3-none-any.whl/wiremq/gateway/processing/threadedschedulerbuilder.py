# -*- coding: utf-8 -*-

from typing import Dict
from wiremq.wmqsockets import outboundsocket
from wiremq.processing import (
    threadedscheduler,
    basethreadpool,
    baseprocessmanager
)
from wiremq.processing.methods import pmmethod
from wiremq.filters import (
    idempotentfilter,
    resequencer,
    sockdispatcher
)
from wiremq.translators import (
    httpparser,
    httpformatter,
    bsoncontentdecoder,
    bsoncontentencoder,
    envelopewrapper,
    validator
)


class ThreadedSchedulerBuilder():
    """Build a threaded scheduler.


    Methods
    -------
    _reset(): None
        Reset the config and create a fresh product instance.
    make_scheduler(): None
        Create a scheduler.
    config(): None
        Configure attributes of the scheduler.
    register(): None
        Register components of the scheduler.
    """

    def __init__(self) -> None:
        """Threaded Scheduler Builder constructor.

        Example
        -------
        See integration test files for threaded scheduler's config, which
        contains an example of the fields and values required.

        >>> ts_builder = threadedschedulerbuilder.ThreadedSchedulerBuilder
        >>> ts_builder.make_scheduler(config)
        >>> scheduler = ts_builder.product
        """
        super().__init__()
        self._terminator = b"\r\r\r\r"
        self._processor_module_map = {
            "SD": sockdispatcher.SockDispatcher,
            "HF": httpformatter.HTTPFormatter,
            "HP": httpparser.HTTPParser,
            "BD": bsoncontentdecoder.BSONContentDecoder,
            "BE": bsoncontentencoder.BSONContentEncoder,
            "VA": validator.Validator,
            "EW": envelopewrapper.EnvelopeWrapper,
            "IF": idempotentfilter.IdempotentFilter,
            "RQ": resequencer.Resequencer
        }
        self._task_map = {
            "PM": {
                "worker": baseprocessmanager.BaseProcessManager,
                "method": pmmethod.execute,
            }
        }
        self._reset()

    def __str__(self):
        return 'ThreadedScheduler-Builder Object'

    def _reset(self) -> None:
        """Reset the builder's product.

        This internal call refreshes the builder's current configured product
        and creates a fresh instance of the class. The builder can then accept
        new building requests.
        """
        self._scheduler = threadedscheduler.ThreadedScheduler()

    @property
    def product(self) -> threadedscheduler.ThreadedScheduler:
        """This is the result of the building.

        Note
        ----
        Provided is the interface for retrieving the final product.
        After the retrieval of a configured product, the builder
        should be ready to accept new building requests. To account for
        this design, a call to the `product` property calls the internal
        `_reset()` method.
        """
        scheduler = self._scheduler
        self._reset()
        return scheduler

    def make_scheduler(self, scheduler_opt: Dict) -> None:
        """Create a scheduler.

        Parameters
        ----------
        scheduler_opt : Dict, required
            The initial scheduler configuration.
        """
        pmmap = scheduler_opt["worker_config"]["processor_map"]
        for proc in pmmap.keys():
            pmmap[proc]["processor"] = self._processor_module_map[proc]
            if proc == "SD" and "terminator" in pmmap[proc]["config"]:
                pmmap[proc]["config"]["terminator"] = self._terminator
            if "outbound_socket_config" in pmmap[proc]:
                pmmap[proc]["config"]["outbound"] = outboundsocket.\
                    OutboundSocket(pmmap[proc]["outbound_socket_config"])
        for task in scheduler_opt["worker_map"]:
            scheduler_opt["worker_map"][task] = {
                "worker": self._task_map[scheduler_opt["worker_map"][
                    task]["worker"]]["worker"],
                "config": scheduler_opt["worker_config"],
                "method": self._task_map[scheduler_opt["worker_map"][
                    task]["method"]]["method"],
                "queue_config": scheduler_opt["worker_config"][
                    "processor_queue_config"]
            }
        _threadpool = basethreadpool.BaseThreadPool(
            scheduler_opt["threadpool_config"]
        )
        self.config(scheduler_opt)
        self.register({"threadpool": _threadpool,
                       "task_queue": scheduler_opt["task_queue"]})

    def config(self, attributes: Dict = None) -> None:
        """Configure attributes for the scheduler.

        Parameters
        ---------
        attributes : dict, required
            The attributes for the scheduler.
        """
        self._scheduler.config(attributes)

    def register(self, components: Dict = None) -> None:
        """Register the components to the scheduler.

        Parameters
        ----------
        components : dict, required
            The components to be added.
            threadpool: list, required
            task_queue: Queue, required
        """
        self._scheduler.register(components["threadpool"],
                                 components["task_queue"])
