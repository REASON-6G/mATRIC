# -*- coding: utf-8 -*-
from typing import (
    Any,
    Dict
)
import uuid
import json
import bson
import logging
from wiremq.utils import iotask
from wiremq.producers import abstractproducer
from wiremq.extlib.err.processingexception import ThreadedSchedulerException
from wiremq.extlib.err.producerexceptions import BaseProducerException


class BaseProducer(abstractproducer.AbstractProducer):
    """Base producer class.

    Attributes
    ----------
    _config: Dict
        The producer configuration dictionary
    _message_store: MessageStore
        The message store for the producer.
    _eventloop: IOEventLoop
        The event loop for the producer used to poll for events.
    _scheduler: Scheduler
        The scheduler used to schedule and execute tasks.
    _transactional_client: TransactionalClient
        The transactional client for the producer.
    _scheduled_tasks: queue
        Used to store tasks after polling through the eventloop.
    _registered: bool
        Flag denoting if producer components are registered.
    _listening: bool
        Flag denoting if producer is in a listening state.
    _message_factory: object
        Message factory used for producing messages.
    _log: object
        Python logging instance.

    Methods
    -------
    _create_task(): None
        Creates a single IO-Task.
    send_ack(): None
        Composes and sends an acknowledgement message.
    produce(): None
        Composes and dispatches a message.
    _execute_scheduled(): list
        Uses the registered scheduler to get the scheduled tasks and
        execute them.
    _loop(): list
        Loops over the io poller.
    _loop_once(): list
        Loops once over the io poller.
    store_message(): bool
        Saves message to a Message Store
    remove_message(): bool
        Removes message from a message store.
    get_message():
        Retrieves a message from a message store.
    process(): Dict
        Defines the processing sequence of the Producer.
    get_config(): Dict
        Getter for the producer config.
    register(): bool
        Registers components to the base producer.
    unregister(): bool
        Unregisters components from the base producer.
    run(): Object
        Overrides io engine's run method.
    run_once(): object
        Overrides io engine's run_once method.
    get_task_stack(): list
        Gets the active tasks to be executed.
    """

    def __init__(self, config: Dict = None):
        """Base Producer class constructor.

        Parameters
        ----------
        config: Dict
            type: str
                The producer type
            alias: str
                Alias of the base producer
            name: str
                Name of the base producer
            uid: hash
                Identification number
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> config = {
        ...     "name": "Test producer",
        ...     "alias": "testproducer",
        ...     "message_store": None,
        ...     "eventloop": None,
        ...     "scheduler": None,
        ...     "transactional_client": None,
        ... }
        >>> message_store= messagestore.MessageStore(message_store_config)
        >>> eventloop = ioeventloopudp.IOEventLoopUDP(ioloop_config)
        >>> scheduler = threadedscheduler.ThreadedScheduler(scheduler_config)
        >>> txclient = transactionalclient.TransactionalClient(txclient_config)
        >>> config["message_store"] = message_store
        >>> config["eventloop"] = eventloop
        >>> config["scheduler"] = scheduler
        >>> config["transactional_client"] = txclient
        >>> base_producer = baseproducer.BaseProducer(config)
        """
        super().__init__(config)
        self._id = self._generate_id()
        self._config = None
        self._message_factory = None
        self._message_store = None
        self._eventloop = None
        self._scheduler = None
        self._transactional_client = None
        self._scheduled_tasks = None
        self._registered = False
        self._listening = False
        self._log = None
        if config:
            self.register(config)

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def _create_task(self, _b: bytes, task_name: str) -> object:
        """Creates a single IO-Task.

        Parameters
        ----------
        _b  : bytes object
           The byte string received.
        task_name: str
            Name of the task to be created (e.g. 'io-task', 'ack-task')
        """
        self._log.args("%s (_b: %s)" % (self, _b))
        task = iotask.IOTask(name=task_name, buff=_b)
        self._log.rtn("%s: success | data: %s" % (self, task))
        return task

    def send_ack(self, message: dict) -> None:
        """Composes and sends an acknowledgement message.

        Uses the received message_id as its correlation ID.

        Produces a minimal message here, then an ack-task is created to pass
        the minimal message through the ack process manager.

        Parameters
        ----------
        message: dict
            Message to be acknowledged

        """
        self._log.args("%s (message: %s)" % (self, message))
        config = {
            "type": "event",
            "message": message
        }
        self.produce(config)
        self._log.rtn("success")

    def produce(self, config: dict) -> None:
        """Composes and dispatches a message.

        Command or event messages may be produced here.

        Passes the config to the message factory to generate a message, then
        creates a task which is scheduled, ready for dispatch by the producer.

        Parameters
        ----------
        config: dict
            Message configuration, e.g.
            {
                "type": "command",
                "payload": ...
            }

        """
        self._log.args("%s: (config: %s)" % (self, config))
        msg = self._message_factory.message(config)
        task = self._create_task(bson.BSON.encode(msg), "io-task")
        self._scheduled_tasks.put(task)
        self._log.rtn("success")

    def _execute_scheduled(self) -> list:
        """Uses the registered scheduler to get the scheduled tasks and
        executes them.

        Returns
        -------
        rtn: Dict
            Results from executed tasks.
        """
        self._log.args("%s: ()" % self)
        rtn = self._scheduler.schedule()
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _loop(self) -> None:
        """Loops over the io poller.
        """
        self._eventloop.run_once()
        if not self._scheduled_tasks.empty():
            self._log.info("%s: task scheduled" % self)
            self._execute_scheduled()

    def _loop_once(self) -> list:
        """Loops once over the io poller.

        Returns
        -------
        events: list
            A list of events.
        """
        events = self._eventloop.run_once()
        if events:
            self._log.rtn("%s: success | data: %s" % (self, events))
        return events

    def _store_message(self, message: Dict) -> bool:
        """Saves message to a Message Store

        Parameters
        ----------
        message: Dict
            Message to be stored in the message store.

        Returns
        -------
        rtn: bool
            True if operation succeeded, False otherwise
        """
        self._log.args("%s: (message: %s)" % (self, message))
        rtn = self._message_store.store({
            "message_id": message["message_id"],
            "dest_ip": message["dest_ip"],
            "dest_port": message["dest_port"],
            "message": json.dumps(message)
        })

        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _remove_message(self, where: Dict) -> bool:
        """Removes message from a message store.

        Parameters
        ----------
        where : Dict
            A dictionary where the keys correspond to column names and the
            values to those values used when removing from the message
            store's db.

        Returns
        -------
        rtn: bool
            True if operation succeeded, False otherwise.
        """
        self._log.args("%s: (message_id: %s)" % (self, where))
        self._message_store.remove(where)
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _get_message(self, where: Dict) -> Any:
        """Retrieves a message from a message store.

        Parameters
        ----------
        where : Dict
            A dictionary where the keys correspond to column names and the
            values to those values used when selecting from the message
            store's db.

        Returns
        -------
        msg: Dict
            Message retrieved from store.
        """
        self._log.args("%s: (id: %s)" % (self, id))
        msg = self._message_store.get(where)
        self._log.rtn("%s: success | data: %s" % (self, msg))
        return msg

    def get_config(self) -> Dict:
        """Getter for the producer config.

        Returns
        -------
        config: Dict
            Base producer config.
        """
        self._log.args("%s: ()" % self)
        config = self._config
        self._log.rtn("%s: success | data: %s" % (self, config))
        return config

    def register(self, config: Any) -> bool:
        """Registers components to the base producer.

        Can be overridden by subclasses if required.

        Parameters
        ----------
        config: object
            type: str
                The producer type
            alias: str
                Alias of the base producer
            name: str
                Name of the base producer
            uid: hash
                Identification number
            logger: str, optional
                Name of the logger instance.

        Returns
        -------
        rtn: bool
            True if operation successful, otherwise False.

        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: (config: %s)" % (self, str(config)))
        if self._config is None:
            self._config = config
        self._eventloop = self._config.get("eventloop")
        self._scheduler = self._config.get("scheduler")
        self._transactional_client = self._config.get("tx_client")
        self._scheduled_tasks = self._config.get("task_queue")
        self._message_store = self._config.get("message_store")
        self._message_factory = self._config.get("message_factory")
        self._registered = True
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def unregister(self) -> bool:
        """Unregisters components from the base producer.

        Returns
        -------
        rtn: bool
            True if operation succeeded, False otherwise.
        """
        self._log.args("%s: ()" % self)
        self._eventloop = None
        self._scheduler = None
        self._scheduled_tasks = None
        self._transactional_client = None
        self._message_store = None
        self._registered = False

        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def run(self) -> Any:
        """Overrides io engine's run method.

        Returns
        -------
        rtn: object
            All tasks.
        """
        self._listening = True
        while self._listening:
            self._eventloop.run_once()

    def run_once(self) -> Any:
        """Overrides io engine's run_once method.

        Returns
        -------
        rtn: object
            A single task.
        """
        try:
            self._loop()
        except ThreadedSchedulerException as e:
            raise BaseProducerException(e)

    def get_task_stack(self) -> list:
        """Gets the active tasks to be executed.

        Returns
        -------
        rtn: list
            List of tasks to be executed.
        """
        self._log.args("%s: ()" % self)
        rtn = self._scheduled_tasks.as_list()
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def close(self) -> bool:
        """Stops listening, closes the eventloop.

        Returns
        -------
        rtn: bool
            Returns True if successful
        """
        self._log.args("%s: ()" % self)
        self._listening = False
        if self._eventloop:
            self._eventloop.close()
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
