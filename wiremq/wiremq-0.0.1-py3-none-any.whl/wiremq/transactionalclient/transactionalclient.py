# -*- coding: utf-8 -*-

import logging
from typing import (
    Any,
    Dict
)
from hashlib import (
    sha256
)
from secrets import (
    token_bytes
)


class TransactionalClient:
    """Transactional client class

    Attributes
    ----------
    _transactions : Dict
        A dictionary mapping of transaction id to transaction, for all
        transactions created by the transactional client
    _config : Dict
        The dictionary required for configuring the transactional client

    _known_transactions : Dict
        A mapping of known transaction types to tasks that make up each
        transaction
    _in_queue : object
        The queue that messages are placed onto when sending them to the
        transaction client
    _out_queue : object
        The queue that messages are placed onto when sending them from the
        transaction client
    _database : object
        The database used
    _validator : object
    _queue_dispatcher : object
    _log: object
        Python logging instance.

    Methods
    -------
    config_transactional_client(): None
        Config transactional client with dict
    register(): bool
        Register components to the transactional client
    get_config(): Dict
        Return the transactional client's config
    validate(): bool
        Validate data received by the transactional client
    sequence(): bool
        Create a new transaction or retrieve an existing one
    schedule(): bool
        Get a task, based on tx_id
    _get_task(): Any
        Helper method for the schedule method above
    _get_task_key(): Any
        Helper method for the _get_task method above
    _init_task(): Any
        Helper method for the _get_task method above
    execute_task(): Any
        Execute task and update the respective transaction
    send_queue_dispatcher_message(): None
        Places a message into out_queue registered to the queue
    recv_queue_dispatcher_message(): dict
        Receives a message from the in_queue registered to the queue
        dispatcher.
    get_transactions(): dict
        Return all current transactions
    _create_transaction(): str
        Instantiate and return a transaction
    _update_transaction(): None
        Update transaction log information
    _get_transaction(): Any
        Return transaction from ID
    _complete_transaction(): None
        Remove transaction from the list of transactions
    _set_transaction_id(): str
        Create the transaction id with sha256
    handle(): bool
        Handle an incoming message
    loop(): None
        An automated loop through the transactional client's methods
    """

    def __init__(self, config: Dict = None) -> None:
        """Transactional Client Constructor

        Parameters
        ----------
        config : Dict
            A dictionary containing data needed to run the transactional client
            name: str
                Name of container.
            uid: hash
                Container identification number.
            known_transactions: Dict
                transaction_name: Dict
                    "tasks": Dict
                        task_name: task_module.ExecutableTask
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        config = {
            "name": "Transactional Client",
            "uid": "6134696547993b9da10745c4d06126c" +
            ...    "79ad730dcd36844aeba1072386e652f187"
            "known_transactions": {
                "ping": {
                    "tasks": {
                        "send_ping": sendping.ExecutableTask
                        "ack_pong": ackpong.ExecutableTask
                    }
                }
                "pong": {
                    "tasks": {
                        "send_pong": sendpong.ExecutableTask
                    }
                }
            }
        }
        """
        self._transactions = {}
        self._known_transactions = {}
        self._in_queue = None
        self._out_queue = None
        self._database = None
        self._validator = None
        self._queue_dispatcher = None
        self._config = None
        self._log = None
        if config:
            self.config(config)

    def __repr__(self):
        return "Transactional client object"

    def __str__(self):
        return "Transactional client object"

    def config(self, config: Dict) -> None:
        """Config transactional client with dict

        Note
        ----
        See constructor above for params and example information
        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._config = config
        self._known_transactions = config.get("known_transactions", {})
        self._log.rtn("%s: success" % self)

    def register(self, in_queue: Any = None, out_queue: Any = None,
                 database: Any = None, validator: Any = None,
                 queue_dispatcher: Any = None):
        """Register components to the transactional client

        Parameters
        ----------
        in_queue: basequeue
            A queue for messages sent to the transactional client
        out_queue: basequeue
            A queue for messages sent from the transactional client
        database: database
            A database for storing information for retrieval upon post-crash
            recovery
        validator: validator
            A component for validating incoming messages
        queue_dispatcher: queuedispatcher
            A dispatcher to put and get items to and from the out and in queues

        Example
        -------
        tx_client = transactionalclient.TransactionalClient(
            transactional_client_config
        )
        tx_client.register(in_queue=tx_inqueue,
                           out_queue=tx_outqueue,
                           queue_dispatcher=dispatcher)
        """
        self._log.info('register')
        self._in_queue = in_queue
        self._out_queue = out_queue
        self._database = database
        self._validator = validator
        self._queue_dispatcher = queue_dispatcher

    def get_config(self) -> Dict:
        """Return the transactional client's config

        Returns
        -------
        _config : Dict
            The config of the transactional client
        """
        self._log.info('get_config')
        return self._config

    def validate(self, data: Dict) -> bool:
        """Validate data received by the transactional client

        Parameters
        ----------
        data: Dict
            A data structure containing information on the transaction
            being requested.

        Example
        -------
        data = {"tx_type": "ping"}
        tx_client.validate(data)

        Returns
        -------
        result: bool
            True if data is valid, false otherwise
        """
        self._log.info('validate')
        return self._validator.translate(data)

    def sequence(self, data: Dict) -> bool:
        """Create a new transaction or retrieve an existing one

        Parameters
        ----------
        data: Dict
            A data structure containing information on the transaction
            being requested.

        Example
        -------
        For a new transaction:
            data = {"tx_type": "ping"}
            tx = tx_client.sequence(data)

        Or for an existing transaction:
            data = {"tx_correlation_id": "123"}
            tx = tx_client.sequence(data)

        Returns
        -------
        tx: Dict
            A newly created or existing transaction
        """
        self._log.info('sequence')
        if "tx_correlation_id" not in data:
            transaction = self._create_transaction(data)
        else:
            if data["tx_correlation_id"] == "0":
                transaction = self._create_transaction(data)
            else:
                transaction = self._get_transaction(data["tx_correlation_id"])
        if self._database:
            self._store_new_transaction_in_db(transaction)
        return transaction

    def schedule(self, tx_data: Dict) -> bool:
        """Get a task, based on tx_id

        Parameters
        ----------
        tx_data: Dict
            tx_id: str
                The ID of the transaction to look up the task to retrieve
            config: Dict, Optional
                A config used for task instantiation

        Example
        -------
        data = {
            "tx_id": "123",
            "config": {
                "dummy_key": "dummy_value"
            }
        }
        task = tx_client.schedule(data)

        Returns
        -------
        task: ExecutableTask
            The task to be executed
        """
        self._log.info('schedule')
        task = self._get_task(tx_data)
        return task

    def execute_task(self, task: Any) -> Any:
        """Execute task and update the respective transaction

        Parameters
        ----------
        task: ExecutableTask
            The task to be executed

        Example
        -------
        result = tx_client.execute_task(task)

        Returns
        -------
        ret: Any
            The return value from executing the transaction
        """
        self._log.info('execute_task')
        ret = task.execute()
        self._update_transaction(ret)
        return ret

    def get_transactions(self) -> dict:
        """Return all current transactions

        Returns
        -------
        Dict
            A dictionary containing all transactions being run by the
            transactional client.
        """
        self._log.info('get_transactions')
        return self._transactions

    def send_queue_dispatcher_message(self,
                                      descriptor: str,
                                      payload: dict) -> None:
        """Places a message into out_queue registered to the queue
        dispatcher.

        Parameters
        ----------
        descriptor: str
            Dispatcher item descriptor, the identifier for the target
            queue/channel.
        payload: Any
            The message to be sent.
        """
        self._log.info('send_queue_dispatcher_message')
        self._queue_dispatcher.dispatch(descriptor, payload)

    def recv_queue_dispatcher_message(self, descriptor: str) -> dict:
        """Receives a message from the in_queue registered to the queue
        dispatcher.

        Parameters
        ----------
        descriptor: str
            Dispatcher item descriptor, the identifier for the target
            queue/channel to retrieve the message from.

        Returns
        -------
        payload: Any
            The received message
        """
        self._log.info('recv_queue_dispatcher_message')
        payload = self._queue_dispatcher.dispatch(descriptor)
        return payload

    def _get_task(self, data: Dict) -> Any:
        """Helper method for the schedule method above

        Parameters
        ----------
        tx_data: Dict
            tx_id: str
                The ID of the transaction to look up the task to retrieve
            config: Dict, Optional
                A config used for task instantiation

        Example
        -------
        data = {
            "tx_id": "123",
            "config": {
                "dummy_key": "dummy_value"
            }
        }
        task = tx_client.schedule(data)

        Returns
        -------
        task: ExecutableTask
            The task to be executed
        """
        self._log.info('_get_task')
        tx = self._transactions[data["tx_id"]]
        task_key = self._get_task_key(tx)
        task = self._init_task(tx, task_key, data)
        return task

    def _get_task_key(self, tx: Dict) -> Any:
        """Helper method for the _get_task method above

        Parameters
        ----------
        tx: Dict
            A transaction

        Example
        -------
        tx = {
            'tx_id': 'ff0e',
            'tx_type': 'ping',
            'log': ['send_ping']
        }

        Returns
        -------
        task_key: Any
            The key for the task to be executed
        """
        self._log.info('_get_task_key')
        task_keys = list(
            self._known_transactions[tx["tx_type"]]["tasks"].keys())
        if tx["log"]:
            last_task = tx["log"][-1]
            last_task_index = task_keys.index(last_task)
            task_key = task_keys[last_task_index + 1]
        else:
            task_key = task_keys[0]
        return task_key

    def _init_task(self, tx: Dict, task_key: Any, data: Dict) -> Any:
        """Helper method for the _get_task method above

        Parameters
        ----------
        tx: Dict
            A transaction
        task_key: Any
            The key for the task to be initialized
        Data: Dict
            tx_id: str
                The ID of the transaction to look up the task to retrieve
            config: Dict, Optional
                A config used for task instantiation

        Example
        -------
        tx = {
            'tx_id': 'ff0e',
            'tx_type': 'ping',
            'log': ['send_ping']
        }
        task_key = "ping"
        data = {
            "tx_id": "ff0e"
        }
        tx_client._init_task(tx, task_key, data)

        Returns
        -------
        task: ExecutableTask
            The task to be executed
        """
        self._log.info('_init_task')
        if "config" in data:
            if "tx_id" not in data["config"]:
                data["config"]["tx_id"] = tx["tx_id"]
            task = self._known_transactions[tx["tx_type"]]["tasks"][task_key](
                data["config"]
            )
        else:
            task_config = {"tx_id": data["tx_id"]}
            task = self._known_transactions[tx["tx_type"]]["tasks"][task_key](
                task_config
            )
        return task

    def _create_transaction(self, config: dict) -> str:
        """Instantiate and return a transaction

        Parameters
        ----------
        config : Dict
            Configuration required for the creation of a transaction
            tx_type : str
                A string representation of the type of transaction to create

        Example
        -------
        config = {
            "type": "ping",
        }

        Returns
        -------
        tx_id : int
            The id of the transaction that was created
        """
        self._log.info('_create_transaction')
        tx_id = self._set_transaction_id()
        config["tx_id"] = tx_id
        self._transactions[tx_id] = {
            "tx_id": tx_id,
            "tx_type": config["payload"]["command"],
            "log": []
        }
        return self._transactions[tx_id]

    def _update_transaction(self, data: Dict) -> None:
        """Update transaction log information

        Parameters
        ----------
        data: Dict
            Task result Dict containing the id of the transaction and the name
            of the task completed, which is then added to the transaction's log

        Example
        -------
        data = {
            "tx_id": 123,
            "task": "send_ping"
        }
        tx_client._update_transaction(data)
        """
        self._log.info('_update_transaction')
        tx = self._transactions[data["tx_id"]]
        tx["log"].append(data["task"])
        if self._database:
            self._update_transaction_in_db(data)

    def _store_new_transaction_in_db(self, tx: Dict) -> bool:
        """Stores transaction data in the database

        Parameters
        ----------
        tx: Dict
            A transaction

        Example
        -------
        tx = {
            'tx_id': 'ff0e',
            'tx_type': 'ping',
            'log': ['send_ping']
        }
        """
        self._log.info('_store_new_transaction_in_db')
        pass

    def _update_transaction_in_db(self, data) -> bool:
        """Updates existing transaction data in the database

        Parameters
        ----------
        data: Dict
            Task result Dict containing the id of the transaction and the name
            of the task completed, which is then added to the transaction's log

        Example
        -------
        data = {
            "tx_id": 123,
            "task": "send_ping"
        }
        """
        self._log.info('_update_transaction_in_db')
        pass

    def _get_transaction(self, tx_id: str) -> Any:
        """Return transaction from ID

        Parameters
        ----------
        tx_id : int
            An id associated with an existing transaction

        Example
        -------
        tx_id = 4

        Returns
        -------
        BaseTransaction
            A single transaction that corresponds to the id supplied.
        """
        self._log.info('_get_transaction')
        return self._transactions[tx_id]

    def _complete_transaction(self, tx_id: int) -> None:
        """Remove transaction from the list of transactions

        Parameters
        ----------
        tx_id : int
            An id associated with an existing transaction

        Example
        -------
        tx_id = 4
        """
        self._log.info('_complete_transaction')
        del self._transactions[tx_id]

    def _set_transaction_id(self) -> str:
        """Create the transaction id with sha256

        Returns
        -------
        transaction_id : str
            A string to be used as the id for a created transaction
        """
        self._log.info('_set_transaction_id')
        return sha256(token_bytes(32)).hexdigest()

    def handle(self) -> bool:
        """Handle an incoming message

        Returns
        -------
        result: bool
            A boolean indicating whether the handling was performed
            successfully.
        """
        self._log.info("handle")
        tx_data = self.recv_queue_dispatcher_message(
            self._in_queue.get_config()["id"],
        )
        if not self.validate(tx_data["data"]):
            return False
        transaction = self.sequence(tx_data["data"])
        task = self.schedule(transaction)
        results = self.execute_task(task)
        self.send_queue_dispatcher_message(
            self._out_queue.get_config()["id"],
            results
        )
        return True

    def loop(self) -> None:
        """An automated loop through the transactional client's methods"""
        self._log.info('loop')
        while True:
            self.handle()
