# -*- coding: utf-8 -*-
"""Base queue class """

from typing import (
    Any
)
from abc import (
    ABC,
    abstractmethod
)


class AbstractQueue(ABC):
    """Abstract Queue Class."""

    def __init__(self):
        """Queue class constructor."""
        super().__init__()

    @abstractmethod
    def _init_queue(self) -> None:
        pass

    @abstractmethod
    def qsize(self) -> int:
        """Return the number of items in the Queue.
        """
        pass

    @abstractmethod
    def empty(self) -> bool:
        """Check if the queue is empty.
        """
        pass

    @abstractmethod
    def full(self) -> bool:
        """Check if the queue is full.
        """
        pass

    @abstractmethod
    def put(self, item: Any, block: bool, timeout: int) -> None:
        """Add an item to the queue.
        """
        pass

    @abstractmethod
    def put_nowait(self, item: Any) -> None:
        """Equivalent to put(item, False); i.e, a put() with no blocking.
        """
        pass

    @abstractmethod
    def get(self, block: bool, timeout: int) -> Any:
        """Remove an item from the queue.
        """
        pass

    @abstractmethod
    def get_nowait(self) -> Any:
        """Equivalent to get(False); i.e, a get() with no blocking.
        """
        pass

    @abstractmethod
    def as_list(self) -> list:
        """Returns contents of queue as a list
        """
        pass

    @abstractmethod
    def task_done(self) -> None:
        """Indicates that a previously retrieved item has been processed.
        Used in consumer threads that perform one or multiple get() calls.
        """
        pass

    @abstractmethod
    def join(self) -> None:
        """Blocks the thread until all items in the queue have been gotten and
        processed; i.e. when the queue's item count is 0.
        """
        pass

    @abstractmethod
    def get_ordering(self) -> str:
        """Return ordering of queue"""
        pass

    @abstractmethod
    def get_max_size(self) -> int:
        """Return max size of queue"""
        pass

    @abstractmethod
    def get_type(self) -> str:
        """Return type of queue"""
        pass

    @abstractmethod
    def _empty(self) -> bool:
        """Check if the queue is empty.
        """
        pass

    @abstractmethod
    def _full(self) -> bool:
        """Check if the queue is full.
        """
        pass

    @abstractmethod
    def _put(self, item: Any, block: bool, timeout: int) -> None:
        """Add an item to the queue.
        """
        pass

    @abstractmethod
    def _get(self, block: bool, timeout: int) -> Any:
        """Remove an item from the queue.
        """
        pass

    @abstractmethod
    def _reset(self) -> None:
        """Reset the queue."""
        pass
