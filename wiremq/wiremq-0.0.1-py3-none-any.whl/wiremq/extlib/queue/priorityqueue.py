# -*- coding: utf-8 -*-
"""Priority Queue class """

from wiremq.extlib.queue import basequeue
from typing import (
    Any,
    Dict
)


class PriorityQueue(basequeue.BaseQueue):
    """Priority Queue Class.

    Attributes
    ----------
    _config : Dict
        id : int
            The ID used to identify the queue
        ordering : string
            The type of queue ("priority")
        maxsize : int
            The maximum number of items storable in the queue (0 = infinite)
        type : string
            The queue type, either "inqueue" or "outqueue"
        logger: str, optional
            Name of the logger instance.
    _queue : queue.PriorityQueue
        Contains items to be stored and later retrieved in order of
        priority (lowest number first).
    _log: object
        Python logging instance.

    Methods
    -------
    _put() : None
        Put item into queue
    _get() : Any
        Get item from queue
    item_processed() : None
        Mark the last retrieved item as processed
    """

    def __init__(self, config: Dict = None):
        """PriorityQueue class constructor.

        Initialize a Priority queue. The options for the queue are passed
        along in the config.

        Parameters
        ----------
        config : Dict
            id: Hex
                The queue ID
            ordering : string
                The type of queue ("priority")
            maxsize : int
                The max number of items storable in the queue (0 = infinite)
            type : string
                The queue type, either "inqueue" or "outqueue"
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        config = {
            "id": "858bee1907e8eddfd1e0aeeef249c40f" +
                  "6b724f14c9da00cae8ea1da9d4c8c0e5"
            "ordering": "priority",
            "maxsize": 0,
            "type": "inqueue"
        }
        queue = priorityqueue.PriorityQueue(config)
        queue.put({item})
        retrieved_item = queue.get()
        """
        super().__init__(config)
        self._current_item = None

    def _put(self, item: Any, block: bool = True, timeout: int = None) -> None:
        """Add an item to the queue.

        Parameters
        ----------
        item : Any
            The data to be inserted into the queue.
        block : bool
            A flag to determine if the put action should block the thread
        timeout : int
            The amount of time a put action, if blocking is set to true, should
            block the thread for.
        """
        self._log.args("%s: (item: %s, block: %r, timeout: %s)"
                       % (self, item, block, timeout))
        _rtn = self._queue.put(item, block, timeout)
        self._log.rtn("%s: success | data: %s" % (self, _rtn))
        return _rtn

    def _get(self, block: bool = True, timeout: int = None) -> Any:
        """Retrieve an item from the queue.

        If the previous item hasn't been marked as processed, the queue will
        return the previous item. This is a failsafe in the event of the item
        being lost during processing. If the previously retrieved item has been
        marked as processed, _get() will return a new item retrieved from the
        queue.

        Parameters
        ----------
        block : bool
            A flag to determine if the put action should block the thread
        timeout : int
            The amount of time a put action, if blocking is set to true, should
            block the thread for.

        Returns
        -------
        _current_item : Any
            The item of data retrieved from the queue.
        """
        self._log.args("%s: (block: %r, timeout: %s)" % (self, block, timeout))
        if self._current_item is None:
            self._current_item = self._queue.get(block, timeout)
        _current_item = self._current_item
        self._log.rtn("%s: success | data: %s" % (self, _current_item))
        return _current_item

    def item_processed(self) -> None:
        """Marks an item as processed. This allows a new item to be
        retrieved from the queue.
        """
        self._log.args("%s: ()" % self)
        self._current_item = None
        self._log.rtn("%s: success" % self)
