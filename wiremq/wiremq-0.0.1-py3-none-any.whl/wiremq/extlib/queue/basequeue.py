# -*- coding: utf-8 -*-

"""Base queue class """

import threading
import queue
import logging
import uuid
from typing import (
    Any,
    Dict
)
from pymongo.errors import InvalidOperation
from wiremq.extlib.queue import abstractqueue
from wiremq.extlib.err.queueexception import (
    QueueEmptyException,
    QueueFullException,
    DurableQueueInsertException,
    DurableQueueSelectException,
    DurableQueueDeleteException
)
from wiremq.extlib.err.databaseexception import (
    DBInsertException,
    DBSelectException,
    DBDeleteException
)


class BaseQueue(abstractqueue.AbstractQueue):
    """Base Queue Class.

    Queue may be held in memory, or durable with a database attached

    Attributes
    ----------
    _config : Dict
        id : Hex
            The queue ID
        ordering : string
            The type of queue ("fifo", "lifo", "priority")
        maxsize : int
            The maximum number of items storable in the queue (0 = infinite)
        type : string
            The queue type, either "inqueue" or "outqueue"
        durable : bool
            Whether the queue is durable (i.e. stores items in a database)
        dbconn : DBConn
            The database connection used to store and retrieve the values for
            the durable queue, used if the durable flag is set to true.
        logger: str, optional
            Name of the logger instance.
    _db: object
        For durable queues, the database connection object.
    _current_item: str
        For durable queues, the ID of the current queue item.
    _queue : queue.Queue, queue.LifoQueue, or queue.PriorityQueue
        Contains items to be processed in a particular order, specified in
        config["ordering"].
    _log: object
        Python logging instance.

    Methods
    -------
    get_config() : dict
        Return the queue's config
    qsize() : int
        Get the size of the queue
    empty() : bool
        Check if the queue is empty
    full() : bool
        Check if the queue is full
    put() : None
        Put item into queue
    put_nowait() : None
        Put item into queue, without blocking
    get() : Any
        Get item from queue
    get_nowait() : Any
        Get item from queue, without blocking
    as_list(): list
        Returns contents of queue as a list
    task_done() : None
        Indicate that a gotten item has been processed
    join() : None
        Block until all items in queue have been gotten and processed
    get_ordering() : str
        Return ordering scheme of queue
    get_max_size() : int
        Return max size of queue
    get_type() : str
        Return type of queue
    _empty() : bool
        Check if the queue is empty
    _full() : bool
        Check if the queue is full
    _put() : None
        Put item into queue, and puts into database if durable
    _get() : Any
        Get item from queue, and deletes from database if durable
    _reset() : None
        Reset the queuepa
    _get_from_db() : Any
        Get item from database
    _delete_from_db() : None
        Delete current_item from database
    item_processed() : None
        Call _delete_from_db()

    Raises
    ------
    QueueFullException
        Exception raised when putting to a queue that is full.
    QueueEmptyException
        Exception raised when getting from a queue that is empty.
    DurableQueueInsertException:
        Exception raised when a durable queue is unable to insert an item into
        the message store.
    DurableQueueSelectException:
        Exception raised when a durable queue is unable to retrieve an item
        from the message store.
    """

    def __init__(self, config: Dict = None):
        """Queue class constructor

        Initialize a base queue. The options for the queue are passed along in
        the config.

        Parameters
        ----------
        config : Dict
            id : Hex
                The queue ID
            ordering : string
                The type of queue ("fifo", "lifo", "priority")
            maxsize : int
                The max number of items storable in the queue (0 = infinite)
            type : string
                The queue type, either "inqueue" or "outqueue"
            durable : bool
                Flag for whether the queue is durable, i.e. uses a database
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        config = {
            "id": 1,
            "ordering": "fifo",
            "maxsize": 0,
            "type": "inqueue"
        }
        queue = basequeue.BaseQueue(config)
        queue.put({item})
        retrieved = queue.get()
        """
        super().__init__()
        self._id = self._generate_id()
        self._config = None
        self._queue = None
        self._queue_id = None
        self._lock = threading.Lock()
        self._durable = False
        self._log = None
        if config:
            self.config(config)
            self._init_queue()

    def __name__(self) -> str:
        """Return name."""
        return object.__name__

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def _generate_id(self) -> str:
        """Generate a unique task-id.

        Returns
        -------
        id: str
            Generated identifier of task.
        """
        return str(uuid.uuid4())

    def get_id(self) -> Any:
        """Returns the id of the task.
        Returns
        -------
        id: str
            Identifier of task.
        """
        _id = str(uuid.uuid4())
        self._log.rtn("success | data: %s" % _id)
        return _id

    def _init_queue(self) -> None:
        """Initialize a queue of type specified in the config"""
        self._log.args("%s: ()" % self)
        if self._config["ordering"] == "fifo":
            self._queue = queue.Queue(self._config["maxsize"])
        elif self._config["ordering"] == "lifo":
            self._queue = queue.LifoQueue(self._config["maxsize"])
        elif self._config["ordering"] == "priority":
            self._queue = queue.PriorityQueue(self._config["maxsize"])
        self._log.rtn("%s: success" % self)

    def config(self, config: Dict) -> None:
        """Configure the queue.
        A method to configure a queue after an object has been
        created.
        Parameters
        ----------
        config : Dict, required
            The queue configuration dictionary.
        """
        if self._config is None:
            self._log = logging.getLogger(config.get("logger", "basic_logger"))
            self._log.args("%s: (config: %s)" % (self, str(config)))
            self._config = config
            self._durable = config.get("durable", False)
            if self._durable:
                self._queue_id = config["id"]
                self._db = config["dbconn"]
                self._current_item = None
            self._init_queue()
        self._log.rtn("%s: success" % self)

    def get_config(self) -> Dict:
        """A getter for the queue config
        Returns
        -------
        _config : Dict
            The queue's config dictionary
        """
        self._log.args("%s: ()" % self)
        _config = self._config
        self._log.rtn("%s: success | data: %s" % (self, _config))
        return _config

    def qsize(self) -> int:
        """Return the number of items in the Queue.
        Returns
        -------
        int
            Number of items in the queue.
        """
        self._log.args("%s: ()" % self)
        _qsize = self._queue.qsize()
        self._log.rtn("%s:  success | data: %d" % (self, _qsize))
        return _qsize

    def empty(self) -> bool:
        """Check if the queue is empty.
        Returns
        -------
        rtn: bool
            True if queue is empty, else false.
        """
        rtn = self._empty()
        return rtn

    def full(self) -> bool:
        """Check if the queue is full.
        Returns
        -------
        bool
            True if queue is full, else false.
        """
        self._log.args("%s: ()" % self)
        _full = self._full()
        self._log.rtn("%s: success | data: %r" % (self, _full))
        return _full

    def put(self, item: Any, block: bool = True, timeout: int = None) -> None:
        """Add an item to the queue. Raises a QueueFullException when putting
        into a queue that is already full and the timeout is exceeded.
        Parameters
        ----------
        item : Any
            The data to be inserted into the queue. If a priority queue, the
            item takes the form of a tuple: (priority_number: int, data: Any),
            e.g.: (1, BaseMessage), where the queue item with the lowest
            priority_number value is retrieved first
        block : bool
            A flag to determine if the put action should block the thread
        timeout : int
            The amount of time a put action, if blocking is set to true, should
            block the thread for.
        Raises
        ------
        QueueFullException:
            Exception raised when putting to a queue that is full.
        """
        self._log.args("%s: (item: %s, block: %r, timeout: %s)"
                       % (self, item, block, str(timeout)))
        with self._lock:
            try:
                self._put(item, block, timeout)
            except queue.Full:
                raise QueueFullException
            except DBInsertException as e:
                raise DurableQueueInsertException(e)

            self._log.rtn("%s: success" % self)

    def put_nowait(self, item: Any) -> None:
        """Equivalent to put(item, False); i.e, a put() with no blocking.
        Raises a QueueFullException when attempting to put into a queue that
        is already full.
        Parameters
        ----------
        item : Any
            The data to be inserted into the queue
        Raises
        ------
        QueueFullException
            Exception raised when putting to a queue that is full.
        """
        self._log.args("%s}: (item: %s)" % (self, item))
        with self._lock:
            try:
                self._put(item, False)
            except queue.Full:
                raise QueueFullException
            except DBInsertException as e:
                raise DurableQueueInsertException(e)
            self._log.rtn("%s: success" % self)

    def get(self, block: bool = True, timeout: float = None) -> Any:
        """Remove an item from the queue. Raises a QueueEmptyException when
        attempting to retrieve an item form an empty queue and the timeout is
        exceeded.
        Parameters
        ----------
        block : bool
            A flag to determine if the put action should block the thread
        timeout : float
            The amount of time a put action, if blocking is set to true, should
            block the thread for.
        Return
        ------
        item : Any
            The item of data retrieved from the queue.
        """
        self._log.args("%s: ()" % self)
        with self._lock:
            try:
                item = self._get(block, timeout)
            except queue.Empty:
                raise QueueEmptyException
            except DBSelectException as e:
                raise DurableQueueSelectException(e)
            self._log.rtn("%s: success | data: %self" % (self, item))
            return item

    def get_nowait(self) -> Any:
        """Equivalent to get(False); i.e, a get() with no blocking. Raises a
        QueueEmptyException when getting from an empty queue.
        Return
        ------
        item : Any
            The item of data retrieved from the queue.
        Raises
        ------
        QueueEmptyException:
            Exception raised when getting from a queue that is empty.
        """
        self._log.args("%s: ()" % self)
        with self._lock:
            try:
                item = self._get(False)
            except queue.Empty:
                raise QueueEmptyException
            self._log.rtn("%s: success | data: %self" % (self, item))
            return item

    def as_list(self) -> list:
        """Returns contents of queue as a list
        Returns
        -------
        rtn: list
            A list containing all elements currently in the list.
        """
        self._log.args("%s: ()" % self)
        with self._lock:
            as_list = list(self._queue.queue)

            self._log.rtn("%s: success | data: %s" % (self, as_list))
            return as_list

    def task_done(self) -> None:
        """Indicates that a previously retrieved item has been processed.
        Used in consumer threads that perform one or multiple get() calls.
        Example
        -------
        q = basequeue.BaseQueue()
        def worker():
            while True:
                item = q.get()
                print(f'Working on {item}')
                print(f'Finished {item}')
                q.task_done()
        threading.Thread(target=worker, daemon=True).start()
        """
        self._log.args("%s: ()" % self)
        self._queue.task_done()
        self._log.rtn("%s: success" % self)

    def join(self) -> None:
        """Blocks the thread until all items in the queue have been gotten and
        processed; i.e. when the queue's item count is 0.
        When an item is added to the queue, the count is incremented, and
        decremented whenever a consumer thread calls task_done() to indicate
        that an item has been retrieved and processed. When the count goes to
        zero, join() unblocks.
        Example
        -------
        q = basequeue.BaseQueue()
        def worker():
            while True:
                item = q.get()
                print(f'Working on {item}')
                print(f'Finished {item}')
                q.task_done()
        threading.Thread(target=worker, daemon=True).start()
        # send thirty task requests to the worker
        for item in range(30):
            q.put(item)
        print('All task requests sent)
        # block until all tasks are done
        q.join()
        print('All work completed')
        """
        self._log.args("%s: ()" % self)
        self._queue.join()
        self._log.rtn("%s: success" % self)

    def get_ordering(self) -> str:
        """Return ordering of queue
        Returns
        -------
        ordering : str
            The ordering of the queue, either "fifo", "lifo", or "priority"
        """
        self._log.args("%s: ()" % self)
        _ordering = self._config.get("ordering", "No ordering specified")
        self._log.rtn("%s: success | data: %s" % (self, _ordering))
        return _ordering

    def get_max_size(self) -> int:
        """Return max size of queue
        Returns
        -------
        max_size : str
            The max size value of the queue
        """
        self._log.args("%s: ()" % self)
        max_size = self._config.get("maxsize", "No max size specified")
        self._log.rtn("%s: success | data: %d" % (self, max_size))
        return max_size

    def get_type(self) -> str:
        """Return type of queue
        Returns
        -------
        type : str
            The type of the queue, either "inqueue", or "outqueue"
        """
        self._log.args("%s: ()" % self)
        _type = self._config.get("type", "No type specified")
        self._log.rtn("%s: success | data: %s" % (self, _type))
        return _type

    def _empty(self) -> bool:
        """Check if the queue is empty.
        Returns
        -------
        bool
            True if queue is empty, else false.
        """
        _empty = self._queue.empty()
        return _empty

    def _full(self) -> bool:
        """Check if the queue is full.
        Returns
        -------
        bool
            True if queue is full, else false.
        """
        self._log.args("%s: ()" % self)
        _full = self._queue.full()
        self._log.rtn("%s: success | data: %r" % (self, _full))
        return _full

    def _put(self, item: Any, block: bool = True, timeout: int = None) -> None:
        """Add an item to the queue.
        Parameters
        ----------
        item : Any
            The data to be inserted into the queue.
        block : bool
            A flag to determine if the put action should block the thread
        timeout : int
            The amount of time a put action, if blocking is set to true, should
            block the thread for.
        TODO: Investigate line 3 of this method currently it does nothing,
              changing : to = breaks tests and some other logic.
        """
        self._log.args("%s: (item: %s, block: %r, timeout: %s)"
                       % (self, item, block, timeout))
        if self._durable:
            item["queue_id"]: self._queue_id
            try:
                insert_id = self._db.insert(self._config["ordering"], item)
            except DBInsertException as e:
                self._log.error(e)
                raise DurableQueueInsertException(e)

        self._queue.put(item, block, timeout)

        if self._durable:
            self._log.rtn("%s: success | data: %s" % (self, insert_id))
            return insert_id
        self._log.rtn("%s: success" % self)

    def _get(self, block: bool = True, timeout: int = None) -> Any:
        """Remove an item from the queue. For durable queues, raises a
        DurableQueueSelectException when there is an error retrieving an item
        from the durable store.
        Parameters
        ----------
        block : bool
            A flag to determine if the put action should block the thread
        timeout : int
            The amount of time a put action, if blocking is set to true, should
            block the thread for.
        Return
        ------
        item : Any
            The item of data retrieved from the queue.
        Raises
        ------
        DurableQueueSelectException:
            Exception raised when a durable queue is unable to retrieve an item
            from the message store.
        """
        self._log.args("%s: (block: %r, timeout: %s)" % (self, block, timeout))
        if self._durable:
            try:
                record = self._get_from_db()
                for doc in record:
                    self._current_item = doc["_id"]
            except InvalidOperation as e:
                self._log.error(e)
                raise DurableQueueSelectException(e)
        data = self._queue.get(block, timeout)
        self._log.rtn("%s: success | data: %s" % (self, data))
        return data

    def _get_from_db(self) -> Any:
        """Retrieve values from DB. A DurableQueueSelectException is raised if
        there is an issue retrieving from the message store.

        Raises
        ------
        DurableQueueSelectException:
            Exception raised when a durable queue is unable to retrieve an item
            from the message store.
        """
        self._log.args("%s: ()" % self)
        where = {"queue_id": self._queue_id}
        if self._config["ordering"] == "fifo":
            order_by = [("id", "ASC")]
            limit = 1
        elif self._config["ordering"] == "lifo":
            order_by = [("id", "DESC")]
            limit = 1
        elif self._config["ordering"] == "priority":
            order_by = [[self._config["priority"]["field"]],
                        [self._config["priority"]["sort"]]]
            limit = 1
        try:
            res = self._db.select(_table=self._config["ordering"], _attrs=None,
                                  _where=where, _distinct=None, _group_by=None,
                                  _order_by=order_by, _limit=limit)
        except DBSelectException as e:
            self._log.error(e)
            raise DurableQueueSelectException(e)
        self._log.rtn("%s: success | res: %s" % (self, res))
        return res

    def _delete_from_db(self) -> None:
        """Delete value from DB. A DurableQueueDeleteException is raised if
        there is an issue deleting from the message store.
        Raises
        ------
        DurableQueueDeleteException:
            Exception raised when a durable queue is unable to delete an item
            from the message store.
        """
        self._log.args("%s: ()" % self)
        val = {"id": self._current_item}
        try:
            self._db.delete(self._config["ordering"], val)
        except DBDeleteException as e:
            self._log.error(e)
            raise DurableQueueDeleteException(e)
        self._log.rtn("%s: success" % self)

    def item_processed(self) -> None:
        self._log.args("%s: ()" % self)
        self._delete_from_db()
        self._log.rtn("%s: success" % self)

    def _reset(self) -> None:
        """Reset the queue."""
        self._log.args("%s: ()" % self)
        self._queue = None
        self._init_queue()
        self._log.rtn("%s: success" % self)
