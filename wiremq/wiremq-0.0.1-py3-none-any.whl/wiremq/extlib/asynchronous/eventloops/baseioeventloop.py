# -*- coding: utf-8 -*-

import hashlib
import uuid
from typing import (
    Any,
    Dict,
)
import logging


class BaseIOEventLoop:
    """IO Event loop.

    BaseIOEventloop class is the parent class for TCP/UDP event loops.

    Attributes
    ----------
    _config : Dict
        The configuration dictionary.
    _id : str
        The unique identifier.
    _listening : int
        The listening flag.
    _wmqsocket: InboundSocket
        The wmqsocket inbound socket.
    _wmqsocket_id : str
        The ID of the listening socket.
    _wmqsocket_fd : int
        The file descriptor representing the listening socket.
    _io : IOBasePoller
        The IO Polling engine.
    _scheduler : Scheduler
        The scheduler object.
    _ready : list
        Holds the FD whose buffers are ready for tasking.
    _map : Dict
        A connection object to buffer index list
    _active : list
        A list of active connections
    _scheduled : list
        Ready and scheduled tasks.
    _log: object
        Python logging instance.

    Methods
    -------
    initialize() : None
        Init the event loop.
    run() : None
        Run the _loop() until signaled otherwise.
    run_once() : Any
        Run a single iteration of the _loop() method.
    get_scheduled() : list
        Return the scheduled tasks.
    get_map() : Dict
        Return the active connection map.
    _generate_fdid() : hexstring
        Given a tuple with string IP and int Port, create a unique hash.
    _checksum() : hexdigest
        Calculate the checksum given a string.
    _generate_id() : uuid
        Generate a new UUID for the object.
    _add_mapping() : None
        Add a new entry into the active socket map.
    _del_mapping() : None
        Delete an existing mapping.
    _update_mapping() : None
        Update an active connection mapping (incl. buffer/conn)
    _loop() : None
        Override. The main loop for the Event Loop.
    _handle_events() : None
        Override. Handle events on the inbound socket.
    _handle_request() : None
        Overrride. Handle connection requests.
    _handle_active() : None
        Override. Handle active connections.
    _handle_close() : None
        Override. Handle closing proceedure.
    _bind_and_listen() : None
        Execute bind and listen in one method.
    _bind() : None
        Given HOST and PORT, bind the socket.
    _listen() : None
        Begin listening on the boiund socket and specify the max connections.
    """

    def __init__(self, config: Dict = None):
        """BaseIOEventloop constructor.

        Initialize with the configuration dictionary as follows:

        Parameters
        ----------
        config: dict
            BaseIOEventloop configuration dictionary.
            poller : BaseIOPoller
                BaseIOPoller object type.
            terminator : bytes
                The termination sequence (as byte string)
            scheduler : Scheduler
                A BaseScheduler type object.
            socket : Inboundsocket
                An inbound wmq socket.
            host : str
                The host IP as a string.
            port : int
                The port to bind to as an integer.
            max_con : int
                Specify the maximum allowable connections (at a time).
            logger: str, optional
                Name of the logger instance.

        Example:
        -------
        >>> config = {}
        >>> config["poller"] = iopoller
        >>> config["terminator"] = b'\r\r'
        >>> config["scheduler"] = None
        >>> config["socket"] = wmqsocket
        >>> config["buffer_size"] = 1024
        >>> config["listening"] = True
        >>> config["host"] = "127.0.0.1"
        >>> config["port"] = 60081
        >>> config["max_con"] = 202
        >>> evloop = baseioeventloop.BaseIOEventloop(config)
        """
        self._id = self._generate_id()
        self._config = None
        self._id = self._generate_id()
        self._CONN_RECV_BUFF_SIZE = None
        self._wmqsocket = None
        self._wmqsocket_id = None
        self._wmqsocket_fd = None
        self._io = None
        self._scheduler = None
        self._listening = None
        self._scheduled = None
        self._active = []
        self._map = {}
        self._ready = []
        self._log = None
        if config:
            self.config(config)

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def __repr__(self):
        return f"<Object: {self.__class__.__name__}>"

    def config(self, config: Dict) -> None:
        """Configure the eventloop.

        Parameters
        ----------
        config: dict
            BaseIOEventloop configuration dictionary.
            poller : BaseIOPoller
                BaseIOPoller object type.
            terminator : bytes
                The termination sequence (as byte string)
            scheduler : Scheduler
                A BaseScheduler type object.
            socket : Inboundsocket
                An inbound wmq socket.
            host : str
                The host IP as a string.
            port : int
                The port to bind to as an integer.
            max_con : int
                Specify the maximum allowable connections (at a time).
            logger: str, optional
                Name of the logger instance.

        Returns
        -------
        config : dict
          The configuration dictionary.
        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: (config: %s)" % (self, config))
        self._config = config
        self._CONN_RECV_BUFF_SIZE = config["buffer_size"]
        self._wmqsocket = config["socket"]
        self._wmqsocket_id = self._wmqsocket.get_id()
        self._wmqsocket_fd = self._wmqsocket.get_fd()
        self._io = config["poller"]
        self._scheduler = config.get("scheduler")
        self._listening = config["listening"]
        self._scheduled = config["task_queue"]

    def get_config(self) -> Dict:
        """Return the configuration.

        Returns
        -------
        _config : dict
          The configuration dictionary.
        """
        self._log.args("%s: ()" % self)
        _config = self._config
        self._log.rtn("%s: success | data: %s" % (self, _config))
        return _config

    def _generate_fdid(self, _conn: tuple) -> str:
        """Generate a unique hash based on connection tuple.

        Parameters
        ----------
        _conn : tuple
            host : str
              The IP in string format.
            port : int
              The port as an integer.

        Return
        ------
        _fdid : str
          A sha1 hexdigest as a string.
        """
        _str = "".join(_conn[0] + str(_conn[1]))
        _fdid = hashlib.sha1(str.encode(_str)).hexdigest()
        self._log.rtn("%s: success | data: %s" % (self, _fdid))
        return _fdid

    def _checksum(self, m: str) -> bytes:
        """Given a message, calculate the checksum.

        Returns
        -------
        _chk : bytes
          Encoded checksum bytes string.
        """
        self._log.args("%s: (m: %s)" % (self, m))
        _rtn = hashlib.md5(m).hexdigest()
        _chk = _rtn.encode
        self._log.rtn("%s: success | data: %s" % (self, _chk))
        return _chk

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        _id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def initialize(self) -> None:
        """Override. Initialize the event loop.

        Bind and listen on the socket. Register the socket to the socket map
        the io poller.
        """
        self._log.args("%s: ()" % self)
        pass

    def get_map(self) -> Dict:
        """Return the map dictionary.

        Returns
        -------
        rtn: Dict
            The active socket/connections map.
        """
        self._log.args("%s: ()" % self)
        _map = self._map
        self._log.rtn("%s: success | data: %s" % (self, _map))
        return _map

    def get_id(self) -> str:
        """Return the id.

        Returns
        -------
        _id: str
            The id of the event loop.
        """
        self._log.args("%s: ()" % self)
        _id = self._id
        self._log.rtn("%s: success | data: %s" % (self, _id))
        return _id

    def get_scheduled(self) -> list:
        """Return the scheduled tasks in a list.

        Returns
        -------
        _scheduled: list
            The list of scheduled tasks.
        """
        self._log.args("%s: ()" % self)
        _scheduled = self._scheduled
        self._log.rtn("%s: success | data: %s" % (self, _scheduled))
        return _scheduled

    def run(self, timeout: float = 0.0) -> None:
        """Runs the event loop forever.

        Parameters
        ----------
        timeout : float
            The iopoller timeout. This is the time b/w polling the kernel.
        """
        self._log.args("%s: (timeout: %s)" % (self, timeout))
        while self._listening:
            self._loop(timeout)
        self._log.rtn("%s: success" % self)

    def run_once(self, timeout: float = 0.0) -> Any:
        """Run a single iteration of the event loop."""
        self._loop(timeout)

    def _add_mapping(self, _indx: str, _fd: int, _t: str = None, _b: Any = b"",
                     _c: object = None) -> None:
        """Private. Add a connection object, fd and id entry into the socket map.

        Parameters
        ----------
        _indx : hexstring
           The unique sha1 identifier indexing the connection.
        _fd : int
           The file descriptor.
        _t : bytes
           The termination byte string.
        _b  : bytes
           The byte string.
        _c  : object
           The connection object (socket).
        """
        self._log.args("%s: (_indx: %s, _t: %s, _b: %s, _c: %s)"
                       % (self, _indx, _t, _b, _c))
        self._map[_indx] = {"fd": _fd,
                            "terminator": _t,
                            "buffer": _b,
                            "conn": _c}
        self._log.info("%s: _map: %s" % (self, self._map))
        self._log.rtn("%s: success" % self)

    def _del_mapping(self, _indx: str) -> None:
        """Private. Remove a socket from the socket map.

        Parameters
        ----------
        _fdid : string
           The file descriptor identifier.
        """
        self._log.args("%s: (_indx: %s)" % (self, _indx))
        del self._map[_indx]["fd"]
        del self._map[_indx]["conn"]
        del self._map[_indx]["buffer"]
        del self._map[_indx]["terminator"]
        del self._map[_indx]
        self._log.info("%s: _map: %s" % (self, self._map))
        self._log.rtn("%s: success" % self)

    def _update_mapping(
        self, _indx: str = None, _b: Any = None, _c: object = None
    ) -> None:
        """Private. Update an existing entry in the socket map.

        Parameters
        ----------
        _indx : hexstring
           The file descriptor identifier.
        _b  : bytes
           The byte string.
        _c  : object
           The connection object (socket).
        """
        self._log.args("%s (_indx: %s, _b: %s, _c: %s})"
                       % (self, _indx, _b, _c))
        if _b and _c:
            self._map[_indx]["buffer"] += _b
            self._map[_indx]["conn"] = _c
        elif _c is None and _b:
            self._map[_indx]["buffer"] += _b
        elif _b is None and _c:
            self._map[_indx]["conn"] = _c
        else:
            pass
        self._log.info("%s: _map: %s" % (self, self._map))
        self._log.rtn("%s: success" % self)

    def _loop(self, timeout: float = 0.0) -> None:
        """Override. The event loop."""
        self._log.args("%s: (timeout: %d)" % (self, timeout))
        pass

    def _handle_event(self, _e: int) -> None:
        """Override. Handle the events returned by the iopoller."""
        self._log.args("%s (_e: %s)" % (self, _e))
        pass

    def _handle_request(self, _req: object) -> None:
        """Override. Handle a connection request."""
        self._log.args("%s (_req: %s)" % (self, _req))
        pass

    def _handle_active(self, _fd: int) -> None:
        """Override. Handle an existing connection."""
        self._log.args("%s (_fd: %s)" % (self, _fd))
        pass

    def _handle_close(self, _fd: int, _c: object) -> None:
        """Override. Handle the closing of a connection."""
        self._log.args("%s (_fd: %s, _c: %s)" % (self, _fd, _c))
        pass

    def _schedule_task(self) -> None:
        """Override. Create a task from buffers onto the task queue."""
        self._log.args("%s: ()" % self)
        pass

    def _create_task(self, _b: list) -> object:
        """Override. Create a single Task."""
        self._log.args("%s (_b: %s)" % (self, _b))
        pass

    def _execute_scheduled(self) -> None:
        """Private. Execute a task in the task list."""
        pass

    def _retrieve_task(self, task_id: str) -> Any:
        """Helper method to get task from scheduled.

        Parameters
        ----------
        task_id: str
            Task identification string.
        """
        self._log.args("%s (task_id: %s)" % (self, task_id))
        pass

    def _bind_and_listen(self) -> None:
        """Private. Bind and listen on the inbound socket."""
        self._log.args("%s: ()" % self)
        self._bind(
            self._config["inbound_socket_config"]["host"],
            self._config["inbound_socket_config"].get("port")
        )
        self._listen(self._config["max_con"])
        self._log.rtn("%s: success" % self)

    def _bind(self, host: str, port: int) -> None:
        """Private. Bind on the listening socket.

        Parameters
        ----------
        host : str
           IP address.
        port : int
           The port to bind to.
        """
        self._log.args("%s (host: %s, port: %s)" % (self, host, port))
        self._wmqsocket.bind(host, port)
        self._log.rtn("%s: success" % self)

    def _listen(self, _max: int = 0) -> None:
        """Private. Listen on the Inbound socket.

        Parameters
        ----------
        _max : int
           An integer marking the max connections.
        """
        self._log.args("%s (_max: %s)" % (self, _max))
        self._wmqsocket.listen(_max)
        self._log.rtn("%s: success" % self)

    def close(self) -> None:
        """Public. Close the listening socket"""
        self._log.args("%s ()" % self)
        self._wmqsocket.close()
        self._log.rtn("%s: success" % self)
