# -*- coding: utf-8 -*-

from wiremq.utils import iotask
from typing import Dict
from wiremq.extlib.asynchronous.eventloops import baseioeventloop
from wiremq.extlib.err.socketexception import SocketException
from wiremq.extlib.err.asyncexception import IOEventLoopInitException


class IOEventLoopTCP(baseioeventloop.BaseIOEventLoop):
    """TCP IO Event loop.

    This compoenent works in conjunction with the wmqsocket, Task, Scheduler
    and IOBasePoller. The event loop aims to handle io tasks within a single
    thread.

    Attributes
    ----------
    _config : Dict
        The configuration dictionary.
    _fdid_map : Dict
        A dictionary of file descriptor ids to file descriptors.

    Methods
    -------
    _loop() : None
        This is the main event loop. Poll the kernel, return the events,
        handle and schedule for execution.
    _handle_events() : None
        Overriden. Handles an event occurring on the fd.
        _e : int
          The fd the event has occurred on.
    _handle_request() : None
        Overriden. Receives and determines if the connection is unique.
        _req : int
          The request or fd.
    _handle_active() -> None:
        _fd : int
          The connection objects file descriptor.
        Handle an existing connection.
    _handle_close() : None
        Handles the removal of _fdid from the active list and prepares them for
        task creation (by appending to ready buffer).
    _accept_request() : tuple
        Calls validate and verify prior to accepting an inbound request. If the
        request is validated and verifies it returns the socket and connection
        obj as a tuple.
    _schedule_task() : None
        Schedule a task. Check the ready list, extract the fd, retrieve bytes,
        create a task object and instantiate with the bytes in the buffer.
    _create_task() : Task
        Receive a byte string and create and return a task object.
    _execute_scheduled(): None
        Use the class object's scheduler to schedule and execute a task in the
        task list.
    _retrieve_task(): object
        Helper method to get task from scheduled.
    _verify_request() : bool
        Verify the inbound request. Unimplemented, returns True.
    _validate_request() : bool
        Validate an inbound request. Unimplemented, returns True.
    """

    def __init__(self, config: Dict = None):
        """IOEventLoopTCP constructor.

        Initialize with the configuration dictionary as follows:

        Parameters
        ----------
        config: dict
            IOEventloopTCP configuration dictionary.
            poller : BaseIOPoller
                BaseIOPoller object type.
            terminator : bytes
                The termination sequence (as byte string)
            scheduler : Scheduler
                A BaseScheduler type object.
            socket : Inboundsocket
                An inbound (TCP) wmq socket.
            host : str
                The host IP as a string.
            port : int
                The port to bind to as an integer.
            max_con : int
                Specify the maximum allowable connections (at a time).

        Example:
        -------
        >>> config = {}
        >>> config["poller"] = iopoller
        >>> config["terminator"] = b'\r\r'
        >>> config["scheduler"] = None
        >>> config["socket"] = wmqsocket
        >>> config["buffer_size"] = 1024
        >>> config["listening"] = True
        >>> config["host"] = "127.0.0.1"
        >>> config["port"] = 60081
        >>> config["max_con"] = 202
        >>> config["task_name"] = "io-task"
        >>> evloop = ioeventlooptcp.IOEventLoopTCP(config)
        """
        super().__init__(config)
        self._fdid_map = {}

    def initialize(self) -> None:
        """Initialize the event loop.

        Bind and listen on the socket. Register the socket to the socket map
        and the io poller.

        Raises
        ------
        IOEventLoopInitException
            Exception handling the failure of initialization the io loop.
        """
        self._log.args("%s: ()" % self)
        try:
            self._bind_and_listen()
            self._io.register(self._wmqsocket_fd, "IN")
            self._add_mapping(
                _indx=self._wmqsocket_id, _fd=self._wmqsocket_fd, _c=self._wmqsocket
            )
        except SocketException as e:
            self._log.error(e)
            raise IOEventLoopInitException(e)
        self._log.rtn("%s: success" % self)

    def _loop(self, timeout: float = 0.0) -> None:
        """The event loop."""
        self._log.args("%s: (timeout: %d)" % (self, timeout))
        events = self._io.poll(timeout)

        for e in events:
            self._log.info("%s: [event]: %s" % (self, e))
            self._handle_event(e)

        # For completed buffers, create the task
        self._schedule_task()

        # For ready tasks in the task queue, execute.
        if self._scheduler:
            self._execute_scheduled()
        self._log.rtn("%s: success" % self)

    def _handle_event(self, _e: int) -> None:
        """Private. Handles all the fd in the events list.

        Parameters
        ----------
        _e : int
            The file descriptor representing the event.
        """
        self._log.args("%s: (_e: %d)" % (self, _e))
        if _e == self._wmqsocket_fd:
            self._handle_request(_e)
        else:
            self._handle_active(_e)
        self._log.rtn("%s: success" % self)

    def _handle_request(self, _req: int) -> None:
        """Private. Handles an event from the events list.

        Accept a request and handle the returned socket. The returned socket
        object's fd is appended to the active fd list and registered to the
        poller. A mapping is then created for the request.

        Parameters
        ----------
        _req : int
           The file descriptor the connection request occurred on.
        """
        self._log.args("%s (_req: %s)" % (self, _req))
        conn, addr = self._accept_request(_req)
        conn.setblocking(0)
        _fdid = self._generate_fdid(addr)
        _fd = conn.fileno()
        self._log.info("%s: accepted connection on fd: %s" % (self, _fd))
        self._fdid_map[_fd] = _fdid
        self._active.append(_fdid)
        self._log.info("%s: _active: %s" % (self, self._active))
        self._add_mapping(_indx=_fdid, _fd=_fd, _c=conn)
        self._io.register(_fd, "IN")
        self._log.rtn("%s: success" % self)

    def _handle_active(self, _fd: int) -> None:
        """Private. Handle active bytes exchange.

        For each file descriptor, look up the connection object and the active
        buffer and place the bytes data onto the buffer.

        Parameters
        ----------
        _fd : int
           The file descriptor the event has occurred on.
        """
        self._log.args("%s (_fd: %s" % (self, _fd))
        _fdid = self._fdid_map[_fd]
        _conn = self._map[_fdid]["conn"]
        _data = _conn.recv(self._CONN_RECV_BUFF_SIZE)
        if _data:
            self._log.info("%s: _conn: %s" % (self, _conn))
            self._log.info("%s: recv %s bytes" % (self, len(_data)))
            self._update_mapping(_indx=_fdid, _b=_data)
        else:
            self._handle_close(_fd, _conn)
        self._log.rtn("%s: success" % self)

    def _handle_close(self, _fd: int, _c: object) -> None:
        """Handle the closing of a connection.

        Closing a connection requires the removal of the file descriptor from
        active connections list, unregistering the file descriptor from the io
        poller object appending the fd to the ready for scheduling list and
        finally closing the connection object associated with the descriptor.
        Unregistering a fd which does not exist raises a
        IOLoopUnregisterFDException.

        Parameters
        ----------
        _fd : int
           The file descriptor the event has occurred on.
        _c  : object
           The connection object (socket).
        """
        self._log.args("%s (_fd: %s, _c: %s)" % (self, _fd, _c))
        _fdid = self._fdid_map[_fd]
        self._io.unregister(_fd)
        self._active.remove(_fdid)
        self._ready.append(_fdid)
        self._log.info("%s: _active: %s}" % (self, self._active))
        self._log.info("%s: _ready: %s" % (self, self._ready))
        _c.close()
        self._log.rtn("%s: success" % self)

    def _schedule_task(self) -> None:
        """Private. Create a task from buffers onto the task queue.

        Scheduling a task by first checking the ready list, extracting the fd,
        retrieving the bytes buffer from the map and instantiating a task with
        the acquired buffer. Afterwards, remove the fd from the ready list,
        append the task to the scheduled list and delete the mapping (indexed
        by the file descriptor).
        """
        self._log.args("%s: ()" % self)
        for _fdid in self._ready:
            _t = self._create_task(_b=self._map[_fdid]["buffer"])
            self._log.info("%s: [Task-Created]: %s" % (self, _t.get_id()))
            self._scheduled.put(_t)
            self._del_mapping(_fdid)
            self._log.info("%s: [Task-Scheduled]: %s" % (self, self._scheduled))
            self._ready.remove(_fdid)
            self._log.info("%s: _ready: %s" % (self, self._ready))
        self._log.rtn("%s: success" % self)

    def _create_task(self, _b: bytes) -> object:
        """Private. Create a single IO-Task.

        Parameters
        ----------
        _b  : bytes object
            The byte string received.

        Returns
        -------
        task : IOTask
            The newly created task object.
        """
        self._log.args("%s (_b: %s)" % (self, _b))
        task = iotask.IOTask(name="io-task", buff=_b)
        self._log.rtn("%s: success | data: %s" % (self, task))
        return task

    def _accept_request(self, _req: int) -> tuple:
        """Accept the request on the socket.

        Parameters
        ----------
        req : int
           The file descriptor.

        Returns
        -------
        rtn : tuple
           sock : object
              The connection object.
           addr : tuple
              The address and port of the requestor.
        """
        self._log.args("%s (_req: %s)" % (self, _req))
        rtn = self._wmqsocket.accept()
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _verify_request(self, sock: object, addr: tuple) -> bool:
        """Verify a single received request.

        This method can be used for accept/deny policy rules.

        Parameters
        ----------
        sock : object
            The connection object.
        addr : tuple
            The address and port to be verified.

        Returns
        -------
        rtn : bool
            True if the request is from a verified sender, false otherwise.
        """
        self._log.args("%s (sock: %s, addr: %s)" % (self, sock, addr))
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _validate_request(self, sock: object, addr: tuple) -> bool:
        """Private. Ensure the request is valid.

        This method can be used for accept/deny policy rules.

        Parameters
        ----------
        sock : object
            The connection object.
        addr : tuple
            The address and port to be validated.

        Returns
        -------
        rtn : bool
           True if the request is of a valid form, false otherwise.
        """
        self._log.args("%s: (sock: %s, addr: %s)" % (self, sock, addr))
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _log_stats(self, events: list = None) -> None:
        self._log.info("%s: events: %s" % (self, events))
        self._log.info("%s: active : %s" % (self, self._active))
        self._log.info("%s map: %s}" % (self, self._map))
        self._log.info("%s: ready: %s" % (self, self._ready))
        self._log.info("%s: scheduled %s" % (self, self._scheduled))
