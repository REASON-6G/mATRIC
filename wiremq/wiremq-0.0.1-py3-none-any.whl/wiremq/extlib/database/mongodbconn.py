# -*- coding: utf-8 -*-
"""Database (plugin) connector for Mongo DB."""

from typing import (
    Any,
    Dict
)
import pymongo
from wiremq.extlib.database import basedbconn
from wiremq.extlib.err.databaseexception import (
    DBOperationalException,
    DBProgrammingException,
    DBInsertException,
    DBSelectException,
    DBUpdateException,
    DBDeleteException
)


class MongoDBConn(basedbconn.BaseDBConn):
    """DB connection class for MongoDB.

    Attributes
    ----------
    _connection: object
        Database connection object.
    _db: object
        Holds the database object to be accessed/modified.
    _config: dict
        Database configuration dictionary.
    _log: object
        Python logging instance.

    Methods
    -------
    config(): None
        Configures database connection object.
    get_database_config(): Dic
        Returns the configuration of the database connection.
    connect(): Any
        Creates a connection to the database.
    select(): list
        Select implements the find statement from the database.
    count_documents() : list
        Count_documents implements the count_documents query from the database.
    insert(): None
        Insert implements insert statement.
    update(): int
        Update implements update statement.
    delete(): None
        Delete implements delete to remove data from a database colection.
    create_db(): bool
        Create a new database.
    create_table(): None
        Create a new database collection.
    delete_table(): None
        Delete a collection.
    _set_sb: None
        Set the working db.
    close(): None
        Closes a database connection.

    Raises
    ------
    DBOperationalException:
        Exception raised an operational error occurs in database interactions.
    DBProgrammingException:
        Exception raised when a programming error occurs when interacting with
        a database.

    """

    def __init__(self, config: Dict = None) -> None:
        """Mongo database connection constructor.

        Initializes an MongoDB connection with the Mongo database.

        Parameters
        ----------
        config: Dict
            type: str
                Database connection type.
            credentials: Dict
                user: str
                    User name, user must exists in the database.
                password: str
                    Password of user.
                port: int
                    Port number.
                host: str
                    Host ip.
                database: str
                    Database name
            connect_timeout: int, optional
                Time in milliseconds for server connection timeout.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> config = {}
        >>> config["type"] = "MongoDBConn",
        >>> config["credentials"] = {}
        >>> config["credentials"]["user"] = "weaverusr"
        >>> config["credentials"]["pasword"] = "weaverpass"
        >>> config["credentials"]["port"] = 27017
        >>> config["credentials"]["host"] = "localhost"
        >>> config["credentials"]["database"] = "user": "weaverdb"
        >>> config["connect_timeout"] = 10000
        >>> mongodb = mongodbconn.MongoDBConn(config)
        """

        self._id = self._generate_id()
        self._config = None
        self._log = None
        self._connection = None
        self._db = None
        if config:
            self.config(config)

    def __enter__(self) -> Any:
        """Magic method. Make the Mongo DB connection and return it."""
        self._log.args("%s: ()" % self)
        self._connection = self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Magic method. Close the database connection."""
        self._log.args("%s: (exc_type: %s, exc_val: %s, exc_tb: %s)"
                       % (self, exc_type, exc_val, exc_tb))
        try:
            self._cursor.close()
            if isinstance(exc_val, Exception):
                self._connection.rollback()
            else:
                self._connection.commit()
            self._connection.close()
        except Exception as e:
            self._log.error("%s: failure | message: %s" % (self, str(e)))
        self._log.rtn("%s: success" % self)

    def config(self, config: Dict) -> None:
        """Configures database connection object.

        Parameters
        ----------
        config: Dict
            type: str
                Database connection type.
            credentials: Dict
                user: str
                    User name, user must exists in the database.
                password: str
                    Password of user.
                port: int
                    Port number.
                host: str
                    Host ip.
                database: str
                    Database name
            connect_timeout: int, optional
                Time in milliseconds for server connection timeout.
            logger: str, optional
                Name of the logger instance.
        """
        super().config(config)
        self._log.args("%s: (config: %s)" % (self, config))
        self._connection = self.connect()
        self._log.rtn("%s: success" % self)

    def get_database_config(self) -> Dict:
        """Returns the configuration of the database connection

        Returns
        -------
        config: Dict
            type: str
                Database connection type.
            credentials: Dict
                user: str
                    User name, user must exists in the database.
                password: str
                    Password of user.
                port: int
                    Port number.
                host: str
                    Host ip.
                database: str
                    Database name
            connect_timeout: int
                Time in milliseconds for server connection timeout.

        """
        self._log.args("%s: ()" % self)
        config = self._config
        self._log.rtn("%s: success | data: %s" % (self, config))
        return config

    def connect(self) -> Any:
        """Creates a connection to the database. Raises DBOperationalException
        for operational errors (such as credential or connection issues), also
        raises DBProgrammingException for syntax errors in queries for example.

        Returns
        -------
        dbconn: Any
            Database connection object.

        Raises
        ------
        DBOperationalException:
            Exception raised an operational error occurs in database
            interactions.
        DBProgrammingException:
            Exception raised when a programming error occurs when interacting
            with a database.
        """
        self._log.args("%s: ()" % self)

        _user = self._config["credentials"]["user"]
        _pass = self._config["credentials"]["password"]
        _host = self._config["credentials"]["host"]
        _port = self._config["credentials"]["port"]
        _connect_timeout = self._config.get("connect_timeout")
        if not _connect_timeout:
            _connect_timeout = 30000
        _database = self._config["credentials"]["database"]

        try:
            self._connection = pymongo.MongoClient(
                "{}:{}".format(_host, _port),
                username=_user,
                password=_pass,
                authSource=_database,
                authMechanism='SCRAM-SHA-256',
                serverSelectionTimeoutMS=_connect_timeout
            )
        except pymongo.errors.ConfigurationError as e:
            self._log.error(e)
            raise DBProgrammingException(e)
        except ValueError as e:
            self._log.error(e)
            raise DBProgrammingException(e)

        try:
            self._connection.server_info()
        except pymongo.errors.OperationFailure as e:
            self._log.error(e)
            raise DBOperationalException(e)
        except pymongo.errors.ServerSelectionTimeoutError as e:
            self._log.error(e)
            raise DBOperationalException(e)
        except pymongo.errors.InvalidOperation as e:
            self._log.error(e)
            raise DBOperationalException(e)

        self._db = self._connection[_database]

        dbconn = self._connection
        self._log.rtn("%s: success | data: %s" % (self, dbconn))
        return dbconn

    def select(self, _table: str, _attrs: Dict = None,
               _where: str = None, _distinct: bool = False,
               _group_by: list = None, _order_by: tuple = False,
               _limit: int = None) -> list:
        """Select implements the find statement for mongo db.  Raises a
        DBSelectException if there is an error in completing this operation.

        Parameters
        ----------
        _table: str
            Name of the database table.
        _attrs: list, optional
            The attributes to select.
            If not specified all attrs are selected.
        _where: str, optional
            Where clause of a database query. Restrict the return
            base on column data.
        _distinct: str, optional
            This flag determines whether the results should have repeated
            elements.
        _group_by: list
            Group the result into given column(s)
        _order_by: list
            Order results by column(s).
        _limit: int
            Specify the number of results from the database.

        Returns
        -------
        res: list
            The results from the select query as a list.

        Raises
        ------
        DBSelectException:
            Exception raised when an operational or programming error occurs
            with the dbconn when issuing a SELECT query.
        """
        self._log.args("%s: (_table: %s, _attrs: %s, _where: %s, "
                       "_distinct: %r, _group_by: %s, _order_by: %s, "
                       "_limit: %s)" % (self, _table, _attrs, _where,
                                        _distinct, _group_by, _order_by,
                                        _limit))
        _col = self._db[_table]

        try:
            if _attrs is not None:
                if "_id" not in _attrs:
                    _attrs["_id"] = 0

            if _where and _attrs:
                _res = _col.find(_where, _attrs)
            elif _where and not _attrs:
                _res = _col.find(_where)
            elif not _where and _attrs:
                _res = _col.find({}, _attrs)
            else:
                _res = _col.find()

            if _group_by:
                _res = _res.aggregate(_group_by)
            if _order_by:
                _order_by = self._add_ordering(_order_by)
                _res = _res.sort(_order_by)
            if _limit:
                _res = _res.limit(_limit)
        except pymongo.errors.OperationFailure as e:
            self._log.error(e)
            raise DBSelectException(e)
        except pymongo.errors.ServerSelectionTimeoutError as e:
            self._log.error(e)
            raise DBSelectException(e)
        except pymongo.errors.InvalidOperation as e:
            self._log.error(e)
            raise DBSelectException(e)
        self._log.rtn("%s: success | data: %s" % (self, _res))
        return list(_res)

    def count_documents(self, _table: str,
                        _where: str = None,
                        _limit: int = None) -> list:
        """Count_documents implements the count_documents query for mongo db.
        Raises a DBSelectException if there is an error in completing this
        operation.

        Parameters
        ----------
        _table: str
            Name of the database table.
        _where: str, optional
            Where clause of a database query. Restrict the return
            base on column data.
        _limit: int
            Specify the maximum number of results to count from the table.

        Returns
        -------
        res: list
            The results from the select query as a list.

        Raises
        ------
        DBSelectException:
            Exception raised when an operational or programming error occurs
            with the dbconn when issuing a SELECT query.
        """
        self._log.args("%s: (_table: %s, _where: %s,_limit: %s)"
                       % (self, _table, _where, _limit))
        _col = self._db[_table]
        try:
            if _where and _limit:
                _res = _col.count_documents(_where, _limit)
            elif _where and not _limit:
                _res = _col.count_documents(_where)
            else:
                _res = _col.count_documents({})
        except pymongo.errors.OperationFailure as e:
            self._log.error(e)
            raise DBSelectException(e)
        except pymongo.errors.ServerSelectionTimeoutError as e:
            self._log.error(e)
            raise DBSelectException(e)
        except pymongo.errors.InvalidOperation as e:
            self._log.error(e)
            raise DBSelectException(e)
        self._log.rtn("%s: success | data: %s" % (self, _res))
        return _res

    def insert(self, _table: str, records: Dict) -> None:
        """Insert implements INSERT statement to insert records to a
        collection. Raises a DBDeleteException if there is an error in
        completing this operation.

        Parameters
        ----------
        _table: str
            The name of the database table.
        records: dict
            column: column name
                Column name as key of dictionary.
            column_value: str
                Data value for each column to be added in database.

        Raises
        ------
        DBInsertException:
            Exception raised when an operational or programming error occurs
            with the dbconn when issuing an INSERT query.
        """
        self._log.args("%s: (_table: %s, records: %s)"
                       % (self, _table, records))
        _col = self._db[_table]
        try:
            _col.insert_one(records)
        except pymongo.errors.OperationFailure as e:
            self._log.error(e)
            raise DBInsertException(e)
        except pymongo.errors.ServerSelectionTimeoutError as e:
            self._log.error(e)
            raise DBInsertException(e)
        except pymongo.errors.InvalidOperation as e:
            self._log.error(e)
            raise DBInsertException(e)
        self._log.rtn("%s: success" % self)

    def insert_many(self, _table: str, list_records: list) -> None:
        """Insert implements INSERT statement to insert records to a database
        collection. Raises a DBDeleteException if there is an error in
        completing this operation.

        Parameters
        ----------
        _table: str
            The name of the database table.
        list_records: list
            List of records to be inserted.
            records: dict
                column: column name
                    Column name as key of dictionary.
                column_value: str
                    Data value for each column to be added in database.

        Raises
        ------
        DBInsertException:
            Exception raised when an operational or programming error occurs
            with the dbconn when issuing an INSERT query.
        """
        self._log.args("%s: (_table: %s, list_records: %s)"
                       % (self, _table, list_records))
        _col = self._db[_table]
        try:
            _col.insert_many(list_records)
        except pymongo.errors.OperationFailure as e:
            self._log.error(e)
            raise DBInsertException(e)
        except pymongo.errors.ServerSelectionTimeoutError as e:
            self._log.error(e)
            raise DBInsertException(e)
        except pymongo.errors.InvalidOperation as e:
            self._log.error(e)
            raise DBInsertException(e)
        self._log.rtn("%s: success" % self)

    def update(self, _table: str, _set: Dict, _where: Dict = None) -> None:
        """Update implements UPDATE statement, to update database records.
        Raises a DBUpdateException if there is an error in completing this
        operation.

        Parameters
        ----------
        _table: str
            The name of the collection.
        _where: str, optional
            field: str
                Column name as key of dictionary.
            field_value: str
                Data value for each column.
        _set: dict
            field: str
                New column name as key of dictionary.
            field_value: str
                New data value for each column.

        Raises
        ------
        DBUpdateException:
            Exception raised when an operational or programming error occurs
            with the dbconn when issuing an UPDATE query.

        """
        self._log.args("%s: (_table: %s, _set: %s, _where: %s)"
                       % (self, _table, _set, _where))
        _col = self._db[_table]
        try:
            _col.update_one(_where, {"$set": _set})
        except pymongo.errors.OperationFailure as e:
            self._log.error(e)
            raise DBUpdateException(e)
        except pymongo.errors.ServerSelectionTimeoutError as e:
            self._log.error(e)
            raise DBUpdateException(e)
        except pymongo.errors.InvalidOperation as e:
            self._log.error(e)
            raise DBUpdateException(e)
        self._log.rtn("%s: success | data: success" % self)

    def delete(self, _table: str, _where: Dict) -> None:
        """Delete implements DELETE to remove data from a database collection.
        Raises a DBDeleteException if there is an error in completing this
        operation.

        Parameters
        ----------
        _table: str
            The name of the collection.
        _where: str, optional
            Where clause of a database query.
            field: str
                New column name as key of dictionary.
            field_value: str
                New data value for each field.

        Raises
        ------
        DBDeleteException:
            Exception raised when an operational or programming error occurs
            with the dbconn when issuing a DELETE query.
        """
        self._log.args("%s: (_table: %s, _where: %s)" % (self, _table, _where))
        _col = self._db[_table]
        try:
            _col.delete_one(_where)
        except pymongo.errors.OperationFailure as e:
            self._log.error(e)
            raise DBDeleteException(e)
        except pymongo.errors.ServerSelectionTimeoutError as e:
            self._log.error(e)
            raise DBDeleteException(e)
        except pymongo.errors.InvalidOperation as e:
            self._log.error(e)
            raise DBDeleteException(e)
        self._log.rtn("%s: success" % self)

    def create_db(self, db_name: str) -> None:
        """Create a new database.

        Parameters
        ----------
        _db_name: str
            The name of the database.
        """
        self._log.args("%s: (db_name: %s)" % (self, db_name))
        self._connection[db_name]
        self._log.rtn("%s: success" % self)

    def _set_db(self, db_name) -> None:
        """Sets another active db.

        Parameters
        ----------
        _db_name: str
            The name of the database.
        """
        self._log.args("%s: (db_name: %s)" % (self, db_name))
        self._db = self._connection[db_name]
        self._log.rtn("%s: success" % self)

    def create_table(self, collection: str) -> None:
        """Create a new collection in database. Raises DBOperationalException
        for operational errors (such as credential or connection issues), also
        raises DBProgrammingException for syntax errors in queries for example.

        Raises
        ------
        DBProgrammingxception:
            Exception raised when a programming error occurs when interacting
            with a database.
        DBOperationalException:
            Exception raised an operational error occurs in database
            interactions.

        Parameters
        ----------
        collection: str
            Collection/Table to add in the database.
        """
        self._log.args("%s: (collection: %s)" % (self, collection))
        try:
            self._db[collection]
        except pymongo.errors.OperationFailure as e:
            self._log.error(e)
            raise DBOperationalException(e)
        except pymongo.errors.ServerSelectionTimeoutError as e:
            self._log.error(e)
            raise DBOperationalException(e)
        except pymongo.errors.InvalidOperation as e:
            self._log.error(e)
            raise DBOperationalException(e)
        self._log.rtn("%s: success" % self)

    def delete_table(self, table: str) -> None:
        """Delete a collection. Raises DBOperationalException for operational
        errors (such as credential or connection issues), also raises
        DBProgrammingException for syntax errors in queries for example.

        Parameters
        ----------
        table: str
            Collection name to be dropped.

        Raises
        ------
        DBProgrammingxception:
            Exception raised when a programming error occurs when interacting
            with a database.
        DBOperationalException:
            Exception raised an operational error occurs in database
            interactions.
        """
        self._log.args("%s: (table: %s" % (self, table))
        try:
            _col = self._db[table]
        except pymongo.errors.OperationFailure as e:
            self._log.error(e)
            raise DBOperationalException(e)
        except pymongo.errors.ServerSelectionTimeoutError as e:
            self._log.error(e)
            raise DBOperationalException(e)
        except pymongo.errors.InvalidOperation as e:
            self._log.error(e)
            raise DBOperationalException(e)
        _col.drop()
        self._log.rtn("%s: success" % self)

    def close(self) -> None:
        """Closes a database connection."""
        self._log.args("%s: ()" % self)
        self._connection.close()
        self._log.rtn("%s: success" % self)

    def _add_ordering(self, ordering: list) -> list:
        self._log.args("%s: (ordering: %s)" % (self, ordering))
        order_by = []
        for item in ordering:
            if item[1] == "ASC":
                sort = 1
            else:
                sort = -1
            order_by.append((item[0], sort))
        self._log.rtn("%s: success | data: %s" % (self, order_by))
        return order_by
