# -*- coding: utf-8 -*-

"""Base database (plugin) connector.
This is the parent class for a database plugin (eg. mysql,
mariadb .. etc. )"""

import uuid
from typing import (
    Any,
    Dict
)
import logging


class BaseDBConn(object):
    """Base (adaptee) class for database plugins.

    Attributes
    ----------
    _connection : object
        Database connection object.
    _cursor: object
        Cursor is used to execute SQL statements.
    _log: object
        Python logging instance.

    Methods
    -------
    select()
        Select implements the SELECT statement from the database.
    insert()
        Insert implements INSERT statement to insert
        records to a database table.
    update()
        Update implements UPDATE statement, to update
        database records.
    delete()
        Delete implements DELETE to remove data from a
        database table.
    create_db()
        Create a new database.
    create_table()
       Create a new database table.
    """

    def __init__(self, config: dict) -> None:
        self._id = self._generate_id()
        self._connection = None
        self._config = None
        self._cursor = None
        self._log = None
        if config:
            self.config(config)

    def __enter__(self) -> Any:
        """Magic method. Make the DB connection and return it."""
        self._log.args("%s: ()" % self)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Magic method. Close the database connection."""
        self._log.args("%s: (exc_type: %s, exc_val: %sexc_tb: %s)"
                       % (self, exc_type, exc_val, exc_tb))
        try:
            self._cursor.close()
            if isinstance(exc_val, Exception):
                self._connection.rollback()
            else:
                self._connection.commit()
            self._connection.close()
        except Exception as e:
            self._log.critical("%s: failure | message: %s" % (self, e))

    def __name__(self) -> str:
        """Return name."""
        return object.__name__

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def config(self, config: Dict) -> None:
        """Configures the database connection.

        Parameters
        ----------
        config: Dict
            dbconn configuration dictionary
            logger: str, optional
                Name of the logger instance.

        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: (config: %s)" % (self, config))
        self._config = config

    def connect(self,
                kwargs: Dict
                ) -> Any:
        """Creates a connection to the database.

        Parameters
        ----------
        kwargs: dict
            Hold all the connection credintial, the name
            of the database and the host.

        Returns
        -------
        dbconn: Any
            Database connection object.
        """
        self._log.args("%s: (kwargs: %s)" % (self, kwargs))
        pass

    def query(self,
              _query: str,
              _values: list
              ) -> list:
        """Database Query."""
        self._log.args("%s: (_query: %s, _values: %s)"
                       % (self, _query, _values))
        pass

    def select(self,
               _table: str,
               _field: str,
               _where: str,
               args: tuple,
               kwargs: Dict
               ) -> list:
        """Select implements the SELECT statement from the database.

        Parameters
        ----------
        _table: str
            Name of the database table.
        _attrs: list, optional
            The attributes to select.
            If not specified all attrs are selected.
        _where: str, optional
            Where clause of a database query. Restrict the return
            base on column data.
        _distinct: str, optional
           This flag determines whether the results should have repeated
           elements.

        """
        self._log.args("%s: (_table: %s, _field: %s, where: %s, args: %s, "
                       "kwargs: %s)" % (self, _table, _field, _where, args,
                                        kwargs))
        pass

    def insert(self,
               _table: str,
               _where: str,
               args: tuple,
               kwargs: Dict
               ) -> list:
        """Insert implements INSERT statement to insert
           records to a database table.

        Parameters
        ----------
        _table: str
            The name of the database table.
        _where: str, optional
            Where clause of a database query. Restrict the return
            base on column data.
        args: list
            List of database columns to insert data.
        kwargs: dict
            column: column name
                Column name as key of dictionary.
            column_value: str
                Data value for each column.

        """
        self._log.args("%s: (_table: %s, _where: %s, args: %s, kwargs: %s)"
                       % (self, _table, _where, args, kwargs))
        pass

    def update(self,
               _table: str,
               _where: tuple,
               kwargs: Dict
               ) -> list:
        """Update implements UPDATE statement, to update
           database records.

        Parameters
        ----------
        _table: str
            The name of the table.
        _where: str, optional
            Where clause of a database query. Restrict the return
            base on column data.
        kwargs: dict
            column: column name
                Column name as key of dictionary.
            column_value: str
                Data value for each column.

        """
        self._log.args("%s: (_table: %s, _where: %s, kwargs: %s)"
                       % (self, _table, _where, kwargs))
        pass

    def delete(self,
               _table: str,
               _where: list
               ) -> list:
        """Delete implements DELETE to remove data from a
           database table.

        Parameters
        ----------
        _table: str
            The name of the table.
        _where: str, optional
            Where clause of a database query. Restrict the return
            base on column data.

        """
        self._log.args("%s: (_table: %s, _where: %s)" % (self, _table, _where))
        pass

    def create_db(self,
                  _table_name: str,
                  _command: str
                  ) -> bool:
        """Create a new database.

        Parameters
        ----------
        _db_name: str
            The name of the database.

        """
        self._log.args("%s: (_table_name: %s, _command: %s)"
                       % (self, _table_name, _command))
        pass

    def create_table(self,
                     _command: str
                     ) -> bool:
        """Create a new database table.

        Parameters
        ----------
        _command: str
            The command tp create the database table.
        """
        self._log.args("%s: (_command: %s)" % (self, _command))
        pass
