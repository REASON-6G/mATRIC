# -*- coding: utf-8 -*-
"""Database Adapter base class. """

from typing import Dict
import uuid
import logging
from wiremq.extlib.database import (
    abstractdbconn,  # Abstract Target
    basedbconn       # Adaptee base class
)


class BaseDatabase(abstractdbconn.AbstractDBConn):
    """Base (Adapter) class for database queries.

    Base database inherits from the abstract conn class.
    Standardizes the database interface used through the class.

    Attributes
    ----------
    _database : object
        Database connection object.
    _log: object
        Python logging instance.

    Methods
    -------
    select()
        Select implements the SELECT statement from the database.
    insert()
        Insert implements INSERT statement to insert
        records to a database table.
    update()
        Update implements UPDATE statement, to update
        database records.
    delete()
        Delete implements DELETE to remove data from a
        database table.
    create_db()
        Create a new database.
    create_table()
       Create a new database table.
    _log: object
        Python logging instance.
    """

    def __init__(self, config: dict) -> None:
        """Base class constructor.

        Initialize a base database class.

        Parameters
        ----------
        config: dict
            Database configuration dictionary
            adaptee: object
                A base database connection is required.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> config = {
        ...     "adaptee": basedbconn.BaseDBConn(),
        ...     "logger": "basic_logger"
        ... }
        >>> basedatabase = basedatabase.BaseDatabase(config)
        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._id = self._generate_id()
        self._log.args("%s: (config: %s" % (self, config))
        self._database = config["adaptee"]
        self._log.rtn("%s: success" % self)

    def __name__(self) -> str:
        """Return name."""
        return object.__name__

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        self._log.rtn("success | data: %s" % _id)
        return _id

    def select(self, _table: str,
               _field: str = None,
               _where: str = None,
               args: tuple = None,
               kwargs: Dict = None
               ) -> list:
        """Select implements the SELECT statement from the database.

        Parameters
        ----------
        _table: str
            Name of the database table.
        _attrs: list, optional
            The attributes to select.
            If not specified all attrs are selected.
        _where: str, optional
            Where clause of a database query. Restrict the return
            base on column data.
        _distinct: str, optional
           This flag determines whether the results should have repeated
           elements.

        Returns
        -------
        res: list
            The results from the select query as a list.
        """
        self._log.args("%s: (_field: %s, _where: %s, args: %s, kwargs: %s)"
                       % (self, _field, _where, args, kwargs))
        with self._database as db:
            res = db.select(_table,
                            _field,
                            _where,
                            args,
                            kwargs
                            )
        self._log.rtn("%s: success | data: %s" % (self, res))
        return res

    def insert(self,
               _table: str,
               _where: str = None,
               args: tuple = None,
               kwargs: Dict = None
               ) -> list:
        """Insert implements INSERT statement to insert
           records to a database table.

        Parameters
        ----------
        _table: str
            The name of the database table.
        _where: str, optional
            Where clause of a database query. Restrict the return
            base on column data.
        args: list
            List of database columns to insert data.
        kwargs: dict
            column: column name
                Column name as key of dictionary.
            column_value: str
                Data value for each column.

        Returns
        -------
        res: list
            The result of the insert query as a dict.
        """
        self._log.args("%s: (_table: %s, _where: %s, args: %s, kwargs: %s)"
                       % (self, _table, _where, args, kwargs))
        with self._database as db:
            res = db.insert(_table,
                            _where,
                            args,
                            kwargs
                            )
        self._log.rtn("%s: success | data: %s" % (self, res))
        return res

    def update(self,
               _table: str,
               _where: str = None,
               kwargs: Dict = None
               ) -> list:
        """Update implements UPDATE statement, to update
           database records.

        Parameters
        ----------
        _table: str
            The name of the table.
        _where: str, optional
            Where clause of a database query. Restrict the return
            base on column data.
        kwargs: dict
            column: column name
                Column name as key of dictionary.
            column_value: str
                Data value for each column.

        Returns
        -------
        res: list
            The result of the update query as a list.
        """
        self._log.args("%s: (_table: %s, _where: %s, kwargs: %s)"
                       % (self, _table, _where, kwargs))

        with self._database as db:
            res = db.update(_table,
                            _where,
                            kwargs
                            )
        self._log.rtn("%s: success | data: %s" % (self, res))
        return res

    def delete(self,
               _table: str,
               _where: list = None
               ) -> list:
        """Delete implements DELETE to remove data from a
           database table.

        Parameters
        ----------
        _table: str
            The name of the table.
        _where: str, optional
            Where clause of a database query. Restrict the return
            base on column data.

        Returns
        -------
        res: list
            The result of the delete operation as a list.
        """
        self._log.args("%s: (_table: %s, _where: %s)" % (self, _table, _where))
        with self._database as db:
            res = db.delete(_table,
                            _where
                            )
        self._log.rtn("%s: success | data: %s" % (self, res))
        return res

    def create_db(self,
                  _table_name: str,
                  _command: str,
                  ) -> bool:
        """Create a new database.

        Parameters
        ----------
        _db_name: str
            The name of the database.

        Returns
        -------
        created: bool
            True if the database was created successfully.
        """

        self._log.args("%s: (_table_name: %s, _command: %s)"
                       % (self, _table_name, _command))
        rtn = self.create_table(_command)
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def create_table(self,
                     _command: str
                     ) -> bool:
        """Create a new database table.

        Parameters
        ----------
        _command: str
            The command tp create the database table.

        Returns
        -------
        created: bool
            True if the database table was created successfully.
        """
        self._log.args("%s: (_command: %s)" % (self, _command))
        res = basedbconn.BaseDBConn().create_table(_command)
        self._log.rtn("%s: success | data: %s" % (self, res))
        return res
