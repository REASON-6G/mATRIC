from wiremq.extlib.err import wmqexception


class EndpointException(wmqexception.WmqException):
    """Exception raised when an endpoint component throws an error."""

    def __init__(self, message: str):
        message = "[EndpointException] " + str(message)
        super().__init__(message)
