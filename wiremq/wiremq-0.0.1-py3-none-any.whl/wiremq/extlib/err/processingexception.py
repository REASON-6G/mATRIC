from wiremq.extlib.err import wmqexception


class ProcessManagerException(wmqexception.WmqException):
    """Exception raised for errors relating to a process manager."""

    def __init__(self, message: str) -> None:
        message = "[ProcessManagerException] " + str(message)
        super().__init__(message)


class ThreadPoolException(wmqexception.WmqException):
    """Exception raised for errors relating to a thread pool."""

    def __init__(self, message: str) -> None:
        message = "[ThreadPoolException] " + str(message)
        super().__init__(message)


class ThreadedSchedulerException(wmqexception.WmqException):
    """Exception raised for errors related to processor failures."""

    def __init__(self, message: str) -> None:
        message = "[ThreadedSchedulerException] " + str(message)
        super().__init__(message)


class ProcessingFailureException(wmqexception.WmqException):
    """Exception raised for errors related to processor failures."""

    def __init__(self, message: str) -> None:
        message = "[ProcessingFailureException] " + str(message)
        super().__init__(message)
