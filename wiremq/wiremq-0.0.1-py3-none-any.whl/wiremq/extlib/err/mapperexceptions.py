from wiremq.extlib.err import wmqexception


class BaseMapperException(wmqexception.WmqException):
    """Exception raised when a mapper raises an exception."""

    def __init__(self, message: str):
        message = "[BaseMapperException] " + str(message)
        super().__init__(message)
