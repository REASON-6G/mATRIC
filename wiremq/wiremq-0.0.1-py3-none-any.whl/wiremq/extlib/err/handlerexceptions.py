from wiremq.extlib.err import wmqexception


class HTTPRequestHandlerException(wmqexception.WmqException):
    """Exception raised for errors relating to queue dispatcher errors."""

    def __init__(self, message: str) -> None:
        message = "[QueueDispatcherException] " + str(message)
        super().__init__(message)
