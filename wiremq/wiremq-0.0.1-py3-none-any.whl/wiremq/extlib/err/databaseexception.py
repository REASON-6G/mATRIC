from wiremq.extlib.err import wmqexception


class DBOperationalException(wmqexception.WmqException):
    """Exception raised an operational error occurs in database interactions.

    For example, connection issues, authentication issues, accessing an item
    which does not exist.
    """
    def __init__(self, message: str):
        message = "[DBOperationalException] " + str(message)
        super().__init__(message)


class DBProgrammingException(wmqexception.WmqException):
    """Exception raised when a programming error occurs when interacting with
    a database.

    For example, a syntax error in a query.
    """
    def __init__(self, message: str):
        message = "[DBProgrammingException] " + str(message)
        super().__init__(message)

    def _make_log(self):
        self._log.critical(self._message)


class DBInsertException(wmqexception.WmqException):
    """Exception raised when executing an INSERT query.
    """
    def __init__(self, message: str):
        message = "[DBInsertException] " + str(message)
        super().__init__(message)


class DBSelectException(wmqexception.WmqException):
    """Exception raised when executing a SELECT query.
    """
    def __init__(self, message: str):
        message = "[DBSelectException] " + str(message)
        super().__init__(message)


class DBUpdateException(wmqexception.WmqException):
    """Exception raised when executing an UPDATE query.
    """
    def __init__(self, message: str):
        message = "[DBUpdateException] " + str(message)
        super().__init__(message)


class DBDeleteException(wmqexception.WmqException):
    """Exception raised when executing a DELETE query.
    """
    def __init__(self, message: str):
        message = "[DBDeleteException] " + str(message)
        super().__init__(message)
