from wiremq.extlib.err import wmqexception


class BaseProducerException(wmqexception.WmqException):
    """Exception raised when a base producer exceptions."""

    def __init__(self, message: str):
        message = "[BaseProducerException] " + str(message)
        super().__init__(message)
