from wiremq.extlib.err import wmqexception


class BaseConsumerException(wmqexception.WmqException):
    """Exception raised when a base consumer exceptions."""

    def __init__(self, message: str):
        message = "[BaseConsumerException] " + str(message)
        super().__init__(message)
