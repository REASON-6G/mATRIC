from wiremq.extlib.err import wmqexception


class ClaimCheckException(wmqexception.WmqException):
    """Exception raised for errors relating to claim check errors."""

    def __init__(self, message: str) -> None:
        message = "[ClaimCheckException] " + str(message)
        super().__init__(message)


class BSONDecoderException(wmqexception.WmqException):
    """Exception raised for errors relating to the BSON content decoder"""

    def __init__(self, message: str, *args, **kwargs) -> None:
        message = "[BSONDecoderException] " + str(message)
        super().__init__(message)
