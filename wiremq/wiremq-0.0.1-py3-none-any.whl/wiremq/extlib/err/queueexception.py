from wiremq.extlib.err import wmqexception


class QueueEmptyException(wmqexception.WmqException):
    """Exception raised when getting from a queue that is empty.
    """
    def __init__(self,
                 message: str = "Queue empty",
                 logger: str = "basic_logger") -> None:
        message = "[QueueEmptyException] " + str(message)
        super().__init__(message)


class QueueFullException(wmqexception.WmqException):
    """Exception raised when getting from a queue that is empty.
    """
    def __init__(self,
                 message: str = "Queue full",
                 logger: str = "basic_logger") -> None:
        message = "[QueueFullException] " + str(message)
        super().__init__(message)


class DurableQueueInsertException(wmqexception.WmqException):
    """Exception raised when a durable queue is unable to insert an item into
    the message store.
    """
    def __init__(self,
                 message: str = "",
                 logger: str = "basic_logger") -> None:
        message = "[DurableQueueInsertException] " + str(message)
        super().__init__(message)


class DurableQueueSelectException(wmqexception.WmqException):
    """Exception raised when a durable queue is unable to retrieve an item from
    the message store.
    """
    def __init__(self,
                 message: str = "",
                 logger: str = "basic_logger") -> None:
        message = "[SocketException] " + str(message)
        super().__init__(message)


class DurableQueueDeleteException(wmqexception.WmqException):
    """Exception raised when a durable queue is unable to delete an item from
    the message store.
    """
    def __init__(self,
                 message: str = "",
                 logger: str = "basic_logger") -> None:
        message = "[DurableQueueDeleteException] " + str(message)
        super().__init__(message)
