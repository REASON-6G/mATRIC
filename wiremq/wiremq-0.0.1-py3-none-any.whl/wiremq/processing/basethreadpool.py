# -*- coding: utf-8 - *-

import uuid
from typing import Dict

from concurrent.futures import (
    ThreadPoolExecutor,
    BrokenExecutor,
    InvalidStateError
)
from concurrent.futures.thread import BrokenThreadPool

import logging
from wiremq.processing import (
    abstractthreadpool,
    future
)
from wiremq.extlib.err.processingexception import ThreadPoolException


class BaseThreadPool(abstractthreadpool.AbstractThreadPool):
    """Base thread pool class.

    The Base Threadpool class executes multiple tasks with preconfigured workers.

    Attributes
    ----------
    _config: dict
        Configuration of Base threadpool.
    _max_threads: int
        The maximum amount of threads.
    _executor: object
        Object managing creating and freeing threads.
    _log: object
        Python logging instance.

    Methods
    -------
    register(): bool
        Registers components to the threadpool.
    unregister(): bool
        Unregisters components from the threadpool.
    config(): bool
        Configures the threadpool.
    get_config(): dict
        Getter for the threadpool config.
    get_pool_size(): int
        Returns the number of threads in the threadpool.
    start(): bool
        Starts the execution of tasks.
    shutdown(): bool
        Closes the active threads.

    Raises
    ------
    ThreadPoolException:
        Exception raised for errors relating to a thread pool.
    """

    def __init__(self, config: Dict = None):
        """Base class constructor.

        Parameters
        ----------
        config: dict
            type: str
                Type of threadpool.
            uid: str
                Unique identifier of threadpool.
            max_threads: int
                maximum amount of threads per threadpool.

        Example
        -------
        >>> config = {
        ...    "alias": "Base Thread Pool",
        ...    "name": "Base thread pool 1",
        ...    "type": "basethreadpool",
        ...    "max_threads": 7
        ... }
        >>> tasks = [taskobject1()]
        >>> worker = processmanager.ProcessManager(pm_config)
        >>> task.set_worker(worker)
        >>> threadpool = basethreadpool.BaseThreadPool(config)
        >>> threadpool.start(tasks)
        """
        super().__init__(config)
        self._id = self._generate_id()
        self._config = None
        self._executor = None
        self._max_threads = None
        self._log = None
        if config:
            self.config(config)

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def __repr__(self):
        return f"<Object: {self.__class__.__name__}>"

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def get_id(self) -> str:
        """Return the id of the threadpool.

        Returns
        -------
        rtn: str
            The unique ID of the threadpool, cast from UUID4 to string.
        """
        self._log.args("%s: ()" % self)
        rtn = str(self._id)
        self._log.rtn("success | data: {rtn}")
        return rtn

    def config(self, config: Dict) -> bool:
        """Configures the threadpool.

        Parameters
        ---------
        config: dict
            type: str
                Type of threadpool.
            uid: str
                Unique identifier of threadpool.
            max_threads: int
                maximum amount of thread per threadpool.

        Returns
        -------
        rtn: bool
            Returns true if threadpool is configured, False otherwise.
        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: ()" % self)
        self._config = config
        self._max_threads = config["max_threads"]
        rtn = True
        self._log.rtn("success | data: {rtn}")
        return rtn

    def get_config(self) -> dict:
        """Getter for the threadpool config

        Returns
        -------
        config: dict
            type: str
                Type of threadpool.
            uid: str
                Unique identifier of threadpool.
            max_threads: int
                maximum amount of thread per threadpool.
        """
        self._log.args("%s: ()" % self)
        config = self._config
        self._log.rtn("success | data: {config}")
        return config

    def get_pool_size(self) -> int:
        """Returns the maximum number of threads in the threadpool.

        Returns
        -------
        size : int
            The value of the _max_threads attribute, indicating the maximum
            number of threads in the pool.
        """
        self._log.args("%s: ()" % self)
        size = self._max_threads
        self._log.rtn("success | data: {size}")
        return size

    def start(self, tasks: list) -> bool:
        """Starts the threadpool.

        Threadpool is initialized with the maximum amount of workers. Then work
        is dispatched to the workers. Each worker then is dispatched
        to a thread.

        A ThreadPoolException is raised when either: a worker has failed to
        initialize, the executor is broken and cannot be used to submit or
        execute new tasks, or an operation is performed on a future that is not
        allowed in the current state.

        Parameters
        ----------
        tasks: list
            Tasks to be executed.

        Returns
        -------
        dispatched: bool
            Returns True if tasks were dispatched, False otherwise.

        Raises
        ------
        ThreadPoolException:
            Encompasses errors related to concurrent futures.
        """
        self._log.args("%s: (tasks: %s)" % (self, tasks))
        with ThreadPoolExecutor(max_workers=self._max_threads) as executor:
            self._executor = executor

            for task in tasks:
                method = task.get_method()
                data = task.get_buffer()
                worker = task.get_worker()
                try:
                    _future = executor.submit(method, worker, data)
                except BrokenThreadPool as e:
                    self._log.error(e)
                    raise ThreadPoolException(e)
                except BrokenExecutor as e:
                    self._log.error(e)
                    raise ThreadPoolException(e)
                except RuntimeError as e:
                    self._log.error(e)
                    raise ThreadPoolException(e)
                except InvalidStateError as e:
                    self._log.error(e)
                    raise ThreadPoolException(e)
                task.set_future(future.Future(_future))
                self._log.info("%s: method: %s" % (self, method))
                self._log.info("%s: data: %s" % (self, data))
                self._log.info("%s: worker: %s" % (self, worker))
                self._log.info("%s: _future: %s" % (self, _future))

        rtn = True
        self._log.rtn("success | data: {rtn}")
        return rtn

    def shutdown(self) -> bool:
        """Shutdown active tasks and resets executor.

        Returns
        -------
        rtn: bool
            Returns true if futures are canceled, False otherwise.
        """
        self._log.args("%s: ()" % self)
        self._executor.shutdown(True)
        self._executor = None
        rtn = True
        self._log.rtn("success | data: {rtn}")
        return rtn
