# -*- coding: utf-8 -*-

from typing import (
    Any,
    Dict
)
import uuid
import logging
from wiremq.processing import abstractprocessor


class BaseProcessor(abstractprocessor.AbstractProcessor):
    """Base processor class description.

    Base processor is the skeleton of all wiremq processors. It provides the
    functionality required for message processing during its life cycle.
    Processors are composed of channels, and filters depending on the type of
    processor we want to implement.

    Attributes
    ----------
    _config: Dict
        Configuration for processor.
    _queue: Object
        The shared queue object to get a message from, and to put a message
        onto.
    _alias: str
        The processor alias.
    _log: object
        Python logging instance.

    Methods
    -------
    init(): bool
        Perform initial processor setup.
    process(): None
        Process message.
    _process(): Message
        Helper method for process(). To be overridden by sub-classes.
    finish(): None
        Perform teardown/cleanup of the processor.
    """
    def __init__(self, config):
        """Base processor class constructor.

        Parameters
        ----------
        config: Dict
            transport_type: str
                Type of inbound and outbound transport used. Can either be
                "shared", "queue", or "channel".
            name: str
                Name of processor.
            uid: hash
                Processor identification number.
            processor_queue: object
                queue object for receiving and sending messages for processing.

        Example
        -------
        >>> processor_queue = basequeue.BaseQueue(queue_fifo_config)
        >>> config = {
        ...     "transport_type": "channel",
        ...     "name": "Base Processor",
        ...     "uid": "616251e047993b9da10745c4d06126c" +
        ...            "79ad730dcd36844aeba1072386e652f187",
        ...     "processor_queue": processor_queue
        ... }
        >>> bp = baseprocessor.BaseProcessor(config)
        """
        self._id = self._generate_id()
        self._config = None
        self._alias = None
        self._queue = None
        self._log = None
        self.config(config)
        self.init()
        self.process()
        self.finish()

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id} Alias: {self._alias}>'

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def config(self, config: Dict) -> None:
        """Configures the base processor.

        Parameters
        ----------
        config: Dict
            transport_type: str
                Type of inbound and outbound transport used. Can either be
                "shared", "queue", or "channel".
            name: str
                Name of processor.
            uid: hash
                Processor identification number.
            processor_queue: object
                queue object for receiving and sending messages for processing.
            logger: str, optional
                Name of the logger instance.

        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: (config: %s)" % (self, config))
        self._alias = config.get("alias")
        self._config = config
        self._log.rtn("%s: success" % self)

    def init(self) -> bool:
        """Initial setup of the processor.

        Initializes processor sub-components and attributes, as well as
        performing any other setup. To be overridden by sub-classes.

        Returns
        -------
        rtn: bool
            Returns 'True' once the method has completed.
        """
        self._log.args("%s: ()" % self)
        self._queue = self._config["processor_queue"]
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def process(self) -> None:
        """Process message.

        Consume a message from the inbound transport component, process the
        message, and send the processed message out via the outbound transport.
        """
        self._log.args("%s: ()" % self)
        msg = self._queue.get()
        self._log.info("%s: msg: %s" % (self, msg))
        msg = self._process(msg)
        self._log.info("%s: msg: %s" % (self, msg))
        self._queue.item_processed()
        self._queue.put(msg)
        self._log.rtn("%s: success" % self)

    def _process(self, message: Any) -> Any:
        """Private process method implements each procesesor's logic.

        Generic method to be overwritten based on the processor logic.

        Parameters
        ----------
        message: Any
            Message to be processed.

        Returns
        -------
        rtn: Any
            Processed message.
        """
        self._log.args("%s: ()" % self)
        rtn = {"status": "success", "data": message}
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def finish(self) -> bool:
        """Cleans up and finishes a processor's operation.

        Returns
        -------
        rtn: bool
            Returns 'True' once the method has completed.
        """
        self._log.args("%s: ()" % self)
        self._queue = None
        self._config = None
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
