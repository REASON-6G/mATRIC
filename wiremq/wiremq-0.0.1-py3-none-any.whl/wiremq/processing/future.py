# -*- coding: utf-8 -*-

import uuid
from typing import Any


class Future:
    """Base Future class.

    Implementing Future module of the concurrent library.

    Attributes
    ----------
    _future: object
        The future object from the concurrent library

    Methods
    -------
    generate_id(): str
        Generate a unique task-id.
    get_id(): Any
        Return the id of the task.
    set_future(): bool
        Sets future object.
    get_future(): object
        Gets future object.
    cancel(): bool
        Attempts to cancel a process.
    cancelled(): bool
        Returns result of process cancellation.
    running(): bool
        Checks if the process is currently running.
    is_done(): bool
        Checks if a process is finished or canceled.
    get_result(): object
        Return the value returned by the process.
    get_exception(): object
        Return the exception raised by the process.
    """

    def __init__(self, future: Any = None):
        """Base processor class constructor.

        Parameter
        ---------
        future: object
            Future object generated from a process in a thread.

        Example
        -------
        >>> _future = future.Future(future)
        >>> _future.get_result()
        """
        self._id = self._generate_id()
        self._id = None
        self._future = future

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def get_id(self) -> Any:
        """Return the id of the Future.

        Returns
        -------
        rtn: str
            The unique ID of the Future, cast from UUID4 to string.
        """
        rtn = str(self._id)
        return rtn

    def set_future(self, future: Any) -> None:
        """Set future object.

        Parameters
        ----------
        future: object
            Future object.
        """
        self._future = future

    def get_future(self) -> Any:
        """Get the future object.

        Returns
        -------
        future: object
            Future object.
        """
        future = self._future
        return future

    def cancel(self) -> bool:
        """Attempts to cancel a process.

        Returns
        -------
        rtn: bool
            True if the process is canceled, False otherwise.
        """
        rtn = self._future.cancel()
        return rtn

    def cancelled(self) -> bool:
        """Returns the result of process cancellation.

        Returns
        -------
        rtn: bool
            Return True if the call was successfully canceled.
        """
        rtn = self._future.cancelled()
        return rtn

    def running(self) -> bool:
        """Checks if the process is currently running.

        Returns
        -------
        rtn: bool
            Return True if the call is currently being executed and cannot
            be canceled, False otherwise.
        """
        rtn = self._future.running()
        return rtn

    def is_done(self) -> bool:
        """Checks if a process is finished or cancelled.

        Returns
        -------
        rtn: bool
            Return True if the call was successfully canceled or
            finished running, False otherwise.
        """
        rtn = self._future.done()
        return rtn

    def get_result(self) -> Any:
        """Return the value returned by the process.

        Returns
        -------
        rtn: Any
            Returns the result of the process.
        """
        rtn = self._future.result()
        return rtn

    def get_exception(self, timeout: int = None) -> Any:
        """Return the exception raised by the process.

        Returns
        -------
        rtn: Any
            Returns the exception message of the failed process.
        """
        rtn = self._future.exception(timeout)
        return rtn
