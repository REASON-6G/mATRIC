# -*- coding: utf-8 -*-

from typing import Any
from wiremq.processing.coroutines import basecoroutine


class ProcessManagerCoroutine(basecoroutine.BaseCoroutine):
    """The process manager coroutine class.

    Process Manager Coroutine class implements the steps required to process
    the message with a process manager

    Methods
    -------
    execute(): str
        Overrides base coroutine execute method. Process a message.
    """

    def execute(self, worker: Any, data: Any) -> str:
        """Executes a task.

        ParametersW
        ----------
        worker: object
            Worker executing the task.
        data: dict
            Message to be processed.

        Returns
        -------
        worker_id: str
            Transaction id of processing.
        """
        worker.process(data)
        worker.finish()
        worker_id = worker.get_id()
        return worker_id
