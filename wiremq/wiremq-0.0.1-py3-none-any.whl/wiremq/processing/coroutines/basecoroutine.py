# -*- coding: utf-8 -*-

import uuid
from typing import Any


class BaseCoroutine:
    """Base Coroutine class.

    The base coroutine class is responsible for setting the skeleton for every
    coroutine implemented in wiremq.

    Attributes
    ----------
    _id: str
        Unique identifer of the coroutine
    _completed: bool
        True if the coroutine is complete, False otherwise.

    Methods
    -------
    generate_id(): Any
        Generate a unique task-id.
    complete(): bool
        Sets if the coroutine is complete.
    execute(): Any
        Base method for coroutines to execute
    """

    def __init__(self, worker: Any = None):
        """Coroutines class constructor.

        Parameters
        ----------
        worker: object
            Worker object.

        Example
        -------
        >>> coroutine = pmcoroutine.ProcessManagerCoroutine(worker)
        >>> coroutine.execute(manager,)
        """
        self._id = self._generate_id()
        self._completed = False

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def __repr__(self):
        return f"<Object: {self.__class__.__name__}>"

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def get_id(self) -> str:
        """Returns the coroutine's unique ID

        Returns
        -------
        rtn: str
            The unique ID of the coroutine, cast from UUID4 to string.
        """
        rtn = str(self._id)
        return rtn

    def complete(self) -> None:
        """Sets if coroutine as complete."""
        self._completed = True

    def execute(self) -> Any:
        """Base method for coroutines to execute"""
        rtn = True
        return rtn
