#!/usr/bin/python

import time
import copy
import os
from pathlib import Path
from urllib import parse
import uuid
import bson
import json
from typing import (
    Any,
    Dict,
    Callable,
    AnyStr,
    List,
    ByteString,
    Tuple
)
import logging
from wiremq.extlib.queue import fifoqueue
from wiremq.processing import baseprocessmanager
from wiremq.extlib.asynchronous.eventloops import ioeventloopudp
from wiremq.gateway.processing import baseprocessmanagerbuilder
from wiremq.gateway.eventloops import ioeventloopudpbuilder
from wiremq.extlib.err import handlerexceptions


class HTTPRequestHandler:
    """HTTP request handler which forms the basis of an ASGI application.

    Incoming requests are expected to follow a standardised path format:

         <URL>:/<API name>/<API version>/<service>/<command>

    For example

        http://localhost:8001/testapi/v1/battery/get_voltage


    Attributes
    ----------
    _iohost: str
        Unix domain socket host for internal communication from the service.
    _config: Dict
        HTTP request handler configuration dictionary.


    Methods
    -------
    __call__: None
        ASGI interface method where all requests pass through.
    _handle_get: None
        Handles incoming GET requests.
    _handle_post: None
        Handles incoming POST requests.
    _generate_headers: List
        Creates headers for HTTP responses.
    _generate_body: Str
        Extracts body data from service response and returns it as a string.
    _read_body: Dict
        Uses the receive callable to receive the message body from the
        client.
    _build_processmanager: BaseProcessManager
        Builds a process manager to be used in the generation of a response.
    _build_ioloop: IOEventLoopUDP
        Builds an event loop, used to receive a response from the service.
    _get_header: Str
        Gets the values for a given header.
    _build_service_message: Dict
        Builds a wiremq message intended for the service.
    _stringify_scope: Dict
        Converts bytes data from scope into strings, maintaining the
        structure of the original scope.
    _handle_request: Dict
        Perform handling pertinent to both request method types.
    _parse_path: Tuple
        Translates a URL path into a Dict.
    _generate_id: Str
        Generates a unique id.
    log_message: None
        Overrides class to remove default logging functionality
        of BaseHTTPRequestHandler.
    _finish: None
        Cleans up the request handler.


    References
    ----------
    ASGI specification:
        https://asgi.readthedocs.io/en/latest/specs/main.html

    """
    def __init__(self, config: Dict) -> None:
        """HTTP request handler initialization function.

        Parameters
        ----------
        config: Dict
            HTTP request handler configuration dictionary.
            host: str
                Hostname for the HTTP server
            port: int
                Port number for the HTTP server
            allow_cross_site: bool
                Sets access control headers, if true CORS enabled, else it is
                disabled.
            processmanager_config: Dict
                Process manager config, see baseprocessmanager
            task_queue_config: Dict
                Task queue config, see fifoqueue
            ioloop_config: Dict
                IO event loop config, see ioeventloopudp
            timeout: float
                Time to wait in seconds for requests to complete

        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: (config: %s)" % (self, config))
        self._iohost = None
        self._config = config

    async def __call__(self,
                       scope: Dict,
                       receive: Callable,
                       send: Callable) -> None:
        """ASGI interface method where all requests pass through.

        Required for any class-based ASGI application.

        Parameters
        ----------
        scope: Dict
            HTTP connection scope, contains HTTP data and headers.
        receive: Callable
            Method which may be called to receive HTTP data.
        send: Callable
            An awaitable callable (which takes a dictionary as an argument)
            that will return once the send has been completed or the connection
            has been closed.

        """
        self._log.args("%s: (scope: %s, receive: %s, send: %s)" %
                       (self, scope, receive, send))
        print(scope)
        try:
            assert scope["type"] == "http"
        except AssertionError:
            e = f"Invalid message type received, expecting http, " \
                f"received {scope['type']}"
            self._log.err(e)
            raise handlerexceptions.HTTPRequestHandlerException(e)
        if scope["method"] == "GET":
            await self._handle_get(scope, send)
        elif scope["method"] == "POST":
            await self._handle_post(scope, receive, send)
        self._log.rtn("%s: success" % self)

    async def _handle_get(self, scope: Dict, send: Callable) -> None:
        """Handles incoming GET requests.

        Parameters
        ----------
        scope: dict
            Describes all information relevant to a specific connection.
        send: Callable
            An awaitable callable (which takes a dictionary as an argument)
            that will return once the send callable has been completed or the
            connection has been closed.

        """
        self._log.args("%s: (scope: %s, send: %s)" % (self, scope, send))
        resp = self._handle_request(scope)
        headers = self._generate_headers()
        await send({
            "type": "http.response.start",
            "status": 200,
            "headers": headers
        })
        body = self._generate_body(resp)
        await send({
            "type": "http.response.body",
            "body": body.encode("utf-8")
        })
        self._log.rtn("%s: success" % self)

    async def _handle_post(self,
                           scope: Dict,
                           receive: Callable,
                           send: Callable) -> None:
        """Handles incoming POST requests.

        Parameters
        ----------
        scope: dict
            Describes all information relevant to a specific connection.
        receive: method
            An awaitable callable which is used to receive body data from the
            client.
        send: method
            An awaitable callable (which takes a dictionary as an argument)
            that will return once the send has been completed or the connection
            has been closed.

        """
        self._log.args("%s: (scope: %s, receive: %s, send: %s)" %
                       (self, scope, receive, send))
        body = await self._read_body(receive)
        resp = self._handle_request(scope, body)
        headers = self._generate_headers()
        await send({
            "type": "http.response.start",
            "status": 201,
            "headers": headers
        })
        body = self._generate_body(resp)
        await send({
            "type": "http.response.body",
            "body": body.encode("utf-8")
        })
        self._log.rtn("%s: success" % self)

    def _generate_headers(self) -> List:
        """Creates headers for HTTP responses.

        Creates headers in the form of a list of lists. The first item in each
        sub-list is the header name, and subsequent items are its values.

        Returns
        -------
        rtn: list
            A list of headers.

        """
        self._log.args("%s: ()" % self)
        headers = []
        if self._config.get("allow_cross_site"):
            headers.append([b"Access-Control-Allow-Origin", b"*"], )
            headers.append([b"Access-Control-Allow-Methods", b"GET"])
            headers.append(
                [b"Cache-Control", b"no-store, no-cache, must-revalidate"])
        self._log.rtn("%s: success" % self)
        return headers

    def _generate_body(self, resp: Dict) -> AnyStr:
        """Extracts body data from service response and returns it as a string.

        Parameters
        ----------
        resp: Dict
            Response from service

        Returns
        -------
        rtn: str
            Body string.

        """
        self._log.args("%s: (resp: %s)" % (self, resp))
        if "payload" in resp and "data" in resp["payload"]:
            body = json.dumps(resp["payload"]["data"])
        elif "payload" in resp and "data" not in resp["payload"]:
            body = json.dumps(resp["payload"])
        else:
            body = ""
        self._log.rtn("%s: success | data: %s" % (self, body))
        return body

    async def _read_body(self, receive: Callable) -> ByteString:
        """Uses the receive callable to receive the message body from the
        client.

        Parameters
        ----------
        receive: Coroutine
            Method to receive data from the client.

        Returns
        -------
        body: ByteString
            The received message body.
        """
        self._log.args("%s: (receive: %s)" % (self, receive))
        body = b""
        more_body = True
        while more_body:
            message = await receive()
            body += message.get("body", b"")
            more_body = message.get("more_body", False)
        self._log.rtn("%s: success | data: %s" % (self, body))
        return body

    def _build_processmanager(
            self, pm_config: Dict) -> baseprocessmanager.BaseProcessManager:
        """Builds a process manager to be used in the generation of a response.

        Also initializes the outbound socket and sockdispatcher used in the
        processor chain.

        Parameters
        ----------
        pm_config: Dict
            Process manager configuration.

        Returns
        -------
        pm: BaseProcessManager
            A process manager.
        """
        self._log.args("%s: (pm_config: %s)" % (self, pm_config))
        pm_config["processor_map"]["SD"]["config"][
            "outbound_socket_config"
        ]["host"] = "{}/.wiremq/domain_sockets/{}".format(
            Path.home(), self._generate_id()
        )
        pm_config["logger"] = self._config.get("logger")
        try:
            os.unlink(
                pm_config["processor_map"]["SD"]["config"][
                    "outbound_socket_config"]["host"])
        except OSError:
            pass

        pmb = baseprocessmanagerbuilder.BaseProcessManagerBuilder()
        pmb.make_processmanager(pm_config)
        pm = pmb.product
        self._log.rtn("%s: success | data: %s" % (self, pm))
        return pm

    def _build_ioloop(
            self, ioloop_config: Dict) -> ioeventloopudp.IOEventLoopUDP:
        """Builds an event loop, used to receive a response from the service.

        Parameters
        ----------
        ioloop_config: Dict
            Event loop configuration

        Returns
        -------
        ioloop: IOEventLoopUDP
            Event loop

        """
        self._log.args("%s: (ioloop_config: %s)" % (self, ioloop_config))
        self._iohost = "{}/.wiremq/domain_sockets/{}".format(
            Path.home(), self._generate_id()
        )
        try:
            os.unlink(self._iohost)
        except OSError:
            pass
        ioloop_config["host"] = self._iohost
        ioloop_config["inbound_socket_config"]["host"] = self._iohost
        ioloop_config["logger"] = self._config.get("logger")

        ioloop_builder = ioeventloopudpbuilder.IOEventLoopUDPBuilder()
        ioloop_builder.make_eventloop(ioloop_config)
        ioloop = ioloop_builder.product
        self._log.rtn("%s: success | data: %s" % (self, ioloop))
        return ioloop

    def _get_header(self, key: AnyStr, scope: Dict) -> Any:
        """Gets the values for a given header.

        If header string is not found, returns None.

        Parameters
        ----------
        key: Str
            Header name to search.
        scope: Dict
            HTTP scope to be read.

        Returns
        -------
        rtn: Any
            String with header values, or None if header does not exist.

        """
        self._log.args("%s: (key: %s, scope: %s)" % (self, key, scope))
        for item in scope["headers"]:
            if key.lower() == item[0].lower():
                self._log.rtn("%s: success | data: %s" % (self, item[1]))
                return item[1]
        return None

    def _build_service_message(self, scope: Dict, body: AnyStr) -> Dict:
        """Builds a wiremq message intended for the service.

        Parameters
        ----------
        scope: Dict
            HTTP connection information and headers.
        body: Str
            Message body from the original HTTP request.

        Returns
        -------
        message: Dict
            Constructed wiremq message.

        """
        self._log.args("%s: (scope: %s, body: %s)" % (self, scope, body))
        message = {}
        message["payload"] = self._stringify_scope(scope)
        message["method"] = scope["method"]
        if scope["method"] == "POST":
            message["type"] = "command"
        elif scope["method"] == "GET":
            message["type"] = "query"
        if body:
            content_type = self._get_header("Content-Type", message["payload"])
            if content_type == "application/json":
                payload = self._extract_query_string(body.decode("utf-8"))
            else:
                payload = body.decode("utf-8")
            message["data"] = payload
        message["message_id"] = ""
        message["correlation_id"] = ""
        message["dest_ip"], message["dest_port"] = scope["client"]
        message["payload"]["request_id"] = self._generate_id()
        message["sender_ip"] = self._iohost
        message["sender_port"] = None
        api, api_version, service, command, params = \
            self._parse_path(scope["path"])
        if "query_string" in scope:
            params.update(
                self._extract_query_string(message["payload"]["query_string"]))
        message["payload"]["http_method"] = scope["method"]
        message["payload"]["api"] = api
        message["payload"]["api_version"] = api_version
        message["payload"]["service"] = service
        message["payload"]["command"] = command
        message["payload"]["params"] = params
        self._log.rtn("%s: success | data: %s" % (self, message))
        return message

    def _stringify_scope(self, scope: Dict) -> Dict:
        """Converts bytes data from scope into strings, maintaining the
        structure of the original scope.

        Parameters
        ----------
        scope: Dict
            HTTP connection information and headers.

        Returns
        -------
        scope: Dict
            Modified scope, with bytes values converted to strings.

        """
        s_scope = {}
        self._log.args("%s: (scope: %s)" % (self, scope))
        new_headers = []
        for header in scope["headers"]:
            new_header = []
            for item in header:
                if isinstance(item, bytes):
                    new_header.append(item.decode("utf-8"))
            new_headers.append(new_header)
        s_scope["headers"] = new_headers
        if isinstance(scope["raw_path"], bytes):
            s_scope["raw_path"] = scope["raw_path"].decode("utf-8")
        if isinstance(scope["query_string"], bytes):
            s_scope["query_string"] = scope["query_string"].decode("utf-8")
        self._log.rtn("%s: success | data: %s" % (self, scope))
        return s_scope

    def _extract_query_string(self, query: str) -> Dict:
        """Extracts keys and values from the query string, converting to a
        dictionary.

        Parameters
        ----------
        query: str
            HTTP query string (e.g. "data1=example1&data2=example2")

        Returns
        -------
        data: Dict
            The query string transposed to a dictionary.
            e.g. {'data1': ['example1'], 'data2': ['example2']}
        """
        return parse.parse_qs(query)

    def _handle_request(self, scope: Dict, body: Any = None) -> Dict:
        """Perform handling pertinent to both request method types.

        For each request,

          - a process manager is created which is used to dispatch messages to
            the service
          - an ioloop is created which is used to receive a message from the
            service
          - the ioloop is run until a message is received on it
          - the ioloop and process manager are then closed
          - if a timeout is set, then the receiving ioloop is shut down after
            the configured time

        Parameters
        ----------
        scope: Dict
            HTTP connection information and headers.
        body: bytes (optional)
            The http request's payload/body

        Returns
        -------
        resp: Dict
            A dictionary containing the response payload.
        """
        self._log.args("%s: (scope: %s, body: %s)" % (self, scope, body))

        # Initialize configs
        pm_config = copy.deepcopy(self._config["processmanager_config"])
        ioloop_config = copy.deepcopy(self._config["ioloop_config"])

        # Build queues
        processor_queue = fifoqueue.FifoQueue(
            pm_config["processor_queue_config"]
        )
        task_queue = fifoqueue.FifoQueue(self._config["task_queue_config"])
        pm_config["processor_queue"] = processor_queue
        ioloop_config["task_queue"] = task_queue

        # Initialize ioloop socket
        self._iohost = "{}/.wiremq/domain_sockets/{}".format(
            Path.home(), self._generate_id()
        )
        try:
            os.unlink(self._iohost)
        except OSError:
            pass
        ioloop_config["host"] = self._iohost
        ioloop_config["inbound_socket_config"]["host"] = self._iohost

        # Build components
        pm = self._build_processmanager(pm_config)
        ioloop = self._build_ioloop(ioloop_config)
        ioloop.initialize()
        message = self._build_service_message(scope, body)

        # Dispatch message
        processor_queue.put(message)
        pm.process()

        received_response = False
        timeout = self._config.get("timeout", None)
        if timeout:
            expiry = time.time() + timeout
        while not received_response:
            ioloop.run_once()
            if not task_queue.empty():
                task = task_queue.get()
                resp = bson.BSON.decode(task.get_buffer())
                task_queue.item_processed()
                received_response = True
            if timeout and time.time() > expiry:
                break
        ioloop.close()
        pm.finish()
        self._log.rtn("%s: success | data: %s" % (self, resp))
        return resp

    def _parse_path(self, data: AnyStr) -> Tuple:
        """Translates a URL path into a Dict.

        Parameters
        ----------
        data: str
            The path of the http request.

        Returns
        -------
        rtn: tuple
            A tuple containing segments extracted from the http request path.
            api: API name or code
            api_version: The version of the API
            service: The endpoint being requested
            command: The action for the endpoint to perform
            params: Any parameters associated with the request.
        """
        self._log.args("%s: (data: %s)" % (self, data))
        path_seg = data.split("/")
        api = path_seg[1]
        api_version = path_seg[2]
        service = path_seg[3]
        params = {}
        if "?" in path_seg[4]:
            commandparam_seg = path_seg[4].split("?")
            command = commandparam_seg[0]
            params_str = commandparam_seg[1]
            params_list = params_str.split("&")
            for par in params_list:
                key, val = par.split("=")
                params[key] = val
        else:
            command = path_seg[4]
        self._log.rtn("%s: success | data: %s" % (self, (
            api, api_version, service, command, params
        )))
        return api, api_version, service, command, params

    def _generate_id(self) -> AnyStr:
        """Generates a unique id.

        Returns
        -------
        rtn: str
            The unique ID of the endpoint, cast from UUID4 to string.
        """
        _id = uuid.uuid4()
        self._log.rtn("%s: success | data: %s" % (self, _id))
        return str(_id)

    def log_message(self, format, *args) -> None:
        """Overrides class to remove default logging functionality
        of BaseHTTPRequestHandler"""
        pass

    def _finish(self) -> None:
        """Cleans up the request handler.

        Removes the unix domain used by the ioloop.

        """
        self._log.args("%s: ()" % self)
        try:
            os.unlink(self._iohost)
        except OSError:
            pass
        self._log.rtn("%s: success" % self)
