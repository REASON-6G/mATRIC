# -*- coding: utf-8 -*-

from abc import (
    ABC,
    abstractmethod
)
from typing import (
    Any,
    Dict
)


class AbstractHandler(ABC):
    """Abstract handler class.
    """
    def __init__(self, config: Dict = None):
        """Abstract handler class constructor.
        """
        pass

    @abstractmethod
    def config(self, config) -> bool:
        """Initial setup of the handler.
        """
        pass

    @abstractmethod
    def handle(self, message: bytes) -> None:
        """Handle message.
        """
        pass

    @abstractmethod
    def _handle(self, message: bytes) -> Any:
        """Private handle method implements each handler's logic.
        """
        pass

    @abstractmethod
    def _dispatch(self, message: bytes) -> Any:
        """Private handle method implements each handler's logic.
        """
        pass

    @abstractmethod
    def finish(self) -> bool:
        """Cleans up and finishes a processor's operation.
        """
        pass
