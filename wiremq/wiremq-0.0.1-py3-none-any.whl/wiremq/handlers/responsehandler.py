# -*- coding: utf-8 -*-

from typing import Dict
from wiremq.handlers import basehandler


class ResponseHandler(basehandler.BaseHandler):
    """Response handler class description.

    Response handler functions in a similar way to base handler, except that
    its destination host and port attributes can be updated.

    Attributes
    ----------
    _config: Dict
        Configuration for processor.
    _dispatcher: object
        Dispatcher for sending a message after handling.
    _outsocket_fd: int
        The file descriptor for the dispatcher's outbound socket.
    _host: str
        The destination IP/host addresss to dispatch messages to.
    _port: int, optional
        The destination port number to dispatch messages to.

    Methods
    -------
    config(): bool
        Perform initial handler configuration.
    update_destination(): bool
        Update host/port used when dispatching messages.
    """
    def __init__(self, config: Dict = None):
        """Response processor class constructor.

        Parameters
        ----------
        config: Dict
            name: str
                Name of handler.
            uid: hash
                Handler identification number.
            dispatcher: object
                Dispatcher for sending a message after handling.
            outsocket_fd: int
                The file descriptor for the dispatcher's outbound socket.

        Example
        -------
        >>> tdispatcher = transportdispatcher.TransportDispatcher(td_config)
        >>> config = {
        ...     "dispatcher": "tdispatcher",
        ...     "name": "Base Handler",
        ...     "uid": "616251e047993b9da10745c4d06126c" +
        ...            "79ad730dcd36844aeba1072386e652f187",
        ...     "outsocket_fd": 8,
        ... }
        >>> bh = responsehandler.ResponseHandler(config)
        """
        super().__init__(config)

    def config(self, config) -> bool:
        """Initial setup of the handler.

        Initializes the handler config, dispatcher, outsocket fd, host, and
        port attributes.

        Returns
        -------
        bool
            Returns 'True' once attribute assignment has been completed.
        """
        self._log.args("%s: (config: %s)" % (self, config))
        self._config = config
        self._dispatcher = self._config["dispatcher"]
        self._outsocket_fd = self._config["outsocket_fd"]
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def update_destination(self, config) -> bool:
        """Update host/port used when dispatching messages.
        """
        self._log.args("%s: (config: %s)" % (self, config))
        self._dest_host = config.get("dest_host", self._dest_host)
        self._dest_port = config.get("dest_port", self._dest_port)
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
