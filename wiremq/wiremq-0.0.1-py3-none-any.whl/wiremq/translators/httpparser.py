# -*- coding: utf-8 - *-
"""HTTP Parser class"""

import json
from typing import (
    Dict,
    Any
)
from wiremq.processing import baseprocessor
from wiremq.handlers import httprequest


class HTTPParser(baseprocessor.BaseProcessor):
    """HTTP Parser class.

    This class inherits the methods from the base processor class, while
    overriding the _process function and introducing a new _decode_data
    function.

    Attributes
    ----------
    _config  : dict
        Configuration of the content filter.
    _service_paths: dict
        Service paths
    _headers: dict
        Headers
    _log: object
        Python logging instance.

    Methods
    -------
    _process : Dict
        Translates an HTTP request in bytes form into a Dict, using the
        HTTPRequest object.
    """

    def __init__(self, config: Dict = None):
        """HTTP Parser constructor

        Parameters
        -----------
        config : dict
            type: str
                The type of the translator
            alias: str
                Translator's alias
            name: str
                Translator's name
            translator_id : hex
                Unique id using secrets lib with sha256 hashing.
            processor_queue: object
                Queue object for receiving and sending messages for processing.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        processor_queue = basequeue.BaseQueue(queue_fifo_config)
        config = {
            "alias": "HTTP Request Decoder",
            "name": "HTTP-DCDR Processor",
            "type": "HTTPRequestDecoder",
            "processor_queue": processor_queue
        }
        translator = httprequestdecoder.HTTPRequestDecoder(config)
        """
        self._service_paths = config["service_paths"]
        self._headers = config.get("headers", {})
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._log.rtn("%s: success" % self)

    def _process(self, data: bytes) -> Dict:
        """Translates an HTTP request in bytes form into a Dict.

        Parameters
        ----------
        data : bytes, required
            This object will be sent to the decoding function.

        Returns
        -------
        _res: Dict
            The Dict data decoded from the bytes parameter, returned by the
            decoding function.
        """
        self._log.args("%s: (data: %s)" % (self, data))
        _t = b"\r\r\r\r"
        if data.endswith(_t):
            data = data[:len(data) - len(_t)]
        if not self._validate_protocol(data):
            rtn = {
                "type": "request",
                "request_version": self._config["version"],
                "error_code": 400,
                "error_message": "Bad Request"
            }
            return {"status": "success", "data": rtn}
        httpreq = httprequest.HTTPRequest(data)
        request_dict = self._parse_request(httpreq)
        if not self._validate_request(request_dict):
            rtn = {
                "request_version": self._config["version"],
                "error_code": 404,
                "error_message": "Service not found"
            }
        else:
            rtn = request_dict
        rtn["type"] = "request"
        _res = {"status": "success", "data": rtn}
        self._log.rtn("%s: success | data: %s" % (self, _res))
        return _res

    def _parse_request(self, data: Any) -> Dict:
        """Translate http request into a Dict.

        Parameters
        ----------
        data : object, required
            This object will be decoded into a Dict.
        Returns
        -------
        _res: Dict
            The Dict data decoded from the http request parameter.
        """
        self._log.args("%s: (data: %s)" % (self, data))
        message = {}
        message["http_method"] = data.command
        message["path"] = data.path
        message["request_version"] = data.request_version
        message["error_code"] = data.error_code
        message["error_message"] = data.error_message
        message["headers"] = {}
        for header in data.headers:
            message["headers"][header] = data.headers[header]
        payload = data.payload
        if data.headers["Content-type"] == "application/json":
            payload = json.loads(payload)
        elif data.headers["Content-type"] == "text/plain":
            payload = str(payload)
        message["payload"] = payload
        message["response"] = data.response()
        message["request_id"] = data.get_id()
        api, api_version, service, command, params = self._parse_path(
            data.path
        )
        message["api"] = service
        message["api_version"] = service
        message["service"] = service
        message["command"] = command
        message["params"] = params
        self._log.rtn("%s: success | data: %s" % (self, message))
        return message

    def _parse_path(self, data: str) -> Dict:
        """Translate path into a Dict."""
        path_seg = data.split("/")
        api = path_seg[1]
        api_version = path_seg[2]
        service = path_seg[3]
        params = {}
        if "?" in path_seg[4]:
            commandparam_seg = path_seg[4].split("?")
            command = commandparam_seg[0]
            params_str = commandparam_seg[1]
            params_list = params_str.split("&")
            for par in params_list:
                key, val = par.split("=")
                params[key] = val
        else:
            command = path_seg[4]
        return api, api_version, service, command, params

    def _validate_protocol(self, httpreq: bytes) -> bool:
        self._log.args("%s: (httpreq: %s)" % (self, str(httpreq)))
        httpr = httpreq.decode("UTF-8")
        headers = httpr.splitlines()
        firstLine = headers.pop(0)
        _, _, version = firstLine.split()
        rtn = True
        if version != self._config["version"]:
            rtn = False
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _validate_request(self, httpreq: Any) -> bool:
        self._log.args("%s: (httpreq: %s)" % (self, str(httpreq)))
        rtn = True
        self._log.warning(httpreq["service"])
        if httpreq["service"] not in self._service_paths:
            rtn = False
        else:
            rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
