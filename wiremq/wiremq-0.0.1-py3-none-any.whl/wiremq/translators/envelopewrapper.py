# -*- coding: utf-8 - *-

from typing import (
    Any,
    Dict
)
import datetime
from wiremq.processing import baseprocessor
from wiremq.utils import configtools


class EnvelopeWrapper(baseprocessor.BaseProcessor):
    """EnvelopeWrapper class

    This class transforms a message by adding key-value pairs to any message
    dict passed through it. Both the header and payload of a message dict may
    be wrapped.

    Attributes
    ----------
    _config  : dict
        Configuration of the content filter.
    _log: object
        Python logging instance.

    Methods
    -------
    _process : Dict
        Adds supplementary data to the header and payload of a message
        dictionary.

    """

    def __init__(self, config: Dict = None):
        """EnvelopeWrapper constructor

        Parameters
        ----------
        config: dict
            type: str
                The type of the translator.
            alias: str
                Translator's alias.
            name: str
                Translator's name.
            processor_id: hex
                Unique id using secrets lib with sha256 hashing.
            processor_queue: object
                Queue object for receiving and sending messages for processing.
            add_datetime: bool
                Flag to denote whether datetime is automatically added to
                header. Default = False.
            add_id: bool
                Flag to denote whether message_id is automatically added to the
                header. Default = False
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> message = {
        >>>     'timestamp': 1580131898.357799,
        >>>     'echo': 1580131941.151655,
        >>>     'sender_ip': '192.168.1.29',
        >>>     'sender_port': 65535,
        >>>     'payload': {
        >>>         'command': 2,
        >>>     }
        >>> }
        >>> processor_queue = basequeue.BaseQueue(queue_fifo_config)
        >>> config = {
        >>>    'alias': "Envelope Wrapper",
        >>>    'name': "ENVWRP Translator",
        >>>    'type': "envelopewrapper",
        >>>    'transport_type': "queue",
        >>>    'processor_queue': processor_queue,
        >>>    'add_id': True,
        >>>    'add_datetime': True,
        >>>    'header': {
        >>>        'protocol_version': '0.0.1',
        >>>        'sender_ip': '192.168.1.29',
        >>>    },
        >>>    'payload': {
        >>>        "cores": 16
        >>>    }
        >>>  }
        >>> config['inbound'] = inbound_queue
        >>> config['outbound'] = outbound_queue
        >>> processor_queue.put(message)
        >>> envelopewrapper.EnvelopeWrapper(config)
        >>> processor_queue.item_processed()
        >>> wrapped_message = outbound_queue.get()
        >>> processor_queue.item_processed()
        """
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._log.rtn("%s: success" % self)

    def _process(self, message: Any) -> Any:
        """Adds supplementary data to the header and payload of a message
        dictionary.

        Parameters
        ----------
        message : Dict
            The message to wrap. The header data should be at the root level
            of the Dict and the payload should be in a "payload" nested Dict.

        Returns
        -------
        rtn: Dict
            The wrapped message, which has been populated with header and
            payload values from the translator's config.

        """
        self._log.args("%s: (message: %s)" % (self, message))
        message.update(self._config['header'])
        add_datetime = self._config.get("add_datetime", False)
        add_id = self._config.get("add_id", False)
        payload_config = self._config.get('payload', {})
        if payload_config and "payload" not in message:
            message["payload"] = {}
        if "payload" in message:
            message['payload'].update(payload_config)
        if add_datetime:
            message["datetime"] = datetime.datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S.%f")
        if add_id:
            message["message_id"] = configtools.generate_id()
        rtn = {"status": "success", "data": message}
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
