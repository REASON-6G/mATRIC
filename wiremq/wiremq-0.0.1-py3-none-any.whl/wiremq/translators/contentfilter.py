# -*- coding: utf-8 -*-

from typing import Dict
from wiremq.processing import baseprocessor


class ContentFilter(baseprocessor.BaseProcessor):
    """Content Filter class

    The content filter takes a message and removes fields from its header and
    payload according to its configuration.

    Attributes
    ----------
    _config  : dict
        Configuration of the content filter.
    _header_filter list
        Contains a list of keys to be filtered out from the header.
    _payload_filter: list
        Contains a list of keys to be filtered out from the payload.
    _log: object
        Python logging instance.

    Methods
    -------
    _process() : Dict
        Overrides method of base processor, holds the processor logic.
    _filter_content(): Dict
        Implements the message filtering functionality.
    -------
    """

    def __init__(self, config: Dict = None):
        """Content Filter class constructor.

        Parameters
        ----------
        config: Dict
            type: str
                The processor type
            alias: str
                Alias of the content filter
            name: str
                Name of the content filter
            transport_type: str
                Type of inbound and outbound transport used. Can either be
                "shared", "queue", or "channel".
            uid: hash
                Identification number.
            header_filter: list
                A list of keys to be filtered out from the message header
            payload_filter: list
                A list of keys to be filtered out from the message payload
            processor_queue: object
                Queue object for receiving and sending messages for processing.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> config = {
        >>>     "type": "contentfilter",
        >>>     "alias": "Content filter",
        >>>     "name": "My content filter",
        >>>     "transport_type": "queue",
        >>>     "uid": "0868bc20384ad8cbf15b03350ce5671",
        >>>     "header_filter": ["sender_signature", "tx_id"],
        >>>     "payload_filter": ["type"],
        >>>     "processor_queue": processor_queue
        >>> }
        >>> cfilter = contentfilter.ContentFilter(config)

        """
        self._header_filter = config.get("header_filter", None)
        self._payload_filter = config.get("payload_filter", None)
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._log.rtn("%s: success" % self)

    def _process(self, message: Dict) -> Dict:
        """Overrides route method of base processor.

        Filters out specific keys from the top level of the message's header
        and payload.

        Parameters
        ----------
        message: Dict
            The message to filter. The header data should be at the root level
            of the Dict and the payload should be in a "payload" nested Dict.

        Returns
        ----------
        rtn: Dict
            The filtered message and status information.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        for key in self._config["filter"]["header"]:
            if key in message.keys():
                del message[key]

        for key in self._config["filter"]["payload"]:
            if key in message["payload"].keys():
                del message["payload"][key]
        rtn = {"status": "success", "data": message}
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
