# -*- coding: utf-8 -*-

import json
from secrets import token_bytes
from hashlib import sha256
from typing import Any, Dict
from wiremq.processing import baseprocessor
from wiremq.extlib.err.sysmanagementexceptions import MessageStoreException
from wiremq.extlib.err.translatorexceptions import ClaimCheckException


class ClaimCheck(baseprocessor.BaseProcessor):
    """Claim-Check class.

    The ClaimCheck translator is used to both check items into a message store
    and claim previously checked items. As processor lifetimes are short, the
    translator only performs one action during its instance (either claim or
    check). The message store that is passed to the ClaimCheck can be passed to
    future instance of the component to perform another operation on the same
    message store.

    Checking an item into the store returns a claim id. This id is used during
    the claiming prodecure.

    Attributes
    ----------
    config: Dict
        alias: str
            Alias for the claimcheck.
        name: str
            Name for the claimcheck.
        type: str
            Type of processor (claimcheck).
        uid: hex
            Unique identifier for the claimcheck.
        processor_queue:
            Queue object.
        message_store: Object
            Message store object, used for checking and claiming messages.

    Methods
    -------
    _process(): Dict
        Overrides _process method of Base Processor with translator logic.
    _check(): str
        Check a message into the message store
    _claim(): Any
        Claim a message from the message store
    """

    def __init__(self, config: Dict = None):
        """Claim-Check class constructor.

        Parameters
        ----------
        config: Dict
            alias: str
                Alias for the claimcheck.
            name: str
                Name for the claimcheck.
            type: str
                Type of processor (claimcheck).
            uid: hex
                Unique identifier for the claimcheck.
            processor_queue:
                Queue object.
            message_store: Object
                Message store object, used for checking and claiming messages.

        Example
        -------
        >>> claimcheck_config = {
        ...     "alias": "ClaimCheck",
        ...     "name": "Claimcheck translator",
        ...     "type": "claimcheck",
        ...     "uid": "a8f43e278bd249cc239d32ab280e35f2",
        ...     "processor_queue": None,
        ...     "message_store": None
        }
        >>> queue = fifoqueue.FifoQueue(queue_config)
        >>> claimcheck_config["processor_queue"] = queue
        >>> queue.put(msg)
        >>> claimcheck.ClaimCheck(claimcheck_config)
        >>> res = queue.get()
        >>> queue.item_processed()

        """
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._log.rtn("%s: success" % self)

    def _process(self, message: Any) -> Dict:
        """Overrides _process method of Base Processor with translator logic.

        Parameters
        ----------
        msg: Any
            Message containing a request to either check a message into the
            store, or to claim a previously checked message. The request is
            accompanied by data which contains either the message to check in,
            or the claim id to reference the message to be retrieved.

        Returns
        -------
        rtn: Dict
            Dictionary containing the results of the claimcheck. If a claim
            request is made, and an unknown id supplied, the status will be
            failure.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        if message["request"] == "claim":
            res = self._claim(message["data"])
        elif message["request"] == "check":
            res = self._check(message["data"])
        if res:
            _status = "success"
        else:
            _status = "failure"
        rtn = {"status": _status, "data": res}
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _check(self, message: Any) -> str:
        """Check a message into the message store

        Parameters
        ----------
        message: Any
            The message to check into the message store

        Returns
        -------
        claim_id: str
            The claim id corresponding to the message in the store

        Raises
        ------
        MessageStoreException
            Throws an exception when failing to store message on the store.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        claim_id = sha256(token_bytes(32)).hexdigest()
        try:
            self._config["message_store"].store(
                {"claim_id": claim_id, "message": json.dumps(message)}
            )
        except MessageStoreException as e:
            raise ClaimCheckException(e)
        self._log.rtn("%s: success | data: %s" % (self, claim_id))
        return claim_id

    def _claim(self, claim_id: str) -> Any:
        """Claim a message from the message store

        Parameters
        ----------
        claim_id: str
            The claim id corresponding to the message in the store

        Returns
        -------
        message: Any
            The message claimed from the message store
        """
        self._log.args("%s: (claim_id: %s)" % (self, claim_id))
        query = self._config["message_store"].get({"claim_id": claim_id})

        if len(query) == 0:
            message = None
        else:
            message = json.loads(query[0][1])
            self._config["message_store"].remove({"claim_id": claim_id})
        self._log.rtn("%s: success | data: %s" % (self, message))
        return message
