# -*- coding: utf-8 - *-
"""BSON ContentEncoder"""

from typing import Dict
import bson
from wiremq.processing import baseprocessor


class BSONContentEncoder(baseprocessor.BaseProcessor):
    """BSON ContentEncoder.

    This class implements inherits the methods from the base processor class,
    while overriding the process function and introducing a new _encode_data
    function. Currently, channel registration, and use of the process() method
    is not included here.

    Methods
    -------
    _process : Dict
        Translates dict data into bytes, using BSON encoder.
    """

    def __init__(self, config: Dict = None):
        """BSON ContentEncoder constructor

        Parameters
        -----------
        config: dict
            type: str
                The type of the translator
            alias: str
                Processor's alias
            name: str
                Translator's name
            processor_id: hex
                Unique id using secrets lib with sha256 hashing.
            processor_queue: object
                Queue object for receiving and sending messages for processing.

        Example
        -------
        processor_queue = basequeue.BaseQueue(queue_fifo_config)
        config = {
            "alias": "BSON Content Encoder",
            "name": "CNCODR Translator",
            "type": "BSONContentEncoder",
            "processor_queue": processor_queue
        }
        translator = bsoncontentencoder.BSONContentEncoder(config)
        """
        super().__init__(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._log.rtn("%s: success" % self)

    def _process(self, data: Dict) -> Dict:
        """Translates dict data into bytes, using BSON encoder.

        Parameters
        ----------
        data : Dict, required
            This object will be sent to the encoding function.

        Returns
        -------
        _res: bytes
            The bytes data encoding of the Dict parameter, returned by the
            encoding function.
        """
        self._log.args("%s: (data: %s)" % (self, data))
        _res = {"status": "success", "data": bson.BSON.encode(data)}
        self._log.rtn("%s: success | data: %s" % (self, _res))
        return _res
