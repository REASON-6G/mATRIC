# -*- coding: utf-8 - *-
"""Initializes logging throughout wiremq, adds custom log levels to python's
logging system.

Log levels:
  debug: 10
  rtn: 18
  args: 19
  info: 20
  dev: 21
  test: 22
  warning: 30
  error: 40
  critical: 50

Used in conjunction with wiremq.logging.wmqlogger
"""

import logging

# Remove existing logging handlers
logging.basicConfig(encoding="utf-8", level=20)
for handler in logging.root.handlers[:]:
    logging.root.removeHandler(handler)

# Define custom log levels
ARGS = logging.INFO - 1
RTN = logging.INFO - 2
DEV = logging.INFO + 1
TEST = logging.INFO + 2


def loglevel_args(self, msg: str, *args, **kwargs) -> None:
    """Custom log level handler for object method arguments.

    Parameters
    ----------
    self: Logger instance
        Instance of the logging.Logger class
    msg: str
        The message to be logged.
    args:
        Arguments forwarded to the logging method.
    kwargs:
        Keyword arguments forwarded to the Logger.debug method.
    """
    if self.isEnabledFor(ARGS):
        self._log(ARGS, msg, args, **kwargs)


def loglevel_rtn(self, msg: str, *args, **kwargs) -> None:
    """Custom log level handler for object method return values.

    Parameters
    ----------
    self: Logger instance
        Instance of the logging.Logger class
    msg: str
        The message to be logged.
    args:
        Arguments forwarded to the logging method.
    kwargs:
        Keyword arguments forwarded to the Logger.debug method.
    """
    if self.isEnabledFor(RTN):
        self._log(RTN, msg, args, **kwargs)


def loglevel_dev(self, msg: str, *args, **kwargs) -> None:
    """Custom log level handler for developer logs.

    Parameters
    ----------
    self: Logger instance
        Instance of the logging.Logger class
    msg: str
        The message to be logged.
    args:
        Arguments forwarded to the logging method.
    kwargs:
        Keyword arguments forwarded to the Logger.debug method.
    """
    if self.isEnabledFor(DEV):
        self._log(DEV, msg, args, **kwargs)


def loglevel_test(self, msg: str, *args, **kwargs) -> None:
    """Custom log level handler for testing logs.

    Parameters
    ----------
    self: Logger instance
        Instance of the logging.Logger class
    msg: str
        The message to be logged.
    args:
        Arguments forwarded to the logging method.
    kwargs:
        Keyword arguments forwarded to the Logger.debug method.
    """
    if self.isEnabledFor(TEST):
        self._log(TEST, msg, args, **kwargs)


# Add logging levels to the global logger
logging.addLevelName(ARGS, "ARGS")
logging.addLevelName(RTN, "RTN")
logging.addLevelName(DEV, "DEV")
logging.addLevelName(TEST, "TEST")

# Add the log level handler methods to the global logger
logging.Logger.args = loglevel_args
logging.Logger.rtn = loglevel_rtn
logging.Logger.dev = loglevel_dev
logging.Logger.test = loglevel_test
