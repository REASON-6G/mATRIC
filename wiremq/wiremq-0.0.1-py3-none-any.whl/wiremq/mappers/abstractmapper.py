# -*- coding: utf-8 -*-
""" abstract message mapper class """

from typing import Dict
from abc import (
    ABC,
    abstractmethod
)


class AbstractMapper(ABC):
    """ Abstract message mapper class """

    @abstractmethod
    def config(self, config: Dict) -> bool:
        pass

    @abstractmethod
    def register(self, config: Dict) -> bool:
        pass

    @abstractmethod
    def map(self, msg: Dict) -> Dict:
        pass

    @abstractmethod
    def unregister(self) -> bool:
        pass
