# -*- coding: utf-8 -*-

import os
from pathlib import Path
from wiremq.extlib.database import sqlitedbconn

home_dir = Path.home()


def sqlite_create_table(config: dict, db_path) -> None:
    """Generates a query for sqlite to create a table and its columns.

    Parameters
    ----------
    config: dict
        db_table: str
            Name of the table
        id_field: str
            Field used as the identifier
        id_type: str
            Type (and other formatting) e.g. CHAR(16)
        fields: list of dict
            name: str
                Name of the field
            type: str
                Type (and other formatting) e.g. CHAR(16)
        db_config: dict
            type: str
                Type of the db conn (sqlitedbconn)
            check_same_thread: bool
                Required False when using multi-threading
            credentials: dict
                db_file: str
                    Name of the sqlite db file
    db_path: str
        Root path to the database directory
    """

    # Build query
    query = f"{config['db_table']}("
    query += f"{config['id_field']} {config['id_type']}"
    for field in config["fields"]:
        query += f", {field['name']} {field['type']}"
    query += ")"

    # Create conn object
    db_file = \
        os.path.join(db_path, config["db_config"]["credentials"]["db_file"])
    try:
        os.unlink(db_file)
    except OSError:
        pass
    config["db_config"]["credentials"]["db_file"] = db_file
    db_conn = sqlitedbconn.SQLiteDBConn(config["db_config"])

    # Create the table
    db_conn.create_table(query)


def sqlite_delete_db_file(config: dict, db_path: str) -> None:
    """Deletes an sqlite database from the file system.

    Parameters
    ----------
    config: dict
        db_table: str
            Name of the table
        id_field: str
            Field used as the identifier
        id_type: str
            Type (and other formatting) e.g. CHAR(16)
        fields: list of dict
            name: str
                Name of the field
            type: str
                Type (and other formatting) e.g. CHAR(16)
        db_config: dict
            type: str
                Type of the db conn (sqlitedbconn)
            check_same_thread: bool
                Required False when using multi-threading
            credentials: dict
                db_file: str
                    Name of the sqlite db file
    db_path: str
        Root path to the database directory
    """
    db_file = \
        os.path.join(db_path, config["db_config"]["credentials"]["db_file"])
    if os.path.isfile(db_file):
        os.remove(db_file)
