# -*- coding: utf-8 -*-

import uuid
from typing import (
    Any,
    Dict
)


class BaseTask:
    """The Base task class.

    Base task defines the basic structure of a task. A task is a work item to
    be executed by the scheduler. A Base Task contains an executable method,
    data, an executable stack and a result variable.

    Attributes
    ----------
    _method: object
        Method executed.
    _name: string
        Name of the task.
    _result: object
        Result of the task.
    _data: object
        Data of task.
    _stack: list
        List of execution steps for the task.
    _coroutine: object
        Coroutine object.
    _future: object
        Future object.

    Methods
    -------
    _generate_id(): str
        Generates unique identifier for the task.
    get_id(): str
        Returns the identifier of the task.
    set_result(): None
        Sets the result of the task.
    get_result(): Any
        Returns the result of the task.
    set_data(): Any
        Sets the data of the task.
    get_data(): Any
        Returns the data of the task.
    set_stack(): None
        Sets the execution stack of the task.
    get_stack(): Any
        Returns the execution stack of the task.
    set_method(): None
        Sets the execution method of the task.
    get_method(): Any
        Returns the execution method of the task.
    set_name(): None
        Sets the name of the task.
    get_name(): Any
        Returns the name of the task.
    set_result(): None
        Sets the result of the task.
    get_result(): Any
        Returns the result of the task execution.
    set_coroutine(): None
        Sets the coroutine object of a task.
    get_coroutine(): Any
        Returns the coroutine object of a task.
    set_future(): None
        Sets the coroutine of a task.
    get_future(): Any
        Returns the coroutine of a task.
    set_worker(): None
        Sets the worker of a task.
    get_worker(): Any
        Returns the worker of a task.
    """

    def __init__(self, method: Any = None, name: str = None):
        """Base Task class constructor.

        Parameters
        ----------
        method: object
            Method executed.
        name: string
            Name of task.

        Example
        -------
        >>> method = worker.execute(,
        >>> name = "pmtask"
        >>> task = basetask.BaseTask(method, name)
        """
        super().__init__()
        self._id = self._generate_id()
        self._method = method
        self._name = name
        self._data = {}
        self._stack = []
        self._result = None
        self._coroutine = None
        self._future = None
        self._worker = None

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def __repr__(self):
        return f"<Object: {self.__class__.__name__}>"

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def get_id(self) -> Any:
        """Returns the id of the task.

        Returns
        -------
        id: str
            Identifier of task.
        """
        rtn = str(self._id)
        return rtn

    def set_name(self, name: str) -> None:
        """Sets the name of the task.

        Parameters
        ----------
        name: str
            The name of the task.
        """
        self._name = name

    def get_name(self) -> str:
        """Returns the name of the task.

        Returns
        -------
        name: str
            The name of the task.
        """
        name = self._name
        return name

    def set_data(self, data: Dict) -> None:
        """Sets the data of the task.

        Parameters
        ----------
        data: dict
            Data required for the execution of the task.
        """
        self._data = data

    def get_data(self) -> Any:
        """Returns the data of the task.

        Returns
        -------
        data: dict
           Data required for the execution of the task.
        """
        data = self._data
        return data

    def set_result(self, result: Any) -> None:
        """Sets the result of the task.

        Parameters
        ----------
        result: object
            Result of task.
        """
        self._result = result

    def get_result(self) -> Any:
        """Returns the result of the task.

        Returns
        -------
        result: object
           The result of the task.
        """
        result = self._result
        return result

    def set_stack(self, stack: Dict) -> None:
        """Sets the execution stack of the task.

        Parameters
        ----------
        stack: Dict
            Execution steps of the method executing the task.
        """
        self._stack = stack

    def get_stack(self) -> Any:
        """Returns the execution stack of the task.

        Returns
        -------
        stack: dict
            Execution steps of the method executing the task.
        """
        stack = self._stack
        return stack

    def set_method(self, method: Any) -> None:
        """Sets the execution method of the task.

        Parameters
        ----------
        method: object
            Method executing the task.
        """
        self._method = method

    def get_method(self) -> Any:
        """Returns the execution method of the task.

        Returns
        -------
        method: object
            Method executing the task.
        """
        method = self._method
        return method

    def set_coroutine(self, coroutine: Any) -> None:
        """Sets the coroutine of the task.

        Parameters
        ----------
        coroutine: object
            Coroutine object.
        """
        self._coroutine = coroutine

    def get_coroutine(self) -> Any:
        """Returns the coroutine of the task.

        Returns
        -------
        coroutine: object
            Coroutine object.
        """
        coroutine = self._coroutine
        return coroutine

    def set_future(self, future: Any) -> None:
        """Sets the future object of a task.

        Parameters
        ----------
        future: object
            Future object.
        """
        self._future = future

    def get_future(self) -> Any:
        """Returns the future object of a task.

        Returns
        -------
        future: object
            Future object.
        """
        future = self._future
        return future

    def set_worker(self, worker: Any) -> None:
        """Sets the worker of a task.

        Parameters
        ----------
        worker: object
            Worker assigned to a task.
        """
        self._worker = worker

    def get_worker(self) -> Any:
        """Returns the worker of a task.

        Returns
        -------
        worker: object
            Worker assigned to a task.
        """
        worker = self._worker
        return worker
