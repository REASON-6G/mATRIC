# -*- coding: utf-8 -*-

from typing import (
    Any,
    Dict
)
import re
import uuid
import yaml
import os


@staticmethod
def get_config_from_yaml(module: Any, config_name: str) -> dict:
    """Extract config from yaml file and return it as a dict

    Parameters
    ----------
    module: Object
        A python module that shares the same location as a config file
    config_name: str
        The name of the config file (minus the .yaml extension)

    Example
    -------
    >>> from tests.integration.baseintegrationtest import /
    >>>     BaseIntegrationTest
    >>>
    >>> config = BaseIntegrationTest.get_config_from_yaml(
    >>>              __file__, 'config')

    Returns
    -------
    config: dict
        A dictionary storing the data extracted from the yaml file
    """
    dir_path = os.path.dirname(os.path.realpath(module))
    config_path = dir_path + '/' + config_name + '.yaml'
    with open(config_path) as yaml_file:
        config = yaml.safe_load(yaml_file)
    return config


def initialize_terminator(config: dict) -> dict:
    """Converts terminator strings in a config into bytes.

    This recursive method parses through a config, identifies terminator
    strings, then converts them into bytes.

    Parameters
    ----------
    config: Dict
        Endpoint config (or sub-config when in recursion)

    Returns
    -------
    """
    for k, v in config.items():
        if isinstance(v, dict):
            if "terminator" in v.keys() \
                    and isinstance(v["terminator"], str):
                v["terminator"] = v["terminator"].encode("utf")
            else:
                initialize_terminator(v)
    return config


def initialize_unix_sockets(config: dict, domain: str) -> dict:
    """Initializes unix socket domains in a config.

    This recursive method parses through a config, identifies any hosts
    which are unix domains, then prefixes the domain path and unlinks any
    existing socket at that domain.

    Parameters
    ----------
    config: Dict
        Component config (or sub-config when in recursion)
    domain: str
        Root domain where unix sockets are hosted

    Returns
    -------
    config: dict
        Modified config or sub-config

    """
    for k, v in config.items():
        if "socket_config" in k \
                and v["family"] == "unix" \
                and "host" in v.keys():
            if v["host"] is not None:
                v["host"] = os.path.join(domain, v["host"])
                try:
                    os.unlink(v["host"])
                except OSError:
                    pass
        if isinstance(v, dict):
            initialize_unix_sockets(v, domain)
    return config


def initialize_unix_destinations(config: dict, domain: str) -> dict:
    """Initializes unix socket domains in a config.

    This recursive method parses through a config, identifies any destinations
    which are unix domains, then prefixes the domain path.

    Parameters
    ----------
    config: Dict
        Component config (or sub-config when in recursion)
    domain: str
        Root domain where unix sockets are hosted

    Returns
    -------
    config: dict
        modified config or sub-config

    """
    for k, v in config.items():
        if k == "SD" and "outbound_socket_config" in v["config"]:
            if v["config"]["outbound_socket_config"]["family"] == "unix":
                v["config"]["dest_ip"] = os.path.join(
                    domain,
                    v["config"]["dest_ip"]
                )
        if k == "sockdispatcher_config":
            if v["outbound_socket_config"]["family"] == "unix":
                v["dest_ip"] = os.path.join(
                    domain,
                    v["dest_ip"]
                )
        if k == "requesthandler_config":
            if v["dispatcher_config"]["outsocket_config"]["family"] == "unix":
                v["dest_ip"] = os.path.join(
                    domain,
                    v["dest_ip"]
                )
        if isinstance(v, dict):
            initialize_unix_destinations(v, domain)

    return config


def initialize_db_paths(config: dict, path: str) -> dict:
    """Initializes sqlite database paths.

    This recursive method parses through a config, identifies any db files
    then prefixes the path.

    Parameters
    ----------
    config: Dict
        Component config (or sub-config when in recursion)
    path: str
        Path where sqlite databases are stored

    Returns
    -------
    config: dict
        Modified config or sub-config

    """
    for k, v in config.items():
        if "db_config" in k and v["type"] == "sqlitedbconn":
            v["credentials"]["db_file"] = os.path.join(
                path,
                v["credentials"]["db_file"]
            )
        if isinstance(v, dict):
            initialize_db_paths(v, path)
    return config


def generate_id() -> str:
    """Generates a unique id.

    Returns
    -------
    id: str
        Generated identifier.
    """
    _id = str(uuid.uuid4())
    return _id


def get_dict_value(data: Dict, path: str) -> Any:
    """Gets a value from a nested dictionary using dot notation.

    Parameters
    ----------
    data: Dict
        The dictionary to extract data from.
    path str
        The path to extract the value, e.g. "payload.params.attr1"

    Returns
    -------
    rtn: Any
        The extracted dict value at the specified path.

    Example
    -------
    >>> d = {
    ...   "name": "Nostromo",
    ...   "params": {
    ...     "crew": 7,
    ...     "length": "334m"
    ...   }
    ... }
    >>> path = "params.crew"
    >>> get_dict_value(d, path)
    7

    """
    split_path = re.split(r"\.", path, flags=re.IGNORECASE)
    rtn = data
    for key in split_path:
        try:
            # key = int(key) if key.isnumeric else key
            rtn = rtn[key]
        except KeyError:
            rtn = None
            break
    return rtn


def set_dict_value(data: Dict, path: str, value: Any) -> Dict:
    """Sets a value in a nested dictionary using dot notation.

    If a key does not exist at the specified path, it will be created.

    Parameters
    ----------
    data: Dict
        The dictionary to modify.
    path: str
        The path to set the value, e.g. "payload.params.attr1".
    value: Any
        Value to be set in the dictionary at the specified path.

    Example
    -------
    >>> d = {
    ...   "name": "Nostromo",
    ...   "params": {
    ...     "crew": 7,
    ...     "length": "334m"
    ...   }
    ... }
    >>> path = "params.mainframe"
    >>> set_dict_value(d, path, "mother")
    {
      "name": "Nostromo",
      "params": {
        "crew": 7,
        "length": "334m",
        "mainframe": "mother
      }
    }

    """
    split_path = re.split(r"\.", path, flags=re.IGNORECASE)
    target = data
    for key in split_path[:-1]:
        try:
            if key not in target:
                target[key] = {}
            target = target[key]
        except KeyError:
            break
    target[split_path[-1]] = value
    return data
