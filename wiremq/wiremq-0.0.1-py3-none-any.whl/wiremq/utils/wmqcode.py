# -*- coding: utf-8 -*-
"""Commands used by wiremq components.

Commands are transported as integers and are mapped here.

0 - 200 are reserved for internal wiremq messages
"""
# =============================MESSAGE TYPES===================================
EVENT = 1
COMMAND = 2

# ===============================COMMANDS======================================
# General
ACKNOWLEDGEMENT = 1
ONLINE_NOTIFICATION = 2

# Subscriptions
ADD_SUBSCRIBER = 21
UPDATE_SUBSCRIBER = 22
REMOVE_SUBSCRIBER = 23

# Bus channel connections
ADD_BUS_CONNECTION = 31
REMOVE_BUS_CONNECTION = 32
