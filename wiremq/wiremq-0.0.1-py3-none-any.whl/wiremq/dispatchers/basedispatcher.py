# -*- coding: utf-8 - *-

from typing import Dict
import uuid
import logging
from wiremq.dispatchers import abstractdispatcher


class BaseDispatcher(abstractdispatcher.AbstractDispatcher):
    """Base dispatcher class

    Attributes
    ----------
    _config: dict
        Dispatcher configuration dictionary.
    _dmap: dict
        Dispatcher map, holding all the objects that the dispatcher handles.
    _log: object
        Python logging instance.

    Methods
    -------
    generate_uid(): hex
        Generates and returns a unique hexadecimal identifier for the
        dispatcher.
    config(): None
        Configures the dispatcher.
    get_config(): Dict
        Getter for dispatcher configuration.
    register(): bool
        Generic method to register transport objects.
    unregister(): bool
        Generic method to unregister transport objects.
    dispatch(): Any
        Generic method to dispatch data.
    """

    def __init__(self, config: Dict = None) -> None:
        """Dispatcher class constructor.

        Parameters
        ----------
        config: dict
            Dispatcher configuration dictionary.
            type: str
                Type of dispatcher.
            transport_type: str
                Type of inbound and outbound transport used. Can either be
                "queue", or "channel".
            logger: str
                Name of the logger instance.

        Example
        -------
        >>> dispatcher_config = {
        ...     "type": "transportdispatcher_channel",
        ...     "logger": "basic_logger"
        ... }
        >>> dispatcher = basedispatcher.BaseDispatcher(config)

        """
        super().__init__(config)
        self._id = self._generate_id()
        self._config = None
        self._log = None
        self._dmap = {}
        if config:
            self.config(config)

    def __str__(self) -> str:
        """Override __str__ class."""
        return f'<Object: {self.__class__.__name__} Id: {self._id}>'

    def _generate_id(self) -> str:
        """Generates a unique id.

        Returns
        -------
        id: str
            Generated identifier.
        """
        _id = str(uuid.uuid4())
        return _id

    def config(self, config: Dict) -> bool:
        """Configures the dispatcher.

        Parameters
        ----------
        config: dict
            Dispatcher configuration dictionary.
            type: str
                Type of dispatcher.
            logger: str, optional
                Name of the logger instance.

        Returns
        -------
        bool
            True if configuration successful, False otherwise
        """
        self._log = logging.getLogger(config.get("logger", "basic_logger"))
        self._log.args("%s: (config: %s)" % (self, config))
        if not self._config:
            self._config = config
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def get_config(self) -> Dict:
        """Getter for dispatcher configuration.

        Returns
        -------
        config: dict
            Dispatcher configuration dictionary.
            type: str
                Type of dispatcher.
        """
        config = self._config
        return config

    def register(self) -> None:
        """Generic method to register transport objects."""
        self._log.args("%s: ()" % self)
        pass

    def unregister(self) -> None:
        """Generic method to unregister transport objects."""
        self._log.args("%s: ()" % self)
        self._config = None

    def dispatch(self, _fd: int, _message: bytes) -> None:
        """Generic method to dispatch data."""
        self._log.args("%s: ()" % self)
        pass
