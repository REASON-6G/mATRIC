# -*- coding: utf-8 - *-

from typing import Dict

from abc import (
    ABC,
    abstractmethod
)


class AbstractDispatcher(ABC):
    """ Abstract dispatcher class. """

    def __init__(self, config: Dict = None) -> None:
        """Dispatcher class constructor"""
        pass

    @abstractmethod
    def config(self, config: Dict) -> None:
        """Configures the dispatcher."""
        pass

    @abstractmethod
    def get_config(self) -> Dict:
        """Getter for dispatcher configuration."""
        pass

    def register(self) -> None:
        """Registers transport objects."""
        pass

    def unregister(self) -> None:
        """Unregisters transport objects."""
        pass

    @abstractmethod
    def dispatch(self) -> None:
        """Generic method to dispatch data."""
        pass
