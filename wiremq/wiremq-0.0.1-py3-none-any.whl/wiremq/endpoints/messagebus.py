# -*- coding: utf-8 -*-
from typing import (
    Dict
)
import bson
from wiremq.endpoints import baseendpoint
from wiremq.filters import sockdispatcher
from wiremq.extlib.err.endpointexceptions import EndpointException
from wiremq.extlib.err.consumerexceptions import BaseConsumerException
from wiremq.extlib.err.processingexception import ThreadedSchedulerException
from wiremq.extlib.err.producerexceptions import BaseProducerException
from wiremq.extlib.err.queueexception import (
    QueueEmptyException,
    QueueFullException
)


class MessageBus(baseendpoint.BaseEndpoint):
    """Message bus class description.

    Message bus inherits from baseendpoint, it runs as a thread and the process
    method contains the bus's logic.

    When sending, the message bus endpoint sends to all other members of the
    bus. Messages are only added to the received queue when the message's
    dest_ip and dest_port match the consumer's host and ip.

    Attributes
    ----------
    For other attributes, see baseendpoint.

    Methods
    -------
    config(): bool
        Configures the message bus.
    process(): None
        Consumes and processes command and event messages.
    _process_message_inbound(): None
        Handles all incoming messages from the ioloop
    _process_message_outbound(): None
        Handles outbound messages.
    _process_event(): None
        Processes event messages.
    _process_command(): None
        Processes command messages.
    _add_connection(): None
        Helper method to process an ADD_BUS_CONNECTION command message.
    _remove_connection(): None
        Helper method to process a REMOVE_BUS_CONNECTION command message.
    send_connection_command(): None
        Creates the configuration for a connection command message and
        dispatches it to the producer.
    _update_dispatcher_destinations(): None
        Sets the destinations in the bus endpoint's producer.
    connect: bool
        Adds a connection to the bus.
    close_connection(): bool
        Removes a connection from the bus.
    send(): None
        Adds a message to the outbound sending queue, to be sent in the
        bus's main loop.
    receive(): list
        Extracts messages from the received queue.
    close(): bool
        Unregisters components from the publisher subscriber channel.

    """

    def __init__(self, config: Dict = None):
        """Message bus class constructor.

        Parameters
        ----------
        config: Dict (fields required unless otherwise stated)

        Example
        -------

        """
        self._connections = []
        super().__init__(config)

    def config(self, config: Dict) -> bool:
        """Configures the message bus.

        Parameters
        ----------

        Returns
        -------
        rtn: bool
            True if successful
        """
        super().config(config)
        self._connections = config["connections"]
        return True

    def process(self) -> None:
        """Consumes and processes command and event messages.

        Raises
        ------
        EndpointException
            Throws an exception whenever the io loops fail to handle a task.
        """
        try:
            self.consume("consumer")
            self._eventloop.run_once()
            self._handle_inbound()
            self._handle_outbound()
            self.produce("producer")
        except (BaseProducerException, BaseConsumerException) as e:
            self._log.error(e)
            raise EndpointException(e)
        except ThreadedSchedulerException as e:
            self._log.error(e)
            raise EndpointException(e)

    def _process_message_inbound(self, message: Dict) -> None:
        """Handles all incoming messages from the ioloop.

        Called by baseendpoint's _handle_inbound method, this method takes a
        message, then places it in the received queue. If the message
        destination address does not match this endpoint, it is placed into
        the invalid message queue.

        Parameters
        ----------
        message: Dict
            Incoming message to be processed.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        try:
            if message["dest_ip"] == self._config["consumer_host"] and \
                    message["dest_port"] == self._config["consumer_port"]:
                self._received_queue.put(message)
            else:
                self._invalid_message_queue.put(message)
        except QueueFullException as e:
            self._log.error(e)
            raise EndpointException(e)

    def _process_message_outbound(self, message: Dict) -> None:
        """Handles outbound messages.

        Updates the sockdispatcher's recipients and dispatches the message,
        then stores the message in the durable store for each recipient.

        Parameters
        ----------
        message: dict
            Message to process

        Raises
        ------
        EndpointException
            Raised either when an item cannot be put into nor retrieved from
            the dispatch queue
        """
        self._log.args("%s: (message: %s)" % (self, message))
        try:
            self._dispatch_queue.put(bson.BSON.encode(message))
        except QueueFullException as e:
            self._log.error(e)
            self._invalid_message_queue.put(message)
            raise EndpointException(e)
        self._update_dispatcher_destinations()
        sockdispatcher.SockDispatcher(self._config["sockdispatcher_config"])
        try:
            dispatch_result = self._dispatch_queue.get()
        except QueueEmptyException as e:
            self._log.error(e)
            self._invalid_message_queue.put(message)
            raise EndpointException(e)
        self._log.info("%s: (dispatch: %s)" % (self, dispatch_result))
        self._dispatch_queue.item_processed()

        if self._durable and "payload" in message:
            for recipient in self._connections:
                self._store_durable(message, recipient)

    def _update_dispatcher_destinations(self) -> None:
        """Sets the destinations in the bus endpoint's producer.

        """
        self._config["producer_config"]["scheduler_config"]["worker_config"][
            "processor_map"]["SD"]["config"]["outbound_socket_config"][
            "destinations"] = self._connections

    def connect(self, host: str, port: int) -> bool:
        """Adds a connection to the bus, then sends a command message with a
        wmqcode.ADD_BUS_CONNECTION command code.

        Parameters
        ----------
        host: str
            The hostname/ip of the remote connection.
        port: int
            The port number of the remote connection.

        Returns
        -------
        rtn: bool
            True if successful
        """
        self._log.args("%s: (host: %s, port: %s)" % (self, host, port))
        self._connections.append((host, port))
        self._update_dispatcher_destinations()
        rtn = True
        self._log.rtn("success | data: %s" % rtn)
        return rtn

    def close_connection(self, host: str, port: int) -> bool:
        """Removes a connection from the bus.

        Parameters
        ----------
        host: str
            The hostname/ip of the remote connection.
        port: int
            The port number of the remote connection.

        Returns
        -------
        rtn: bool
            True if successful
        """
        self._log.args("%s: (host: %s, port: %s)" % (self, host, port))
        self._connections.remove((host, port))
        rtn = True
        self._log.rtn("success | data: %s" % rtn)
        return rtn

    def send(self, msg: Dict) -> None:
        """Adds a message to the outbound sending queue, to be sent in the
        bus's main loop.

        Parameters
        ----------
        msg: Dict
            Message to be sent.

        Raises
        ------
        EndpointException
            Throws a message store exception whenever the send queue is full.
        """
        self._log.args("%s: (msg: %s)" % (self, msg))
        self._update_dispatcher_destinations()
        try:
            self._send_queue.put(msg)
        except QueueFullException as e:
            self._log.error(e)
            raise EndpointException(e)
        super().send(msg)
        self._log.rtn("%s: success" % self)

    def receive(self) -> list:
        """Extracts messages from the received queue.

        Returns
        -------
        rtn: list
            List of messages from the received queue.
        """
        super().receive()
        rtn = []
        if not self._received_queue.empty():
            _item = self._received_queue.get()
            self._log.info("%s: _item: %s" % (self, _item))
            rtn.append(_item)
            self._received_queue.item_processed()
        return rtn

    def close(self) -> bool:
        """Unregisters components from the publisher subscriber channel.

        Returns
        -------
        rtn: bool
            Returns True if successful
        """
        self._log.args("%s: ()" % self)
        self._connections = []
        rtn = super().close()
        return rtn
