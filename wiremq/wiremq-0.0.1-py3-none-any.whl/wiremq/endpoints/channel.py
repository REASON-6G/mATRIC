# -*- coding: utf-8 -*-
from typing import (
    Dict
)
import bson
from wiremq.endpoints import baseendpoint
from wiremq.filters import sockdispatcher
from wiremq.utils import wmqcode
from wiremq.extlib.err.endpointexceptions import EndpointException
from wiremq.extlib.err.consumerexceptions import BaseConsumerException
from wiremq.extlib.err.processingexception import ThreadedSchedulerException
from wiremq.extlib.err.producerexceptions import BaseProducerException
from wiremq.extlib.err.queueexception import (
    QueueEmptyException,
    QueueFullException
)


class Channel(baseendpoint.BaseEndpoint):
    """Channel class description.

    Channel inherits from baseendpoint, it runs as a thread and the process
    method contains the channel's logic.

    The channel receives messages from a consumer, which pipes to the
    channel's event loop, the message is then processed according to the
    channel's configuration and endpoint logic

    When sending, messages are added to a send queue, and the channel logic
    sends to the channel's producer via a sockdispatcher.

    After instantiating a channel, a consumer needs to be registered to it
    with the alias, "consumer"; and a producer needs to be registered with
    an alias of "producer".

    Attributes
    ----------
    For other attributes, see baseendpoint.

    Methods
    -------
    process(): None
        The channel's main loop, overrides baseendpoint's process method.
    receive(): list
        Extracts messages from the received queue.
    subscribe(): None
        Subscribe to a publisher-subscriber channel.
    send(): None
        Adds a message to the outbound sending queue,
    _process_message_inbound(): None
        Handles all incoming messages.
    _process_message_outbound(): None
        Handles outbound messages.
    """

    def __init__(self, config: Dict = None):
        """Channel class constructor.

        Parameters
        ----------
        config: Dict
            Channel configuration dictionary.
            consumer_host: str
                Hostname of the channel's consumer.
            consumer_port: int
                Port number of the channel's consumer.

        Example
        -------
        >>> channel_config = {
        ...     "name": "Channel",
        ...     "alias": "channel",
        ...     "message_store": None,
        ...     "eventloop": None,
        ...     "consumer": None,
        ...     "producer": None,
        ...     "scheduler": None,
        ...     "task_queue": None,
        ... }
        >>> consumer = baseconsumer.BaseConsumer(consumer_config)
        >>> producer = baseproducer.BaseProducer(producer_config)
        >>> iopoller = ioeventloopudp.IOEventLoopUDP(ioloop_config)
        >>> insocket = inboundsocket.InboundSocket(inbound_socket_config)
        >>> task_queue = fifoqueue.FifoQueue(task_queue_config)
        >>> received_queue = fifoqueue.FifoQueue(task_queue_config)
        >>> send_queue = fifoqueue.FifoQueue(task_queue_config)
        >>> processmanager_inbound = baseprocessmanager.BaseProcessManager(
        >>>                              pm_in_config)
        >>> processmanager_outbound = baseprocessmanager.BaseProcessManager(
        >>>                              pm_out_config)
        >>> message_store = messagestore.MessageStore(ms_config
        >>> scheduler = threadedscheduler.ThreadedScheduler(scheduler_config)
        >>> channel_config["eventloop"] = channel_ioloop
        >>> channel_config["insocket"] = channel_in_sock
        >>> channel_config["task_queue"] = channel_task_queue
        >>> channel_config["received_queue"] = channel_received_queue
        >>> channel_config["send_queue"] = channel_send_queue
        >>> channel_config["processmanager_inbound"] = processmanager_inbound
        >>> channel_config["processmanager_outbound"] = processmanager_outbound
        >>> channel_config["durable_store"] = durable_messagestore
        >>> ch = channel.Channel(channel_config)
        >>> ch.register_consumer(consumer)
        >>> ch.register_producer(producer)
        >>> ch.start()
        >>> ch.close()
        >>> ch.join(0.1)
        >>> ch.unregister()
        """
        super().__init__(config)

    def process(self) -> None:
        """The channel's main loop, overrides baseendpoint's process method.

        This method is invoked by the channel's run method, which operates as
        the threaded channel's main loop.

        Handles message consumption, receiving of inbound messages via the
        poller, sending of outbound messages to the producer, and message
        production.

        Raises
        ------
        EndpointException
            Throws an exception whenever the io loops fail to handle a task.
        """
        try:
            self._eventloop.run_once()
            self.consume("consumer")
            self._handle_outbound()
            self._handle_inbound()
            self.produce("producer")
        except (BaseProducerException, BaseConsumerException) as e:
            self._log.error(e)
            raise EndpointException(e)
        except ThreadedSchedulerException as e:
            self._log.error(e)
            raise EndpointException(e)

    def receive(self) -> list:
        """Extracts messages from the received queue.

        Messages extracted from this queue have been received by the consumer,
        and processed through the channel's inbound process manager. Once
        messages have been received they are marked as processed.

        Returns
        -------
        rtn: list
            List of messages from the received queue.
        """
        super().receive()
        rtn = []
        if not self._received_queue.empty():
            _item = self._received_queue.get()
            self._log.info("%s: _item: %s" % (self, _item))
            rtn.append(_item)
            self._received_queue.item_processed()
        return rtn

    def send(self, msg: Dict) -> None:
        """Adds a message to the outbound sending queue, to be sent in the
        channel's main loop.

        Parameters
        ----------
        msg: Dict
            Message to be sent.

        Raises
        ------
        EndpointException
            Throws a message store exception whenever the send queue is full.
        """
        self._log.args("%s: (msg: %s)" % (self, msg))
        try:
            self._send_queue.put(msg)
        except QueueFullException as e:
            self._log.error(e)
            raise EndpointException(e)
        super().send(msg)
        self._log.rtn("%s: success" % self)

    def subscribe(self, topics: list, criteria: dict,
                  dest_ip: str = None, dest_port: int = None) -> None:
        """Subscribes to a publisher/subscriber channel.

        Generates a config for the producer's message factory and requests
        that the producer create and dispatch the constructed command message.

        Parameters
        ----------
        topics: list of str
            A list of topics to subscribe to.
        criteria: dict
            For each topic, a set of criteria to filter received messages, e.g.
            {
                "topic1": {
                    "ram": ("gt", 15000000),
                    "cores": ("gt", 2),
                },
                "topic2": {
                    "ram": ("gt", 15000000),
                    "cores": ("gt", 2),
                }
            }
        dest_ip: str (optional)
            Sets the destination host in the message header, used when the
            producer's sockdispatcher is utilizing the from_msg sending mode.
        dest_port: int (optional)
            Sets the destination port in the message header, used when the
            producer's sockdispatcher is utilizing the from_msg sending mode.

        """
        self._log.args("%s: (topics: %s, criteria: %s, dest_ip: %s, "
                       "dest_port: %s)"
                       % (self, topics, criteria, dest_ip, dest_port))
        self._dispatch_subscription_config(
            wmqcode.ADD_SUBSCRIBER,
            topics,
            criteria,
            dest_ip,
            dest_port
        )

    def update_subscription(self,
                            topics: list,
                            criteria: dict,
                            dest_ip: str = None,
                            dest_port: int = None) -> None:
        """Sends a request to edit a subscription to a publisher/subscriber
        channel.

        Generates a config for the producer's message factory and requests
        that the producer create and dispatch the constructed command message.

        Parameters
        ----------
        topics: list of str
            A list of topic subscriptions to modify.
        criteria: dict
            For each topic, a set of criteria to filter received messages, e.g.
            {
                "topic1": {
                    "ram": ("gt", 15000000),
                    "cores": ("gt", 2),
                },
                "topic2": {
                    "ram": ("gt", 15000000),
                    "cores": ("gt", 2),
                }
            }
        dest_ip: str (optional)
            Sets the destination host in the message header, used when the
            producer's sockdispatcher is utilizing the from_msg sending mode.
        dest_port: int (optional)
            Sets the destination port in the message header, used when the
            producer's sockdispatcher is utilizing the from_msg sending mode.

        """
        self._log.args("%s: (topics: %s, criteria: %s, dest_ip: %s, "
                       "dest_port: %s)"
                       % (self, topics, criteria, dest_ip, dest_port))
        self._dispatch_subscription_config(
            wmqcode.UPDATE_SUBSCRIBER,
            topics,
            criteria,
            dest_ip,
            dest_port
        )

    def unsubscribe(self, topics: list,
                    dest_ip: str = None, dest_port: int = None) -> None:
        """Unsubscribes from a publisher/subscriber channel.

        Generates a config for the producer's message factory and requests
        that the producer create and dispatch the constructed command message.

        Parameters
        ----------
        topics: list of str
            A list of topics to unsubscribe from.
        dest_ip: str (optional)
            Sets the destination host in the message header, used when the
            producer's sockdispatcher is utilizing the from_msg sending mode.
        dest_port: int (optional)
            Sets the destination port in the message header, used when the
            producer's sockdispatcher is utilizing the from_msg sending mode.

        """
        self._log.args("%s: (topics: %s, dest_ip: %s, dest_port: %s)"
                       % (self, topics, dest_ip, dest_port))
        self._dispatch_subscription_config(
            wmqcode.REMOVE_SUBSCRIBER,
            topics,
            None,
            dest_ip,
            dest_port
        )

    def _dispatch_subscription_config(self,
                                      command: int,
                                      topics: list,
                                      criteria: dict = None,
                                      dest_ip: str = None,
                                      dest_port: int = None) -> None:
        """ Overloads a config to create a subscription related message and
        dispatches the subscription message to the producer.

        Can handle add, update, or remove subscriber commands.

        Parameters
        ----------
        command: int
            Wiremq command number.
        topics: list
            List of topics to subscribe to, unsubscribe from, or update.
        criteria: dict
            For each topic, a set of criteria to filter received messages. (not
            required for unsubscribe)
        dest_ip: str (optional)
            Sets the destination host in the message header, used when the
            producer's sockdispatcher is utilizing the from_msg sending mode.
        dest_port: int (optional)
            Sets the destination port in the message header, used when the
            producer's sockdispatcher is utilizing the from_msg sending mode.

        """
        self._log.args("%s: (command: %s, topics: %s, criteria: %s, "
                       "dest_ip: %s, dest_port %s)"
                       % (self, command, topics, criteria, dest_ip, dest_port))
        subscription_config = {
            "type": "command",
            "payload": {
                "command": command,
                "params": {
                    "host": self._consumer["consumer"]._eventloop.get_config()[
                        "inbound_socket_config"]["host"],
                    "port": self._consumer["consumer"]._eventloop.get_config()[
                        "inbound_socket_config"]["port"],
                    "topics": topics
                }
            }
        }
        if criteria:
            subscription_config["payload"]["params"]["criteria"] = criteria
        if dest_ip:
            subscription_config["dest_ip"] = dest_ip
            subscription_config["dest_port"] = dest_port
        self._producer["producer"].produce(subscription_config)

    def _process_message_inbound(self, message: Dict) -> None:
        """Handles all incoming messages.

        Called by baseendpoint's _handle_inbound method, this method takes a
        message, then places it into the received queue, and if appropriate
        prompts the producer to send an acknowledgement.

        Parameters
        ----------
        message: Dict
            Message to be processed.

        Raises
        ------
        EndpointException
            Raised when the received queue is full and the message cannot be
            sent.

        """
        self._log.args("%s: (message: %s)" % (self, message))
        try:
            self._received_queue.put(message)
        except QueueFullException as e:
            self._log.error(e)
            raise EndpointException(e)

        # Send acknowledgement
        if self._auto_ack and "payload" in message:
            self._producer["producer"].send_ack(message)
        self._log.rtn("%s: success" % self)

    def _process_message_outbound(self, message: dict) -> None:
        """Handles outbound messages.

        Called by baseendpoint's _handle_outbound method, this method takes a
        message, dispatches it, and places it in the durable store.

        Parameters
        ----------
        message: dict
            Message to process

        Raises
        ------
        EndpointException:
            Raised when an item cannot be retrieved from the dispatch queue.
        """
        self._dispatch_queue.put(bson.BSON.encode(message))
        sockdispatcher.SockDispatcher(self._config["sockdispatcher_config"])
        try:
            dispatch_result = self._dispatch_queue.get()
            self._dispatch_queue.item_processed()
        except QueueEmptyException as e:
            self._log.error(e)
            raise EndpointException(e)
        self._log.info("%s: (dispatch: %s)" % (self, dispatch_result))

        if self._durable and "payload" in message:
            self._store_durable(
                message,
                (message["dest_ip"], message["dest_port"])
            )
