# -*- coding: utf-8 -*-

import hashlib
import bson
from typing import Dict
from wiremq.endpoints import baseendpoint
from wiremq.filters import sockdispatcher
from wiremq.extlib.err.endpointexceptions import EndpointException
from wiremq.extlib.err.consumerexceptions import BaseConsumerException
from wiremq.extlib.err.processingexception import ThreadedSchedulerException
from wiremq.extlib.err.producerexceptions import BaseProducerException
from wiremq.filters import recipientlist
from wiremq.utils import wmqcode
from wiremq.extlib.err.queueexception import (
    QueueEmptyException,
    QueueFullException
)


class PublisherSubscriberChannel(baseendpoint.BaseEndpoint):
    """Publisher Subscriber Channel class description.

    Publisher Subscriber Channel is a child class of base endpoint. It can
    receive command messages to modify its subscribers list, as well as
    event messages to publish to its subscribers, based on their topics
    subscribed.

    After instantiating a publisher subscriber channel, two consumers need to
    be registered with the following aliases: "eventconsumer" and
    "commandconsumer".

    Attributes
    ----------
    _config: Dict
        Pubsub channel configuration dictionary.
    _topics: list
        A list of topics that the pub sub channel supports.
    _subscribers: Dict
        A mapping of topic to subscriber.
    _recipients: list
        The list of recipients for the next topic broadcast message.
    _recipientlist_queue: queue
        Queue used for generating a recipient list from a topic message.
    For other attributes, see baseendpoint.

    Methods
    -------
    config(): bool
        Configure endpoint.
    register(): bool
        Register components from config.
    process(): None
        Consume and process command and event messages.
    notify(): None
        Notify subscribers of a new event.
    _process_message_inbound(): None
        Handles all incoming messages.
    _process_message_outbound(): None
        Handles outbound messages.
    _process_event(): None
        Process event messages.
    _process_command(): None
        Process command messages.
    _filter_subscribers(): list
        Uses the recipient list to filter subscribers to a given topic by the
        subscription criteria.
    add_subscriber(): bool
        Register a subscriber, if doing so doesn't exceed max subscribers.
    update_subscriber(): bool
        Update a subscriber.
    remove_subscriber(): bool
        Remove a subscriber.
    get_subscribers(): list
        Return the endpoint's subscribers.
    _generate_subscriber_id(): str
        Generate a unique ID based on alias
    close(): bool
        Unregisters components from the publisher subscriber channel.
    """

    def __init__(self, config: Dict = None):
        """Publisher Subscriber class constructor.

        Parameters
        ----------
        config: Dict (fields required unless otherwise stated)
            subscribers: Dict
                The subscribers to the endpoint.
            max_subscribers: int
                The maximum number of subscribers allowable by the endpoint.
            command_consumer: Consumer
                The endpoint's consumer.
            processmanager_queue: Queue
                The queue for the endpoint's process manager.
            broadcast_socket: BroadcastSocket
                The endpoint's broadcastsocket.
            topics: list
                A list of topics that the pub sub channel supports.
            logger: str, optional
                Name of the logger instance.

        Example
        -------
        >>> ps_config = {}
        >>> ps_config["durable_store"] = durable_ms
        >>> ps_config["persistent_store"] = persistent_ms
        >>> ps_config["idempotent_store"] = idempotent_ms
        >>> ps_config["eventloop"] = eventloop
        >>> ps_config["durable"] = True
        >>> ps_config["persistent"] = True
        >>> ps_config["idempotent"] = False
        >>> ps_config["max_subscribers"] = 100
        >>> ps_config["task_queue"] = prod_task_queue2
        >>> ps_config["broadcast_socket"] = broadcast_socket
        >>> ps_config["processmanager_outbound"] = processmanager_outbound
        >>> ps_config["processmanager_queue"] = processor_queue2
        >>> ps_config["recipientlist_queue"] = recipientlist_queue
        >>> pschannel = publishersubscriberchannel.PublisherSubscriberChannel(
        ...     ps_config
        >>> )
        >>> pschannel.register_consumer(commandconsumer)
        >>> pschannel.register_consumer(eventconsumer)
        >>> pschannel.register_producer(producer)
        """
        self._topics = []
        self._subscribers = {}
        self._recipients = []
        self._recipientlist_queue = None
        super().__init__(config)

    def config(self, config: Dict) -> bool:
        """Configure endpoint.

        Parameters
        ----------
        subscribers: Dict
            The subscribers to the endpoint.
        max_subscribers: int
            The maximum number of subscribers allowable by the endpoint.
        durable: bool
            Flag to indicate whether the endpoint is durable.
        persistent: bool
            Flag to indicate whether the endpoint is persistent.
        idempotent: bool
            Flag to indicate whether the endpoint is idempotent.
        topics: list
            A list of topics that the pub sub channel supports.
            logger: str, optional
                Name of the logger instance.

        Returns
        -------
        rtn: bool
            True if successful
        """
        super().config(config)
        self._topics = config["topics"]
        for topic in self._topics:
            self._subscribers[topic] = {}
        return True

    def register(self, config: Dict) -> bool:
        """Register components from config.

        Parameters
        ----------
        config: Dict (fields required unless otherwise stated)
            For other parameters, see BaseEndpoint.
            broadcast_socket: BroadcastSocket
                The broadcast socket used to send messages to subscribers.

        Returns
        -------
        rtn: bool
            True if successful
        """
        super().register(config)
        self._recipientlist_queue = config["recipientlist_queue"]
        return True

    def process(self) -> None:
        """Consume and process command and event messages.

        Raises
        ------
        EndpointException
            Throws an exception whenever the io loops fail to handle a task.
        """
        try:
            self.consume("commandconsumer")
            self.consume("eventconsumer")
            self._eventloop.run_once()
            self._handle_inbound()
            self._handle_outbound()
            self.produce("producer")
        except (BaseProducerException, BaseConsumerException) as e:
            self._log.error(e)
            raise EndpointException(e)
        except ThreadedSchedulerException as e:
            self._log.error(e)
            raise EndpointException(e)

    def notify(self, event: Dict) -> None:
        """Notify subscribers of a new event.

        Parameters
        ----------
        event: Dict
            See basemessage class for an example. The specific key required
            for event processing is the "topic" key in the payload's params.
        """
        self._log.args("%s: (event: %s)" % (self, event))
        self._process_event(event)

    def _process_message_inbound(self, message: Dict) -> None:
        """Handles all incoming messages.

        Called by baseendpoint's _handle_inbound method, this method takes a
        message, then processes it either as an event or a command.

        Parameters
        ----------
        message: Dict
            Incoming message to be processed.
        """
        # self._log.args("%s: (message: %s)" % (self, message))
        if message["type"] == "event":
            self._process_event(message)
        elif message["type"] == "command":
            self._process_command(message)

    def _process_message_outbound(self, message: dict) -> None:
        """Handles outbound messages.



        Updates the sockdispatcher's recipients and dispatches the message,
        then stores the message in the durable store for each recipient.

        Parameters
        ----------
        message: dict
            Message to process

        Raises
        ------
        EndpointException
            Raised either when an item cannot be put into nor retrieved from
            the dispatch queue
        """
        self._log.args("%s: (message: %s)" % (self, message))
        try:
            self._dispatch_queue.put(bson.BSON.encode(message))
        except QueueFullException as e:
            self._log.error(e)
            raise EndpointException(e)
        self._config["producer_config"]["scheduler_config"]["worker_config"][
            "processor_map"]["SD"]["config"]["outbound_socket_config"][
            "destinations"] = self._recipients
        sockdispatcher.SockDispatcher(self._config["sockdispatcher_config"])
        try:
            dispatch_result = self._dispatch_queue.get()
        except QueueEmptyException as e:
            self._log.error(e)
            raise EndpointException(e)
        self._log.info("%s: (dispatch: %s)" % (self, dispatch_result))
        self._dispatch_queue.item_processed()

        if self._durable and "payload" in message:
            for recipient in self._recipients:
                self._store_durable(message, recipient)

    def _process_event(self, message: Dict) -> None:
        """Process event messages.

        General event messages are handled in the implementation of
        baseendpoint, topic event messages are handled here.

        Parameters
        ----------
        message: Dict
            See basemessage class for an example. The specific key required
            for event processing is the "topic" key in the payload's params.

        Raises
        ------
        EndpointException
            Throws an endpoint exception whenever the send queue is full.
        """
        self._log.args("%s: (message: %s)" % (self, message))
        if "payload" in message and "params" in message["payload"]:
            # Topic event message
            topic = message["payload"]["params"]["topic"]
            # Get all subscribers to this topic
            subscribers = self._subscribers[topic]

            # Filter the subscribers by their criteria using recipient list
            filtered_subscribers = self._filter_subscribers(
                message,
                subscribers
            )
            self._recipients = []
            # for sub in subscribers.values():
            for sub_id in filtered_subscribers:
                sub = subscribers[sub_id]
                self._recipients.append((sub["host"], sub["port"]))

            self._log.info("%s: notifying %s" % (self, self._recipients))
            try:
                self._send_queue.put(message)
            except QueueFullException as e:
                self._log.error(e)
                raise EndpointException(e)

    def _process_command(self, message: Dict) -> None:
        """Process command messages.

        Handles subscription management (add, update, remove subscriber).

        Parameters
        ----------
        message: Dict
            See basemessage class for an example. The specific keys required
            for each subscriber operation can be found in the description of
            each method (add_subscriber, update_subscriber, and
            remove_subscriber).
        """
        self._log.args("%s: (message: %s)" % (self, message))
        if message["payload"]["command"] == wmqcode.ADD_SUBSCRIBER:
            rtn = self.add_subscriber(message)
        elif message["payload"]["command"] == wmqcode.UPDATE_SUBSCRIBER:
            rtn = self.update_subscriber(message)
        elif message["payload"]["command"] == wmqcode.REMOVE_SUBSCRIBER:
            rtn = self.remove_subscriber(message)
        self._log.rtn("success | data: %s" % rtn)
        return rtn

    def _filter_subscribers(self, message: Dict, sub_criteria: list) -> list:
        """Uses the recipientlist to filter subscribers to a given topic by
        the subscription criteria.

        Parameters
        ----------
        message: Dict
            Event message containing topic payload.
        sub_criteria:
            Subscription criteria for this topic.

        Returns
        -------
        list of str:
            List of subscriber identifiers which satisfy the topic criteria.

        """
        self._recipientlist_queue.put(message)
        self._config["recipientlist_config"]["subscribers"] = sub_criteria
        recipientlist.RecipientList(self._config["recipientlist_config"])
        try:
            recipientlist_result = self._recipientlist_queue.get()
        except QueueEmptyException as e:
            self._log.error(e)
            raise EndpointException(e)
        self._recipientlist_queue.item_processed()

        if recipientlist_result["status"] == "failure":
            msg = "Unable to process recipientlist: %s" % message
            self._log.error(msg)
            raise EndpointException(msg)

        rtn = recipientlist_result["data"]
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def add_subscriber(self, subscriber: Dict) -> bool:
        """Register a subscriber, if doing so does not exceed max subscribers.

        Parameters
        ----------
        subscriber: Dict
            The message, containing information of the subscriber to add. It
            must at least contains keys for alias, host, port, topics, and
            criteria.

        Example
        -------
        subscriber = {
            "alias": "sub1",
            "host": "106.12.205.32",
            "port": 11001,
            "topics": ["topic1", "topic2"],
            "criteria": {
                "topic1": {
                    "ram": ("gt", 15000000)
                    "cores": ("gt", 2),
                },
                "topic2": {
                    "ram": ("lt", 12000000)
                    "cores": ("gt", 6),
                }
            }
        }

        Returns
        -------
        rtn: bool
            True if the subscriber was registered, false otherwise
        """
        self._log.args("%s: (subscriber: %s)" % (self, subscriber))
        sub_id = self._generate_subscriber_id(subscriber["sender_alias"])
        params = subscriber["payload"]["params"]
        for topic in params["topics"]:
            self._subscribers[topic][sub_id] = {
                "host": params["host"],
                "port": params["port"],
            }
            if "criteria" in params:
                self._subscribers[topic][sub_id].update({
                    "criteria": params["criteria"].get(topic)
                })
        rtn = True
        self._log.rtn("success | data: %s" % rtn)
        return rtn

    def update_subscriber(self, subscriber: Dict) -> bool:
        """Update a subscriber.

        Parameters
        ----------
        subscriber: Dict
            The message, containing information of the subscriber to update.
            It must at least contains keys for alias, host, port, topics, and
            criteria.

        Example
        -------
        subscriber["payload"]["params"] = {
            "alias": "sub1",
            "host": "106.12.205.32",
            "port": 11001,
            "topics": ["topic1", "topic2"],
            "criteria": {
                "topic1": {
                    "ram": ("gt", 15000000)
                    "cores": ("gt", 2),
                },
                "topic2": {
                    "ram": ("lt", 12000000)
                    "cores": ("gt", 6),
                }
            }
        }

        Returns
        -------
        rtn: bool
            True if the subscriber was updated, false otherwise
        """
        self._log.args("%s: (subscriber: %s)" % (self, subscriber))
        sub_id = self._generate_subscriber_id(subscriber["sender_alias"])
        params = subscriber["payload"]["params"]
        for topic in params["topics"]:
            self._subscribers[topic][sub_id].update({
                "host": params["host"],
                "port": params["port"]
            })
            if "criteria" in params:
                self._subscribers[topic][sub_id].update({
                    "criteria": params["criteria"].get(topic)
                })
        rtn = True
        self._log.rtn("success | data: %s" % rtn)
        return rtn

    def remove_subscriber(self, subscriber: Dict) -> bool:
        """Remove a subscriber.

        Parameters
        ----------
        subscriber: Dict
            The message, containing information of the subscriber to remove.
            alias: str
                Subscriber's alias, used to obtain its ID.
            topics: list
                The topics to remove the subscriber from.

        Returns
        -------
        rtn: bool
            True if the subscriber was removed from topics, false otherwise
        """
        self._log.args("%s: (subscriber: %s)" % (self, subscriber))
        sub_id = self._generate_subscriber_id(subscriber["sender_alias"])
        for topic in subscriber["payload"]["params"]["topics"]:
            del self._subscribers[topic][sub_id]
        rtn = True
        self._log.rtn("success | data: %s" % rtn)
        return rtn

    def get_subscribers(self) -> Dict:
        """Return the endpoint's subscribers.

        Returns
        -------
        rtn: Dict
            The endpoint's subscribers
        """
        rtn = self._subscribers
        return rtn

    def _generate_subscriber_id(self, alias: str) -> str:
        """Generate a unique ID based on alias

        Parameters
        ----------
        alias: str
            The alias of the subscriber

        Returns
        -------
        rtn: str
            The hex obtained from hashing the alias
        """
        return hashlib.sha1(str.encode(alias)).hexdigest()

    def close(self) -> bool:
        """Unregisters components from the publisher subscriber channel.

        Returns
        -------
        rtn: bool
            Returns True if successful
        """
        self._log.args("%s: ()" % self)
        self._topics = []
        rtn = super().close()
        return rtn
