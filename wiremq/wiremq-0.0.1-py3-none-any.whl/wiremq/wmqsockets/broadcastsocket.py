# -*- coding: utf-8 -*-
"""Broadcast Socket Class"""

import socket
from typing import Dict
from wiremq.wmqsockets import (
    basesocket,
    outboundsocket
)
from wiremq.extlib.err.socketexception import (
    SocketConnectionRefusedException,
    SocketBrokenPipeException,
    SocketGAIException,
    SocketNotFoundException
)


class BroadcastSocket(basesocket.BaseSocket):
    """Broadcast socket class

    Broadcast socket inherits from the base socket class. Basic functionality
    of base socket is implemented and extended. The broadcast socket sends
    messages to multiple recipients, through the use of one or more outbound
    sockets.

    Attributes
    ----------
    _destinations
    _max_sockets
    _family
    _protocol
    _log: object
        Python logging instance.

    Methods
    -------
    config(): bool
        Configures the socket
    add_dest(): bool
        Adds ip/port pair to destinations attribute.
    remove_dest(): bool
        Removes socket from destinations.
    send(): int
        Sends data to all sockets in the destinations list.
    """

    def __init__(self, config: Dict = None):
        """Broadcast Socket Class Constructor.

        Initializes an broadcast socket. Broadcast socket options are
        required to initialize the socket. They are typically the
        same as those used with a base socket.

        Parameters
        ----------
        config: dict
            Broadcast socket configuration dictionary.
            id : hash
                A unique id using secrets lib with sha256 hashing.
            type : str
                Socket type.
            name : str
                Socket name.
            protocol : str
                Socket protocol. Values are tcp, udp, raw, rdm, seq.
            family : str
                Socket family, Values are unix, inet.
            blocking : bool
                True if socket is in blocking mode, False if in non-blocking.
            buffer_size : int
                Socket buffer size for the number of bytes to send and receive
            context : Dict, optional
                type : str
                    Type of sockets to be wrapped - server or client.
                version : float
                    The TLS version to be applied to the wrapped socket.
                    1.1, 1.2, or 1.3, depending on the lowest version required.
                    For example, "1.2" would allow only connections using
                    TLSv1.2 or higher, excluding any TLSv1 and v1.1 connections.
                peer_cert : bool
                    Flag to specify whether a certicifate is required or not.
                cert: str
                    Path to certificate file.
                key: str
                    Path to key file.
                hostname: str
                    Host name for a wrapped socket.

        Example:
        -------
        >>> config = {}
        >>> config["type"] = "broadcastsocket"
        >>> config["sock_id"] = "6b724f14c9da00cae8ea1da9d4c8c0e5" +
                                "858bee1907e8eddfd1e0aeeef249c40f"
        >>> config["protocol"] = "tcp"
        >>> config["family"] = "inet"
        >>> config["blocking"] = True
        >>> socket = broadcastsocket.BroadcastSocket(config)
        """
        self._destinations = []
        self._max_sockets = None
        self._family = None
        self._protocol = None
        super().__init__(config)

    def config(self, config: Dict) -> bool:
        """Configures the socket

        Parameters
        ----------
        config: Dict
            The configuration of the broadcast socket. See constructor for
            fields.

        Returns
        -------
        rtn: bool
            Returns True if successful
        """
        super().config(config)
        self._log.args("%s: (config: %s)" % (self, str(config)))
        self._destinations = config.get("destinations", [])
        self._max_sockets = config["max_sockets"]
        self._protocol = config["protocol"]
        self._family = config["family"]
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def add_dest(self, destination: Dict) -> bool:
        """Adds ip/port pair to destinations attribute.

        Parameters
        ----------
        destination: Dict
            host: str
                The destination host for the socket.
            port: int
                The destination port for the socket.

        Returns
        -------
        rtn: bool
            Returns True, if successful
        """
        self._log.args("%s: (destination: %s)" % (self, destination))
        self._destinations.append((destination["host"],
                                   destination.get("port")))
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def remove_dest(self, destination: Dict) -> bool:
        """Removes socket from destinations.

        Parameters
        ----------
        destination: Dict
            host: str
                The destination host for the socket to remove.
            port: int
                The destination port for the socket to remove.

        Returns
        -------
        rtn: bool
            Returns True, if successful
        """
        self._log.args("%s: (destination: %s)" % (self, destination))
        self._destinations.remove((destination["host"],
                                   destination.get("port")))
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def update_destinations(self, destinations: list) -> bool:
        """Updates the destinations list with a new list

        Parameters
        ----------
        destinations: list
            A list of tuples, each holding the host and port values of a
            destination.

        Returns
        -------
        rtn: bool
            Returns True, if successful
        """
        self._destinations = destinations
        return True

    def connect(self, host: str, port: int = None) -> bool:
        """Overrides socket connect, as connection is handled elsewhere.

        Parameters
        ----------
        host: str
            Ip address of the socket to connect.
        port: int
            Port address the socket to connect is listening.

        Returns
        -------
        rtn: bool
        """
        return True

    def send(self, data: bytes, host: str = None, port: int = None) -> bool:
        """Sends data to all sockets in the destinations list.

        For TCP connections, the socket must already be connected. For UDP
        connections the destination address must be provided in this method's
        arguments.

        Parameters
        ----------
        data : bytes
            Data to be transmitted via the sockets.

        Returns
        -------
        rtn : bool
            Returns True, if successful.
        """
        self._log.args("%s: (data: %s)" % (self, data))
        if self._protocol == "udp":
            outsock = outboundsocket.OutboundSocket(self._config)
            for dest in self._destinations:
                try:
                    outsock.send(data, dest[0], dest[1])
                except BrokenPipeError as e:
                    self._log.error(e)
                    raise SocketBrokenPipeException(e)
                except socket.gaierror as e:
                    self._log.error(e)
                    raise SocketGAIException(e)
                except FileNotFoundError as e:
                    self._log.error(e)
                    raise SocketNotFoundException(e)
        elif self._protocol == "tcp":
            for dest in self._destinations:
                outsock = outboundsocket.OutboundSocket(self._config)
                try:
                    outsock.connect(dest[0], dest[1])
                except ConnectionRefusedError as e:
                    self._log.error(e)
                    raise SocketConnectionRefusedException(e)

                try:
                    outsock.send(data)
                except BrokenPipeError as e:
                    self._log.error(e)
                    raise SocketBrokenPipeException(e)
                except socket.gaierror as e:
                    self._log.error(e)
                    raise SocketGAIException(e)
                except FileNotFoundError as e:
                    self._log.error(e)
                    raise SocketNotFoundException(e)
                outsock.shutdown()
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def shutdown(self) -> bool:
        """Shuts down the socket, so that it can no longer read or write.

        Returns
        -------
        rtn : bool
            Returns True once the socket has been shut down.
        """
        return True

    def close(self) -> bool:
        """Closes a socket file descriptor."""
        self._destinations = None
        self._max_sockets = None
        self._family = None
        self._protocol = None
        self._config = None
        self._sslcontext = None
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn
