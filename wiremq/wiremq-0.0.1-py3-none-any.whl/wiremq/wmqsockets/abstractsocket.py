# -*- coding: utf-8 -*-
""" abstract socket class """

from typing import (
    Any,
    Dict,
)
from abc import ABC, abstractmethod


class AbstractSocket(ABC):
    """Abstract Socket class"""

    def __init__(self, config: dict = None):
        pass

    @abstractmethod
    def _generate_id(self) -> str:
        pass

    @abstractmethod
    def get_id(self) -> str:
        pass

    @abstractmethod
    def config(self, config: Dict) -> bool:
        pass

    @abstractmethod
    def get_config(self) -> Dict:
        pass

    @abstractmethod
    def set_protocol(self, protocol: str) -> Any:
        pass

    @abstractmethod
    def set_family(self, family: str) -> Any:
        pass

    @abstractmethod
    def create_context(self, config: Dict) -> None:
        pass

    @abstractmethod
    def create_socket(self, config: dict) -> Any:
        pass

    @abstractmethod
    def get_fd(self) -> int:
        pass

    @abstractmethod
    def update_buffer(self, buffer: int) -> bool:
        pass

    @abstractmethod
    def close(self) -> None:
        pass
