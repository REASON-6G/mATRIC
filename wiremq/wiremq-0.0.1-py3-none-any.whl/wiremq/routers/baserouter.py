# -*- coding: utf-8 -*-

""" base routing class """

from typing import Dict
import bson
from wiremq.extlib.err.endpointexceptions import EndpointException
from wiremq.extlib.err.consumerexceptions import BaseConsumerException
from wiremq.extlib.err.processingexception import ThreadedSchedulerException
from wiremq.extlib.err.producerexceptions import BaseProducerException
from wiremq.extlib.err.queueexception import (
    QueueEmptyException,
    QueueFullException
)
from wiremq.filters import sockdispatcher
from wiremq.endpoints import baseendpoint


class BaseRouter(baseendpoint.BaseEndpoint):
    """Base routing class.

    Attributes
    ----------
    _routing_table: Dict
        Table holding mapping data for sender address to destination address.
        Addresses in the routing table are formatted as ip:port,
        e.g. "192.168.0.100:8000".
    _max_routes: int
        Maximum number of routes the router is permitted to hold.

    Methods
    -------
    config(): bool
        Configures the router.
    get_routes(): Dict
        Get the current routing table.
    add_route(): bool
        Adds a route to the routing table.
    remove_route(): bool
        Removes a route from the routing table.
    update_route(): bool
        Updates a route in the routing table.
    _process_message_inbound()
        Handles incoming messages.
    _process_message_outbound()
        Handles outgoing messages
    process(): None
        The router's main loop, overrides baseendpoint's process method.

    """

    def __init__(self, config: Dict = None):
        """Base router constructor.

        Parameters
        -----------
        config : dict
            routing_table: Dict
                Routing table, maps sender to destination address.
            max_routes: int (optional)
                Maximum number of routes the router is permitted to hold. 0 or
                None for unlimited routes.
            for other config attributes, see documentation for baseendpoint.


        Example
        -------
        >>> config = {
        ...     "type" : "baserouter",
        ...     "alias": "Base Router",
        ...     "name": "VNF Router",
        ...     "max_routes": 0,
        ...     "routing_table": {
        ...       "192.168.10.133:5555": "192.168.10.150:8000",
        ...       "192.168.10.100:4545": "192.168.10.150:8000",
        ...     }
        >>> }
        >>> routing = baserouter.BaseRouter(router_config)
        """
        self._routing_table = {}
        self._max_routes = None
        super().__init__(config)

    def config(self, config: Dict) -> bool:
        """Configures the router.

        Parameters
        -----------
        config : Dict

        Example
        -------
        >>> config = {
        ...     "type" : "baserouter",
        ...     "alias": "Base Router",
        ...     "name": "VNF Router",
        ...     "uid": "0868bc20384ad8cbf15b03350ce5671"
        >>> }
        >>> router.config_router(config)
        """
        super().config(config)
        self._routing_table = config["routing_table"]
        self._max_routes = config.get("max_routes", 0)
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def get_routes(self) -> Dict:
        """Get the current routing table.

        Returns
        -------
        rtn: Dict
            Routing table
                Routing table, maps sender to destination address.
        """
        self._log.args("%s: ()" % self)
        rtn = self._routing_table
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def add_route(
            self,
            sender_ip: str,
            sender_port: int,
            dest_ip: str,
            dest_port: int) -> bool:
        """Adds a route to the routing table.

        Parameters
        ----------
        sender_ip: str
            The hostname of the sender endpoint.
        sender_port: int
            The port number of the sender endpoint.
        dest_ip: str
            The host name of the destination endpoint.
        dest_port: int
            The port number of the destination endpoint.

        Returns
        -------
        rtn: bool
            True if successful.
        """
        self._log.args("%s: (sender_ip: %s, sender_port: %s, dest_ip: %s, "
                       "dest_port: %s)" % (self, sender_ip, sender_port,
                                           dest_ip, dest_port))
        sender_address = ":".join([sender_ip, str(sender_port)])
        dest_address = ":".join([dest_ip, str(dest_port)])
        if len(self._routing_table) < self._max_routes:
            self._routing_table[sender_address] = dest_address
            msg = "success"
            rtn = True
        else:
            rtn = False
            msg = "failed to add route, routing table full"

        self._log.rtn("%s: %s | data: %s" % (self, msg, rtn))
        return rtn

    def remove_route(self, sender_ip: str, sender_port: int) -> bool:
        """Removes a route from the routing table.

        Parameters
        ----------
        sender_ip: str
            The hostname of the sender endpoint.
        sender_port: int
            The port number of the sender endpoint.

        Returns
        -------
        rtn: bool
            True if successful.

        """
        self._log.args("%s: (sender_ip: %s, sender_port: %s)" %
                       (self, sender_ip, sender_port))
        sender_address = ":".join([sender_ip, str(sender_port)])
        try:
            del self._routing_table[sender_address]
        except KeyError as e:
            self._log.error(e)
            raise EndpointException(e)
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def update_route(
            self,
            sender_ip: str,
            sender_port: int,
            dest_ip: str,
            dest_port: int) -> bool:
        """Updates a route in the routing table.

        Parameters
        ----------
        sender_ip: str
            The hostname of the sender endpoint.
        sender_port: int
            The port number of the sender endpoint.
        dest_ip: str
            The host name of the destination endpoint.
        dest_port: int
            The port number of the destination endpoint.

        Returns
        -------
        rtn: bool
            True if successful.
        """
        self._log.args("%s: (sender_ip: %s, sender_port: %s, dest_ip: %s, "
                       "dest_port: %s)" % (self, sender_ip, sender_port,
                                           dest_ip, dest_port))
        sender_address = ":".join([sender_ip, str(sender_port)])
        dest_address = ":".join([dest_ip, str(dest_port)])
        try:
            self._routing_table[sender_address] = dest_address
        except KeyError as e:
            err = f"Route does not exist ({e})"
            self._log.error(err)
            raise err
        rtn = True
        self._log.rtn("%s: success | data: %s" % (self, rtn))
        return rtn

    def _process_message_inbound(self, message: Dict) -> None:
        """Endpoint-specific logic for handling incoming messages.

        Called by baseendpoint's _handle_inbound method. Checks a message's
        sender address and routes it to its corresponding destination address
        from the routing table, if available.

        Messages are placed directly into the send queue after routing logic is
        applied.

        Acknowledgements and online messages are discarded here.

        Parameters
        ----------
        message: Dict
            Message to be routed using its sender_ip and sender_port
        """
        self._log.args("%s: (message: %s)" % (self, message))

        # Do not route acknowledgements
        if "payload" not in message:
            return
        # Do not route online messages
        if "payload" in message and "state" in message["payload"]:
            return

        try:
            sender_ip = message["sender_ip"]
            sender_port = message["sender_port"]
        except KeyError:
            e = "Message does not container sender_ip or sender_port"
            raise EndpointException(e)
        sender_address = ":".join([sender_ip, str(sender_port)])
        try:
            dest_address = self._routing_table[sender_address].split(":")
        except KeyError:
            e = f"Sender {sender_ip}:{sender_port} not found in routing table"
            self._log.error(e)
            raise EndpointException(e)
        message["dest_ip"] = dest_address[0]
        message["dest_port"] = int(dest_address[1])
        try:
            self._send_queue.put(message)
        except QueueFullException as e:
            self._log.error(e)
            raise EndpointException(e)

    def _process_message_outbound(self, message: dict) -> None:
        """Handles outbound messages.

        Called by baseendpoint's _handle_outbound method, this method takes a
        message, dispatches it, and places it in the durable store.

        Parameters
        ----------
        message: dict
            Message to process.

        Raises
        ------
        EndpointException:
            Raised when an item cannot be retrieved from the dispatch queue.
        """
        self._dispatch_queue.put(bson.BSON.encode(message))
        sockdispatcher.SockDispatcher(self._config["sockdispatcher_config"])
        try:
            dispatch_result = self._dispatch_queue.get()
            self._dispatch_queue.item_processed()
        except QueueEmptyException as e:
            self._log.error(e)
            raise EndpointException(e)
        self._log.info("%s: (dispatch: %s)" % (self, dispatch_result))

        if self._durable and "payload" in message:
            self._store_durable(
                message,
                (message["dest_ip"], message["dest_port"])
            )

    def process(self) -> None:
        """The router's main loop, overrides baseendpoint's process method.

        This method is invoked by the router's run method, which operates as
        the threaded channel's main loop.

        Handles message consumption, receiving of inbound messages via the
        poller, sending of outbound messages to the producer, and message
        production.

        Raises
        ------
        EndpointException
            Throws an exception whenever the io loops fail to handle a task.
        """
        try:
            self._eventloop.run_once()
            self.consume("consumer")
            self._handle_outbound()
            self._handle_inbound()
            self.produce("producer")
        except (BaseProducerException, BaseConsumerException) as e:
            self._log.error(e)
            raise EndpointException(e)
        except ThreadedSchedulerException as e:
            self._log.error(e)
            raise EndpointException(e)
